--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: sulci_descriptor; Type: TABLE; Schema: public; Owner: ybon; Tablespace: 
--

CREATE TABLE sulci_descriptor (
    id integer NOT NULL,
    parent_id integer,
    name character varying(200) NOT NULL,
    description text
);


ALTER TABLE public.sulci_descriptor OWNER TO ybon;

--
-- Name: sulci_descriptor_id_seq; Type: SEQUENCE; Schema: public; Owner: ybon
--

CREATE SEQUENCE sulci_descriptor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sulci_descriptor_id_seq OWNER TO ybon;

--
-- Name: sulci_descriptor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ybon
--

ALTER SEQUENCE sulci_descriptor_id_seq OWNED BY sulci_descriptor.id;


--
-- Name: sulci_descriptor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ybon
--

SELECT pg_catalog.setval('sulci_descriptor_id_seq', 24126, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ybon
--

ALTER TABLE sulci_descriptor ALTER COLUMN id SET DEFAULT nextval('sulci_descriptor_id_seq'::regclass);


--
-- Data for Name: sulci_descriptor; Type: TABLE DATA; Schema: public; Owner: ybon
--

COPY sulci_descriptor (id, parent_id, name, description) FROM stdin;
1	\N	ZZZZ_Questions financières	
2	1	Bourse	ne s'emploie que pour les transactions sur les valeurs, les marchandises ou les services
3	2	Fonds commun de placement	
4	2	Sicav	
5	2	ZZZZ_place boursière	
6	5	Bourse de Paris	
7	5	Euronext	
8	5	Wall Street	
9	2	actionnaire	
10	9	actionnaire minoritaire	
11	10	Association de défense des actionnaires minoritaires	
12	9	actionnariat salarié	
13	9	groupe d'actionnaires stables	
14	2	agence de notation	
15	2	capitalisation boursière	
16	2	krach boursier	
17	2	marché boursier	
18	17	Nasdaq	
19	17	Nouveau Marché	
20	17	marché hors cote	
21	17	marché à terme	
22	21	Matif	
23	17	second marché	
24	2	marché obligataire	
25	2	opération boursière	
26	25	OPA	
27	25	OPE	
28	25	OPR	
29	25	OPV	
30	25	cotation	
31	25	indice boursier	
32	31	CAC 40	
33	31	Dow Jones	
34	31	Nikkei	
35	25	introduction en bourse	
36	2	tutelle des marchés	
37	36	Autorité des marchés financiers	
38	36	COB	
39	36	Conseil des marchés financiers	
40	36	SEC	
41	36	Société des Bourses françaises	
42	2	valeur mobilière	
43	42	action boursière	
44	42	placement obligataire	
45	42	stock-option	
46	1	ZZZZ_finances extèrieures	
47	46	balance des paiements	
48	46	emprunt international	
49	1	banque	
50	49	Association française des banques	
51	49	Cecei	
52	49	banque centrale	
53	52	Banque de France	
54	52	Bundesbank	
55	52	Réserve fédérale américaine	
56	49	banque commerciale	
57	49	banque d'affaires	
58	49	moyen de paiement	
59	58	billet de banque	
60	58	carte bancaire	
61	58	carte de crédit	
62	58	carte de paiement	
63	58	chèque bancaire	
64	63	chèque sans provision	
65	58	chèque de voyage	
66	58	monnaie électronique	
67	58	pièce de monnaie	
68	49	secret bancaire	
69	49	service bancaire	
70	69	banque à domicile	
71	69	compte bancaire	
72	69	découvert bancaire	
73	69	interdit bancaire	
74	69	virement bancaire	
75	49	services financiers	
76	49	établissement financier	
77	1	crédit	
78	77	créance douteuse	
79	77	crédit bancaire	
80	77	crédit immobilier	
81	80	prêt d'accès à la propriété	
82	80	prêt locatif aidé	
83	80	prêt locatif intermédiaire	
84	77	crédit à la consommation	
85	84	Cetelem	
86	84	crédit revolving	
87	77	emprunt	
88	77	endettement	
89	88	endettement des ménages	
90	77	location-vente	
91	77	microcrédit	
92	77	prêt bonifié	
93	77	recouvrement de créance	
94	77	établissement de crédit	
95	94	Crédit municipal	
96	1	finances mondiales	
97	96	Banque mondiale	
98	97	Association internationale pour le développement	
99	96	Club de Paris	
100	96	système monétaire international	
101	100	FMI	
102	1	finances publiques	
103	102	Inspection des finances	
104	102	budget de l'Etat	
105	104	budget rectificatif	
106	104	dette publique	
107	106	emprunt d'Etat	
108	107	Obligation assimilable du Trésor	
109	107	bon du Trésor	
110	104	déficit budgétaire	
111	104	dépense budgétaire	
112	104	politique budgétaire	
113	112	Trésor public	Ensemble des moyens financiers dont dispose un Etat. Service financier d'exécution du budget, assurant la corrélation des dépenses et des recettes publiques.
114	112	économie budgétaire	
115	104	recette budgétaire	
116	102	finances locales	
117	116	Société de développement régional	
118	116	budget départemental	
119	116	budget municipal	
120	116	budget régional	
121	116	dotation globale de fonctionnement	subvention des collectivités locales données par le gouvernement
122	102	fonds de solidarité	
123	1	fiscalité	
124	123	Syndicat national unifié des impôts	
125	123	contribuable	
126	125	Association de défense des contribuables parisiens	
127	123	contrôle fiscal	
128	123	droits de mutation	
129	123	droits de succession	
130	123	déduction fiscale	
131	130	quotient familial	
19095	\N	NT1	\N
132	123	exonération fiscale	
133	132	zone franche	
134	123	fiscalité locale	
135	134	taxe d'habitation	
136	134	taxe foncière	
137	134	taxe professionnelle	
138	134	vignette automobile	
139	123	fraude fiscale	
140	123	impôt sur la fortune	
141	123	impôt sur le revenu	
142	123	impôt sur les sociétés	
143	123	politique fiscale	
144	143	allègement fiscal	
145	143	assiette fiscale	
146	143	fiscalisation	
147	123	taxe	
148	147	TVA	
149	147	redevance	
150	147	taxe intérieure sur les produits pétroliers	
151	147	écotaxe	
152	1	marché financier	
153	152	crise financière	
154	152	fluctuation monétaire	
155	154	contrôle des changes	
156	154	convertibilité	
157	154	dévaluation	
158	154	marché des changes	
159	154	réévaluation	
160	154	taux de change	
161	152	marché monétaire	
162	161	masse monétaire	
163	161	mouvement de capitaux	
164	163	fuite de capitaux	
165	161	réserve monétaire	
166	161	taux d'escompte	
167	152	monnaie	
168	167	Deutsche Mark	
169	167	dollar	
170	167	franc (monnaie)	
171	170	zone franc	
172	167	lire (monnaie)	
173	167	livre sterling	
174	167	peseta	
175	167	rouble	
176	167	yen	
177	152	politique monétaire	
178	177	Conseil de politique monétaire	
179	152	spéculation financière	
180	152	taux d'intérêt	
181	180	taux de base bancaire	
182	1	épargne	
183	182	Caisse d'épargne	
184	182	placement financier	
185	182	produit d'épargne	
186	185	Codevi	
187	185	livret A	
188	185	livret d'épargne	
189	185	plan d'épargne populaire	
190	185	plan épargne en actions	
191	182	épargne logement	
192	182	épargne retraite	
193	192	Association française d'épargne et de retraite	
194	\N	ZZZZ_Mots outils	Ne pas utiliser. Employer un terme plus précis.
195	194	ZZZZ_Fonctionnement des organisations	Ne pas employer. Utiliser un terme plus précis.
196	195	assemblée générale	
197	195	calendrier	
198	195	coalition	
199	195	comité	
200	199	comité de défense	
201	199	comité de soutien	
202	199	comité national	
203	195	commission (organisme)	
204	203	commission d'enquête	
205	203	commission de contrôle	
206	203	commission de recours	
207	195	composition	
208	195	conférence	
209	195	congrès (réunion)	
210	195	conseil national	
211	195	célébrité	
212	195	cérémonie	
213	195	direction	
214	213	dirigeant	
215	195	directive	
216	195	débat	
217	195	démission	
218	195	déplacement (voyage)	
219	195	dérogation	
220	195	effectif	
221	195	entourage	
222	195	exclusion (éviction)	
223	195	fonctionnement	
224	195	fédération	
225	195	inauguration	
226	195	invitation	
227	195	jury (sauf justice)	
228	195	mandat	
229	195	mission	
230	195	neutralité	
231	195	nomination	
232	195	négociation	
233	195	organigramme	
234	195	organisation	
235	195	organisme	
236	235	institut	
237	235	observatoire	
238	195	programmation	
239	195	proposition	
240	195	protestation	
241	195	présidence	
242	241	vice-président	
243	195	radiation (élimination)	
244	195	rapport	
245	195	rassemblement	
246	195	représentativité	
247	195	réconciliation	
248	195	réunion	
249	195	révocation	
250	195	secrétariat	
251	250	secrétariat général	
252	250	secrétariat national	
253	195	veto	
254	195	voisinage	
255	195	élargissement	
256	195	états généraux	
257	194	ZZZZ_Mots outils classiques	Ne pas utiliser. Employer un terme plus précis.
258	257	abandon	
259	257	abattage	
260	257	accessoire	
261	257	accord	
262	257	adhésion	
263	257	adoption (procédure)	
264	257	adresse	
265	257	agrément	
266	257	aide	
267	257	ajournement	
268	257	alerte	
269	257	alliance	
270	257	aménagement	
271	257	analyse	
272	257	annulation	
273	257	anomalie	
274	257	appel (sollicitation)	
21067	\N	RG	\N
275	257	application	
276	257	arrêt	
277	257	attribution	
278	257	audience	
279	257	audition	
280	257	augmentation	
281	257	autonomie	
282	257	autorisation	
283	257	avertissement	
284	257	baisse	
285	257	bilan	
286	257	biographie	
287	257	blocage	
288	257	boycottage	
289	257	budget	
290	257	certificat	
291	257	choix	
292	257	chronologie	
293	257	chute	
294	257	clandestinité	
295	257	classement	
296	257	collecte	
297	257	commande	
298	257	comparatif	
299	257	compte	
300	257	concours	
301	257	confiance	
302	257	confrontation	
303	257	construction	
304	257	conséquence	
305	257	contrat	
306	257	contrôle	
307	257	coopération (collaboration)	
308	257	coût	
309	257	crise	
310	257	critique	
311	257	critère	
312	257	création	
313	257	culpabilité	
314	257	destruction	
315	257	disparition	
316	257	dissidence	
317	257	division	
318	257	don	
319	257	découverte	
320	257	défaite	
321	257	déficit	
322	257	dégradation	
323	257	délai	
324	257	démenti	
325	257	dénomination	
326	325	homonymie	
327	257	départ	
328	257	désaccord	
329	257	enquête	
330	257	entraînement	
331	257	erreur (faute)	
332	257	expertise	
333	257	expulsion	
334	257	extension	
335	257	extrait	
336	257	facturation	
337	257	falsification	
338	257	fermeture	
339	257	fiche technique	
340	257	fiction	
341	257	fonds secrets	
342	257	fouille	
343	257	fréquentation	
344	257	fuite	
345	257	gestion	
346	257	guidage	
347	257	hypothèse	
348	257	indépendance	
349	257	interdiction	
350	257	isolement	
351	257	itinéraire	
352	257	journée d'action	
353	257	lancement	
354	257	liste	
355	257	lutte (action contre)	
356	257	manifestation	
357	257	menace	
358	257	mesure	
359	257	mobilisation	
360	257	modernisation	
361	257	modification	
362	257	modèle	
363	257	méthode	
364	257	nouveauté	
365	257	nouvelle formule	
366	257	nécrologie	
367	257	ouverture	
368	257	paiement	
369	257	palmarès	
370	257	panne	
371	257	partage	
372	257	perte	
373	257	perturbation	
374	257	polémique	
375	257	preuve	
376	257	projet	
377	257	prolifération	
378	257	provocation	
379	257	préparation	
380	257	pénurie	
381	257	qualité	
382	257	quota	
383	257	rapatriement	
384	257	ratification	
385	257	recensement	
386	257	recherche (hors sciences)	
387	257	reconstitution	
388	257	reconstruction	
389	257	record (hors sport)	
390	257	rectificatif	
391	257	refus	
392	257	regroupement	
393	257	rejet	
394	257	remboursement	
395	257	rencontre	
396	257	rentrée	
397	257	responsabilité	
398	257	restitution	
399	257	restriction	
400	257	retard	
401	257	retour	
402	257	retrait	
403	257	revalorisation	
404	257	revendication	
405	257	risque	
406	257	rupture	
407	257	réaction	
408	257	récit	
409	257	réforme	
410	257	régularisation	
411	257	réintégration	
412	257	rénovation	
413	257	réparation (remise en état)	
414	257	répartition	
415	257	réquisition	
416	257	résistance (endurance)	
417	257	résolution	
418	257	résultat	
419	257	rétrocession	
420	257	rétrospective	
421	257	révision	
422	257	rééchelonnement	
423	257	saisie	
424	257	scandale	
425	257	signature	
426	425	signature électronique	
427	257	solidarité (aide)	
428	257	sommet	
429	257	soutien	
430	257	statistique	
431	257	statut	
432	257	succession (suite)	
433	257	succès	
434	257	supporter	
435	257	surveillance	
436	257	suspect	
437	257	suspension	
438	257	sécurité	
439	257	sélection	
440	257	séparation	
441	257	test	
442	257	transfert	
443	257	transparence	
444	257	trésor	
445	257	témoignage	
446	257	unification	
447	257	université d'été	
448	257	urgence (sans délai)	
449	257	victoire	
450	257	violation	
451	257	voeux	
452	257	échange	
453	257	échec (insuccès)	
454	257	étude	
455	257	évacuation	
456	257	évaluation	
457	\N	Civilisation	
458	457	ZZZZ_grande civilisation	
459	458	Antiquité (civilisation)	
460	458	civilisation celtique	
461	458	civilisation gallo-romaine	
462	458	civilisation pré-colombienne	Née au Pérou au XVe siècle
463	457	datation	
464	463	ZZZZ_Année	
465	464	1910	
466	464	2000	
467	464	2001	
468	464	2002	
469	464	2003	
470	464	2004	
471	464	2005	
472	464	2006	
473	464	2007	
474	464	2008	
475	464	2009	
476	464	2010	
477	464	2012	
478	464	2016	
479	464	2020	
480	464	années cinquante	
481	464	années quarante	
482	481	1945	
483	464	années quatre-vingt	
484	483	1981	
485	483	1982	
486	483	1983	
487	483	1984	
488	483	1985	
489	483	1986	
490	483	1987	
491	483	1988	
492	483	1989	
493	464	années quatre-vingt-dix	
494	493	1990	
495	493	1991	
496	493	1992	
497	493	1993	
498	493	1994	
499	493	1995	
500	493	1996	
501	493	1997	
502	493	1998	
503	493	1999	
504	464	années soixante	
505	504	1968	
506	464	années soixante-dix	
507	464	années trente	
508	507	1936	
509	463	ZZZZ_jour	
510	509	dimanche	attention! pour le TRAVAIL du DIMANCHE, voir à Travail dominical
511	509	jour férié	
512	509	samedi	
513	463	ZZZZ_mois	
514	513	août	
515	513	avril	
516	513	décembre	
517	513	février	
518	513	janvier	
519	513	juillet	
520	513	juin	
521	513	mai	
522	513	mars (mois)	
523	513	novembre	
524	513	octobre	
525	513	septembre	
526	463	ZZZZ_siècle	
527	526	XIXe siècle	
528	526	XVIIIe siècle	
529	526	XVIIe siècle	
530	526	XVIe siècle	
531	526	XXIe siècle	
532	526	XXe siècle	
533	463	nuit	
534	457	histoire	
535	534	Front populaire	
536	534	Moyen-Age	
537	536	Clovis	
538	536	Jeanne d'Arc	
539	534	Première guerre mondiale	
540	534	Renaissance	
541	534	Révolution française	
542	534	Seconde guerre mondiale	
543	542	Libération (1944)	
544	542	Occupation (1940-1944)	
545	542	rafle du Vel d'Hiv	
546	542	régime de Vichy	
547	534	Troisième Reich	
548	534	mythe	
549	548	monstre	
550	548	vampire	
551	457	préhistoire	
552	\N	Logement	
553	552	ZZZZ_marché du logement	
554	553	Haut comité au logement	
555	553	charges immobilières	
556	553	location immobilière	
557	556	bail locatif	
558	556	loi de 1948	
559	556	loyer	
560	553	logement ancien	
561	553	logement insalubre	
562	553	logement neuf	
563	553	logement vacant	
564	553	propriété immobilière	
565	564	accession à la propriété	
566	564	copropriété	
567	564	résidence principale	
568	564	résidence secondaire	
569	564	syndic de copropriété	
570	552	habitat	
571	570	appartement	
572	570	chambre de bonne	
573	570	hôtel particulier	
574	570	immeuble	
575	570	logement meublé	
576	570	maison individuelle	
577	570	résidence officielle	
578	552	marché immobilier	
579	578	agence immobilière	
580	579	FNAIM	
581	578	immobilier de bureau	
582	581	bureau transformé en logement	
583	578	immobilier de loisir	
584	578	marchand de biens	
585	578	parc immobilier	
586	585	parc immobilier privé	
587	578	promoteur immobilier	
588	578	spéculation immobilière	
589	552	politique du logement	
590	589	Direction de la construction et du logement	
591	589	OPAC	
592	589	aide au logement	
593	592	Aide Personnalisée au Logement	
594	589	aide à la construction	
595	589	amélioration de l'habitat	
596	589	logement social	
597	596	HLM	
598	596	Office HLM	
599	596	Régie immobilière de la Ville de Paris	
600	596	Société anonyme de gestion immobilière	
601	596	logement intermédiaire	
602	589	mal-logé	
603	602	Comité des sans-logis	
604	602	Droit au logement	
605	602	droit opposable au logement	
606	602	relogement	
607	602	sans-domicile-fixe	
608	602	squat	
609	\N	Géographie	
610	609	ZZZZ_région naturelle	
611	610	Amazonie	
612	610	Laponie	
613	610	Pôle Nord	
614	610	Pôle Sud	
615	609	banquise	
616	609	cartographie	
617	609	désert	
618	617	Sahara	
619	609	fleuve	
620	619	Danube	
621	619	Nil	
622	619	Rhin	
623	619	Seine	
624	619	Yang-Tsé	
625	609	glacier	
626	609	grotte	
627	609	lac	
628	609	littoral	
629	628	Conservatoire du littoral	
630	628	plage	
631	609	mer	
632	631	IFREMER	
633	631	La Manche (mer)	
634	631	Mer Baltique	
635	631	Mer Caspienne	
636	631	Mer Egée	
637	631	Mer Morte	
638	631	Mer Noire	
639	631	Mer des Caraïbes	
640	631	Mer du Nord	
641	631	Méditerranée	
642	631	Océan Antarctique	
643	631	Océan Atlantique	
644	631	Océan Indien	
645	631	Océan Pacifique	
646	631	fonds marins	
647	609	monde	
648	609	montagne	
649	648	Alpes	
650	649	Mont-Blanc	
651	648	Himalaya	
652	648	Massif central	
653	652	Beaujolais	
654	648	Mercantour	
655	648	Pyrénées	
656	609	nord (pt cardinal)	
657	609	sud (pt cardinal)	
658	609	volcan	
659	609	île	
660	\N	Faits divers	
661	660	accident (sinistre)	
662	661	accident aérien	
663	661	accident de circulation	
664	661	accident de montagne	
665	661	accident de navigation	
666	665	naufrage	
667	666	renflouage	
668	666	épave	
669	661	accident domestique	
670	661	accident ferroviaire	
671	661	accident nucléaire	
672	661	accident sportif	reservé aux sportifs professionnels, dans l'exercice de leurs disciplines sportives.
673	661	asphyxie	
674	661	blessure	
675	661	explosion	
676	675	explosif	
677	661	incendie	
678	677	brûlure	
679	661	incident	
680	661	noyade	
681	660	infraction	
682	681	affaire de moeurs	
683	681	affaire politico-financière	
684	683	affaire OM-VA	
685	683	affaire Whitewater	nom d'un projet immobilier auquel les Clinton étaient associés dans l'Arkansas
686	681	agression	
687	681	assassinat	
688	687	enfant meurtrier	
689	687	homicide involontaire	
690	687	infanticide	
691	690	affaire Villemin	
692	687	parricide	
693	687	tueur en série	
694	687	tueur à gage	
695	681	attentat	
696	695	colis piégé	
697	695	véhicule piégé	
698	681	autodéfense	
699	681	bagarre	
700	681	banqueroute	
701	681	braconnage	
702	681	chantage	
703	681	complicité	
704	681	contrebande	
705	681	contrefaçon	
706	705	plagiat	
707	681	criminalité	
708	707	grand banditisme	
709	707	mafia	
710	681	diffamation	
711	681	délation	
712	681	délinquance	
713	712	délinquance informatique	
714	712	délinquance juvénile	
715	712	délinquance sexuelle	
716	715	harcèlement sexuel	
717	715	inceste	
718	715	pédophilie	
719	715	viol	
720	712	délinquance économique	
721	712	gang	
722	681	délit	
723	722	abus de bien social	
724	722	abus de confiance	
725	722	abus de faiblesse	
726	722	abus de pouvoir	
727	722	concussion	
728	722	corruption	
729	728	lutte anticorruption	
730	729	Service central de prévention de la corruption	
731	722	délit d'ingérence	
732	722	délit d'initié	
733	722	délit non intentionnel	
734	722	escroquerie	
735	734	détournement de fonds	
736	734	fausse facture	
737	734	fausse monnaie	
738	734	faux (oeuvre d'art)	
739	734	faux en écriture	
740	734	faux et usage de faux	
741	734	faux papier d'identité	
742	734	rançon	
743	734	vente pyramidale	
744	722	piratage	
745	744	pirate de la route	
746	722	trafic d'influence	
747	681	emploi fictif	
748	681	empoisonnement	
749	681	enlèvement	
750	681	excès de vitesse	
751	681	forcené	
752	681	fraude	
753	681	fusillade	
754	681	illégalité	
755	681	incendie criminel	
756	681	lettre anonyme	
757	681	mise en danger d'autrui	
758	681	non-assistance à personne en danger	
759	681	outrage à autorité publique	
760	681	pornographie	
761	681	profanation	
762	681	prostitution	
763	762	proxénétisme	
764	681	racket	
765	681	recel	
766	681	récidive	
767	681	sabotage	
768	681	séquestration	
769	681	trafic frauduleux	
770	769	blanchiment d'argent	
771	769	trafic d'organe	
772	681	vandalisme	
773	772	tag	
774	681	violence	
775	774	violence urbaine	
776	774	violence à agent	
777	681	vol (cambriolage)	
778	777	pickpocket	
779	777	pillage	
780	777	vol à main armée	
781	660	ordre public	
782	781	CRS	
783	781	Préfecture de Police	
784	783	préfet de police	
785	781	ZZZZ_police privée	
786	785	détective privé	
787	785	milice	
788	785	vigile	
789	781	contrat local de sécurité	
790	781	gendarmerie	
791	790	GIGN	
792	790	garde républicaine	
793	781	police	
794	793	administration policière	
795	794	DICCILEC	
796	794	Direction départementale de la sécurité publique	
797	794	Europol	
798	794	FBI	
799	794	GIPN	
800	794	Inspection générale de la Police nationale	
801	800	IGS	
802	794	Interpol	
803	794	OCRTEH	
804	794	OCRTIS	
805	794	RAID (unité de police)	
806	794	Renseignements généraux	
807	794	brigade anticriminalité	
808	794	brigade criminelle	
809	794	brigade de recherche et d'intervention	
810	794	brigade de répression du banditisme	
811	794	brigade de répression du proxénétisme	
812	794	brigade des mineurs	
813	794	brigade des stupéfiants	
814	794	commissariat de police	
815	794	police judiciaire	
816	794	service des courses et des jeux	
817	793	méthode policière	
818	817	contrôle policier	
819	817	indice policier	
820	817	informateur	
821	817	perquisition	
822	817	police de proximité	
823	822	ilôtage	
824	817	portrait-robot	
825	817	violence policière	
826	781	police municipale	
827	781	policier	
828	827	Centrale unitaire de la police	
829	827	FASP	
830	827	commissaire de police	
831	827	inspecteur de police	
832	827	syndicat général de la police	
833	781	politique de la police	
834	781	protection des mineurs	
835	781	répression	
836	835	arrestation	
837	835	châtiment corporel	
838	835	détention provisoire	
839	835	garde à vue	
840	781	service d'ordre	
841	781	sécurité civile	
842	841	pompier	
843	841	secours	
844	843	plan Orsec	
845	781	terrorisme	
846	845	Action directe	
847	845	lutte antiterrorisme	
848	845	otage	
849	845	piraterie aérienne	
850	845	piraterie maritime	
851	\N	Sport	
852	851	activité sportive	
853	852	club sportif	
854	852	course d'endurance	
855	852	espoir sportif	
856	852	médecine sportive	
857	856	dopage	
858	857	Agence mondiale antidopage	
859	852	politique sportive	
860	852	profession sportive	
861	860	arbitre	
862	860	entraîneur	
863	860	gardien de but	
864	852	record sportif	
865	864	record d'Europe	
866	864	record de France	
867	864	record du monde	
868	852	éducation physique et sportive	
869	852	équipe sportive	
870	869	équipe de France	
871	851	compétition sportive	
872	871	24 Heures du Mans	
873	871	Bol d'or	
874	871	Coupe des nations	
875	871	Grand Prix (sport)	
876	871	Jeux méditerranéens	
877	871	Rallye Dakar	
878	871	Tour de France	
879	871	US open	
880	871	championnat	
881	880	championnat d'Europe	
882	880	championnat de France	
883	880	championnat du monde	
884	871	compétition en salle	
885	871	coupe nationale	
886	885	Coupe d'Europe	
887	885	Coupe de France	
888	885	Coupe du monde	
889	871	course	
890	889	course sur route	
891	871	croisière	
892	871	derby	rencontre qui oppose deux équipes sportives d'une même ville ou de deux villes voisines
893	871	finale	
894	893	demi-finale	
895	893	huitième de finale	
896	893	quart de finale	
897	871	jeux olympiques	
898	871	master (sport)	
899	871	match	
900	899	match amical	
901	871	play-off	
902	871	qualification sportive	
903	902	disqualification	
904	871	rallye (sport)	
905	871	régate	
906	871	tour du monde	
907	871	tournoi	
908	871	traversée (sport)	
909	871	éliminatoire	
910	851	discipline sportive	
911	910	alpinisme	
912	910	arts martiaux	
913	912	judo	
914	912	karaté	
915	912	sumo	
916	910	athlétisme	
917	916	course de demi fond	
918	916	course de fond	
919	916	course de haies	
920	916	course de relais	
921	916	cross-country	
922	916	décathlon	
923	916	heptathlon	
924	916	lancer sportif	
925	924	lancer du disque	
926	924	lancer du javelot	
927	924	lancer du marteau	
928	924	lancer du poids	
929	916	marathon	
930	916	marche athlétique	
931	916	saut	
932	931	saut en hauteur	
933	931	saut en longueur	
934	931	saut à la perche	
935	931	triple saut	
936	916	sprint (sport)	
937	910	badminton	
938	910	base-ball	
939	910	basketball	
940	939	NBA	
941	910	billard (jeu)	
942	910	boxe	
943	910	char à voile	
944	910	course d'orientation	
945	910	cricket	
946	910	culturisme	
947	910	cyclisme	
948	947	Paris-Nice	
949	947	Paris-Roubaix	course cycliste
950	947	cyclo-cross	
951	947	tour cycliste	
952	910	escalade	
953	910	escrime	
954	910	football	
955	954	Copa America	
956	954	Coupe Intertoto	
957	954	Coupe UEFA	
958	954	Coupe d'Afrique des Nations	
959	954	Coupe de la ligue	
960	954	Coupe des coupes	
961	954	FIFA	
962	954	Ligue 1	
963	954	Ligue 2	
964	954	Ligue des champions	
965	954	Olympique de Marseille	
966	954	Paris-Saint-Germain	
967	954	Red Star	Club de foot
968	954	Superligue	
969	954	football américain	
970	910	golf	
971	910	gymnastique	
972	910	gymnastique rythmique et sportive	
973	910	haltérophilie	
974	910	handball	
975	910	hippisme	
976	910	hockey	
977	910	jeu de boules	
978	910	motocyclisme	
979	978	motocross	
980	910	omnisport	
981	910	pentathlon	
982	910	rugby	
983	982	All Blacks	équipe de rugby
984	982	Coupe latine	
985	982	Paris Université Club	
986	982	Stade Français	
987	982	Super 12	
988	982	Top 14	
989	982	rugby à XIII	
990	982	springboks	
991	982	tournoi des Six nations	Le tournoi des Cinq nations (Angleterre, Ecosse, Pays de Galles, République d'Irlande, France) devient tournoi des Six nations en 2000, après avoir intégré l'Italie.
992	910	sport automobile	
993	992	Formule 1	
994	992	IndyCar	
995	992	karting	
996	992	écurie automobile	
997	996	BAR (écurie automobile)	
998	996	Jordan Peugeot	
999	996	McLaren (Formule 1)	
1000	996	Stewart Grand Prix	
1001	996	Tyrrell	écurie de F1
1002	996	Williams (F1)	
1003	910	sport aérien	
1004	1003	aérostat	
1005	1003	parachutisme	
1006	1003	voltige aérienne	
1007	910	sport d'hiver	
1008	1007	biathlon	
1009	1007	raquette à neige	
1010	1007	ski	
1011	1010	kilomètre lancé	
1012	1010	saut à ski	
1013	1010	ski acrobatique	
1014	1010	ski alpin	
1015	1014	combiné alpin	
1016	1010	ski de fond	
1017	1010	ski nordique	
1018	1017	combiné nordique	
1019	1010	slalom	
1020	1019	Super G	épreuve de ski
1021	1019	slalom géant	
1022	1010	snowboard	
1023	910	sport de combat	
1024	910	sport de glace	
1025	1024	bobsleigh	
1026	1024	hockey sur glace	
1027	1024	patinage sur glace	
1028	910	sport nautique	
1029	1028	aviron	
1030	1028	canoë-kayak	
1031	1028	canyoning	
1032	1028	natation	
1033	1032	natation synchronisée	
1034	1032	plongeon	
1035	1028	navigation à la rame	
1036	1028	planche à voile	
1037	1028	plongée sous marine	
1038	1028	ski nautique	
1039	1028	surf	
1040	1028	voile (nautisme)	
1041	1040	Around Alone	
1042	1040	Coupe de l'America	
1043	1042	Coupe Louis Vuitton	
1044	1040	Match racing	
1045	1040	Solitaire du Figaro	
1046	1040	The Race	
1047	1040	Trophée Jules Verne	
1048	1040	Vendée Globe Challenge	
1049	1040	monocoque	
1050	1040	multicoque	
1051	1040	route du Rhum	
1052	1040	transat	
1053	1052	Mini-transat	
1054	910	squash	
1055	910	tauromachie	
1056	910	tennis	
1057	1056	Coupe Davis	
1058	1056	Coupe de la Fédération	tennis. Pendant féminin de la Coupe Davis
1059	1056	Open Gaz de France	
1060	1056	Open d'Australie	
1061	1056	Roland-Garros	
1062	1056	Wimbledon	
1063	910	tennis de table	
1064	910	tennis-ballon	
1065	910	tir sportif	
1066	1065	tir à l'arc	
1067	910	trampoline	
1068	910	triathlon	
1069	910	volley-ball	
1070	910	water-polo	
1071	910	yoga	
1072	910	équitation	
1073	851	institution sportive	
1074	1073	Comité international olympique	
1075	1073	Comité national olympique	
1076	1073	Fédération internationale de l'automobile	
1077	1073	Ligue de football professionnel	
1078	1073	Racing Club De France	
1079	1073	UCPA	
1080	1073	UEFA	
1081	851	équipement sportif	
1082	1081	circuit (sport)	
1083	1082	Magny-Cours	
1084	1081	hippodrome	
1085	1081	patinoire	
1086	1081	piscine	
1087	1081	piste sportive	
1088	1081	salle de sport	
1089	1081	stade	
1090	1089	Parc des Princes	
1091	1089	Stade de France	
1092	1089	stade Charlety	
1093	1081	vélodrome	
1094	\N	ZZZZ_Questions internationales	
1095	1094	Union européenne	
1096	1095	Fonds européen de développement	
1097	1095	Politique Etrangère et de Sécurité Commune	
1098	1097	OSCE	
1099	1095	Système monétaire européen	
1100	1095	Union économique et monétaire	
1101	1100	Banque centrale européenne	réunion des 15 banques centrales des pays européens
1102	1100	marché unique	
1103	1100	monnaie unique	
1104	1103	Conseil de l'Euro	
1105	1103	Euro (monnaie)	
1106	1103	zone euro	
1107	1095	conférence intergouvernementale	
1108	1095	droit communautaire	
1109	1108	espace Schengen	
1110	1095	eurosceptique	
1111	1095	institutions européennes	
1112	1111	Commission européenne	
1113	1112	Office européen de lutte antifraude	
1114	1111	Conseil européen	
1115	1111	Convention sur l'avenir de l'Europe	
1116	1111	Parlement européen	
1117	1094	action humanitaire	
1118	1117	Médecins Sans Frontières	
1119	1117	Médecins du monde	
1120	1117	ONG	
1121	1117	Pharmaciens sans Frontières	
1122	1094	colonisation	
1123	1122	colonie de peuplement	
1124	1094	conflit	
1125	1124	Opération des Nations Unies	
1126	1124	collaboration avec l'ennemi	
1127	1124	guerre	
1128	1127	guerre civile	
1129	1127	guerre du Golfe	
1130	1127	prisonnier de guerre	
1131	1127	reddition	
1132	1124	offensive	
1133	1132	affrontement	
1134	1132	cessez-le-feu	
1135	1132	combat	
1136	1132	guérilla	
1137	1136	Sentier lumineux	
1138	1132	invasion	
1139	1132	massacre	
1140	1139	charnier	
1141	1132	mouvement de résistance	
1142	1132	rébellion	
1143	1132	émeute	
1144	1124	paix	
1145	1144	armistice	
1146	1144	plan de paix	
1147	1144	processus de paix	
1148	1124	ultimatum	
1149	1094	diplomatie	
1150	1149	communauté internationale	
1151	1149	convention internationale	
1152	1149	médiation internationale	
1153	1149	relations diplomatiques	
1154	1153	ambassade	
1155	1153	consulat	
1156	1153	diplomate	
1157	1156	immunité diplomatique	
1158	1156	observateur	
1159	1153	reconnaissance diplomatique	
1160	1149	sanction diplomatique	
1161	1149	traité	
1162	1094	géopolitique	
1163	1162	ACP (états associés)	
1164	1162	Alena	marché commun entre le Canada, les Etats-Unis et le Mexique
1165	1162	Asean	
1166	1162	Bénélux	
1167	1162	CEDEAO	
1168	1162	Commonwealth	
1169	1162	Conseil de l'Europe	
1170	1162	Forum de coopération économique Asie-Pacifique	
1171	1162	Forum méditerranéen	
1172	1162	Ligue arabe	
1173	1162	Occident	
1174	1162	Organisation des Etats américains	
1175	1162	Orient	
1176	1162	Pays d'Europe centrale et orientale	
1177	1162	Union africaine	
1178	1162	francophonie	
1179	1162	mondialisation	
1180	1179	altermondialisation	
1181	1180	Attac	
1182	1162	pays non-alignés	
1183	1094	politique étrangère	
1184	1183	ingérence étrangère	
1185	1183	voyage officiel	
1186	1094	relations internationales	
1187	1186	CERI	
1188	1186	accord international	
1189	1186	aide internationale	
1190	1186	blocus	
1191	1186	frontière	
1192	1191	annexion territoriale	
1193	1191	revendication territoriale	
1194	1186	guerre froide	
1195	1186	pacte de stabilité	
1196	1186	protectorat	
1197	1186	relations bilatérales	
1198	\N	Politique	
1199	1198	action politique	
1200	1199	CEVIPOF	
1201	1199	alternance politique	
1202	1199	cohabitation	
1203	1199	crise politique	N'utiliser que dans le cas où le pouvoir politique en place est réellement menacé.
1204	1203	complot	
1205	1203	coup d'Etat	
1206	1203	révolution	
1207	1206	révolution culturelle	
1208	1203	état d'exception	
1209	1208	couvre-feu	
1210	1208	état de siège	
1211	1199	démagogie	
1212	1199	engagement politique	
1213	1199	impartialité de l'Etat	
1214	1199	lobby	
1215	1199	majorité politique	
1216	1199	marketing politique	
1217	1199	militantisme	
1218	1217	tract	
1219	1199	minorité politique	
1220	1199	opposition politique	
1221	1199	parti politique	
1222	1221	Parti Socialiste	
1223	1221	Parti communiste	
1224	1223	communisme refondateur	
1225	1221	Parti conservateur	
1226	1221	Parti démocrate	
1227	1221	Parti démocrate chrétien	
1228	1221	Parti libéral	
1229	1221	Parti social démocrate	
1230	1221	bureau politique	
1231	1221	front républicain	coalition de partis politiques
1232	1221	parti unique	
1233	1221	écologiste	
1234	1199	personnalité politique	
1235	1199	programme politique	
1236	1199	société civile	
1237	1199	stratégie politique	
1238	1198	idéologie politique	
1239	1238	ZZZZ_doctrine politique	
1240	1239	anarchisme	
1241	1239	autonomisme	
1242	1239	centrisme	
1243	1242	centre droit	
1244	1242	centre gauche	
1245	1239	communisme	
1246	1239	conservatisme	
1247	1239	droite	
1248	1239	extrémisme	
1249	1248	extrême-droite	
1250	1248	extrême-gauche	
1251	1239	fascisme	
1252	1251	néofascisme	
1253	1239	franc-maçonnerie	
1254	1253	Grand Orient de France	
1255	1253	Grande Loge de France	
1256	1239	gauche	
1257	1239	gaullisme	
1258	1239	indépendantisme	
1259	1239	isolationnisme	
1260	1239	laïcité	
1261	1260	Réseau Voltaire	
1262	1239	libéralisme	
1263	1239	maoïsme	
1264	1239	marxisme	
1265	1239	nationalisme	
1266	1239	nazisme	
1267	1266	néonazisme	
1268	1239	pacifisme	
1269	1239	patriotisme	
1270	1239	populisme	
1271	1239	radicalisme	
1272	1239	royalisme	
1273	1239	régionalisme	
1274	1239	sionisme	
1275	1239	social-démocratie	
1276	1239	socialisme	
1277	1276	Internationale socialiste	
1278	1239	stalinisme	
1279	1239	trotskisme	
1280	1239	unionisme	
1281	1238	courant politique	
1282	1281	balladurien	
1283	1281	chiraquien	
1284	1281	club politique	
1285	1284	fondation Saint-Simon	
1286	1198	institution politique	
1287	1286	Constitution	
1288	1287	Conseil constitutionnel	
1289	1287	ordonnance (politique)	
1290	1286	Parlement	
1291	1290	Assemblée nationale	
1292	1290	Assemblée territoriale	
1293	1290	Congrès parlementaire	
1294	1290	Sénat	
1295	1290	commission parlementaire	
1296	1295	commission parlementaire d'enquête	
1297	1290	dissolution parlementaire	
1298	1290	groupe parlementaire	
1299	1290	parlementaire	
1300	1299	absentéisme parlementaire	
1301	1299	député	
1302	1299	immunité parlementaire	
1303	1299	indemnité parlementaire	
1304	1299	mission parlementaire	
1305	1299	suppléant parlementaire	
1306	1299	sénateur	
1307	1290	travaux parlementaires	
1308	1307	législature	
1309	1307	motion de censure	
1310	1307	motion de renvoi	
1311	1307	question de confiance	
1312	1307	session parlementaire	
1313	1312	session parlementaire extraordinaire	
1314	1286	ZZZZ_corps constitué	
1315	1314	Conseil d'Etat	
1316	1314	Conseil économique et social	
1317	1314	Cour des comptes	
1318	1317	Cour régionale des comptes	
1319	1286	chef de l'Etat	
1320	1319	intérim présidentiel	
1321	1319	mandat présidentiel	
1322	1321	quinquennat	
1323	1321	septennat	
1324	1286	gouvernement	
1325	1324	Conseil de sécurité intérieure	
1326	1324	Conseil des ministres	
1327	1324	Premier ministre	
1328	1327	déclaration de politique générale	
1329	1324	comité interministériel	
1330	1324	gouvernement local	Ne pas utiliser pour la FRANCE.
1331	1324	gouvernement provisoire	
1332	1324	gouverneur	
1333	1324	ministère (gouvernement)	
1334	1333	ministre	
1335	1334	cabinet ministériel	
1336	1333	ministère de l'Economie et des Finances	
1337	1333	ministère de l'Intérieur	
1338	1333	ministère de la Coopération	
1339	1333	ministère de la Jeunesse et des Sports	
1340	1333	ministère des Affaires européennes	
1341	1333	ministère des Affaires sociales	
1342	1333	ministère des Affaires étrangères	
1343	1333	secrétariat d'Etat	
1344	1324	mission interministérielle	
1345	1324	politique gouvernementale	
1346	1345	plan gouvernemental	
1347	1324	remaniement ministériel	
1348	1324	solidarité gouvernementale	
1349	1286	porte parole	
1350	1198	nation	
1351	1350	Etat	
1352	1351	Etat de droit	
1353	1351	protocole officiel	
1354	1351	secret d'Etat	
1355	1350	identité nationale	
1356	1350	souveraineté	
1357	1356	pouvoir	
1358	1198	pouvoir local	
1359	1358	conseil général	
1360	1358	conseil municipal	
1361	1360	Conseil de Paris	
1362	1360	Conseil de quartier	
1363	1360	conseil d'arrondissement	
1364	1360	conseil municipal d'enfants et de jeunes	
1365	1360	loi PLM	
1366	1360	maire	
1367	1366	Association des maires de France	
1368	1366	Association des maires des grandes villes de France	
1369	1360	mairie	
1370	1358	conseil régional	
1371	1358	gestion locale	
1372	1371	communauté urbaine	seuil de création:  500 000 habitants.
1373	1371	coopération intercommunale	
1374	1358	élu local	
1375	1198	régime politique	
1376	1375	autocratie	
1377	1375	dictature	
1378	1375	démocratie	
1379	1375	empire	
1380	1375	fédéralisme	
1381	1375	monarchie	
1382	1381	souverain	
1383	1375	régime militaire	
1384	1375	régime présidentiel	
1385	1375	république	
1386	1385	IIIe République	
1387	1385	IVe République	
1388	1385	Ve République	
1389	\N	Loisir	
1390	1389	activité de loisir	
1391	1390	bal	
1392	1390	bricolage	
1393	1390	cerf-volant	
1394	1390	collectionneur	
1395	1390	fête	
1396	1395	cadeau	
1397	1395	carnaval	
1398	1395	feu d'artifice	
1399	1395	fête foraine	
1400	1399	foire du Trône	
1401	1395	fête nationale	
1402	1395	fêtes de fin d'année	
1403	1402	nouvel an	
1404	1390	jeu	
1405	1404	PMU	
1406	1404	jeu d'échecs	
1407	1404	jeu de cartes	
1408	1404	jeu de hasard	
1409	1408	Loto	
1410	1408	casino (salle de jeux)	
1411	1408	loterie	
1412	1408	machine à sous	
1413	1408	tirage au sort	
1414	1404	jeu de rôle	
1415	1404	jeu vidéo	
1416	1390	modélisme	
1417	1390	scoutisme	
1418	1389	activité de plein air	
1419	1418	baignade	
1420	1418	camping	
1421	1418	chasse	
1422	1418	exploration (voyage)	
1423	1418	jardinage	
1424	1418	marche à pied	
1425	1418	navigation de plaisance	
1426	1418	patinage à roulettes	
1427	1418	pêche (loisir)	
1428	1418	skate-board	
1429	1418	trottinette	
1430	1389	tourisme	
1431	1430	agence de voyage	
1432	1430	hôtellerie	
1433	1432	chambre d'hôte	
1434	1432	gîte rural	
1435	1430	office du tourisme	
1436	1430	politique du tourisme	
1437	1436	chèque-vacances	
1438	1430	séjour linguistique	
1439	1430	tourisme industriel	
1440	1430	tourisme rural	
1441	1430	tourisme sexuel	
1442	1430	tourisme social	
1443	1430	voyage organisé	
1444	1389	vacances	
1445	1444	colonie de vacances	
1446	1389	équipement de loisir	
1447	1446	centre aéré	
1448	1446	parc de loisirs	
1449	1448	Disneyland Paris	
1450	1448	Futuroscope	
1451	1448	Jardin d'Acclimatation	
1452	1446	station de sport d'hiver	
1453	\N	Secteur tertiaire	
1454	1453	administration	
1455	1454	action administrative	
1456	1455	Inspection générale de l'administration	
1457	1455	centralisation	
1458	1455	déclaration d'utilité publique	
1459	1454	douane	
1460	1459	visa	
1461	1454	fonction publique	
1462	1461	agent contractuel	
1463	1461	fonction publique territoriale	
1464	1461	haute fonction publique	
1465	1454	préfecture	
1466	1465	préfet	
1467	1465	sous-préfet	
1468	1454	service public	
1469	1468	médiateur	
1470	1468	relations Etat citoyen	
1471	1468	service minimum	
1472	1468	simplification administrative	
1473	1453	artisanat	
1474	1473	atelier	
1475	1473	chambre des métiers	
1476	1453	commerce	
1477	1476	chambre de commerce et d'industrie	
1478	1476	commerce d'occasion	
1479	1478	brocante	
1480	1476	commerce équitable	
1481	1476	marchandise	
1482	1476	marché noir	
1483	1476	stratégie commerciale	
1484	1483	abonnement	
1485	1483	franchisage	
1486	1483	marketing	
1487	1486	marketing direct	
1488	1486	sponsoring	
1489	1483	promotion commerciale	
1490	1483	soldes	
1491	1483	tarification	
1492	1491	ticket	
1493	1483	étiquetage	
1494	1493	code-barres	
1495	1453	distribution	
1496	1495	circuit de distribution	
1497	1496	centrale d'achat	
1498	1496	centre commercial	
1499	1496	commerce d'alimentation	
1500	1496	drugstore	
1501	1496	grande distribution	
1502	1501	grand magasin	
1503	1501	grande surface	
1504	1496	magasin	
1505	1504	magasin d'usine	
1506	1496	marché (lieu de vente)	
1507	1496	petit commerce	
1508	1507	CDCA	
1509	1507	commerçant	
1510	1495	commercialisation	
1511	1510	agent commercial	
1512	1510	client	
1513	1510	représentant de commerce	
1514	1510	salon (exposition)	
1515	1514	foire	
1516	1510	technique commerciale	
1517	1516	achat	
1518	1516	libre service	
1519	1516	livraison à domicile	
1520	1516	location de matériel	
1521	1516	vente	
1522	1521	camelot	
1523	1521	vente aux enchères	
1524	1523	Christie's	
1525	1523	Drouot	
1526	1523	Sotheby's	
1527	1521	vente directe	
1528	1521	vente à bas prix	
1529	1521	vente à distance	
1530	1529	commerce électronique	
1531	1529	téléachat	
1532	1529	vente par correspondance	
1533	1521	vente à perte	
1534	1453	services	
1535	1534	association	
1536	1535	association caritative	
1537	1535	association à but non lucratif	
1538	1534	assurance	
1539	1538	assurance vie	
1540	1534	café (bar)	
1541	1534	centre d'affaires	
1542	1534	coiffure	
1543	1534	déménagement	
1544	1534	employé de maison	
1545	1534	garage	
1546	1545	contrôle technique	
1547	1534	gardiennage	
1548	1534	maintenance	
1549	1534	nettoyage	
1550	1549	blanchisserie	
1551	1534	pompes funèbres	
1552	1551	cimetière	
1553	1551	rite funéraire	
1554	1553	exhumation	
1555	1553	incinération funéraire	
1556	1553	monument funéraire	
1557	1553	obsèques	
1558	1534	poste (courrier)	
1559	1558	centre de tri	
1560	1558	courrier	
1561	1560	carte postale	
1562	1560	lettre ouverte	
1563	1558	timbre	
1564	1534	reprographie	
1565	1534	restaurant	
1566	1565	chèque restaurant	
1567	1565	restauration collective	
1568	1565	restauration rapide	
1569	1534	service à distance	
1570	1569	centre d'appel	
1571	1534	service à domicile	
1572	1534	société de service	
1573	1534	système de sécurité	
1574	1573	agent d'ambiance	
1575	1573	coffre fort	
1576	1573	vidéosurveillance	
1577	1453	usager	
1578	1577	Association des usagers de l'administration	
1579	1577	comité des usagers	
1580	\N	ZZZZ_Territoires étrangers	
1581	1580	Afrique	
1582	1581	Afrique australe	
1583	1582	Afrique du Sud	
1584	1583	Johannesburg	
1585	1583	KwaZulu-Natal	
1586	1583	Le Cap	
1587	1583	Natal	
1588	1583	Pretoria	
1589	1583	Soweto	
1590	1582	Angola	
1591	1590	Luanda	
1592	1582	Botswana	
1593	1582	Comores	
1594	1593	Moroni	
1595	1582	Ile Maurice	
1596	1582	Lesotho	
1597	1582	Madagascar	
1598	1597	Antananarivo	
1599	1582	Malawi	
1600	1582	Mozambique	
1601	1600	Maputo	
1602	1582	Namibie	
1603	1582	Seychelles	
1604	1582	Swaziland	
1605	1582	Zambie	
1606	1605	Lusaka	
1607	1582	Zimbabwe	
1608	1581	Afrique centrale	
1609	1608	Cameroun	
1610	1609	Yaoundé	
1611	1608	Congo	
1612	1611	Brazzaville	
1613	1608	Gabon	
1614	1613	Libreville	
1615	1608	Guinée-Equatoriale	
1616	1608	République centrafricaine	
1617	1616	Bangui	
1618	1608	République démocratique du Congo	
1619	1618	Goma	
1620	1618	Kinshasa	capitale du Zaïre
1621	1618	Kisangani	
1622	1618	Kivu	
1623	1618	Lubumbashi	
1624	1608	Sao Tomé	
1625	1608	Tchad	
1626	1581	Afrique francophone	
1627	1581	Afrique occidentale	
1628	1627	Burkina Faso	
1629	1628	Ouagadougou	
1630	1627	Bénin	
1631	1630	Cotonou	
1632	1627	Cap-Vert	
1633	1627	Côte-d'Ivoire	
1634	1633	Abidjan	
1635	1627	Gambie	
1636	1627	Ghana	
1637	1627	Guinée	
1638	1637	Conakry	
1639	1627	Guinée-Bissau	
1640	1627	Libéria	
1641	1640	Monrovia	
1642	1627	Mali	
1643	1642	Bamako	
1644	1627	Niger	
1645	1644	Niamey	
1646	1627	Nigeria	
1647	1646	Lagos	
1648	1627	Sierra Leone	
1649	1648	Freetown	
1650	1627	Sénégal	
1651	1650	Casamance	
1652	1650	Dakar (ville)	
1653	1627	Togo	
1654	1653	Lomé	
1655	1581	Afrique orientale	
1656	1655	Burundi	
1657	1656	Bujumbura	
1658	1655	Djibouti	
1659	1655	Ethiopie	
1660	1659	Addis-Abeba	
1661	1659	Erythrée	
1662	1655	Kenya	habitant du Kenya
1663	1662	Nairobi	
1664	1655	Ouganda	
1665	1655	Rwanda	
1666	1665	Gisenyi	
1667	1665	Kibeho	
1668	1665	Kigali	
1669	1655	Somalie	
1670	1669	Mogadiscio	
1671	1655	Soudan	
1672	1671	Darfour	 
1673	1671	Khartoum	
1674	1655	Tanzanie	
1675	1674	Arusha	
1676	1674	Zanzibar	
1677	1580	Amérique du Nord	
1678	1677	Canada	
1679	1678	Halifax	ville du Canada
1680	1678	Nunavut	
1681	1678	Québec (province)	
1682	1681	Montréal	
1683	1681	Québec (ville)	
1684	1678	Terre-Neuve	
1685	1678	Toronto	
1686	1678	Vancouver	
1687	1677	Etats-Unis	
1688	1687	Alabama	
1689	1687	Alaska	
1690	1687	Arizona	
1691	1690	Phoenix	
1692	1687	Arkansas	Etat américain d'où arrive Bill Clinton
1693	1687	Californie	
1694	1693	Berkeley	
1695	1693	Los Angeles	
1696	1695	Hollywood	
1697	1693	Orange (Comté d')	comté inclus dans l'Etat de Californie aux USA
1698	1693	San Diego	
1699	1693	San Francisco	
1700	1693	Silicon Valley	
1701	1687	Caroline du Nord	
1702	1687	Caroline du Sud	
1703	1687	Colorado	
1704	1703	Denver	
1705	1687	Connecticut	
1706	1687	Dakota du Sud	
1707	1687	Dakota du nord	
1708	1687	Delaware	
1709	1687	District of Columbia	
1710	1709	Washington DC	
1711	1710	Maison Blanche	
1712	1687	Floride	
1713	1712	Cap Canaveral	
1714	1712	Miami	
1715	1712	Orlando	
1716	1687	Géorgie (USA)	
1717	1716	Atlanta	
1718	1687	Hawaii	
1719	1687	Illinois	
1720	1719	Chicago	
1721	1687	Indiana	
1722	1687	Iowa	
1723	1687	Kansas	
1724	1687	Kentucky	
1725	1687	Louisiane	
1726	1725	Nouvelle Orléans	
1727	1687	Maine	
1728	1687	Maryland	
1729	1728	Baltimore	
1730	1687	Massachusetts	
1731	1730	Boston	
1732	1687	Michigan	Etat américain
1733	1732	Detroit (USA)	
1734	1687	Minnesota	
1735	1734	Minneapolis	
1736	1687	Mississipi	
1737	1687	Missouri	
1738	1687	Montana	
1739	1687	Nebraska	
1740	1687	Nevada	
1741	1740	Las Vegas	
1742	1687	New Hampshire	
1743	1687	New Jersey	
1744	1687	New-York (état)	
1745	1744	New-York (ville)	
1746	1745	Brooklyn	
1747	1745	Harlem	
1748	1745	Long Island	
1749	1687	Nouveau-Mexique	
1750	1687	Ohio	
1751	1750	Cleveland	
1752	1750	Dayton	
1753	1687	Oklahoma	
1754	1753	Oklahoma City	
1755	1687	Oregon	
1756	1755	Seattle	
1757	1687	Pennsylvanie	
1758	1757	Philadelphie	
1759	1757	Pittsburgh	
1760	1687	Rhode Island	
1761	1687	Tennessee	
1762	1687	Texas	
1763	1762	Dallas	équipe de Super Bowl
1764	1762	Houston	
1765	1762	Waco	
1766	1687	Utah	
1767	1766	Salt Lake City	
1768	1687	Vermont	
1769	1687	Virginie	
1770	1687	Virginie-Occidentale	
1771	1687	Washington (état)	
1772	1687	Wisconsin	
1773	1687	Wyoming	
1774	1677	Groenland	
1775	1580	Amérique latine et centrale	
1776	1775	Argentine	
1777	1776	Buenos Aires	
1778	1776	Patagonie	
1779	1775	Belize	
1780	1775	Bermudes	
1781	1775	Bolivie	
1782	1775	Brésil	
1783	1782	Bahia	
1784	1782	Brasilia	
1785	1782	Rio de Janeiro	
1786	1782	Sao Paulo	
1787	1775	Chili	
1788	1787	Santiago	
1789	1787	cap Horn	
1790	1775	Colombie	
1791	1790	Bogota	
1792	1790	Cali	
1793	1790	Medellin	
1794	1775	Costa Rica	
1795	1775	Equateur	
1796	1795	Galapagos	
1797	1775	Guatemala	
1798	1775	Honduras	
1799	1775	Iles des Caraïbes	
1800	1799	Antilles néerlandaises	
1801	1799	Bahamas	
1802	1799	Barbade	
1803	1799	Cuba	
1804	1803	La Havane	
1805	1799	Grenade (Antilles)	
1806	1799	Haïti	
1807	1806	Port-au-Prince	
1808	1799	Jamaïque	
1809	1799	La Dominique	Etat des petites Antilles
1810	1799	Montserrat	
1811	1799	Porto Rico	
1812	1799	République Dominicaine	
1813	1799	Sainte-Lucie	
1814	1799	Trinidad et Tobago	
1815	1775	Malouines	
1816	1775	Mexique	
1817	1816	Chiapas	
1818	1816	Mexico	
1819	1775	Nicaragua	
1820	1775	Panama	
1821	1775	Paraguay	
1822	1775	Pérou	
1823	1822	Lima	Capitale du Pérou
1824	1775	Salvador	
1825	1824	San Salvador	
1826	1775	Surinam	
1827	1775	Uruguay	
1828	1827	Montevideo	
1829	1827	Punta del Este	
1830	1775	Venezuela	
1831	1830	Caracas	
1832	1580	Asie	
1833	1832	Asie centrale	
1834	1833	Afghanistan	
1835	1834	Hérat	ville d'Afghanistan
1836	1834	Kaboul	
1837	1834	Kandahar	
1838	1833	Mongolie	
1839	1833	Pakistan	
1840	1839	Islamabad	
1841	1839	Karachi	
1842	1832	Asie du sud-est	
1843	1842	Brunei	
1844	1842	Iles Spratly	îles situées entre la Chine et les Philippines
1845	1842	Indochine	
1846	1845	Birmanie	
1847	1846	Karen (Birmanie)	
1848	1846	Rangoon	
1849	1845	Cambodge	
1850	1849	Phnom Penh	
1851	1845	Laos	
1852	1845	Malaisie	
1853	1845	Thaïlande	
1854	1853	Bangkok	
1855	1845	Viêt-nam	
1856	1855	Hanoi	
1857	1855	Ho Chi Minh-Ville	
1858	1842	Indonésie	
1859	1858	Bali	
1860	1858	Bornéo	
1861	1858	Iles Moluques	
1862	1858	Irian Jaya	
1863	1858	Java (Indonésie)	
1864	1863	Jakarta	
1865	1858	Sumatra	
1866	1858	Timor occidental	
1867	1858	Timor oriental	
1868	1842	Philippines	
1869	1868	Manille	
1870	1842	Singapour	
1871	1832	Asie méridionale	
1872	1871	Bangladesh	
1873	1872	Dhaka	
1874	1871	Bhoutan	
1875	1871	Inde	
1876	1875	Bangalore	
1877	1875	Bengale	
1878	1877	Calcutta	
1879	1875	Cachemire	Etat divisé entre l'Inde et le Pakistan au NO
1880	1879	Jammu	capitale d'hiver du Cachemire indien
1881	1879	Srinagar	
1882	1875	Dharamsala	
1883	1875	Goa	
1884	1875	Madras	
1885	1875	Maharashtra	
1886	1885	Bombay	
1887	1875	New-Delhi	
1888	1875	Pendjab	
1889	1875	Rajasthan	
1890	1875	Tamil Nadu	
1891	1875	Uttar Pradesh	
1892	1871	Maldives	
1893	1871	Népal	
1894	1893	Katmandou	Capitale du Népal
1895	1871	Sri Lanka	
1896	1895	Colombo	Capitale du Sri Lanka
1897	1895	Jaffna	
1898	1832	Extrême-Orient	
1899	1898	Chine	
1900	1899	Canton (Chine)	
1901	1899	Hunan	
1902	1899	Mandchourie	
1903	1899	Nankin	ville chinoise où en 1947 les japonais massacrèrent les civils, "massacres de Nankin"
1904	1899	Pékin	
1905	1904	Tiananmen	place/Pékin
1906	1899	Shanghai	
1907	1899	Shenzhen	
1908	1899	Sichuan	
1909	1899	Xinjiang	
1910	1898	Corée du Nord	
1911	1910	Pyongyang	
1912	1898	Corée du Sud	
1913	1912	Séoul	
1914	1898	Hong-Kong	
1915	1898	Japon	
1916	1915	Hiroshima	
1917	1915	Kobe	
1918	1915	Nagasaki	seconde ville du japon bombardée par une bombe atomique en 1945
1919	1915	Okinawa	
1920	1915	Osaka	
1921	1915	Tokyo	
1922	1915	Yokohama	
1923	1898	Macao	
1924	1898	Taiwan	
1925	1898	Tibet	
1926	1925	Lhassa	
1927	1580	Europe	
1928	1927	Europe centrale	
1929	1927	Europe occidentale	
1930	1929	Allemagne	
1931	1930	Bade-Wurtemberg	
1932	1931	Baden-Baden	
1933	1931	Heidelberg	
1934	1931	Stuttgart	
1935	1930	Basse-Saxe	
1936	1935	Hanovre	
1937	1930	Bavière	
1938	1937	Dachau	
1939	1937	Munich	
1940	1937	Nuremberg	
1941	1930	Berlin	
1942	1930	Brandebourg	
1943	1942	Francfort-sur-Oder	
1944	1942	Potsdam	
1945	1930	Brême	
1946	1930	Hambourg	
1947	1930	Hesse	
1948	1947	Francfort	
1949	1930	Länder	
1950	1930	Rhénanie du Nord-Westphalie	
1951	1950	Aix-la-Chapelle	
1952	1950	Bonn	
1953	1950	Cologne	
1954	1950	Dortmund	
1955	1950	Düsseldorf	
1956	1950	Essen	
1957	1950	Gelsenkirchen	
1958	1950	Leverkusen	
1959	1950	Solingen	
1960	1930	Rhénanie-Palatinat	
1961	1960	Trèves (Allemagne)	
1962	1930	Sarre (Allemagne)	
1963	1930	Saxe	
1964	1963	Dresde	ville d'Allemagne très bombardée en 1945
1965	1963	Leipzig	
1966	1930	Saxe-Anhalt	
1967	1930	Schleswig-Holstein	
1968	1967	Lübeck	
1969	1930	Thuringe	
1970	1969	Buchenwald	
1971	1969	Weimar	
1972	1930	ex-RDA	
1973	1929	Andorre	
1974	1929	Autriche	
1975	1974	Kitzbühel	
1976	1974	Salzbourg	
1977	1974	Vienne (Autriche)	
1978	1929	Belgique	
1979	1978	Anvers	
1980	1978	Bruxelles	
1981	1978	Charleroi	
1982	1978	Flandre	
1983	1978	Liège	
1984	1978	Mons (Belgique)	
1985	1978	Ostende	
1986	1978	Vilvorde	
1987	1978	Wallonie	
1988	1929	Espagne	
1989	1988	Andalousie	
1990	1989	Cordoue	
1991	1989	Grenade (Espagne)	
1992	1989	Jerez	
1993	1989	Séville	
1994	1988	Aragon (Espagne)	
1995	1994	Saragosse	
1996	1988	Asturies	
1997	1996	Gijon	
1998	1988	Canaries	
1999	1988	Castille-La Manche	
2000	1988	Castille-Léon	
2001	2000	Salamanque	
2002	1988	Catalogne	
2003	2002	Barcelone	
2004	1988	Ceuta	enclave espagnole au Maroc
2005	1988	Estrémadure	
2006	1988	Galice	
2007	2006	Saint-Jacques-de-Compostelle	
2008	1988	Iles Baléares	
2009	2008	Ibiza	
2010	2008	Majorque	
2011	1988	Madrid	
2012	1988	Melilla	
2013	1988	Navarre	
2014	2013	Pampelune	
2015	1988	Pays basque espagnol	
2016	2015	Bilbao	
2017	2015	San Sebastian	
2018	1988	Santander	
2019	1988	Valence (Espagne)	
2020	1929	Finlande	
2021	2020	Helsinki	
2022	1929	Gibraltar	
2023	1929	Grande-Bretagne	
2024	2023	Angleterre	
2025	2024	Birmingham	
2026	2024	Blackpool	
2027	2024	Bradford	
2028	2024	Brighton	
2029	2024	Cambridge	
2030	2024	Cornouailles	
2031	2024	Coventry	
2032	2024	Douvres	
2033	2024	Gloucester	
2034	2024	Leeds	
2035	2024	Liverpool	
2036	2024	Londres	
2037	2024	Manchester	
2038	2024	Newcastle	
2039	2024	Nottingham	
2040	2024	Oxford	
2041	2024	Southampton	
2042	2024	Twickenham	
2043	2024	Wembley	
2044	2023	Ecosse	
2045	2044	Dunblane	
2046	2044	Edimbourg	
2047	2044	Glasgow	equipe de foot UK
2048	2044	Lockerbie	
2049	2023	Iles anglo-normandes	
2050	2023	Irlande du nord	
2051	2050	Belfast	
2052	2050	Derry	
2053	2050	Portadown	
2054	2023	Pays de Galles	
2055	1929	Grèce	
2056	2055	Athènes	
2057	2055	Corfou	
2058	2055	Crète	
2059	2055	Salonique	
2060	1929	Islande	
2061	1929	Italie	
2062	2061	Bologne	
2063	2061	Calabre	
2064	2061	Gênes	
2065	2061	Imola	
2066	2061	Lombardie	
2067	2066	Milan (Italie)	
2068	2061	Naples	
2069	2061	Padanie	
2070	2061	Padoue	
2071	2061	Parme	
2072	2061	Pompéi	
2073	2061	Pouilles	
2074	2061	Rome	
2075	2061	Saint-Marin	
2076	2061	San Remo	
2077	2061	Sardaigne	
2078	2061	Sicile	
2079	2078	Catane	
2080	2078	Corleone	
2081	2078	Palerme	
2082	2061	Toscane	
2083	2082	Florence	
2084	2082	Pise	
2085	2061	Trieste	
2086	2061	Trévise	
2087	2061	Turin	
2088	2061	Venise	
2089	2061	Vérone	
2090	1929	Liechtenstein	
2091	1929	Luxembourg	
2092	1929	Malte	
2093	2092	La Valette	
2094	1929	Monaco	
2095	2094	Monte-Carlo	
2096	1929	Pays-Bas	
2097	2096	Amsterdam	
2098	2096	La Haye	
2099	2096	Maastricht	
2100	2096	Rotterdam	
2101	1929	Portugal	
2102	2101	Lisbonne	
2103	2101	Madère	
2104	2101	Porto	
2105	1929	République d'Irlande	
2106	2105	Dublin	
2107	2105	Londonderry	
2108	1929	Scandinavie	
2109	2108	Danemark	
2110	2109	Copenhague	
2111	2109	Féroé	territoire autonome danois
2112	2108	Norvège	
2113	2112	Oslo	
2114	2108	Suède	
2115	2114	Göteborg	
2116	2114	Malmö	
2117	2114	Stockholm	
2118	1929	Suisse	
2119	2118	Berne	
2120	2118	Bâle	Ville de Suisse. Chef-lieu du demi-canton de Bâle-ville.
2121	2118	Davos (Suisse)	
2122	2118	Genève	
2123	2118	Lausanne	
2124	2118	Locarno	
2125	2118	Montreux	
2126	2118	Neuchâtel	
2127	2118	Wengen	
2128	2118	Zurich	
2129	1929	Vatican	
2130	1927	Europe orientale	
2131	2130	Albanie	
2132	2131	Tirana	
2133	2131	Vlora	
2134	2130	Balkans	
2135	2130	Bulgarie	
2136	2135	Sofia	
2137	2130	Ex-Yougoslavie	
2138	2137	Bosnie	
2139	2138	Banja Luka	
2140	2138	Bihac	
2141	2138	Brcko	Ville du nord de la Bosnie
2142	2138	Fédération croato-musulmane	
2143	2138	Gorazde	
2144	2138	Mostar	
2145	2138	Pale	
2146	2138	République serbe de Bosnie	
2147	2138	Sarajevo	
2148	2138	Serbe de Bosnie	
2149	2138	Srebrenica	
2150	2138	Tuzla	
2151	2138	Vukovar	
2152	2138	Zepa	
2153	2138	mont Igman	
2154	2137	Croatie	
2155	2154	Dubrovnik	ville de Croatie
2156	2154	Glina	
2157	2154	Gora	
2158	2154	Krajina	
2159	2158	Knin	
2160	2158	Petrinja	
2161	2158	République serbe de Krajina	
2162	2158	Slavonie Occidentale	
2163	2158	Slavonie Orientale	
2164	2154	Osijek	
2165	2154	Pakrac	ville Serbe en territoire Croate
2166	2154	Split	Ville portuaire de Croatie
2167	2154	Zagreb	
2168	2137	Etat de Serbie et Monténégro	
2169	2168	Montenegro	
2170	2168	Serbie	
2171	2170	Belgrade	
2172	2170	Kosovo	
2173	2170	Voïvodine	
2174	2137	Macédoine	
2175	2174	Skopje	
2176	2137	Slovénie	
2177	2176	Ljubljana	
2178	2130	Hongrie	
2179	2178	Budapest	
2180	2130	Pologne	
2181	2180	Auschwitz	
2182	2180	Cracovie	
2183	2180	Gdansk	
2184	2180	Lodz	
2185	2180	Silésie	
2186	2180	Varsovie	
2187	2130	Roumanie	
2188	2187	Bucarest	
2189	2187	Constanta	
2190	2187	Transylvanie	 
2191	2130	République Tchèque	
2192	2191	Prague	
2193	2191	Sudète	
2194	2130	Slovaquie	
2195	1580	Ex-URSS	contexte historique seulement
2196	2195	Arménie	
2197	2196	Erevan	capitale de l'Arménie
2198	2195	Azerbaïdjan	
2199	2198	Bakou	
2200	2198	Haut-Karabakh	
2201	2195	Biélorussie	
2202	2201	Belojevskaïa Pouchtcha	
2203	2201	Bielomor	
2204	2201	Minsk	
2205	2195	CEI	regroupe les 12 Etats de l'ex-URSS
2206	2195	Caucase	
2207	2195	Géorgie (ex URSS)	
2208	2207	Abkhazie	
2209	2207	Ossétie du Sud	
2210	2195	Kazakhstan	
2211	2210	Akmola	
2212	2210	Alma-Ata	
2213	2210	Baïkonour	
2214	2195	Kirghizstan	
2215	2195	Moldavie	
2216	2215	Transdniestrie	
2217	2195	Ouzbékistan	
2218	2217	Tachkent	
2219	2195	Pays Baltes	
2220	2219	Estonie	
2221	2219	Lettonie	
2222	2221	Riga	
2223	2219	Lituanie	
2224	2195	Russie	
2225	2224	Birobidjan	
2226	2224	Bouriatie	
2227	2224	Daguestan	
2228	2227	Kizliar	
2229	2227	Makhachkala	
2230	2227	Pervomaïskaïa	
2231	2224	Ekaterinbourg	
2232	2224	Ingouchie	
2233	2224	Kabardino-Balkarie	
2234	2224	Kaliningrad	
2235	2224	Kalmoukie	
2236	2224	Kouriles	
2237	2224	Koursk	
2238	2224	Moscou	
2239	2224	Mourmansk	
2240	2224	Nijni-Novgorod	
2241	2224	Ossétie du Nord	
2242	2224	Oudmourtie	
2243	2224	Oural	
2244	2224	Primorié Kraï	
2245	2244	Vladivostok	
2246	2224	République des Komis	
2247	2224	Saint-Pétersbourg	
2248	2224	Sakhaline	îles de l'Extrême-Orient russe revendiqué par la Chine
2249	2224	Stavropol	
2250	2224	Tatarstan	
2251	2224	Tchétchénie	
2252	2251	Boudenovsk	
2253	2251	Goudermès	
2254	2251	Grozny	
2255	2251	Novogrozny	
2256	2251	Sernovodsk	
2257	2224	Volgograd	
2258	2224	république de Karatchaïevo-Tcherkessie	
2259	2195	Sibérie	
2260	2195	Tadjikistan	
2261	2195	Transnistrie	
2262	2195	Turkménistan	
2263	2195	Ukraine	
2264	2263	Crimée	
2265	2263	Donbass	
2266	2263	Kiev	capitale de l'Ukraine
2267	2263	Odessa	
2268	2263	Sébastopol (Ukraine)	
2269	2263	Tchernobyl	
2270	2263	Yalta	
2271	1580	Maghreb	
2272	2271	Algérie	
2273	2272	Alger	
2274	2272	Blida	
2275	2272	Constantine	
2276	2272	Kabylie	
2277	2272	Médéa	
2278	2272	Oran	
2279	2272	Sétif	
2280	2272	Tizi-Ouzou	
2281	2271	Libye	
2282	2281	Tripoli	
2283	2271	Maroc	
2284	2283	Casablanca	
2285	2283	Essaouira	
2286	2283	Fez	
2287	2283	Marrakech	
2288	2283	Rabat	
2289	2283	Tanger	
2290	2283	Tazmamart	
2291	2271	Mauritanie	
2292	2271	Sahara occidental	
2293	2271	Tunisie	
2294	2293	Carthage	
2295	2293	Tunis	
2296	1580	Océanie	
2297	2296	Australie	
2298	2297	Melbourne	
2299	2297	Perth	
2300	2297	Sydney	
2301	2297	Tasmanie	
2302	2296	Micronésie	
2303	2296	Mélanésie	
2304	2303	Fidji	
2305	2303	Iles Salomon	
2306	2303	Papouasie-Nouvelle-Guinée	
2307	2303	Vanuatu	
2308	2296	Nouvelle-Zélande	
2309	2308	Auckland	
2310	2296	Samoa	
2311	2296	Tonga	
2312	1580	Pacifique Sud	
2313	1580	Proche-Orient	
2314	2313	Arabie Saoudite	
2315	2314	La Mecque	
2316	2314	Riyad	
2317	2313	Chypre	
2318	2317	Nicosie	
2319	2317	République turque de Chypre Nord	
2320	2313	Egypte	
2321	2320	Alexandrie	ville d'egypte
2322	2320	Charm al-Cheikh	
2323	2320	Le Caire	
2324	2320	Louxor	
2325	2320	Sinaï	
2326	2320	Suez (Egypte)	
2327	2320	Taba	
2328	2313	Emirats arabes unis	
2329	2328	Abou Dhabi	
2330	2328	Doubaï	
2331	2313	Etats du Golfe	
2332	2331	Bahreïn	
2333	2331	Oman	
2334	2331	Qatar	
2335	2313	Irak	
2336	2335	Bagdad	
2337	2335	Erbil	
2338	2313	Iran	
2339	2338	Téhéran	
2340	2313	Israël	
2341	2340	Galilée	
2342	2340	Jérusalem	
2343	2340	Nazareth	
2344	2340	Néguev	
2345	2340	Tel-Aviv	
2346	2313	Jordanie	
2347	2346	Amman	
2348	2313	Koweit	
2349	2313	Kurdistan	
2350	2313	Liban	
2351	2350	Beyrouth	
2352	2350	Cana	
2353	2350	Sud-Liban	
2354	2350	Tyr	
2355	2313	Palestine	
2356	2355	Autorité palestinienne	
2357	2355	Cisjordanie	
2358	2357	Bethléem	
2359	2357	Hébron	
2360	2357	Jénine	
2361	2357	Jéricho	
2362	2357	Naplouse	
2363	2357	Ramallah	
2364	2357	Tulkarem	
2365	2355	Conseil palestinien	
2366	2355	Erez	ville frontière entre Palestine et Israël
2367	2355	Gaza	
2368	2367	Rafah	Ville de la frontière entre le territoire de Gaza et l'Egypte
2369	2355	Territoires palestiniens autonomes	
2370	2313	Syrie	
2371	2370	Damas	
2372	2370	Golan	
2373	2313	Turquie	
2374	2373	Anatolie	
2375	2373	Ankara	
2376	2373	Istanbul	
2377	2313	Yémen	
2378	2377	Aden (Yémen)	
2379	2377	Sanaa	
2380	\N	Entreprise	
2381	2380	entreprise en difficulté	
2382	2381	dépôt de bilan	Précède la faillite ou le règlement judiciaire
2383	2382	cessation d'activité	
2384	2382	cessation de paiement	
2385	2382	faillite	
2386	2382	redressement judiciaire	
2387	2386	administrateur judiciaire	
2388	2380	gestion d'entreprise	
2389	2388	audit	
2390	2388	autogestion	
2391	2388	direction de l'entreprise	
2392	2391	PDG	
2393	2391	chef d'entreprise	
2394	2391	conseil d'administration	
2395	2394	administrateur	
2396	2391	conseil de surveillance	
2397	2391	gérant	
2398	2391	homme d'affaire	
2399	2380	gestion des ressources humaines	
2400	2399	culture d'entreprise	
2401	2380	gestion financière	
2402	2401	charges sociales	
2403	2401	comptabilité d'entreprise	
2404	2403	commissaire aux comptes	
2405	2403	expert comptable	
2406	2401	coût de production	
2407	2401	financement	
2408	2407	augmentation de capital	
2409	2407	capital social	
2410	2407	capital-risque	
2411	2407	cession d'actif	
2412	2407	fonds propres	
2413	2401	résultat financier	
2414	2413	bénéfice	
2415	2413	chiffre d'affaires	
2416	2380	secteur d'activité	
2417	2380	stratégie de l'entreprise	
2418	2417	acquisition d'entreprise	
2419	2417	cession d'entreprise	
2420	2417	compétitivité	
2421	2420	productivité	
2422	2420	rentabilité	
2423	2417	concentration d'entreprise	
2424	2423	cartel	
2425	2423	fusion d'entreprises	
2426	2425	fusion-acquisition	
2427	2423	prise de participation financière	
2428	2417	création d'entreprise	
2429	2417	entreprise citoyenne	
2430	2417	monopole	
2431	2417	partenariat	
2432	2417	production	
2433	2432	fabrication	
2434	2432	produit	
2435	2434	produit dérivé	
2436	2434	produit détaxé	
2437	2417	reprise d'entreprise	
2438	2437	reprise de l'entreprise par les salariés	
2439	2417	siège social	
2440	2417	transmission d'entreprise	
2441	2380	structure de l'entreprise	
2442	2441	EPIC	
2443	2441	Groupement d'Intérêt Economique	
2444	2441	PME	
2445	2441	Sofica	
2446	2441	conglomérat	
2447	2441	coopérative	
2448	2441	entreprise d'insertion	
2449	2441	entreprise individuelle	
2450	2441	entreprise multinationale	
2451	2441	entreprise étrangère	
2452	2441	filiale	
2453	2441	holding	
2454	2441	société anonyme	
2455	2441	société anonyme à responsabilité limitée	
2456	2441	société d'économie mixte	
2457	2456	Semidep	
2458	2441	très petite entreprise	Entreprise de moins de 10 salariés
2459	\N	Agriculture	
2460	2459	droit rural	
2461	2459	marché agricole	
2462	2461	excédent agricole	
2463	2459	politique agricole	
2464	2463	Politique Agricole Commune	
2465	2463	revenu agricole	
2466	2459	production agricole	
2467	2466	agriculture biologique	
2468	2466	apiculture	
2469	2466	aquaculture	
2470	2466	arboriculture	
2471	2466	bois (matériau)	
2472	2466	culture maraîchère	
2473	2466	horticulture	
2474	2466	viticulture	
2475	2474	cépage	
2476	2474	oenologie	
2477	2474	vendange	
2478	2466	élevage	
2479	2478	bovin	
2480	2479	veau	
2481	2478	caprin	
2482	2478	ovin	
2483	2478	porc	
2484	2478	transhumance	
2485	2478	volaille	
2486	2485	oeuf	
2487	2478	équarrissage	
2488	2459	produit agricole	
2489	2488	céréale	
2490	2489	blé	
2491	2489	maïs	
2492	2489	riz	
2493	2488	oléagineux	
2494	2488	produit agroalimentaire	
2495	2494	boisson alcoolisée	
2496	2495	bière	
2497	2495	champagne	
2498	2495	vin	
2499	2495	vodka	
2500	2495	whisky	
2501	2494	boisson non alcoolisée	
2502	2501	eau minérale	
2503	2494	caviar	
2504	2494	fruit	
2505	2504	agrume	
2506	2504	banane	
2507	2504	fruit exotique	
2508	2504	fruit rouge	
2509	2504	olive	
2510	2494	huile	
2511	2494	légume	
2512	2511	cucurbitacée	
2513	2511	pomme de terre	
2514	2511	tomate	
2515	2494	pain	
2516	2494	produit laitier	
2517	2516	crème glacée	
2518	2516	fromage	
2519	2516	lait	
2520	2516	yaourt	
2521	2494	pâte alimentaire	
2522	2494	pâtisserie	
2523	2494	sel	
2524	2494	sucre	
2525	2494	viande	
2526	2525	abats	
2527	2525	foie gras	
2528	2494	épice	
2529	2488	produit tropical	
2530	2529	cacao	
2531	2530	chocolat	
2532	2529	café (produit)	
2533	2529	caoutchouc	
2534	2529	coca (plante)	
2535	2529	coton	
2536	2529	thé	
2537	2488	soja	
2538	2488	tabac	
2539	2459	pêche industrielle	
2540	2539	bateau de pêche	
2541	2539	droit de pêche	
2542	2541	zone de pêche	
2543	2539	politique de la pêche	
2544	2459	structure agricole	
2545	2544	exploitation agricole	
2546	2545	coopérative agricole	
2547	2545	kibboutz	
2548	2544	réforme agraire	
2549	2544	terre agricole	
2550	2549	SAFER	
2551	2549	remembrement	
2552	2459	technique agricole	
2553	2552	défrichement	
2554	2552	engrais	
2555	2552	irrigation	
2556	2552	jachère	
2557	2552	machine agricole	
2558	2552	pesticide	
2559	2552	recherche agronomique	
2560	2559	INRA	
2561	2552	récolte	
2562	2459	vie rurale	
2563	2562	chambre d'agriculture	
2564	2562	milieu rural	
2565	2562	population rurale	
2566	2565	agriculteur	
2567	2562	syndicat agricole	
2568	2567	CNJA	
2569	2567	Confédération paysanne	
2570	2567	Coordination rurale	
2571	2567	FNSEA	
2572	\N	ZZZZ_Territoires français	
2573	2572	Alsace	
2574	2573	Bas-Rhin	
2575	2574	Strasbourg	
2576	2573	Haut-Rhin	
2577	2576	Colmar	
2578	2576	Habsheim	
2579	2576	Mulhouse	
2580	2572	Aquitaine	
2581	2580	Dordogne	
2582	2581	Bergerac	
2583	2581	Lascaux	
2584	2581	Périgueux	
2585	2580	Gironde	
2586	2585	Arcachon	
2587	2585	Bordeaux	équipe de football de la ville de Bordeaux
2588	2585	Bègles	
2589	2585	Gradignan	
2590	2585	Hourtin	
2591	2585	Lacanau	
2592	2585	Langon	
2593	2585	Libourne	
2594	2585	Médoc	
2595	2585	Mérignac	
2596	2585	Talence	
2597	2580	Landes	
2598	2597	Dax	
2599	2597	Mont-de-Marsan	
2600	2580	Lot-et-Garonne	
2601	2600	Agen	
2602	2600	Villeneuve-sur-Lot	
2603	2580	Pays basque français	
2604	2580	Pyrénées-Atlantiques	
2605	2604	Bayonne	
2606	2604	Biarritz	
2607	2604	Béarn	
2608	2604	Hendaye	
2609	2604	Lacq	
2610	2604	Orthez	
2611	2604	Pau	
2612	2604	Saint-Jean-de-Luz	
2613	2604	Somport	
2614	2580	Périgord	
2615	2572	Auvergne	
2616	2615	Allier	festival théatr
2617	2616	Montluçon	
2618	2616	Moulins	
2619	2616	Vichy (Allier)	
2620	2615	Cantal	
2621	2620	Aurillac	
2622	2615	Haute-Loire	
2623	2622	Le Puy	
2624	2615	Puy-de-Dôme	
2625	2624	Clermont-Ferrand	
2626	2624	Riom	
2627	2572	Bourgogne	
2628	2627	Côte-d'Or	
2629	2628	Beaune	
2630	2628	Dijon	
2631	2628	Saulieu	
2632	2628	Semur-en-Auxois	
2633	2627	Nièvre	
2634	2633	Château-Chinon	
2635	2633	Nevers	
2636	2627	Saône-et-Loire	
2637	2636	Autun	
2638	2636	Chalon-sur-Saône	
2639	2636	Gueugnon	
2640	2636	Montchanin	
2641	2636	Mâcon	
2642	2636	Solutré	
2643	2627	Yonne	
2644	2643	Auxerre	
2645	2643	Chablis	
2646	2643	Sens (Yonne)	
2647	2643	Vézelay	
2648	2572	Bretagne	
2649	2648	Côtes-d'Armor	
2650	2649	Guingamp	
2651	2649	Lannion	
2652	2649	Saint-Brieuc	
2653	2648	Finistère	
2654	2653	Brest	
2655	2653	Concarneau	
2656	2653	Douarnenez	
2657	2653	Landerneau	
2658	2653	Morlaix	
2659	2653	Ouessant	
2660	2653	Plouhinec	
2661	2653	Quimper	
2662	2653	Quimperlé	
2663	2648	Ille-et-Vilaine	
2664	2663	Dinard	
2665	2663	Redon	
2666	2663	Rennes	
2667	2663	Saint-Malo	
2668	2663	Vitré	
2669	2648	Morbihan	
2670	2669	Belle-Ile	
2671	2669	Lorient	
2672	2669	Pontivy	
2673	2669	Quiberon	
2674	2669	Trinité-sur-Mer	
2675	2669	Vannes	
2676	2572	Centre-Val-de-Loire	
2677	2676	Cher (département)	
2678	2677	Bourges	
2679	2677	Vierzon	
2680	2676	Eure-et-Loir	
2681	2680	Chartres	
2682	2680	Dreux	
2683	2676	Indre	
2684	2683	Argenton-sur-Creuse	
2685	2683	Châteauroux	
2686	2676	Indre-et-Loire	
2687	2686	Amboise	
2688	2686	Loches	
2689	2686	Tours	
2690	2676	Loir-et-Cher	
2691	2690	Blois	
2692	2676	Loiret	
2693	2692	Montargis	
2694	2692	Orléans	
2695	2572	Champagne-Ardenne	
2696	2695	Ardennes	
2697	2696	Charleville-Mézières	
2698	2695	Aube	
2699	2698	Troyes	
2700	2695	Haute-Marne	
2701	2700	Colombey-les-Deux-Eglises	
2702	2700	Saint-Dizier	
2703	2695	Marne	
2704	2703	Châlons-en-Champagne	
2705	2703	Epernay	
2706	2703	Mourmelon	
2707	2703	Reims	
2708	2572	Corse	
2709	2708	Corse-du-Sud	
2710	2709	Ajaccio	
2711	2709	Porto-Vecchio	
2712	2709	Sartène	
2713	2708	Haute-Corse	
2714	2713	Bastia	
2715	2713	Calvi	
2716	2713	Corte	
2717	2713	Furiani	
2718	2572	Départements d'Outre-Mer	
2719	2718	Antilles françaises	
2720	2719	Désirade	
2721	2719	Guadeloupe	
2722	2721	Pointe-à-Pitre	
2723	2721	Saint-Barthélémy (Guadeloupe)	
2724	2721	Saint-Martin (Guadeloupe)	
2725	2719	Martinique	
2726	2725	Fort-de-France	
2727	2718	Guyane	
2728	2727	Cayenne	ville de Guyane
2729	2718	Ile de la Réunion	
2730	2718	Saint-Pierre-et-Miquelon	
2731	2572	France	
2732	2731	Anjou	
2733	2731	Brie (région)	région
2734	2731	Dauphiné	
2735	2731	Larzac	
2736	2731	Morvan	
2737	2731	Provence	
2738	2731	Vercors	
2739	2731	Vexin	région située sur le Val-d'Oise et l'Oise
2740	2572	Franche-Comté	
2741	2740	Doubs	
2742	2741	Besançon	
2743	2741	Montbéliard	
2744	2741	Pontarlier	
2745	2741	Sochaux	
2746	2740	Haute-Saône	
2747	2746	Vesoul	
2748	2740	Jura	
2749	2748	Dole (Jura)	
2750	2748	Lons-le-Saunier	
2751	2748	Saint-Claude	
2752	2740	Territoire-de-Belfort	
2753	2752	Belfort	
2754	2572	Ile-de-France	
2755	2754	Essonne	
2756	2755	Arpajon	
2757	2755	Athis-Mons	
2758	2755	Brétigny-sur-Orge	
2759	2755	Corbeil-Essonnes	 
2760	2755	Draveil	
2761	2755	Epinay-sur-Orge	
2762	2755	Etampes	
2763	2755	Evry	
2764	2755	Fleury-Mérogis	
2765	2755	Grigny	
2766	2755	Juvisy-sur-Orge	
2767	2755	Les Ulis	
2768	2755	Longjumeau	
2769	2755	Massy	
2770	2755	Mennecy	
2771	2755	Montgeron	
2772	2755	Montlhéry	
2773	2755	Orsay (Essonne)	
2774	2755	Palaiseau	
2775	2755	Ris-Orangis	
2776	2755	Saclay	
2777	2755	Sainte-Geneviève-des-Bois	
2778	2755	Vigneux-sur-Seine	
2779	2755	Yerres	
2780	2754	Hauts-de-Seine	
2781	2780	Antony (Hts-de-Seine)	
2782	2780	Asnières-sur-Seine	
2783	2780	Bagneux	
2784	2780	Boulogne-Billancourt	
2785	2780	Chaville	
2786	2780	Châtenay-Malabry	
2787	2780	Châtillon	
2788	2780	Clamart	
2789	2780	Clichy (Hauts-de-Seine)	
2790	2780	Colombes	
2791	2780	Courbevoie	
2792	2780	Fontenay-aux-Roses	
2793	2780	Garches	
2794	2780	Garenne-Colombes (La)	
2795	2780	Gennevilliers	
2796	2780	Issy-les-Moulineaux	
2797	2780	La Défense	
2798	2797	La Grande Arche	
2799	2780	Le Plessis-Robinson	
2800	2780	Levallois-Perret	
2801	2780	Malakoff	
2802	2780	Meudon	
2803	2780	Montrouge	
2804	2780	Nanterre	
2805	2780	Neuilly-sur-Seine	
2806	2780	Puteaux	
2807	2780	Rueil-Malmaison	
2808	2780	Saint-Cloud	
2809	2780	Sceaux (Hauts-de-Seine)	
2810	2780	Suresnes	
2811	2780	Sèvres	
2812	2780	Villeneuve-la-Garenne	
2813	2754	Paris	
2814	2813	Bastille	
2815	2813	IIIe arrondissement	
2816	2813	IIe arrondissement	
2817	2813	IVe arrondissement	
2818	2813	IXe arrondissement	
2819	2813	Ier arrondissement	
2820	2819	Forum des Halles	
2821	2813	Montparnasse	
2822	2813	Petite Ceinture	
2823	2813	VIIIe arrondissement	
2824	2823	Champs-Elysées	
2825	2823	Place de la Concorde	
2826	2813	VIIe arrondissement	
2827	2826	rue du Bac	
2828	2813	VIe arrondissement	
2829	2828	rue du Dragon	
2830	2813	Ve arrondissement	
2831	2830	Port-Royal (Paris)	
2832	2813	XIIIe arrondissement	
2833	2832	Seine Rive Gauche	
2834	2813	XIIe arrondissement	
2835	2834	Bercy (salle)	
2836	2813	XIVe arrondissement	
2837	2813	XIXe arrondissement	
2838	2813	XIe arrondissement	
2839	2838	Charonne	
2840	2813	XVIIIe arrondissement	
2841	2840	Barbès	
2842	2840	Goutte-d'Or	
2843	2840	Montmartre	
2844	2840	Pigalle	
2845	2813	XVIIe arrondissement	
2846	2813	XVIe arrondissement	
2847	2846	Bagatelle	
2848	2813	XVe arrondissement	
2849	2848	Porte de Versailles	
2850	2813	XXe arrondissement	
2851	2850	Belleville (Paris)	
2852	2850	Ménilmontant	
2853	2850	Porte des Lilas	
2854	2813	Xe arrondissement	
2855	2813	place de l'Etoile	
2856	2754	Seine-Saint-Denis	
2857	2856	Aubervilliers	
2858	2856	Aulnay-sous-Bois	
2859	2856	Bagnolet	
2860	2856	Bobigny	
2861	2856	Bondy	
2862	2856	Clichy-sous-Bois	
2863	2856	Drancy	
2864	2856	Dugny	
2865	2856	Epinay-sur-Seine	
2866	2856	Gagny	
2867	2856	Gournay-sur-Marne	
2868	2856	Ile-Saint-Denis	
2869	2856	La Courneuve	
2870	2856	Le Blanc-Mesnil	
2871	2856	Le Bourget (commune)	
2872	2856	Le Raincy	
2873	2856	Les Lilas	
2874	2856	Montfermeil	
2875	2856	Montreuil (Seine-St-Denis)	
2876	2856	Neuilly-sur-Marne	
2877	2856	Noisy-le-Grand	
2878	2856	Noisy-le-Sec	
2879	2856	Pantin	
2880	2856	Plaine-Saint-Denis (la)	
2881	2856	Pré-Saint-Gervais (Le)	
2882	2856	Romainville	
2883	2856	Rosny-sous-Bois	
2884	2856	Saint-Denis	
2885	2856	Saint-Ouen	
2886	2856	Sevran	
2887	2856	Stains	
2888	2856	Tremblay-en-France	
2889	2856	Villepinte	
2890	2856	Villetaneuse	
2891	2754	Seine-et-Marne	
2892	2891	Barbizon	
2893	2891	Champs-sur-Marne	
2894	2891	Chelles	
2895	2891	Combs-la-Ville	
2896	2891	Fontainebleau	
2897	2891	Marne-la-Vallée	
2898	2891	Meaux	
2899	2891	Melun	
2900	2891	Melun-Sénart	
2901	2891	Montereau	
2902	2891	Noisiel	
2903	2891	Provins	
2904	2891	Roissy-en-Brie	
2905	2891	Torcy	
2906	2891	Val-Maubuée	
2907	2754	Val-d'Oise	
2908	2907	Argenteuil	
2909	2907	Auvers-sur-Oise	
2910	2907	Bezons	
2911	2907	Cergy	
2912	2907	Cormeilles-en-Parisis	
2913	2907	Deuil-la-Barre	
2914	2907	Eaubonne	
2915	2907	Enghien-les-Bains	
2916	2907	Garges-lès-Gonesse	
2917	2907	Gonesse	
2918	2907	Goussainville	
2919	2907	Isle-Adam (L')	
2920	2907	Montmorency	
2921	2907	Pontoise	
2922	2907	Roissy-en-France	
2923	2907	Saint-Leu-la-Forêt	
2924	2907	Saint-Ouen-l'Aumône	
2925	2907	Sannois	
2926	2907	Sarcelles	
2927	2907	Taverny	
2928	2907	Villiers-le-Bel	
2929	2754	Val-de-Marne	
2930	2929	Alfortville	
2931	2929	Arcueil	
2932	2929	Boissy-Saint-Léger	
2933	2929	Bonneuil-sur-Marne	
2934	2929	Bry-sur-Marne	
2935	2929	Cachan	
2936	2929	Champigny-sur-Marne	
2937	2929	Charenton-le-Pont	
2938	2929	Chennevières-sur-Marne	
2939	2929	Chevilly-Larue	
2940	2929	Choisy-le-Roi	
2941	2929	Créteil	
2942	2929	Fontenay-sous-Bois	
2943	2929	Fresnes	
2944	2929	Gentilly	
2945	2929	Haÿ-les-Roses (L')	
2946	2929	Ivry-sur-Seine	
2947	2929	Joinville-le-Pont	
2948	2929	Le Kremlin Bicêtre	
2949	2929	Limeil-Brévannes	
2950	2929	Maisons-Alfort	
2951	2929	Nogent-sur-Marne	
2952	2929	Orly	
2953	2929	Rungis	
2954	2929	Saint-Mandé	
2955	2929	Saint-Maur-des-Fossés	
2956	2929	Thiais	
2957	2929	Villejuif	
2958	2929	Villeneuve-Saint-Georges	
2959	2929	Villeneuve-le-Roi	
2960	2929	Vincennes	
2961	2929	Vitry-sur-Seine	
2962	2754	Val-de-Seine	
2963	2754	Yvelines	
2964	2963	Achères	
2965	2963	Beynes	
2966	2963	Carrières-sur-Seine	
2967	2963	Chanteloup-les-Vignes	
2968	2963	Chatou	
2969	2963	Chesnay (Le)	
2970	2963	Conflans-Sainte-Honorine	
2971	2963	Elancourt	
2972	2963	Flins	
2973	2963	Les Mureaux	
2974	2963	Louveciennes	
2975	2963	Maisons-Laffitte	
2976	2963	Mantes-la-Jolie	
2977	2976	Val-Fourré	
2978	2963	Mantes-la-Ville	
2979	2963	Marly-le-Roi	
2980	2963	Maurepas	
2981	2963	Poissy	
2982	2963	Rambouillet	
2983	2963	Saint-Cyr-l'Ecole	
2984	2963	Saint-Germain-en-Laye	
2985	2963	Saint-Quentin-en-Yvelines	
2986	2963	Sartrouville	
2987	2963	Trappes	
2988	2963	Vernouillet	
2989	2963	Versailles	
2990	2963	Vélizy-Villacoublay	
2991	2572	Languedoc-Roussillon	
2992	2991	Aude	
2993	2992	Carcassonne	
2994	2992	Castelnaudary	Chef-lieu du département de l'Aude
2995	2992	Limoux	
2996	2992	Narbonne	
2997	2991	Gard	
2998	2997	Alès	
2999	2997	Marcoule	
3000	2997	Nîmes	
3001	2997	Pont-Saint-Esprit	
3002	2997	Uzés	
3003	2991	Hérault	
3004	3003	Béziers	
3005	3003	Cap-d'Agde	
3006	3003	La Grande-Motte	
3007	3003	Montpellier	
3008	3003	Mèze	
3009	3003	Sète	
3010	2991	Lozère	
3011	3010	Mende	
3012	2991	Pyrénées-Orientales	
3013	3012	Argelès-sur-Mer	
3014	3012	Banyuls-sur-Mer	
3015	3012	Céret	
3016	3012	Perpignan	
3017	2572	Limousin	
3018	3017	Corrèze	
3019	3018	Brive-la-Gaillarde	
3020	3018	Tulle	
3021	3017	Creuse	
3022	3021	Aubusson	
3023	3021	Guéret	
3024	3017	Haute-Vienne	
3025	3024	Limoges	
3026	2572	Lorraine	
3027	3026	Meurthe-et-Moselle	
3028	3027	Lunéville	
3029	3027	Nancy	
3030	3027	Toul	
3031	3027	Vandoeuvre-lès-Nancy	
3032	3026	Meuse	
3033	3032	Bar-le-Duc	
3034	3032	Longwy	
3035	3032	Verdun	
3036	3026	Moselle	
3037	3036	Amnéville	
3038	3036	Creutzwald	
3039	3036	Forbach	
3040	3036	Metz	
3041	3036	Sarreguemines	
3042	3036	Thionville	
3043	3026	Vosges	
3044	3043	Contrexéville	
3045	3043	Epinal	
3046	3043	Gérardmer	
3047	3043	Remiremont	
3048	3043	Saint-Dié	
3049	3043	Vittel	
3050	2572	Midi-Pyrénées	
3051	3050	Ariège	
3052	3051	Foix	
3053	3050	Aveyron	
3054	3053	Millau	
3055	3053	Rodez	
3056	3053	Roquefort	
3057	3050	Gers	
3058	3057	Auch	
3059	3057	Marciac	
3060	3050	Haute-Garonne	
3061	3060	Blagnac	
3062	3060	Toulouse	
3063	3050	Hautes-Pyrénées	
3064	3063	Lourdes	
3065	3063	Tarbes	
3066	3050	Lot	
3067	3066	Cahors	
3068	3050	Tarn	
3069	3068	Albi	
3070	3068	Carmaux	
3071	3068	Castres	
3072	3050	Tarn-et-Garonne	
3073	3072	Montauban	
3074	2572	Nord-Pas-de-Calais	
3075	3074	Nord (département)	
3076	3075	Armentières	
3077	3075	Cambrai	
3078	3075	Douai	
3079	3075	Dunkerque	
3080	3075	Lille	
3081	3075	Marcq-en-Baroeul	
3082	3075	Maubeuge	
3083	3075	Roubaix	
3084	3075	Seclin	
3085	3075	Tourcoing	
3086	3075	Valenciennes	
3087	3075	Villeneuve-d'Ascq	
3088	3074	Pas-de-Calais	
3089	3088	Arras	
3090	3088	Boulogne-sur-mer	
3091	3088	Bruay-la-Bussière	
3092	3088	Béthune	
3093	3088	Calais	
3094	3088	Hénin-Beaumont	
3095	3088	Le Touquet	
3096	3088	Lens	
3097	3088	Liévin	
3098	2572	Normandie	
3099	3098	Basse-Normandie	
3100	3099	Calvados	
3101	3100	Bayeux	
3102	3100	Cabourg	
3103	3100	Caen	
3104	3100	Courson (Calvados)	
3105	3100	Deauville	
3106	3100	Honfleur	
3107	3100	Lisieux	
3108	3099	Manche (département)	
3109	3108	Avranches	
3110	3108	Chausey (îles)	
3111	3108	Cherbourg	
3112	3108	Granville	
3113	3108	La Hague	
3114	3108	Mont-Saint-Michel	
3115	3108	Saint-Lô	
3116	3099	Orne	
3117	3116	Alençon	
3118	3098	Haute-Normandie	
3119	3118	Eure	
3120	3119	Evreux	
3121	3119	Vernon	
3122	3118	Seine-Maritime	
3123	3122	Dieppe	
3124	3122	Fécamp	
3125	3122	Grand-Quevilly	
3126	3122	Le Havre	
3127	3122	Rouen	
3128	2572	Pays de la Loire	
3129	3128	Loire-Atlantique	
3130	3129	Ancenis	
3131	3129	La Baule	
3132	3129	Nantes	
3133	3129	Saint-Herblain	
3134	3129	Saint-Nazaire	
3135	3128	Maine-et-Loire	
3136	3135	Angers	
3137	3135	Cholet	
3138	3135	Saumur	
3139	3128	Mayenne	
3140	3139	Laval	
3141	3128	Sarthe	
3142	3141	Le Mans	
3143	3128	Vendée	
3144	3143	Ile d'Yeu	
3145	3143	Ile de Noirmoutier	
3146	3143	La Roche-sur-Yon	
3147	2572	Picardie	
3148	3147	Aisne	
3149	3148	Folembray	
3150	3148	Saint-Quentin (Aisne)	
3151	3148	Soissons	
3152	3147	Oise	village où se trouve un centre de l'Arche, spécialiste des malades mentaux
3153	3152	Beauvais	
3154	3152	Chantilly	
3155	3152	Compiègne	
3156	3152	Creil	
3157	3152	Montataire	
3158	3152	Noyon	
3159	3152	Senlis	
3160	3147	Somme	
3161	3160	Amiens	
3162	2572	Poitou-Charentes	
3163	3162	Charente	
3164	3163	Angoulême	
3165	3163	Cognac	
3166	3163	Jarnac	
3167	3162	Charente-Maritime	
3168	3167	Ile d'Oléron	
3169	3167	La Rochelle	
3170	3167	Rochefort	
3171	3167	Royan	
3172	3167	Saintes	
3173	3162	Deux-Sèvres	
3174	3173	Niort	
3175	3173	Parthenay	
3176	3162	Vienne (département)	
3177	3176	Châtellerault	
3178	3176	Poitiers	
3179	2572	Provence-Alpes-Côte d'Azur	
3180	3179	Alpes-Maritimes	
3181	3180	Antibes Juan-les-Pins	
3182	3180	Cannes	
3183	3180	Grasse	
3184	3180	Menton	
3185	3180	Nice	
3186	3180	Saint-Paul-de-Vence	
3187	3179	Alpes-de-Haute-Provence	
3188	3187	Castellane	
3189	3187	Digne	
3190	3187	Manosque	
3191	3187	Sisteron	
3192	3179	Bouches-du-Rhône	
3193	3192	Aix-en-Provence	
3194	3192	Arles	
3195	3192	Aubagne	
3196	3192	Cadarache	
3197	3192	Camargue	
3198	3192	Cassis	
3199	3192	Fos-sur-Mer	
3200	3192	Istres	
3201	3192	La Ciotat	
3202	3192	Marignane	
3203	3192	Marseille	
3204	3192	Martigues	
3205	3192	Miramas	
3206	3192	Salon-de-Provence	
3207	3192	Vitrolles	
3208	3179	Hautes-Alpes	
3209	3208	Briançon	
3210	3208	Gap (Htes-Alpes)	
3211	3179	Var	
3212	3211	Bormes-les-Mimosas	
3213	3211	Brignoles	
3214	3211	Draguignan	
3215	3211	Fort de Brégançon	
3216	3211	Fréjus	
3217	3211	Hyères	
3218	3211	Saint-Tropez	
3219	3211	Seyne-sur-mer	
3220	3211	Toulon	
3221	3220	Châteauvallon	
3222	3179	Vaucluse	
3223	3222	Avignon	
3224	3222	Carpentras	
3225	3222	Cavaillon	
3226	3222	Orange (Vaucluse)	
3227	3222	Plateau d'Albion	
3228	3222	Vaison-la-Romaine	
3229	2572	Rhône-Alpes	
3230	3229	Ain	
3231	3230	Bourg-en-Bresse	
3232	3229	Ardèche	
3233	3232	Annonay	
3234	3232	Aubenas	
3235	3232	Lussas	
3236	3232	Privas	
3237	3229	Drôme	
3238	3237	Montélimar	
3239	3237	Nyons	
3240	3237	Valence (Drôme)	
3241	3229	Haute-Savoie	
3242	3241	Annecy	
3243	3241	Annemasse	
3244	3241	Avoriaz	
3245	3241	Chamonix	
3246	3241	Evian	
3247	3241	La Clusaz	
3248	3229	Isère	
3249	3248	Alpe-d'Huez	
3250	3248	Autrans	
3251	3248	Bourgoin-Jallieu	
3252	3248	Chamrousse	
3253	3248	Creys-Malville	
3254	3248	Grenoble	
3255	3248	La Mure	
3256	3248	Vienne (Isère)	
3257	3229	Loire	
3258	3257	Roanne	
3259	3257	Saint-Etienne	
3260	3229	Rhône	
3261	3260	Lyon	
3262	3261	La Croix-Rousse	quartier/Lyon
3263	3260	Saint-Andéol	Commune du Rhône
3264	3260	Saint-Priest	
3265	3260	Vaulx-en-Velin	
3266	3260	Villefranche-sur-Saône	
3267	3260	Villeurbanne	
3268	3260	Vénissieux	
3269	3268	Minguettes	
3270	3229	Savoie	
3271	3270	Aix-les-Bains	
3272	3270	Chambéry	
3273	3270	Méribel-les-Allues	
3274	3270	Val-d'Isère	
3275	2572	Territoires d'Outre-Mer	
3276	3275	Kerguelen	
3277	3275	Mayotte	
3278	3275	Nouvelle-Calédonie	
3279	3278	Nouméa	
3280	3275	Polynésie française	
3281	3280	Fangataufa	atoll de Fangataufa
3282	3280	Iles Marquises	
3283	3280	Moruroa	
3284	3280	Tahiti	
3285	3284	Papeete	
3286	3275	Terre Adélie	
3287	3275	Wallis-et-Futuna	
3288	\N	Aménagement du territoire	
3289	3288	DIACT	
3290	3288	IAURIF	
3291	3288	circonscription territoriale	
3292	3291	arrondissement	
3293	3291	canton (circonscription)	
3294	3291	collectivité locale	
3295	3291	commune	
3296	3295	syndicat intercommunal	
3297	3291	département	
3298	3291	province	
3299	3291	région	
3300	3288	décentralisation	
3301	3288	relations Etat-collectivité locale	
3302	3301	Cadec (Caisse de développement de la Corse)	
3303	3288	schéma d'aménagement	
3304	3288	terrain	
3305	3304	cadastre	
3306	3304	sous-sol	
3307	3288	urbanisme	
3308	3307	banlieue	
3309	3308	cité	
3310	3308	quartier en difficulté	
3311	3310	régie de quartier	
3312	3307	bidonville	
3313	3307	friche industrielle	
3314	3307	mobilier urbain	
3315	3314	sanisette	
3316	3307	permis de construire	
3317	3307	planification urbaine	
3318	3317	Plan d'Occupation des Sols	
3319	3317	ZAC	
3320	3317	zone industrielle	
3321	3307	politique de la ville	
3322	3321	Conseil national des villes	
3323	3321	Délégation interministérielle à la Ville	
3324	3321	Solidarité et Renouvellement Urbain	
3325	3321	contrat de ville	
3326	3321	grand projet de ville	
3327	3321	pacte de relance pour la ville	
3328	3307	ville	
3329	3328	Etablissement public d'aménagement	
3330	3328	capitale	
3331	3328	centre ville	
3332	3328	quartier	
3333	3328	village	
3334	3328	ville nouvelle	
3335	3334	Syndicat d'agglomération nouvelle	
3336	3307	voirie	
3337	3336	rue	
3338	3288	équipement public	
3339	3338	aqueduc	
3340	3338	arène	
3341	3338	barrage hydraulique	
3342	3338	canal	
3343	3338	digue	
3344	3338	grands travaux	
3345	3338	infrastructure routière	
3346	3345	autoroute	
3347	3346	autoroute la Francilienne	
3348	3345	route	
3349	3345	voie rapide	
3350	3338	pont	
3351	3350	viaduc	
3352	3338	remontée mécanique	
3353	3338	tunnel	
3354	3338	égout	
3355	\N	Organisme international	
3356	3355	Amnesty International	
3357	3355	BERD	
3358	3355	Banque africaine de développement	
3359	3355	Banque asiatique de développement	
3360	3355	Banque des Règlements Internationaux	
3361	3355	CICR	
3362	3355	Conseil de sécurité	
3363	3355	FAO	
3364	3355	GIEC	 
3365	3355	Groupe des Huit	Groupe des Sept avec la Russie
3366	3355	Groupe des Sept	Sommet des chefs d'Etat ou de gouvernement des 7 premiers pays industriels occidentaux :AllemagneCanadaFranceGrande-BretagneItalieJaponUSA
3367	3355	OIT	
3368	3355	ONU	
3369	3368	Unesco	
3370	3355	OTAN	
3371	3355	Observatoire international des prisons	
3372	3355	PNUD	
3373	3355	UNICEF	
3374	\N	Défense	
3375	3374	Institut des hautes études de défense nationale	
3376	3374	armement	
3377	3376	Délégation générale pour l'armement	
3378	3376	armement bactériologique	
3379	3376	armement chimique	
3380	3379	gaz de combat	
3381	3376	armement conventionnel	
3382	3381	bombe	
3383	3381	char d'assaut Leclerc	
3384	3381	mine (arme)	
3385	3384	déminage	
3386	3384	mine antipersonnel	
3387	3381	obus	
3388	3376	armement non létal	
3389	3376	armement nucléaire	
3390	3389	bombe atomique	
3391	3389	essai nucléaire	
3392	3389	traité de non-prolifération nucléaire	
3393	3376	aviation militaire	
3394	3393	Eurofighter	
3395	3393	Mirage (avion militaire)	
3396	3393	Rafale	
3397	3393	avion de transport militaire	
3398	3393	hélicoptère militaire	
3399	3376	industrie de l'armement	
3400	3399	Direction des constructions navales	
3401	3399	Giat industries	
3402	3376	missile	
3403	3402	défense antimissile	
3404	3376	porte-avion	
3405	3376	sous-marin	
3406	3376	vente d'armes	
3407	3374	armée	
3408	3407	Casque bleu	
3409	3407	Dicod	
3410	3407	Force de Réaction Rapide	
3411	3407	Légion étrangère	
3412	3407	Marine nationale	
3413	3407	armée de l'air	
3414	3413	GAEL	
3415	3407	armée de métier	
3416	3407	armée de réserve	
3417	3407	armée de terre	
3418	3407	base militaire	
3419	3418	caserne	
3420	3407	commando	
3421	3407	défilé militaire	
3422	3407	force multinationale	
3423	3422	Forpronu	
3424	3422	IFOR	
3425	3424	Sfor	
3426	3422	brigades internationales	
3427	3422	force d'interposition	Position de non belligérant. Pour interposition pacifique.
3428	3407	personnel militaire	
3429	3428	ancien combattant	
3430	3428	commandement militaire	
3431	3430	général (armée)	
3432	3428	déserteur	
3433	3428	mercenaire	
3434	3428	soldat	
3435	3407	service national	
3436	3435	appelé du contingent	
3437	3435	service civil	
3438	3435	service national volontaire	
3439	3435	sursis d'incorporation	
3440	3407	école militaire	
3441	3374	défense européenne	
3442	3441	Agence européenne de l'armement	
3443	3441	Euroforces	
3444	3441	UEO	
3445	3374	désarmement	
3446	3374	politique de défense	
3447	3446	Secrétariat général de la Défense nationale	
3448	3446	coopération militaire	
3449	3446	intervention militaire	
3450	3446	loi de programmation militaire	
3451	3446	sécurité militaire	
3452	3451	secret défense	
3453	3374	services secrets	
3454	3453	CIA	
3455	3453	DGSE	
3456	3453	DST	
3457	3453	FSB	
3458	3453	Mossad	
3459	3453	Shin Beth	Service de sécurité israélien
3460	3453	espionnage	
3461	3460	contre espionnage	
3462	3453	renseignement militaire	
3463	3374	stratégie militaire	
3464	3463	Institut international des études statégiques	
3465	3463	manoeuvre militaire	
3466	3465	siège (opération militaire)	
3467	3463	occupation militaire	
3468	3467	territoires occupés	
3469	3463	offensive terrestre	
3470	3463	raid aérien	
3471	3470	bombardement	
3472	3463	redéploiement militaire	
3473	3463	zone d'exclusion aérienne	
3474	3463	zone de protection	
3475	3463	zone de sécurité	
3476	3463	zone démilitarisée	
3477	\N	Culture	
3478	3477	arts plastiques	
3479	3478	architecture	
3480	3479	architecte	
3481	3479	décoration intérieure	
3482	3479	paysagiste	
3483	3479	toit	
3484	3478	art	
3485	3484	art contemporain	
3486	3484	art digital	
3487	3484	art décoratif	
3488	3484	art primitif	
3489	3484	esthétique	
3490	3484	oeuvre d'art	
3491	3478	art graphique	
3492	3491	affiche	
3493	3491	bande dessinée	
3494	3493	manga	
3495	3491	dessin	
3496	3495	dessinateur	
3497	3491	gravure	
3498	3491	illustration	
3499	3491	infographie	
3500	3478	design	
3501	3478	marché de l'art	
3502	3478	peinture (art)	
3503	3502	expressionnisme	
3504	3502	fauvisme	
3505	3502	fresque	
3506	3502	impressionnisme	
3507	3502	pop art	
3508	3478	photographie	
3509	3508	agence photo	
3510	3509	Sygma	
3511	3509	agence Gamma	Agence photo
3512	3509	agence Magnum	
3513	3478	sculpture	
3514	3478	tapisserie	
3515	3478	vitrail	
3516	3477	cinéma	
3517	3516	cinéclub	
3518	3516	cinéma d'animation	
3519	3516	cinéma d'art et d'essai	
3520	3516	cinéma expérimental	
3521	3516	cinéma fantastique	
3522	3516	cinéma indépendant	
3523	3516	cinéma muet	
3524	3516	cinéma policier	
3525	3516	exploitation cinématographique	
3526	3516	film	
3527	3526	court métrage	
3528	3526	film d'aventure	
3529	3526	filmographie	
3530	3526	moyen métrage	
3531	3526	western	
3532	3516	nouvelle vague	
3533	3516	prix cinématographique	
3534	3533	César (cinéma)	
3535	3533	Oscars	
3536	3533	prix Louis-Delluc	
3537	3516	production cinématographique	
3538	3516	technique cinématographique	
3539	3538	colorisation	
3540	3538	effets spéciaux	
3541	3538	studio de cinéma	
3542	3538	tournage	
3543	3477	danse	
3544	3543	chorégraphie	
3545	3544	Centre chorégraphique national	
3546	3543	compagnie de danse	
3547	3543	danse classique	
3548	3543	danse contemporaine	
3549	3543	flamenco	
3550	3543	tango	
3551	3477	institution culturelle	
3552	3551	Association des réalisateurs producteurs	
3553	3551	Centre national de création et de diffusion culturelle	
3554	3551	Centre national de la cinématographie	
3555	3551	Direction des musées de France	
3556	3551	IMEC	
3557	3551	Ifcic	
3558	3551	Institut Lumière	
3559	3551	Institut de France	
3560	3559	Académie Française	
3561	3559	Académie des Sciences	
3562	3559	Académie des sciences morales et politiques	
3563	3551	Parlement international des écrivains	
3564	3551	SACD	
3565	3551	Sacem	
3566	3551	Société des gens de lettres	
3567	3551	Société des réalisateurs de films	
3568	3551	Syndeac	
3569	3551	commission d'avances sur recettes	
3570	3477	langage	
3571	3570	grammaire	
3572	3570	injure	
3573	3570	langue des signes	
3574	3570	langue française	
3575	3570	langue régionale	
3576	3570	langue étrangère	
3577	3576	yiddish	
3578	3570	linguistique	
3579	3570	sémantique	
3580	3570	traduction	
3581	3570	vocabulaire	
3582	3570	écriture	
3583	3582	orthographe	
3584	3477	littérature	
3585	3584	genre littéraire	
3586	3585	autobiographie	
3587	3585	conte	
3588	3585	correspondance (genre littéraire)	
3589	3585	essai (genre littéraire)	
3590	3585	feuilleton littéraire	
3591	3585	journal (genre littéraire)	
3592	3585	nouvelle (genre littéraire)	
3593	3585	roman	
3594	3593	roman policier	
3595	3585	récit d'aventure	
3596	3585	science fiction	
3597	3584	lecture	
3598	3597	lectorat	
3599	3584	littérature classique	
3600	3584	littérature fantastique	
3601	3584	littérature pour la jeunesse	
3602	3584	poésie	
3603	3584	prix littéraire	
3604	3603	prix Femina	
3605	3603	prix Goncourt	
3606	3603	prix Interallié	
3607	3603	prix Médicis	
3608	3603	prix Renaudot	
3609	3603	prix Sakharov	
3610	3584	écrivain	
3611	3610	atelier d'écriture	
3612	3610	écrivain public	
3613	3477	musique	
3614	3613	Victoires de la musique	
3615	3613	chanson	
3616	3615	chanson française	
3617	3615	karaoké	
3618	3613	enregistrement sonore	
3619	3618	Midem	
3620	3618	Syndicat national de l'édition phonographique	
3621	3618	discographie	
3622	3618	label musical	
3623	3618	studio d'enregistrement	
3624	3613	instrument de musique	
3625	3624	accordéon	
3626	3624	guitare	
3627	3624	instrument à percussion	
3628	3624	piano	
3629	3624	saxophone	
3630	3624	violon	
3631	3624	violoncelle	
3632	3613	jazz	
3633	3632	blues	
3634	3632	funk	
3635	3632	soul	
3636	3613	musicien	
3637	3636	chanteur	
3638	3636	compositeur	
3639	3636	disc-jockey	
3640	3613	musique baroque	
3641	3613	musique classique	
3642	3613	musique contemporaine	
3643	3613	musique de chambre	
3644	3613	musique de film	
3645	3613	musique religieuse	
3646	3613	musique vocale	
3647	3613	opéra	
3648	3647	Opéra de Paris	
3649	3648	Opéra Bastille	
3650	3648	palais Garnier	
3651	3613	opérette	
3652	3613	orchestre	
3653	3652	Orchestre de France	
3654	3652	Orchestre de Paris	
3655	3652	chef d'orchestre	
3656	3613	style musical	
3657	3656	country	
3658	3656	folk	
3659	3656	metal (musique)	
3660	3656	rock	
3661	3660	dance music	
3662	3660	disco	
3663	3660	hard rock	
3664	3660	house music	
3665	3660	new-wave	
3666	3660	pop	
3667	3660	punk	
3668	3656	techno (musique)	
3669	3656	world music	
3670	3669	fado	
3671	3669	groove	genre musical
3672	3669	hip-hop	
3673	3669	raggamuffin	
3674	3669	rap	
3675	3669	raï (musique)	
3676	3669	reggae	
3677	3669	rumba	
3678	3669	salsa	musique
3679	3669	samba	
3680	3477	patrimoine culturel	
3681	3680	antiquités	
3682	3680	archives	
3683	3682	Archives nationales	
3684	3680	archéologie	
3685	3684	archéologie sous-marine	
3686	3684	art préhistorique	
3687	3684	momie	
3688	3684	pyramide	
3689	3680	dépôt légal	
3690	3680	folklore	
3691	3680	monument commémoratif	
3692	3680	monument historique	
3693	3692	Arc de Triomphe	
3694	3692	Centre des monuments nationaux	
3695	3692	Panthéon	
3696	3692	château	
3697	3692	tour Eiffel	
3698	3680	protection du patrimoine	
3699	3680	restauration d'art	
3700	3477	théâtre	
3701	3700	compagnie théâtrale	
3702	3700	salle de théâtre	
3703	3702	Berliner Ensemble	
3704	3702	Bolchoï	
3705	3702	Comédie Française	
3706	3702	Théâtre de Chaillot	
3707	3702	Théâtre des Champs-Elysées	
3708	3702	Théâtre du Châtelet	
3709	3702	Théâtre du Soleil	
3710	3700	théâtre national	
3711	3477	variétés	
3712	3711	cirque	
3713	3712	Cirque d'Hiver	
3714	3712	clown	
3715	3711	magie	
3716	3711	marionnette	
3717	3711	music-hall	
3718	3477	vie culturelle	
3719	3718	activité artistique	
3720	3719	artiste	
3721	3719	auteur	
3722	3719	collection d'oeuvre d'art	
3723	3719	conservateur d'art	
3724	3719	décor de spectacle	
3725	3719	métier d'art	
3726	3719	professionnel du spectacle	
3727	3726	comédien	
3728	3727	comédien de complément	
3729	3727	doublage	
3730	3726	metteur en scène	
3731	3726	réalisateur	
3732	3719	scénario	
3733	3719	scénographie	
3734	3718	commémoration	
3735	3734	anniversaire	
3736	3734	bicentenaire	
3737	3734	centenaire	
3738	3734	cinquantenaire	
3739	3734	hommage	
3740	3718	concert	
3741	3718	exposition	
3742	3741	Exposition universelle	
3743	3741	biennale	
3744	3718	festival	
3745	3744	Eurockéennes	
3746	3744	Eurovision (concours)	festival annuel de la chanson en Europe
3747	3744	Foire internationale d'art contemporain	
3748	3744	Francofolies	festival de la chanson francophone à La Rochelle
3749	3744	festival d'automne	
3750	3744	festival off	
3751	3718	genre artistique	
3752	3751	adaptation artistique	
3753	3751	album	
3754	3751	anthologie	
3755	3751	caricature	
3756	3751	clip	
3757	3751	comédie (genre artistique)	
3758	3751	documentaire	
3759	3751	oeuvre intégrale	
3760	3751	portrait (genre artistique)	
3761	3751	première oeuvre	
3762	3751	remake	
3763	3718	journée porte ouverte	
3764	3718	mouvement artistique	
3765	3764	Fluxus	
3766	3764	beat génération	
3767	3764	dadaïsme	
3768	3764	romantisme	
3769	3764	situationnisme	
3770	3764	surréalisme	
3771	3718	mécénat	
3772	3718	politique culturelle	
3773	3772	acquisition d'oeuvre d'art	
3774	3772	exception culturelle	
3775	3772	prêt (oeuvre culturelle)	
3776	3718	public	
3777	3718	rave	
3778	3718	spectacle	
3779	3778	box-office	
3780	3778	comédie musicale	
3781	3778	mime	
3782	3778	spectacle comique	
3783	3778	spectacle de rue	
3784	3778	spectacle itinérant	
3785	3778	tournée	
3786	3778	tragédie	
3787	3477	édition	
3788	3787	Syndicat National de l'Edition	
3789	3787	collection d'édition	
3790	3787	inédit	
3791	3787	librairie	
3792	3791	bouquiniste	
3793	3787	livre	
3794	3793	best seller	
3795	3793	livre blanc	
3796	3793	livre d'art	
3797	3796	catalogue d'exposition	
3798	3793	livre de poche	
3799	3793	manuscrit	
3800	3787	maison d'édition	
3801	3800	Albin Michel	maison d'édition
3802	3800	Autrement (édition)	revue de collection thématique
3803	3800	Casterman	
3804	3800	Dargaud	
3805	3800	Fayard	
3806	3800	Flammarion	
3807	3800	France-Loisirs	
3808	3800	Gallimard	
3809	3808	Série Noire	
3810	3800	Grasset	
3811	3800	Groupe de la Cité	
3812	3800	Hachette Livre	
3813	3800	Hatier	
3814	3800	Julliard (Edition)	
3815	3800	Le Seuil	
3816	3800	Marabout (édition)	éditions
3817	3800	Mercure de France	
3818	3800	Michel Lafon (édition)	
3819	3800	Milan (édition)	
3820	3800	Mille et une nuits (édition)	Entreprises
3821	3800	Nathan	
3822	3800	Nouvelle Revue Française	
3823	3800	Presses Universitaires de France	
3824	3800	Robert Laffont	
3825	3787	texte intégral	
3826	3787	édition à compte d'auteur	
3827	3787	édition électronique	
3828	3477	équipement culturel	
3829	3828	FRAC	
3830	3828	auditorium	
3831	3828	bibliothèque	
3832	3831	Bibliothèque Nationale de France	
3833	3831	bibliothèque municipale	
3834	3828	cabaret	
3835	3828	centre culturel	
3836	3835	American Center	
3837	3835	Centre Beaubourg	musée national d'art moderne
3838	3835	IRCAM	
3839	3835	La Villette	
3840	3839	Cité de la musique	
3841	3839	Cité des sciences et de l'industrie	
3842	3828	cinémathèque	
3843	3842	Cinémathèque française	
3844	3828	conservatoire (culture)	
3845	3828	discothèque	
3846	3828	galerie d'art	
3847	3828	musée	
3848	3847	Institut du monde arabe	
3849	3847	Maison européenne de la photographie	
3850	3847	Metropolitan Museum of Art	
3851	3847	Museum of modern art	
3852	3847	Musée Carnavalet	
3853	3847	Musée Guggenheim	
3854	3847	Musée d'Art moderne	
3855	3847	Musée d'Orsay	
3856	3847	Musée de l'Homme	
3857	3847	Musée des Arts décoratifs	
3858	3847	Musée du Grand Palais	
3859	3847	Musée du Louvre	
3860	3847	Musée du Prado	
3861	3847	Muséum d'histoire naturelle	
3862	3847	National Gallery of Art	
3863	3828	médiathèque	
3864	3828	salle de spectacle	
3865	3864	Mutualité (salle)	
3866	3864	Olympia	
3867	3864	Zénith (salle de spectacle)	
3868	3864	palais des Congrès	
3869	3828	salle multiplexe	
3870	3828	vidéothèque	
3871	\N	ZZZZ_Science et technologie	
3872	3871	astronomie	
3873	3872	Organisation européenne pour l'astronomie	
3874	3872	astrophysique	
3875	3872	comète	
3876	3872	galaxie	
3877	3872	météorite	
3878	3872	planète (astronomie)	
3879	3878	Jupiter	
3880	3878	Mars (planète)	
3881	3878	Saturne	
3882	3878	Terre (planète)	
3883	3878	astéroïde	
3884	3878	lune	
3885	3878	soleil	
3886	3885	système solaire	
3887	3885	éclipse	
3888	3872	télescope	
3889	3872	étoile	
3890	3871	espace (cosmos)	
3891	3890	arrimage spatial	
3892	3890	astronaute	
3893	3890	lanceur spatial	
3894	3893	fusée Ariane 4	
3895	3893	fusée Ariane 5	
3896	3890	navette spatiale	
3897	3896	Soyouz	
3898	3896	navette Atlantis	
3899	3896	navette Discovery	
3900	3890	politique spatiale	
3901	3900	Agence spatiale européenne	
3902	3900	CNES	
3903	3900	NASA	
3904	3890	satellite d'observation	
3905	3904	satellite Hélios	
3906	3890	sonde spatiale	
3907	3890	station spatiale	
3908	3907	station Mir	
3909	3890	télescope spatial	
3910	3909	télescope Hubble	
3911	3909	télescope ISO	
3912	3890	univers	
3913	3912	trou noir	
3914	3871	matière (substance)	
3915	3914	antimatière	
3916	3914	atome	
3917	3914	gaz	
3918	3917	gaz carbonique	
3919	3917	hydrogène	
3920	3917	oxygène	
3921	3917	ozone	
3922	3914	molécule	
3923	3914	particule élémentaire	
3924	3923	accélérateur de particule	
3925	3871	phénomène naturel	
3926	3871	phénomène paranormal	
3927	3926	extraterrestre	
3928	3926	ovni	
3929	3871	recherche scientifique	
3930	3929	expérience (expérimentation)	
3931	3930	simulation	
3932	3929	expérimentation animale	
3933	3929	laboratoire scientifique	
3934	3929	politique de la recherche	
3935	3934	Anvar	
3936	3934	CNRS	
3937	3934	Observatoire des sciences et techniques	
3938	3929	programme scientifique	
3939	3871	science	
3940	3939	chimie	
3941	3939	mathématiques	
3942	3941	algèbre	
3943	3941	géométrie	
3944	3941	mode de calcul	
3945	3941	numérotation	
3946	3939	mesure scientifique	
3947	3946	dimension	
3948	3946	durée	
3949	3948	horaire	
3950	3946	miniaturisation	
3951	3946	système métrique	
3952	3946	température	
3953	3952	chaleur	
3954	3952	froid	
3955	3946	vitesse	
3956	3939	physique	
3957	3956	acoustique	
3958	3957	son	
3959	3956	gravitation	
3960	3959	apesanteur	
3961	3956	lumière	
3962	3961	couleur	
3963	3956	magnétisme	
3964	3956	onde électromagnétique	
3965	3964	laser	
3966	3964	ultraviolet	
3967	3956	physique nucléaire	
3968	3967	Cern	
3969	3956	radioactivité	
3970	3956	supraconductivité	
3971	3939	scientifique	
3972	3939	théorie scientifique	
3973	3871	sciences naturelles	
3974	3973	botanique	
3975	3973	sciences de la terre	
3976	3975	dérive des continents	
3977	3975	géologie	
3978	3977	paléontologie	
3979	3978	fossile	
3980	3975	géophysique	
3981	3980	glaciation	
3982	3980	hydrologie	
3983	3975	météorologie	
3984	3983	Météo France	
3985	3983	gelée	
3986	3983	neige	
3987	3983	pluie	
3988	3983	vent	
3989	3975	océanographie	étude de ce qu'il y a DANS les océans, mers etc...
3990	3975	spéléologie	
3991	3973	zoologie	
3992	3991	entomologie	
3993	3871	technologie	
3994	3993	aide technique	
3995	3993	cybernétique	
3996	3993	domotique	
3997	3993	essai technique	
3998	3993	informatique	
3999	3998	base de données	
4000	3998	identifiant	
4001	3998	intelligence artificielle	
4002	3998	interactivité	
4003	3998	logiciel	
4004	4003	logiciel de navigation	
4005	4003	moteur de recherche	
4006	4005	Google	
4007	4005	Yahoo	
4008	3998	modem	
4009	3998	numérisation	
4010	3998	ordinateur	
4011	4010	superordinateur	
4012	3998	reconnaissance vocale	
4013	3998	réseau informatique	
4014	3998	serveur informatique	
4015	3998	système d'exploitation	
4016	4015	Windows	
4017	3998	téléchargement	
4018	3993	innovation technologique	
4019	4018	prototype	
4020	3993	nouvelle technologie	
4021	3993	robotique	
4022	3993	transfert de technologie	
4023	\N	Communication	
4024	4023	audiovisuel	
4025	4024	image	
4026	4025	3D	
4027	4025	image de synthèse	
4028	4025	réalité virtuelle	
4029	4024	politique audiovisuelle	
4030	4029	CSA (audiovisuel)	
4031	4029	Festival International des Programmes Audiovisuels	
4032	4029	Institut National de l'Audiovisuel	
4033	4029	ORTF	
4034	4029	Union européenne de radiodiffusion	
4035	4029	audiovisuel public	
4036	4024	production audiovisuelle	
4037	4036	Capa Presse	
4038	4036	Réservoir Prod	
4039	4036	Société Française de Production	
4040	4024	équipement audiovisuel	
4041	4040	antenne parabolique	
4042	4040	camescope	
4043	4040	caméra	
4044	4040	disque (musique)	
4045	4044	compact disc	
4046	4040	décodeur	
4047	4040	magnétoscope	
4048	4040	technique audiovisuelle	
4049	4040	vidéo	
4050	4049	vidéocassette	
4051	4049	vidéodisque	
4052	4040	écran	
4053	4023	documentation	
4054	4053	Documentation française	
4055	4053	document	
4056	4055	annuaire	
4057	4055	bibliographie	
4058	4055	dictionnaire	
4059	4055	fichier	
4060	4055	guide pratique	
4061	4023	information	
4062	4061	Journal officiel	
4063	4061	campagne d'information	
4064	4061	communiqué	
4065	4061	conférence de presse	
4066	4061	diffusion	
4067	4066	Diffusion contrôle	
4068	4061	déclaration	
4069	4068	aveu	
4070	4068	promesse	
4071	4068	révélation	
4072	4061	image de marque	
4073	4061	journalisme	
4074	4073	Centre de formation et de perfectionnement des journalistes	
4075	4073	Reporters sans frontières	
4076	4073	direction de la rédaction	
4077	4073	société des journalistes	
4078	4061	liberté de l'information	
4079	4078	censure	
4080	4078	droit de réponse	
4081	4078	désinformation	
4082	4078	propagande	
4083	4061	manifeste	
4084	4061	message	
4085	4084	cryptage	
4086	4061	média	
4087	4061	petite annonce	
4088	4061	publication	
4089	4061	pétition	
4090	4061	rumeur	
4091	4061	signalétique	
4092	4061	veille technologique	
4093	4061	visioconférence	
4094	4023	multimédia	
4095	4094	CD Rom	
4096	4094	Compact Disc Interactif	
4097	4094	Digital Versatile Disc	
4098	4094	Internet	
4099	4098	Isoc (Internet Society)	
4100	4098	blog	
4101	4098	courrier électronique	
4102	4098	forum de discussion	
4103	4098	fournisseur d'accès	
4104	4103	America Online	
4105	4103	CompuServe	
4106	4103	Infonie	
4107	4103	Microsoft Network	
4108	4103	Wanadoo	
4109	4098	intranet	
4110	4098	messagerie instantanée	
4111	4098	site en ligne	
4112	4098	terminal internet	
4113	4094	Marché international de l'édition et des nouveaux médias	
4114	4094	Société civile des auteurs multimédia	
4115	4094	lien hypertexte	
4116	4023	presse écrite	
4117	4116	Syndicat de la presse quotidienne nationale	
4118	4116	World Media	
4119	4116	agence de presse	
4120	4119	AFP	
4121	4119	Reuters	
4122	4116	magazine (presse)	
4123	4116	presse de rue	
4124	4116	presse gratuite	
4125	4116	presse hebdomadaire	
4126	4125	Canard Enchaîné	
4127	4125	Charlie Hebdo	
4128	4125	Courrier international	
4129	4125	Elle (magazine)	
4130	4125	Evénement du jeudi	
4131	4125	Figaro magazine (Le)	
4132	4125	France Dimanche	
4133	4125	Groupe Express-Expansion	
4134	4133	Express (L')	
4135	4125	Inrockuptibles (Les)	
4136	4125	Journal du dimanche	
4137	4125	Marianne (presse)	
4138	4125	New Yorker	
4139	4125	Nouvel Economiste	
4140	4125	Nouvel Observateur (Le)	
4141	4125	Paris-Match	
4142	4125	Point (Le)	
4143	4125	Spiegel (Der)	
4144	4125	Sunday Times	
4145	4125	Tribune juive	
4146	4125	Voici	
4147	4116	presse locale	
4148	4116	presse mensuelle	
4149	4148	Monde diplomatique (Le)	
4150	4148	Playboy	
4151	4148	Temps Modernes	
4152	4116	presse quotidienne	
4153	4152	Croix (La)	
4154	4152	Echos (Les)	
4155	4152	El País	
4156	4152	Equipe (L')	
4157	4152	Figaro (Le)	
4158	4152	France-Soir	
4159	4152	Guardian (The)	
4160	4152	Humanité (L')	
4161	4152	Independent (The)	
4162	4152	InfoMatin	
4163	4152	International Herald Tribune	
4164	4152	Libération (journal)	
4165	4152	Monde (Le)	
4166	4152	New York Times	
4167	4152	Parisien (Le)	
4168	4152	Quotidien de Paris	
4169	4152	Times (The)	
4170	4152	Tribune (La)	
4171	4152	Wall Street Journal	
4172	4152	Washington Post	
4173	4116	presse régionale	
4174	4173	Dauphiné libéré	
4175	4173	Dernières Nouvelles d'Alsace	
4176	4173	Dépêche du Midi	
4177	4173	Est Républicain (L')	
4178	4173	Midi libre	
4179	4173	Nice-Matin	entreprises n
4180	4173	Ouest France	
4181	4173	Progrès (Le)	
4182	4173	Provence (La) (journal)	
4183	4173	Provençal (Le)	
4184	4173	Voix du Nord (la)	
4185	4116	presse spécialisée	
4186	4185	Capital (magazine)	
4187	4185	Economist (The)	
4188	4185	Entrevue (magazine)	
4189	4185	Financial Times (The)	
4190	4185	Golias	
4191	4185	Jalons	
4192	4185	Première (magazine)	
4193	4185	Quotidien du médecin	
4194	4185	Télé 7 jours	
4195	4185	Télé Star	
4196	4185	Télérama	
4197	4116	presse trimestrielle	
4198	4023	presse électronique	
4199	4023	publicité	
4200	4199	Bureau de vérification de la publicité	
4201	4199	agence de publicité	
4202	4201	BDDP	
4203	4201	Euro-RSCG	
4204	4201	Publicis	
4205	4199	infomercial	
4206	4199	publicité comparative	
4207	4199	publicité mensongère	
4208	4199	spot publicitaire	
4209	4023	radio	
4210	4209	Sofirad	
4211	4209	ZZZZ_stations radiophoniques (liste)	
4212	4211	BFM	Radio d'information économique
4213	4211	Eiffel 95.2	
4214	4211	Europe 1	
4215	4211	Europe 2	
4216	4211	Fun Radio	
4217	4211	NRJ	
4218	4211	Ouï FM	
4219	4211	RFM	radio privée
4220	4211	RMC Info	
4221	4211	RTL	
4222	4221	RTL 1	programme remplacant M40 sur la CLT
4223	4221	RTL 2	
4224	4211	Radio Classique	
4225	4211	Radio France	
4226	4225	France Culture	
4227	4225	France Info	
4228	4225	France Inter	
4229	4225	France Inter Paris	
4230	4225	France Musiques	
4231	4225	RFO	
4232	4225	Radio Bleue	
4233	4225	Radio France Internationale	
4234	4211	Radio Libertaire	
4235	4211	Radio Nostalgie	
4236	4211	Radio Nova	
4237	4211	Skyrock	
4238	4211	Sport O'FM	
4239	4211	Sud Radio	
4240	4209	animateur radio	
4241	4209	bande FM	
4242	4209	programme de radio	
4243	4209	radio locale	
4244	4209	radio numérique	
4245	4209	radio privée	
4246	4209	radio thématique	
4247	4209	émission radiophonique	
4248	4247	auditeur	
4249	4247	feuilleton radiophonique	
4250	4023	télécommunication	
4251	4250	CNET	
4252	4250	opérateur de service	
4253	4250	réseau de télécommunication	
4254	4253	Numéris	réseau numérique à intégration de service baptisé Numéris en France
4255	4253	autoroute de l'information	
4256	4253	fibre optique	
4257	4253	réseau câblé	
4258	4257	câblo opérateur	
4259	4253	réseau hertzien	
4260	4253	transmission à haut débit	
4261	4250	satellite de télécommunication	
4262	4261	Eutelsat	
4263	4261	satellite Astra	
4264	4261	système Galileo	
4265	4250	télécopie	
4266	4250	télématique	
4267	4266	minitel	
4268	4267	messagerie rose	
4269	4250	téléphone	
4270	4269	call back	
4271	4269	numéro vert	
4272	4269	radiomessagerie	
4273	4269	téléphone mobile	
4274	4269	téléphone sans fil	
4275	4269	visiophone	
4276	4023	télévision	
4277	4276	TDF	
4278	4276	TVHD	
4279	4276	Télévision sans Frontières	
4280	4276	animateur de télévision	
4281	4276	chaîne de télévision	
4282	4281	ZZZZ_chaîne de télévision (liste)	
4283	4282	ARD (télévision)	
4284	4282	Arte	
4285	4282	Bloomberg TV	
4286	4282	CBS (TV)	
4287	4282	Canal J	
4288	4282	Canal Jimmy	
4289	4282	Canal Plus	
4290	4289	CanalSatellite	
4291	4282	Euronews	
4292	4282	France 24	 
4293	4282	France Télévisions	
4294	4293	France 2	
4295	4293	France 3	
4296	4293	France 4	 
4297	4293	France 5	
4298	4282	I-Télévision	
4299	4282	LCI	chaîne de télévision câblée
4300	4282	M6	
4301	4282	MCM	chaîne musicale câblée
4302	4282	Monte-Carlo-TMC	
4303	4282	Paris Première	
4304	4282	Planète (chaîne de télévision)	
4305	4282	Première (chaîne TV)	
4306	4282	RAI (télévision italienne)	
4307	4282	RTL 9	nouveau nom pour la chaîne RTL-TV
4308	4282	Série Club	
4309	4282	TF1	
4310	4282	TV5	
4311	4282	TéléFrance international	
4312	4281	chaîne locale	
4313	4281	chaîne thématique	
4314	4281	chaîne à péage	
4315	4276	programme de télévision	
4316	4315	Mip TV	
4317	4276	télévision en relief	
4318	4276	télévision numérique	
4319	4318	télévision numérique terrestre	
4320	4276	émission de télévision	
4321	4320	7 d'Or	
4322	4320	Téléthon	
4323	4320	jeu télévisé	
4324	4320	journal télévisé	
4325	4320	magazine télévisé	
4326	4320	reality show	
4327	4320	retransmission	
4328	4320	série télévisée	
4329	4320	téléfilm	
4330	4320	téléspectateur	
4331	\N	Santé	
4332	4331	biologie	
4333	4332	bactérie	
4334	4332	biométrie	
4335	4332	biotechnologie	
4336	4332	bioéthique	
4337	4336	eugénisme	
4338	4332	génétique	
4339	4338	génome	
4340	4339	ADN	
4341	4339	carte génétique	
4342	4339	cellule (biologie)	
4343	4342	ovule	
4344	4342	spermatozoïde	
4345	4339	chromosome	
4346	4339	empreinte génétique	
4347	4339	hérédité	
4348	4338	manipulation génétique	
4349	4332	hormone	
4350	4349	hormone de croissance	
4351	4332	immunologie	
4352	4332	neurobiologie	
4353	4332	prion	
4354	4353	ESB	
4355	4332	reproduction des espèces	
4356	4332	rythme biologique	
4357	4332	évolution biologique	
4358	4357	clone	
4359	4331	corps humain	
4360	4359	appareil génital	
4361	4359	cerveau	
4362	4359	cheveu	
4363	4359	coeur	
4364	4359	crâne	
4365	4359	dentition	
4366	4359	dos	
4367	4359	main	
4368	4359	oeil	
4369	4359	oreille	
4370	4359	ossature	
4371	4359	peau	
4372	4359	pied	
4373	4359	rein	
4374	4359	sang	
4375	4374	appareil circulatoire	
4376	4359	sein	
4377	4359	sens corporel	
4378	4377	goût	
4379	4377	odeur	
4380	4359	système digestif	
4381	4359	système immunitaire	
4382	4359	système nerveux	
4383	4382	neurone	
4384	4359	thyroïde	
4385	4331	fonctionnement corporel	
4386	4385	coma	
4387	4385	douleur	
4388	4385	hygiène	
4389	4385	mutilation corporelle	
4390	4389	amputation	
4391	4389	circoncision	
4392	4389	mutilation sexuelle	
4393	4392	excision	
4394	4385	ménopause	
4395	4385	sommeil	
4396	4395	hypnose	
4397	4395	rêve	
4398	4385	stérilité	
4399	4331	institution médicale	
4400	4399	Centre national de transfusion sanguine	
4401	4399	Comité d'éthique	
4402	4399	Credes	
4403	4399	Direction générale de la santé	
4404	4399	FDA	
4405	4399	Haut comité de la santé publique	
4406	4399	Inserm	
4407	4399	Institut Pasteur	
4408	4399	OMS	organisme humanitaire dépendant de l'ONU
4409	4331	maladie	
4410	4409	allergie	
4411	4409	cancer	
4412	4411	Association de recherche sur le cancer	
4413	4409	contamination	
4414	4409	diabète	
4415	4409	infection nosocomiale	
4416	4409	intoxication	
4417	4416	intoxication alimentaire	
4418	4416	saturnisme	
4419	4409	maladie cardio-vasculaire	
4420	4419	cholestérol	
4421	4419	infarctus	
4422	4409	maladie de peau	
4423	4409	maladie du sang	
4424	4423	hémophilie	
4425	4423	leucémie	
4426	4409	maladie gastro-intestinale	
4427	4426	hépatite	
4428	4409	maladie génétique	
4429	4428	mucoviscidose	
4430	4428	trisomie	
4431	4409	maladie infantile	
4432	4409	maladie infectieuse	
4433	4432	choléra	
4434	4432	grippe	
4435	4432	listériose	bactérie
4436	4432	lèpre	
4437	4432	méningite	
4438	4432	poliomyélite	
4439	4432	tuberculose	
4440	4409	maladie neurologique	
4441	4440	dépression nerveuse	
4442	4440	maladie d'Alzheimer	
4443	4440	maladie de Creutzfeldt-Jakob	
4444	4440	maladie de Parkinson	
4445	4440	stress	
4446	4440	épilepsie	
4447	4409	maladie neuromusculaire	
4448	4447	myopathie	
4449	4409	maladie parasitaire	
4450	4449	paludisme	
4451	4409	maladie psychique	
4452	4451	amnésie	
4453	4451	autisme	
4454	4451	folie	
4455	4409	maladie rare	
4456	4409	maladie respiratoire	
4457	4456	asthme	
4458	4409	maladie sexuellement transmissible	
4459	4458	sida	
4460	4459	Act-up	
4461	4459	Agence nationale de recherche sur le sida	
4462	4459	Aides	
4463	4459	Arcat-Sida	
4464	4459	Sida Info Service	
4465	4459	séropositivité	
4466	4409	malformation	
4467	4466	hermaphrodisme	
4468	4466	nanisme	
4469	4409	migraine	
4470	4409	obésité	
4471	4409	paralysie	
4472	4409	rhumatisme	
4473	4409	trouble fonctionnel (santé)	
4474	4409	virus	
4475	4474	fièvre hémorragique	
4476	4474	herpès	
4477	4474	variole	
4478	4409	épidémie	
4479	4331	médicament	
4480	4479	Agence du médicament	
4481	4479	antalgique	
4482	4481	aspirine	
4483	4481	morphine	
4484	4479	anti inflammatoire	
4485	4479	antibiotique	
4486	4479	antidépresseur	
4487	4486	prozac	
4488	4479	antispasmodique	
4489	4479	antiviral	
4490	4479	anxiolytique	
4491	4479	médicament générique	
4492	4479	neuroleptique	
4493	4479	vitamine	
4494	4331	politique de la santé	
4495	4494	carte sanitaire	
4496	4494	contrôle sanitaire	
4497	4496	Agence de sécurité sanitaire des aliments	
4498	4496	Agence de sécurité sanitaire des produits de santé	
4499	4496	Agence de sécurité sanitaire environnementale	
4500	4496	Autorité européenne de la sécurité alimentaire	
4501	4494	dépenses de santé	
4502	4501	acte médical	
4503	4331	profession de santé	
4504	4503	dentiste	
4505	4503	médecin	
4506	4505	Confédération des syndicats médicaux français	
4507	4505	internat de médecine	
4508	4505	médecin généraliste	
4509	4505	médecin spécialiste	
4510	4503	personnel hospitalier	
4511	4510	aide soignant	
4512	4510	infirmier	
4513	4503	vétérinaire	
4514	4331	soin médical	
4515	4514	aléa thérapeutique	
4516	4514	consultation médicale	
4517	4516	carnet de santé	
4518	4516	carte Vitale	
4519	4516	dossier médical	
4520	4514	droits du malade	
4521	4514	erreur médicale	
4522	4514	grossesse	
4523	4522	accouchement	
4524	4522	allaitement maternel	
4525	4522	avortement	
4526	4525	anti-IVG	
4527	4525	pilule contragestive	
4528	4522	embryon	
4529	4522	foetus	
4530	4522	grossesse multiple	
4531	4522	prématuré	
4532	4514	matériel médical	
4533	4532	seringue	
4534	4514	permanence des soins	
4535	4514	prescription médicale	
4536	4514	soin palliatif	
4537	4536	euthanasie	
4538	4514	soin à domicile	
4539	4514	technique médicale	
4540	4539	autopsie	
4541	4539	don d'organe	
4542	4541	donneur vivant	
4543	4539	désintoxication	
4544	4539	essai thérapeutique	
4545	4539	greffe d'organe	
4546	4539	homéopathie	
4547	4539	opération chirurgicale	
4548	4539	procréation artificielle	
4549	4548	mère porteuse	
4550	4539	prothèse	
4551	4539	psychothérapie	
4552	4539	rééducation médicale	
4553	4539	thalassothérapie	
4554	4539	thermalisme	
4555	4539	transfusion sanguine	
4556	4555	sang contaminé	
4557	4514	thérapie génique	
4558	4514	traitement médical	
4559	4558	chimiothérapie	
4560	4558	trithérapie	
4561	4331	spécialité médicale	
4562	4561	anesthésie	
4563	4561	cardiologie	
4564	4561	chirurgie	
4565	4564	chirurgie esthétique	
4566	4561	diététique	
4567	4566	régime alimentaire	
4568	4566	régime amaigrissant	
4569	4561	gynécologie	
4570	4561	gérontologie	
4571	4561	kinésithérapie	
4572	4561	médecine libérale	
4573	4561	médecine légale	
4574	4561	médecine parallèle	
4575	4561	médecine préventive	
4576	4575	dépistage	
4577	4575	préservatif	
4578	4575	vaccination	
4579	4561	neurologie	
4580	4561	ophtalmologie	
4581	4561	orthophonie	
4582	4561	psychiatrie	
4583	4561	pédiatrie	
4584	4561	radiologie	
4585	4561	urologie	
4586	4331	équipement de santé	
4587	4586	centre médico psycho pédagogique	
4588	4586	clinique	
4589	4586	hôpital	
4590	4589	Assistance publique	
4591	4589	Institut Gustave-Roussy	
4592	4589	gestion hospitalière	
4593	4592	agence régionale de l'hospitalisation	
4594	4589	hôpital européen Georges-Pompidou	
4595	4589	hôpital psychiatrique	
4596	4589	hôpital universitaire	
4597	4586	maternité (établissement)	
4598	4586	urgence médicale	
4599	4598	Samu	
4600	4598	ambulance	
4601	\N	Election	
4602	4601	campagne électorale	
4603	4602	accord électoral	
4604	4602	candidature	
4605	4604	désistement	
4606	4604	inéligibilité	
4607	4604	primaire électorale	
4608	4604	triangulaire électorale	
4609	4604	éligibilité	
4610	4602	consigne de vote	
4611	4602	investiture	
4612	4602	programme électoral	
4613	4602	temps de parole	
4614	4601	consultation électorale	
4615	4614	contentieux électoral	
4616	4615	fraude électorale	
4617	4614	référendum	
4618	4617	référendum local	
4619	4614	vote	
4620	4619	abstentionnisme	
4621	4619	participation électorale	
4622	4619	premier tour	
4623	4619	report de voix	
4624	4619	second tour	
4625	4619	sociologie électorale	
4626	4619	vote blanc	
4627	4619	vote nul	
4628	4619	vote par procuration	
4629	4614	élection anticipée	
4630	4614	élection cantonale	
4631	4614	élection européenne	
4632	4614	élection locale	
4633	4614	élection législative	
4634	4614	élection municipale	
4635	4614	élection partielle	
4636	4614	élection provinciale	
4637	4614	élection présidentielle	
4638	4637	parrainage présidentiel	signatures indispensables pour se présenter à la présidentielle
4639	4614	élection régionale	
4640	4614	élection sénatoriale	
4641	4601	régime électoral	
4642	4641	circonscription électorale	
4643	4642	circonscription Est	Pour les élections européennes en France. Regroupe les régions: Alsace, Bourgogne, Champagne-Ardenne, Lorraine et Franche-Comté.
4644	4642	circonscription Massif Central-Centre	Pour les élections européennes en France. Regroupe les régions:  Auvergne, Limousin et Centre.
4645	4642	circonscription Nord-Ouest	Pour les élections européennes en France. Regroupe les régions: Basse Normandie,  Haute Normandie, Nord-Pas-de-Calais et Picardie.
4646	4642	circonscription Ouest	Pour les élections européennes en France. Regroupe les régions: Bretagne, Pays de la Loire et Poitou-Charentes.
4647	4642	circonscription Sud-Est	Pour les élections européennes en France. Regroupe les régions: Corse, Provence-Alpes-Côte d'azur et Rhône-Alpes.
4648	4642	circonscription Sud-Ouest	Pour les élections européennes en France. Regroupe les régions:  Aquitaine, Languedoc-Roussillon et Midi-Pyrénées
4649	4641	cumul des mandats	
4650	4641	droit de vote	
4651	4650	droit de vote des étrangers	
4652	4641	découpage électoral	
4653	4641	liste électorale	
4654	4641	loi électorale	
4655	4641	mode de scrutin	
4656	4655	scrutin proportionnel	
4657	4655	suffrage universel	
4658	4655	vote électronique	
4659	4641	électorat	
4660	\N	Travail	
4661	4660	carrière professionnelle	 
4662	4661	bilan de compétence	
4663	4661	curriculum vitae	
4664	4661	expérience professionnelle	
4665	4661	insertion professionnelle	
4666	4665	réinsertion professionnelle	
4667	4661	mobilité professionnelle	
4668	4667	mutation professionnelle	
4669	4661	parité hommes-femmes	
4670	4661	promotion professionnelle	
4671	4661	qualification professionnelle	
4672	4661	reclassement professionnel	
4673	4661	reconversion professionnelle	
4674	4660	conditions de travail	
4675	4674	accident du travail	
4676	4674	durée du travail	
4677	4676	absentéisme	
4678	4676	aménagement du temps de travail	
4679	4676	annualisation du temps de travail	
4680	4676	congé payé	
4681	4676	heure supplémentaire	
4682	4676	repos hebdomadaire	
4683	4676	réduction du temps de travail	
4684	4683	compte épargne-temps	
4685	4683	semaine de 4 jours	
4686	4676	travail de nuit	
4687	4676	travail dominical	
4688	4676	travail du samedi	
4689	4676	travail à temps partiel	
4690	4674	flexibilité du travail	
4691	4690	cumul d'activités	
4692	4690	détachement de salarié	
4693	4674	harcèlement moral au travail	
4694	4674	lieu de travail	
4695	4674	médecine du travail	
4696	4695	maladie professionnelle	
4697	4674	organisation du travail	
4698	4697	bénévolat	
4699	4697	externalisation du travail	
4700	4697	partage du travail	
4701	4697	travail au pair	
4702	4697	travail clandestin	
4703	4697	travail forcé (non volontaire)	
4704	4697	travail indépendant	
4705	4697	travail précaire	
4706	4705	travail intermittent	
4707	4705	travail saisonnier	
4708	4705	travail temporaire	
4709	4697	travail transfrontalier	
4710	4697	travail à domicile	
4711	4697	télétravail	
4712	4660	conflit social	
4713	4712	grève	
4714	4713	droit de grève	
4715	4713	préavis de grève	
4716	4712	occupation de locaux	
4717	4712	sanction disciplinaire	
4718	4660	droit du travail	
4719	4718	Bureau international du travail	
4720	4718	accord d'entreprise	
4721	4718	année sabbatique	
4722	4718	conseil de prud'hommes	
4723	4718	contrat de travail	
4724	4723	contrat à durée déterminée	
4725	4723	contrat à durée indéterminée	
4726	4718	convention collective	
4727	4718	droit de retrait	
4728	4718	droits des salariés	
4729	4718	fête du travail	
4730	4718	inspection du travail	
4731	4718	représentation du personnel	
4732	4731	comité d'entreprise	
4733	4731	délégué du personnel	
4734	4718	seuils sociaux	
4735	4718	élection professionnelle	
4736	4660	emploi	
4737	4736	chômage	
4738	4737	APEIS	
4739	4737	Agir ensemble contre le chômage	
4740	4737	assurance chômage	
4741	4740	Assedic	
4742	4740	Unedic	
4743	4737	chômage de longue durée	
4744	4737	chômage partiel	
4745	4737	chômage technique	
4746	4737	demandeur d'emploi	
4747	4746	demandeur d'emploi en fin de droits	
4748	4746	recherche d'emploi	
4749	4736	marché du travail	
4750	4749	ANPE	
4751	4749	APEC (cadres)	
4752	4749	offre d'emploi	
4753	4736	métier	
4754	4753	CEREQ	
4755	4753	amateurisme	
4756	4753	conducteur	
4757	4753	conseiller	
4758	4753	courtier	
4759	4753	pilote	
4760	4753	professionnalisme	
4761	4736	politique de l'emploi	
4762	4761	Direction des études statistiques du ministère du Travail	
4763	4761	congé de conversion	
4764	4761	contrat d'initiative locale	
4765	4761	contrat d'insertion professionnelle	
4766	4761	contrat de professionnalisation	
4767	4761	contrat de retour à l'emploi	
4768	4761	contrat emploi solidarité	
4769	4761	contrat initiative emploi	
4770	4761	contrat nouvelle embauche	
4771	4761	convention de coopération	
4772	4761	création d'emploi	
4773	4761	emploi de proximité	
4774	4773	chèque services	
4775	4761	plan emploi	
4776	4761	prime pour l'emploi	
4777	4761	recrutement	
4778	4761	suppression d'emploi	
4779	4778	licenciement	
4780	4779	licenciement abusif	
4781	4778	plan social	
4782	4761	suppression de poste	
4783	4736	population active	
4784	4783	catégorie socioprofessionnelle	
4785	4784	cadre	
4786	4784	employé	
4787	4784	ingénieur	
4788	4784	ouvrier (cat. prof.)	
4789	4784	patronat	
4790	4784	profession libérale	
4791	4790	Conseil de l'ordre	
4792	4784	technicien	
4793	4783	main d'oeuvre	
4794	4783	travailleur immigré	
4795	4660	formation professionnelle	
4796	4795	congé individuel de formation	
4797	4795	formation en alternance	
4798	4797	Compagnons du devoir	
4799	4797	apprentissage	
4800	4660	rémunération	
4801	4800	honoraire	
4802	4800	prime	
4803	4800	salaire	
4804	4803	bas salaire	
4805	4804	Smic	
4806	4804	salaire minimum	
4807	4803	politique des salaires	
4808	4803	salaire individualisé	
4809	4803	salariat	
4810	4800	épargne salariale	
4811	4660	syndicat	
4812	4811	Bourse du travail	
4813	4811	CFDT	
4814	4811	CFE-CGC	
4815	4811	CFTC	
4816	4811	CGPME	
4817	4811	CGT	
4818	4811	CISL	
4819	4811	Centre des jeunes dirigeants	
4820	4811	Confédération européenne des syndicats	
4821	4811	Confédération nationale du travail	
4822	4811	Force ouvrière	
4823	4811	Fédération SUD	
4824	4811	IG-Metall	
4825	4811	Medef	
4826	4811	Syndicat des travailleurs corses	
4827	4811	Syndicat du livre CGT	
4828	4811	Unsa	
4976	4974	passager clandestin	
4829	4811	coordination (représentation syndicale)	
4830	4811	délégué syndical	
4831	\N	Religion	
4832	4831	Islam	
4833	4832	CFCM	
4834	4832	Frères Musulmans	
4835	4832	Haut Conseil des musulmans de France	
4836	4832	Organisation de la conférence islamique	
4837	4832	chiisme	
4838	4837	alevi	
4839	4837	druze	
4840	4832	imam	
4841	4832	loi islamique	
4842	4841	fatwa	
4843	4832	mufti	
4844	4832	ramadan	
4845	4832	sunnisme	
4846	4832	voile islamique	
4847	4831	christianisme	
4848	4847	Copte	
4849	4847	Témoin de Jéhovah	
4850	4847	catholicisme	
4851	4850	mouvement charismatique	
4852	4847	clergé	
4853	4852	prêtre	
4854	4852	épiscopat	
4855	4847	mormon	
4856	4847	orthodoxie	
4857	4856	Uniate	
4858	4847	protestantisme	
4859	4858	Eglise anglicane	
4860	4858	Eglise évangélique	
4861	4858	pentecôtisme	
4862	4831	judaïsme	
4863	4862	Crif	
4864	4862	ashkénaze	
4865	4862	loubavitch	
4866	4862	rabbin	
4867	4862	séfarade	
4868	4831	organisation religieuse	
4869	4868	Consistoire	
4870	4868	dignitaire religieux	
4871	4870	cardinal	
4872	4870	pape	
4873	4868	fête religieuse	
4874	4873	Noël	
4875	4873	Pâques	
4876	4873	shabbat	
4877	4868	lieu saint	
4878	4868	ordre religieux	
4879	4878	Opus Dei	
4880	4878	communauté de Taizé	
4881	4878	jésuite	
4882	4868	pèlerinage	
4883	4868	saint	
4884	4883	béatification	
4885	4883	canonisation	
4886	4883	relique	
4887	4868	édifice religieux	
4888	4887	basilique	
4889	4887	cathédrale	
4890	4887	monastère	
4891	4887	mosquée	
4892	4887	synagogue	
4893	4887	temple	
4894	4887	église	
4895	4831	religion orientale	
4896	4895	bouddhisme	
4897	4896	Dalaï-Lama	
4898	4895	hindouisme	
4899	4895	sikh	
4900	4831	sociologie religieuse	
4901	4900	athéisme	
4902	4900	croyance religieuse	
4903	4902	Dieu	
4904	4902	Jésus-Christ	
4905	4902	Vierge Marie	
4906	4902	apostasie	
4907	4902	conversion religieuse	
4908	4900	fanatisme religieux	
4909	4900	intégrisme	
4910	4900	oecuménisme	
4911	4900	secte	
4912	4911	Aum Shinrikyo	
4913	4911	Eglise de scientologie	
4914	4911	Moon (secte)	
4915	4911	New age	
4916	4911	Ordre du Temple solaire	
4917	4911	Secte du Mandarom	
4918	4911	Soka Gakkai	
4919	4831	théologie	
4920	4919	dogme religieux	
4921	4920	encyclique	
4922	4920	satanisme	
4923	4922	exorcisme	
4924	4919	instruction religieuse	
4925	4919	miracle	
4926	4919	pratique religieuse	
4927	4926	baptême	
4928	4926	jeûne (abstinence)	
4929	4926	office religieux	
4930	4926	signe religieux	
4931	4919	texte sacré	
4932	4931	Bible	
4933	4931	Coran	
4934	4931	Torah	
4935	\N	Transport	
4936	4935	circulation routière	Pour le covoiturage, utiliser :automobile + partage
4937	4936	auto-stop	
4938	4936	circulation alternée	
4939	4936	embouteillage	
4940	4936	permis de conduire	
4941	4940	permis à points	
4942	4936	piéton	
4943	4936	péage routier	
4944	4936	stationnement	
4945	4944	fourrière	
4946	4944	parcmètre	
4947	4936	sécurité routière	
4948	4947	alcootest	
4949	4947	ceinture de sécurité	
4950	4947	code de la route	
4951	4947	limitation de vitesse	
4952	4935	politique des transports	
4953	4952	Groupement des autorités responsables de transport	
4954	4935	réseau de transport	
4955	4935	trafic (transport)	
4956	4935	transport aérien	
4957	4956	Administration fédérale de l'aviation	
4958	4956	aviation civile	
4959	4956	aéroport	
4960	4956	compagnie aérienne	
4961	4960	compagnie aérienne à bas coût	
4962	4956	contrôleur aérien	
4963	4956	enregistreur de vol	
4964	4956	espace aérien européen	
4965	4956	liaison aérienne	
4966	4956	personnel navigant	
4967	4935	transport de fonds	
4968	4935	transport de marchandise	
4969	4968	conteneur	
4970	4968	ferroutage	
4971	4968	fret	
4972	4968	merroutage	
4973	4968	messagerie express	
4974	4935	transport de voyageur	
4975	4974	passager	
4977	4935	transport en commun	
4978	4977	RER	
4979	4978	Eole	
4980	4977	Syndicat des transports d'Ile-de-France	
4981	4977	autobus	
4982	4977	funiculaire	
4983	4977	métro	
4984	4983	Météor	future ligne du métro reliant les gares parisiennes
4985	4983	Val (métro)	
4986	4983	carte orange	
4987	4977	taxi	
4988	4977	tramway	
4989	4977	transport en site propre	
4990	4935	transport ferroviaire	
4991	4990	compagnie ferroviaire	
4992	4990	gare	
4993	4992	gare Montparnasse	
4994	4992	gare Saint-Lazare	
4995	4992	gare d'Austerlitz	
4996	4992	gare de Lyon	
4997	4992	gare du Nord	
4998	4990	liaison ferroviaire	
4999	4990	matériel ferroviaire	
5000	4990	personnel ferroviaire	
5001	4990	train	
5002	5001	Eurostar	
5003	5002	Shuttle	
5004	5001	TGV	
5005	5004	TGV Atlantique	
5006	5004	TGV Est	
5007	5004	TGV Méditerranée	
5008	5004	TGV Rhin-Rhône	
5009	5001	passage à niveau	
5010	5001	train de banlieue	
5011	5001	train express régional	
5012	4935	transport fluvial	
5013	5012	péniche	
5014	4935	transport maritime	
5015	5014	armateur	
5016	5014	bateau	
5017	5016	cargo	
5018	5016	ferry	
5019	5016	paquebot	
5020	5014	docker	
5021	5014	liaison maritime	
5022	5014	marine marchande	
5023	5014	phare	
5024	5014	port	
5025	4935	transport routier	
5026	5025	autocar	
5027	5025	poids lourd	
5028	5027	chauffeur routier	
5029	\N	Economie	
5030	5029	conjoncture économique	
5031	5030	commerce extérieur	
5032	5031	Banque française pour le commerce extérieur	
5033	5031	Coface	
5034	5031	excédent commercial	
5035	5031	exportation	
5036	5031	importation	
5037	5030	comptes de la Nation	
5038	5037	Produit intérieur brut	
5039	5037	Produit national brut	
5040	5037	ménage (unité de population)	
5041	5030	consommation	
5042	5041	Conseil national de la consommation	
5043	5041	Institut National de la Consommation	
5044	5041	consommation des ménages	
5045	5041	défense du consommateur	
5046	5045	Commission de la sécurité des consommateurs	
5047	5045	Union Fédérale des Consommateurs	
5048	5041	gaspillage	
5049	5030	cycle économique	
5050	5049	crise économique	
5051	5049	croissance économique	
5052	5049	reprise économique	
5053	5030	indicateur économique	
5054	5030	institut de conjoncture	
5055	5054	BIPE	
5056	5054	Eurostat	
5057	5054	INSEE	
5058	5054	OFCE	
5059	5030	investissement	
5060	5059	investissement à l'étranger	
5061	5059	investissement étranger	
5062	5061	Accord multilatéral sur l'investissement	
5063	5059	investisseur institutionnel	
5064	5030	marché intérieur	
5065	5064	part de marché	
5066	5030	prix (valeur)	
5067	5066	déflation	
5068	5066	gratuité	
5069	5066	indice des prix	
5070	5066	inflation	
5071	5030	prévision économique	
5072	5030	revenu	
5073	5072	CERC	
5074	5072	cumul de revenus	
5075	5072	fortune (richesse)	
5076	5072	niveau de vie	
5077	5076	coût de la vie	
5078	5076	pouvoir d'achat	
5079	5072	patrimoine (fortune)	
5080	5072	pauvreté	
5081	5072	pension (allocation)	
5082	5029	politique économique	
5083	5082	aide publique	
5084	5082	concurrence	
5085	5084	Conseil de la concurrence	
5086	5084	DGCCRF	
5087	5084	concurrence déloyale	
5088	5082	planification	
5089	5088	Commissariat au Plan	
5090	5088	contrat de plan	
5091	5088	plan de redressement	
5092	5088	plan de rigueur	
5093	5082	relance économique	
5094	5082	régulation économique	
5095	5029	programme économique	
5096	5095	dérèglementation	
5097	5095	nationalisation	
5098	5095	privatisation	
5099	5029	système économique	
5100	5099	capitalisme	
5101	5099	secteur privé	
5102	5101	Association française des entreprises privées	
5103	5099	secteur public	
5104	5103	dotation en capital	augmentation de capital des entreprises publiques
5105	5103	tarif public	
5106	5099	économie de marché	
5107	5099	économie parallèle	
5108	5099	économie régionale	
5109	5099	économie sociale	partie de l'activité économique assurée par les associations, les coopératives, les mutuelles.
5110	5099	économie souterraine	
5111	5029	théorie économique	
5112	5111	économiste	
5113	5029	économie internationale	
5114	5113	commerce international	
5115	5114	CNUCED	
5116	5114	Chambre de commerce internationale	
5117	5114	Organisation mondiale du commerce	
5118	5114	accord de compensation	
5119	5114	libre-échange	
5120	5119	union douanière	
5121	5114	protectionnisme	
5122	5114	relations commerciales	
5123	5113	développement économique	
5124	5123	OCDE	
5125	5123	Pays en développement	
5126	5123	pays industrialisés	
5127	5113	relations économiques	
5128	5127	Forum social européen	
5129	5127	Forum social mondial	
5130	5127	Forum économique de Davos	
5131	5127	accord économique	
5132	5131	Alca	
5133	5131	Mercosur	marché de libre-échange qui regroupe: Argentine, Brésil, Paraguay, Uruguay.
5134	5127	aide économique	
5135	5134	aide au développement	
5136	5134	aide financière	
5137	5127	sanction économique	
5138	5137	embargo	
5139	\N	Questions sociales	
5140	5139	Sécurité sociale	
5141	5140	ACOSS	
5142	5140	PLFSS	
5143	5140	assurance complémentaire	
5144	5140	assurance maladie	
5145	5144	Caisse d'Assurance Maladie	
5146	5144	arrêt maladie	
5147	5144	convention médicale	
5148	5144	couverture maladie universelle	
5149	5144	forfait hospitalier	
5150	5144	ticket modérateur	
5151	5140	régime spécial de sécurité sociale	
5152	5139	drogue (stupéfiant)	
5153	5152	cannabis	
5154	5153	Collectif d'information et de recherche cannabique	
5155	5152	cocaïne	
5156	5152	crack	
5157	5152	ecstasy	
5158	5152	héroïne (drogue)	
5159	5152	opium	
5160	5152	produit de substitution	
5161	5160	méthadone	
5162	5152	toxicomanie	
5163	5162	overdose	
5164	5152	trafic de drogue	
5165	5139	immigration	
5166	5165	Cimade	
5167	5165	Gisti	
5168	5165	aide au retour	
5169	5165	code de la nationalité	
5170	5165	deuxième génération	
5171	5165	droit de séjour des étrangers	
5172	5171	carte de séjour	
5173	5165	immigration clandestine	
5174	5165	politique de l'immigration	
5175	5174	Haut Conseil à l'intégration	
5176	5165	regroupement familial	
5177	5165	rétention administrative	
5178	5165	étranger en France	
5179	5139	intégration sociale	
5180	5179	discrimination	
5181	5180	Haute autorité de lutte contre les discriminations et pour l'égalité	
5182	5180	antisémitisme	
5183	5180	racisme	
5184	5183	Licra	
5185	5183	MRAP	
5186	5183	SOS racisme	
5187	5183	antiracisme	
5188	5183	préférence nationale	
5189	5180	sexisme	
5190	5179	exclusion sociale	
5191	5190	ATD-Quart Monde	
5192	5190	Armée du Salut	
5193	5190	Compagnons d'Emmaüs	
5194	5190	Droits devant	
5195	5190	Fondation de France	
5196	5190	Restos du coeur	
5197	5190	Secours Catholique	
5198	5190	Secours populaire français	
5199	5179	handicapé	
5200	5199	Centre d'Aide par le Travail	
5201	5199	Handicap international	association qui soigne les victimes civiles des conflits, en particulier dans le tiers-monde
5202	5199	handicapé mental	
5203	5199	muet	
5204	5199	non-voyant	
5205	5199	sourd	
5206	5179	insertion sociale	
5207	5179	invalidité	
5208	5179	inégalité sociale	
5209	5139	mode de vie	
5210	5209	CREDOC	
5211	5209	alimentation	
5212	5211	art de la table	
5213	5211	cuisine (gastronomie)	
5214	5213	chef cuisinier	
5215	5213	recette de cuisine	
5216	5211	cuisine exotique	
5217	5211	faim	
5218	5217	AICF	
5219	5211	malnutrition	
5220	5211	végétarisme	
5221	5209	emploi du temps	
5222	5209	identité culturelle	
5223	5209	mode	
5224	5223	collection de mode	
5225	5223	couturier	
5226	5223	défilé de mode	
5227	5223	haute couture	
5228	5223	mannequin	
5229	5223	prêt-à-porter	
5230	5223	style	
5231	5230	grunge	
5232	5223	sur mesure	
5233	5209	moeurs	
5234	5233	fétichisme	
5235	5233	piercing	
5236	5233	sadomasochisme	
5237	5233	sexualité	
5238	5237	adultère	
5239	5237	homosexualité	
5240	5237	hétérosexualité	
5241	5237	érotisme	
5242	5233	tatouage	
5243	5233	transsexualité	
5244	5233	travestisme	
5245	5209	qualité de vie	
5246	5245	confort	
5247	5245	privilège	
5248	5209	tradition	
5249	5139	politique sociale	
5250	5249	DASS	
5251	5249	Inspection Générale des Affaires Sociales	
5252	5249	acquis social	
5253	5249	aide sociale	
5254	5253	Samu social	
5255	5253	aide médicale	
5256	5253	aide ménagère	
5257	5253	centre d'accueil	
5258	5257	famille d'accueil	
5259	5257	foyer d'hébergement	
5260	5257	garderie	
5261	5260	assistante maternelle	
5262	5260	crèche	
5263	5253	fonds social	
5264	5253	protection maternelle et infantile	
5265	5253	travailleur social	
5266	5265	éducateur	
5267	5249	diverses dispositions d'ordre social	
5268	5249	gestion paritaire	
5269	5249	prestation sociale	
5270	5269	allocation au jeune enfant	
5271	5269	allocation de garde à domicile	
5272	5269	allocation de rentrée scolaire	
5273	5269	allocation dépendance	
5274	5269	allocation familiale	
5275	5274	Caisse nationale d'allocations familiales	
5276	5269	allocation logement	
5277	5269	allocation maternité	
5278	5269	allocation parentale	
5279	5269	minima sociaux	
5280	5279	RMA	
5281	5279	RMI	
5282	5279	allocation d'adulte handicapé	
5283	5279	allocation de parent isolé	
5284	5279	allocation de solidarité spécifique	
5285	5279	minimum vieillesse	
5286	5249	protection sociale	
5287	5286	Urssaf	
5288	5286	droit social	
5289	5286	mutualisme	
5290	5289	Fédération nationale de la mutualité française	
5291	5289	Maaf Assurances	
5292	5289	Macif	
5293	5289	Mnef	
5294	5289	Mutualité française	
5295	5289	Mutuelle des étudiants	
5296	5289	Mutuelles du Mans	
5297	5249	prélèvement obligatoire	
5298	5297	Contribution Sociale Généralisée	
5299	5297	RDS	
5300	5297	cotisation sociale	
5301	5139	population	
5302	5301	catégorie d'âge	
5303	5302	junior	
5304	5302	senior	
5305	5302	vétéran	
5306	5301	démographie	
5307	5306	INED	
5308	5306	espérance de vie	
5309	5306	mortalité	
5310	5309	décès	
5311	5310	cadavre	
5312	5309	mort subite	
5313	5306	natalité	
5314	5313	contraception	
5315	5314	pilule contraceptive	
5316	5313	contrôle des naissances	
5317	5316	Planning familial	organisme dépendant du Ministère de la Santé
5318	5313	fécondité	
5319	5306	âge	
5320	5301	enfant	
5321	5320	bébé	
5322	5320	enfant surdoué	
5323	5320	orphelin	
5324	5320	placement d'enfant	
5325	5301	famille	
5326	5325	Pacte civil de solidarité	
5327	5325	Union des associations familiales	
5328	5325	concubinage	
5329	5325	célibat	
5330	5325	divorce	
5331	5330	pension alimentaire	
5332	5325	droit de la famille	
5333	5332	adoption d'enfant	
5334	5332	autorité parentale	
5335	5332	droit de garde	
5336	5332	minorité légale	
5337	5332	résidence alternée	
5338	5325	généalogie	
5339	5338	filiation	
5340	5339	CNAOP	
5341	5325	jumeau	
5342	5325	mariage	
5343	5342	conjoint	
5344	5342	mariage blanc	
5345	5342	mariage mixte	
5346	5342	polygamie	
5347	5325	parent	
5348	5347	famille monoparentale	
5349	5347	grands-parents	
5350	5347	mère	
5351	5347	père	
5352	5325	politique de la famille	
5353	5352	congé parental	
5354	5325	veuvage	
5355	5325	vie de couple	
5356	5325	vie familiale	
5357	5301	jeunesse	
5358	5357	adolescence	
5359	5301	migration	
5360	5359	diaspora	
5361	5359	déplacement de population	
5362	5359	exode	
5363	5362	exode rural	
5364	5359	nomade	
5365	5364	tzigane	
5366	5359	rapatrié	
5367	5366	harki	
5368	5359	émigration	
5369	5368	Français à l'étranger	
5370	5368	transfuge	
5371	5368	étranger	
5372	5301	minorités	
5373	5372	minorité culturelle	
5374	5372	minorité ethnique	
5375	5301	métis	
5376	5301	nationalité	
5377	5301	personne âgée	
5378	5377	personne âgée dépendante	
5379	5377	vieillissement	
5380	5301	peuple	
5381	5380	Cosaques	
5382	5380	Kurde	
5383	5380	aborigène	
5384	5380	amérindien	
5385	5380	arabe	
5386	5380	berbère	
5387	5380	esquimau	
5388	5380	hispanophone	
5389	5380	indigène	
5390	5380	latino-américain	
5391	5380	ouïghour	
5392	5380	tamoul	
5393	5380	tribu	
5394	5380	zoulou	
5395	5301	population blanche	
5396	5301	population civile	
5397	5301	population noire	
5398	5397	Conseil représentatif des associations noires	 
5399	5301	surpopulation	
5400	5139	problèmes sociaux	
5401	5400	alcoolisme	
5402	5400	crise de société	
5403	5400	illettrisme	
5404	5400	maltraitance	
5405	5404	enfant maltraité	
5406	5404	femme battue	
5407	5400	mendicité	
5408	5400	prévention	
5409	5400	solitude	
5410	5400	suicide	
5411	5410	immolation	
5412	5400	tabagisme	
5413	5412	Comité national contre le tabagisme	
5414	5400	victime	
5415	5414	rescapé	
5416	5139	retraite	
5417	5416	caisse de retraite	
5418	5417	Caisse nationale d'assurance vieillesse	
5419	5416	fonds de pension	
5420	5416	maison de retraite	
5421	5416	préretraite	
5422	5416	retraite complémentaire	
5423	5422	Agirc	régime de retraite complémentaire des cadres
5424	5422	Arrco	
5425	5139	sciences humaines	
5426	5425	ethnologie	
5427	5426	anthropologie	
5428	5427	homme préhistorique	
5429	5428	homme de Cro-Magnon	
5430	5428	homme de Néandertal	
5431	5427	origine de l'homme	
5432	5426	ethnie	
5433	5432	Dogon	
5434	5432	Hutus	
5435	5432	Ogonis	
5436	5432	Papou	
5437	5432	Pashtoun	ethnie d'Afghanistan et du Pakistan
5438	5432	Tutsis	
5439	5438	Banyamulenge	
5440	5432	massaï	
5441	5425	occultisme	
5442	5441	astrologie	
5443	5441	sorcellerie	
5444	5441	superstition	
5445	5441	voyance	
5446	5425	philosophie	 
5447	5446	humanisme	
5448	5446	morale	
5449	5448	déontologie	
5450	5449	secret médical	
5451	5448	objection de conscience	
5452	5425	psychanalyse	
5453	5425	psychologie	
5454	5453	bonheur	
5455	5453	graphologie	
5456	5453	humour	
5457	5453	intelligence	
5458	5453	mémoire	
5459	5453	parapsychologie	
5460	5453	sentiment	
5461	5460	amitié	
5462	5460	amour	
5463	5460	haine	
5464	5460	horreur	
5465	5460	jalousie	
5466	5460	peur	
5467	5425	sociologie	
5468	5467	classe sociale	
5469	5468	aristocratie	
5470	5468	caste	
5471	5468	classe moyenne	
5472	5468	classe ouvrière	
5473	5467	communauté	
5474	5467	comportement	
5475	5474	autoritarisme	
5476	5474	cannibalisme	
5477	5474	conformisme	
5478	5474	excuse	
5479	5474	mystification	
5480	5474	nudité	
5481	5474	pardon	
5482	5474	savoir-vivre	
5483	5467	femme	
5484	5483	féminisme	
5485	5467	homme	
5486	5467	intellectuel	
5487	5467	marginalité	
5488	5487	skinhead	
5489	5467	opinion publique	
5490	5489	Institut de sondage	
5491	5490	BVA	
5492	5490	CSA (sondage)	
5493	5490	IFOP	
5494	5490	IPSOS	
5495	5490	Louis-Harris	
5496	5490	Médiamétrie	
5497	5490	Sofres	
5498	5489	popularité	
5499	5489	sondage	
5500	5467	récompense	
5501	5500	décoration honorifique	
5502	5501	Légion d'honneur	
5503	5500	prix Nobel	
5504	5467	symbolique	
5505	5504	drapeau	
5506	5504	hymne national	
5507	5467	élite	
5508	\N	ZZZZ_Questions juridiques	
5509	5508	droit	
5510	5509	droit de visite	
5511	5509	garantie	
5512	5509	jurisprudence	
5513	5509	loi	
5514	5513	amendement	
5515	5513	arrêté	
5516	5515	arrêté municipal	
5517	5513	circulaire	
5518	5513	décret	
5519	5513	décret d'application	
5520	5513	légalisation	
5521	5513	projet de loi	
5522	5509	réglementation	
5523	5522	charte	
5524	5509	tutelle	
5525	5508	droit civil	
5526	5525	code civil	
5527	5525	droits civiques	
5528	5527	citoyenneté	
5529	5525	fondation (organisme)	
5530	5525	héritage	
5531	5530	donation	
5532	5525	majorité légale	
5533	5525	responsabilité civile	
5534	5525	état civil	
5535	5534	naturalisation	
5536	5534	papier d'identité	
5537	5534	patronyme	
5538	5537	pseudonyme	
5539	5508	droit commercial	
5540	5539	autorisation de mise sur le marché	
5541	5539	droit d'auteur	
5542	5541	Adami	
5543	5541	Spadem	
5544	5541	droit de reproduction	
5545	5541	photocopillage	
5546	5541	propriété intellectuelle	
5547	5539	droit des sociétés	
5548	5539	droits de retransmission	
5549	5539	licence d'exploitation	
5550	5539	propriété industrielle	
5551	5550	appellation d'origine	
5552	5550	brevet d'invention	
5553	5550	label de qualité	
5554	5550	marque	
5555	5508	droit international	
5556	5555	crime contre l'humanité	
5557	5556	camp de concentration	
5558	5556	déportation	
5559	5556	esclavage	
5560	5556	génocide	
5561	5560	Holocauste	
5562	5556	négationnisme	
5563	5556	purification ethnique	
5564	5555	crime de guerre	
5565	5555	droit aérien	
5566	5555	droit d'asile	
5567	5566	asile politique	
5568	5566	extradition	
5569	5566	réfugié	
5570	5569	Haut Commissariat pour les Réfugiés	
5571	5569	OFPRA	
5572	5569	boat people	
5573	5569	camp de réfugiés	
5574	5555	droit de l'espace	
5575	5555	droit des peuples	
5576	5575	autodétermination	
5577	5575	droit d'ingérence	
5578	5555	droit maritime	
5579	5578	eaux territoriales	
5580	5578	pavillon de complaisance	
5581	5508	droit public	
5582	5581	droit administratif	
5583	5582	concession (acte administratif)	
5584	5582	droit de préemption	
5585	5582	expropriation	
5586	5582	marché public	
5587	5586	appel d'offre	
5588	5581	droit constitutionnel	
5589	5508	droit pénal	
5590	5589	amnistie	
5591	5589	casier judiciaire	
5592	5589	code de procédure pénale	
5593	5589	code pénal	
5594	5589	droit de grâce	
5595	5589	dépénalisation	
5596	5589	légitime défense	
5597	5589	prescription pénale	
5598	5589	repenti	réservé aux anciens criminels ou terroristes qui acceptent de collaborer avec la police en échange d'une remise de peine.
5599	5589	responsabilité pénale	
5600	5508	juridiction	
5601	5600	Cour constitutionnelle	
5602	5600	Cour d'appel	
5603	5600	Cour d'assises	
5604	5603	jury d'assises	
5605	5600	Cour de cassation	
5606	5600	Cour de justice de la République	
5607	5600	Cour européenne de justice	
5608	5600	Cour européenne des droits de l'homme	
5609	5600	Cour internationale de justice	
5610	5600	Cour suprême	
5611	5600	Palais de justice	
5612	5600	Tribunal international	
5613	5612	Cour pénale internationale	
5614	5600	chambre d'instruction	descripteur créé le 01.01.2001
5615	5600	juridiction d'exception	
5616	5600	tribunal administratif	
5617	5600	tribunal correctionnel	
5618	5600	tribunal d'instance	
5619	5600	tribunal de commerce	
5620	5600	tribunal de grande instance	
5621	5600	tribunal des affaires sociales	
5622	5600	tribunal militaire	
5623	5600	tribunal pour enfants	
5624	5508	justice	
5625	5624	Inspection générale des services judiciaires	
5626	5624	espace judiciaire européen	
5627	5624	indépendance de la justice	
5628	5624	justice de proximité	lieu de médiation installé dans les quartiers sensibles
5629	5624	politique de la justice	
5630	5624	procès	
5631	5630	accusation	
5632	5630	acquittement	
5633	5630	droits de la défense	
5634	5630	faux témoignage	
5635	5630	partie civile	
5636	5630	verdict	
5637	5624	procédure judiciaire	
5638	5637	aide judiciaire	
5639	5637	commission rogatoire	
5640	5637	comparution immédiate	
5641	5637	compétence juridictionnelle	
5642	5641	compétence juridictionnelle universelle	
5643	5637	contrôle judiciaire	
5644	5637	dessaisissement judiciaire	
5645	5637	erreur de procédure	
5646	5637	erreur judiciaire	
5647	5637	instruction judiciaire	
5648	5647	secret de l'instruction	
5649	5637	litige	
5650	5637	mandat d'arrêt	
5651	5650	mandat d'arrêt européen	
5652	5650	mandat d'arrêt international	
5653	5637	mise en examen	
5654	5637	non-lieu	
5655	5637	plainte judiciaire	
5656	5655	plainte en nom collectif	
5657	5637	poursuite judiciaire	
5658	5637	présomption d'innocence	
5659	5637	reconnaissance de culpabilité	
5660	5637	recours	
5661	5637	relaxe	
5662	5637	récusation judiciaire	
5663	5637	référé	
5664	5637	témoin assisté	
5665	5624	profession juridique	
5666	5665	avocat	
5667	5665	commissaire priseur	
5668	5665	greffier	
5669	5665	huissier de justice	
5670	5665	juriste	
5671	5665	magistrature	
5672	5671	Conseil supérieur de la magistrature	
5673	5671	Syndicat de la magistrature	
5674	5671	juge d'application des peines	
5675	5671	juge d'instruction	
5676	5675	Afmi	
5677	5671	juge de la détention	
5678	5671	juge pour enfant	
5679	5671	ministère public	
5680	5679	procureur	représentant du ministère public et chef du parquet près de la Cour de cassation, la Cour des comptes et les cours d'appel.
5681	5679	procureur de la République	magistrat représentant du ministére public et chef du parquet près du tribunal de grande instance.
5682	5665	notaire	
5683	5508	libertés publiques	
5684	5683	CNIL	
5685	5683	droits de l'enfant	
5686	5683	droits de l'homme	
5687	5686	Commission européenne des droits de l'homme	
5688	5686	Conseil des droits de l'homme	
5689	5686	Convention européenne sur les droits de l'homme	
5690	5686	Déclaration des droits de l'homme	
5691	5686	France Libertés	
5692	5686	Ligue des droits de l'homme	
5693	5686	apartheid	
5694	5686	camp de travail	
5695	5686	exil	
5696	5686	persécution religieuse	
5697	5686	torture	
5698	5683	droits de la femme	
5699	5683	grève de la faim	
5700	5683	liberté d'expression	
5701	5683	liberté de circulation	
5702	5683	liberté individuelle	
5703	5702	anonymat	
5704	5702	droit de propriété	
5705	5702	droit à l'image	
5706	5702	désobéissance civile	
5707	5702	liberté d'opinion	
5708	5702	vie privée	
5709	5702	écoute téléphonique	
5710	5508	sanction judiciaire	
5711	5710	assignation à résidence	
5712	5710	condamnation	
5713	5712	condamnation avec sursis	
5714	5710	double peine	
5715	5710	détention (emprisonnement)	
5716	5715	détention des mineurs	
5717	5710	indemnisation	
5718	5710	interdiction de séjour	
5719	5710	ordonnance judiciaire	
5720	5710	peine de mort	
5721	5720	bourreau	
5722	5720	exécution capitale	
5723	5710	peine de semi-liberté	
5724	5710	peine de substitution	
5725	5710	peine de sûreté	
5726	5710	placement sous surveillance électronique	
5727	5710	prison	
5728	5727	administration pénitentiaire	
5729	5728	gardien de prison	
5730	5729	Union fédérale autonome pénitentiaire	
5731	5727	détenu	
5732	5731	prisonnier politique	
5733	5727	libération (mise en liberté)	
5734	5733	liberté provisoire	
5735	5733	libération conditionnelle	
5736	5733	libération sous caution	
5737	5727	politique pénitentiaire	
5738	5727	vie carcérale	
5739	5738	isolement carcéral	
5740	5738	permission de sortie	
5741	5727	évasion	
5742	5710	protection judiciaire de la jeunesse	
5743	5742	centre éducatif fermé	
5744	5710	pénalité financière	
5745	5710	réclusion criminelle à perpétuité	
5746	5710	travail forcé (sanction pénale)	
5747	\N	Environnement	
5748	5747	nature	
5749	5748	ZZZZ_saison	
5750	5749	automne	
5751	5749	hiver	
5752	5749	printemps (saison)	
5753	5749	été	
5754	5748	animal	
5755	5754	animal aquatique	
5756	5755	batracien	
5757	5755	crustacé	
5758	5755	poisson	
5759	5758	requin	
5760	5758	saumon	
5761	5758	thon	
5762	5758	turbot	
5763	5754	animal domestique	
5764	5763	pitbull	
5765	5754	animal préhistorique	
5766	5765	dinosaure	
5767	5754	animal sauvage	
5768	5767	félidé	
5769	5767	loup	
5770	5754	insecte	
5771	5770	acridien	
5772	5770	arachnide	
5773	5770	insecte parasite	
5774	5770	mouche	
5775	5770	moustique	
5776	5770	termite	
5777	5754	mammifère	
5778	5777	cervidé	
5779	5777	cheval	
5780	5777	cétacé	
5781	5777	primate	
5782	5777	renard	
5783	5777	rongeur	
5784	5777	éléphant	
5785	5784	ivoire	
5786	5754	mollusque	
5787	5786	huître	
5788	5754	oiseau	
5789	5788	oiseau aquatique	
5790	5754	reptile	
5791	5748	atmosphère	
5792	5748	catastrophe naturelle	
5793	5792	Plan de prévention des risques	
5794	5792	avalanche	
5795	5792	cyclone	
5796	5792	glissement de terrain	
5797	5792	inondation	
5798	5792	orage	
5799	5792	raz-de-marée	
5800	5792	séisme	
5801	5792	tempête	
5802	5748	climat	
5803	5802	désertification	
5804	5802	effet de serre	
5805	5802	sécheresse	
5806	5748	eau	
5807	5806	Agence de l'eau	
5808	5806	nappe phréatique	
5809	5748	espace vert	
5810	5809	forêt	
5811	5810	Office National des Forêts	
5812	5809	parc naturel	
5813	5748	espèce menacée	
5814	5748	flore	
5815	5814	algue	
5816	5815	Caulerpa taxifolia	
5817	5814	arbre	
5818	5814	champignon	
5819	5818	truffe	
5820	5814	fleur	
5821	5748	paysage	
5822	5748	écosystème	
5823	5747	pollution	
5824	5823	bruit	
5825	5823	déchet industriel	
5826	5823	déchet médical	
5827	5823	déchet ménager	
5828	5823	déchet radioactif	
5829	5828	Agence nationale pour la gestion des déchets radioactifs	
5830	5828	Centre de Stockage de la Manche	situé à côté de La Hague et géré par l'Andra (ne pas confondre avec le centre de La Hague qui dépend lui de la Cogema)
5831	5823	déchet toxique	
5832	5823	déchet végétal	
5833	5823	lutte antipollution	
5834	5823	marée noire	
5835	5823	pollution atmosphérique	
5836	5823	produit dangereux	
5837	5836	amiante	
5838	5836	dioxine	
5839	5836	nitrate	
5840	5836	pyralène	
5841	5823	risque technologique	
5842	5747	protection de l'environnement	
5843	5842	Greenpeace	
5844	5843	Rainbow Warrior	
5845	5842	patrimoine naturel	
5846	5845	site (lieu)	
5847	5846	riverain	
5848	5842	politique de l'environnement	
5849	5842	protection des animaux	
5850	5849	Société protectrice des animaux	
5851	5849	parc zoologique	
5852	5842	protection du littoral	
5853	5842	traitement des déchets	
5854	5853	décharge	
5855	5853	recyclage	
5856	5842	épuration de l'eau	
5857	\N	Enseignement	
5858	5857	population scolaire et universitaire	
5859	5858	chef d'établissement scolaire	
5860	5858	enseignant	
5861	5860	instituteur	
5862	5861	IUFM	
5863	5860	maître-auxiliaire	
5864	5860	universitaire	
5865	5858	parent d'élève	
5866	5865	FCPE	
5867	5865	PEEP	
5868	5865	Unapel	
5869	5858	personnel non enseignant	
5870	5869	conseiller d'éducation	
5871	5858	syndicat enseignant	
5872	5871	Fédération syndicale unitaire	
5873	5872	SNES	
5874	5872	Syndicat national unitaire des instits profs et PEGC	
5875	5871	SGEN-CFDT	
5876	5871	SNESUP	
5877	5871	Unsa-Education	
5878	5858	syndicat étudiant	
5879	5878	UDEA	
5880	5878	UEJF	
5881	5878	Unef	
5882	5881	Unef-ID	
5883	5858	écolier	
5884	5858	élève	
5885	5858	étudiant	
5886	5885	étudiant étranger	
5887	5857	pédagogie	
5888	5887	alphabétisation	
5889	5887	classe scolaire	
5890	5889	classe de découverte	
5891	5887	devoirs scolaires	
5892	5887	enseignement alternatif	
5893	5887	enseignement à distance	
5894	5887	manuel scolaire	
5895	5887	matière enseignée	
5896	5887	programme scolaire	
5897	5887	rythme scolaire	
5898	5887	soutien scolaire	
5899	5887	stage de formation	
5900	5857	scolarité	
5901	5900	diplôme	
5902	5901	baccalauréat	
5903	5900	examen scolaire	
5904	5900	frais de scolarité	
5905	5900	inscription scolaire	
5906	5900	inscription universitaire	
5907	5900	orientation scolaire	
5908	5900	rentrée scolaire	
5909	5900	rentrée universitaire	
5910	5900	vie scolaire et universitaire	
5911	5910	CROUS	
5912	5910	bizutage	
5913	5910	bourse d'étude	
5914	5910	calendrier scolaire	
5915	5914	vacances scolaires	
5916	5910	internat (scolaire)	
5917	5910	logement étudiant	
5918	5910	médecine scolaire et universitaire	
5919	5910	restauration scolaire et universitaire	
5920	5910	transport scolaire	
5921	5900	échec scolaire	
5922	5857	système scolaire	
5923	5922	enseignement artistique	
5924	5923	Femis	
5925	5922	enseignement primaire	
5926	5922	enseignement privé	
5927	5926	enseignement confessionnel	
5928	5922	enseignement public	
5929	5922	enseignement secondaire	
5930	5922	enseignement supérieur	
5931	5930	CNESER	
5932	5930	deuxième cycle	
5933	5930	premier cycle	
5934	5930	troisième cycle	
5935	5922	enseignement technique	
5936	5922	école maternelle	
5937	5857	éducation	
5938	5937	Education nationale	
5939	5937	académie d'enseignement	
5940	5939	Inspection académique	
5941	5939	rectorat	
5942	5937	carte scolaire	
5943	5937	instruction civique	
5944	5943	Centre d'information civique	
5945	5937	politique de l'éducation	
5946	5937	scolarisation	
5947	5937	zone d'éducation prioritaire	
5948	5937	éducation sexuelle	
5949	5857	établissement scolaire	
5950	5949	ZZZZ_établissement d'enseignement supérieur	
5951	5950	Collège de France	
5952	5950	Conservatoire National des Arts et Métiers	
5953	5950	Ecole des Beaux-Arts	
5954	5950	IUT	
5955	5954	Institut universitaire professionnel	
5956	5950	grande école	
5957	5956	Ecole Nationale d'Administration	
5958	5956	Ecole des Chartes	
5959	5956	Ecole normale supérieure	
5960	5956	Ecole polytechnique	
5961	5956	Institut d'études politiques	
5962	5956	classe préparatoire	
5963	5950	université	
5964	5963	université Léonard de Vinci	
5965	5963	université Paris-I	
5966	5963	université Paris-II	
5967	5963	université Paris-III	
5968	5963	université Paris-IV	
5969	5963	université Paris-IX	
5970	5963	université Paris-V	
5971	5963	université Paris-VI	
5972	5963	université Paris-VII	
5973	5963	université Paris-VIII	
5974	5963	université Paris-X	
5975	5963	université Paris-XI	
5976	5963	université Paris-XII	université de Créteil
5977	5963	université Paris-XIII	université de Villetaneuse
5978	5950	école de commerce	
5979	5949	collège	
5980	5949	lycée	
5981	5980	lycée professionnel	
5982	5980	lycée technique	
5983	5949	école	 
5984	\N	Matière première	
5985	5984	exploitation des matières premières	
5986	5985	carrière (exploitation)	
5987	5985	exploitation offshore	
5988	5985	gisement	
5989	5985	mine (gisement)	
5990	5989	mineur de fond	
5991	5984	minerai	
5992	5991	charbon	
5993	5991	métal (minerai)	
5994	5991	métal non ferreux	
5995	5994	aluminium	
5996	5994	cuivre	
5997	5994	nickel	
5998	5994	plomb	
5999	5991	métal précieux	
6000	5999	argent	
6001	5999	or (métal précieux)	
6002	5991	phosphate	
6003	5991	pierre précieuse	
6004	6003	diamant	
6005	5991	sable	
6006	5991	uranium	
6007	5984	textile (matière)	
6008	6007	laine	
6009	6007	soie	
6010	5984	énergie	
6011	6010	ZZZZ_type d'énergie	
6012	6011	hydrocarbure	
6013	6012	gaz naturel	
6014	6012	pétrole	
6015	6014	Opep	
6016	6014	produit pétrolier	
6017	6016	carburant de substitution	
6018	6016	essence	
6019	6016	essence sans plomb	
6020	6016	gaz de pétrole liquéfié	
6021	6011	électricité	
6022	6011	énergie nucléaire	
6023	6022	Agence internationale de l'énergie atomique	
6024	6022	Commissariat à l'énergie atomique	
6025	6022	combustible nucléaire	
6026	6011	énergie renouvelable	
6027	6026	énergie marémotrice	
6028	6026	énergie solaire	
6029	6026	énergie éolienne	
6030	6010	chauffage	
6031	6010	politique de l'énergie	
6032	6031	Agence Internationale de l'Energie	
6033	6031	économie d'énergie	
6034	6033	Agence de l'Environnement et maîtrise de l'énergie	
6035	6010	équipement énergétique	
6036	6035	centrale nucléaire	
6037	6036	réacteur nucléaire	
6038	6036	surgénérateur	
6039	6035	centrale thermique	
6040	6035	centrale électrique	
6041	6035	gazoduc	
6042	6035	oléoduc	
6043	\N	ZZZZ_Entreprises (liste alphabétique)	
6044	6043	WWW_Entreprises E	
6045	6044	EADS	
6046	6044	EAS	compagnie aérienne
6047	6044	EDF	
6048	6044	ENI	Compagnie nationale des hydrocarbures d'Italie
6049	6044	ETM-Voisin	
6050	6044	Ecco	
6051	6044	Ed l'Epicier	
6052	6044	Edel	
6053	6044	Eiffage	
6054	6044	Electrolux	
6055	6044	Electron Beam Service	
6056	6044	Electronic Data Systems	
6057	6044	Elf Aquitaine	Cie pétrolière
6058	6057	Elf Atochem	groupe pétrolier
6059	6044	Eli Lilly	
6060	6044	Ellipse Câble	
6061	6044	Elyo	
6062	6044	Emap	groupe de presse britannique
6063	6044	Enimont	
6064	6044	Enron	
6065	6044	Entreprise et Progrès	
6066	6044	Envie	association nantaise de lutte contre l'exclusion qui répare l'électro ménager
6067	6044	Epéda-Bertrand Faure	équipementier français
6068	6044	Eramet	
6069	6044	Ericsson	
6070	6044	Eridania Beghin-Say	
6071	6044	Essilor	
6072	6044	Estée Lauder	marque de cosmétique américaine
6073	6044	Eternit	
6074	6044	Eurest	
6075	6044	Eurest France	
6076	6044	Euris	
6077	6044	Eurocopter	
6078	6044	Eurodif	
6079	6044	Eurofin	banque financière spécialisée dans les fusions d'acquisitions
6080	6044	Europe Online	
6081	6044	Europe-Assistance	
6082	6044	Eurotunnel	
6083	6044	Euthérapie	Laboratoire pharmaceutique
6084	6044	Expand Images	
6085	6044	Exxon	
6086	6043	ZZZZ_Entreprises A	
6087	6086	AB Production	
6088	6087	AB Sat	
6089	6086	ABB	
6090	6086	ABC	
6091	6086	AEG	
6092	6086	AGF	
6093	6086	AOM	
6094	6086	ATT	
6095	6086	Accor	
6096	6086	Adia	
6097	6086	Adidas	
6098	6086	Aeroflot	
6099	6086	Agefi	journal économique
6100	6086	Agfa-Gevaert	
6101	6086	Agnelli (groupe)	
6102	6086	Agnès B	
6103	6086	Agusta	
6104	6086	Air Afrique	
6105	6086	Air Algérie	Cie d'aviation algérienne
6106	6086	Air Charter	
6107	6086	Air France	
6108	6086	Air France Europe	
6109	6086	Air Horizons	
6110	6086	Air Lib	
6111	6086	Air Liberté	
6112	6086	Air Liquide	
6113	6086	Air Littoral	
6114	6086	Airbus industrie	
6115	6114	Airbus (modèle d'avion)	
6116	6086	Airparif	
6117	6086	Akai Electric	
6118	6086	Albert Frère	
6119	6086	Alcatel	
6120	6119	Alcatel CIT	
6121	6119	Alcatel Câble	filiale câble d'Alcatel Alsthom
6122	6119	Alstom	
6123	6086	Alenia	constructeur d'avions italien
6124	6086	Alfa Romeo	
6125	6086	Alitalia	
6126	6086	Allianz	
6127	6086	Altria	
6128	6086	Altus Finance	
6129	6086	Amaury (groupe)	
6130	6086	American Airlines	
6131	6086	American Express	
6132	6086	Amro	Banque des Pays-Bas
6133	6086	André (Groupe Vivarte)	
6134	6086	Apple	Informatique
6135	6086	Arcelor	
6136	6086	Areva	
6137	6086	Arianespace	
6138	6086	Arjo Wiggins Appleton	
6139	6086	Artémis (groupe Pinault)	
6140	6086	Auchan	
6141	6086	Aventis	
6142	6086	Axa	
6143	6086	Axime	
6144	6086	Azur	
6145	6086	Aéroport de Paris	
6146	6086	Aérospatiale	
6147	6086	Aérospatiale Matra	
6148	6043	ZZZZ_Entreprises B	
6149	6148	BASF	groupe chimique allemand
6150	6148	BBC	
6151	6148	BHV	
6152	6148	BMG	branche musicale du groupe de communication allemand Bertelsman
6153	6148	BMW	
6154	6148	BNP	
6155	6148	BNP Paribas	
6156	6148	Baccarat	entreprise cristallière
6157	6148	Balenciaga	
6158	6148	Bally	
6159	6148	Banesto	
6160	6148	Bank of Credit and Commerce International	
6161	6148	Banque Colbert	filiale du Crédit Lyonnais
6162	6148	Banque Hervet	
6163	6148	Banque Morgan Stanley	banque d'affaires (USA)
6164	6148	Banque Rivaud	
6165	6148	Banque Rothschild	
6166	6148	Banque Vernes	
6167	6148	Banque européenne d'investissement	
6168	6148	Banque populaire	
6169	6148	Barclays	
6170	6148	Baring Brothers	banque d'affaires britannique
6171	6148	Barrière (casinos)	
6172	6148	Bata	
6173	6148	Bayard-Presse	
6174	6148	Bayer	
6175	6148	Belin	biscuiterie, filiale de Danone
6176	6148	Bell Atlantic Corporation	
6177	6148	Benetton (groupe)	
6178	6148	Bergasol	
6179	6148	Berkshire Hathaway	
6180	6148	Bernard Tapie Finance	
6181	6148	Bertelsmann (groupe)	
6182	6148	Bertrand Faure	
6183	6148	Bic	
6184	6148	Bidermann (entreprise)	
6185	6148	Bis	troisième groupe français de travail temporaire
6186	6148	Boeing	
6187	6148	Bolloré Technologies	
6188	6148	Bombardier (entreprise)	
6189	6148	Bon Marché	
6190	6148	Borland	
6191	6148	Bouchara	
6192	6148	Bouhyer	fonderie à Ancenis
6193	6148	Bourgoin (entreprise)	
6194	6148	Bouygues (groupe)	
6195	6194	Bouygues Télécom	
6196	6148	Braff	
6197	6148	Brandt	groupe d'électroménager
6198	6148	Brink's	
6199	6148	Bristol-Myers-Squibb	labo pharmaceutique
6200	6148	British Aerospace	
6201	6148	British Airways	
6202	6148	British Petroleum	
6203	6148	British Rail	
6204	6148	British Sky Broadcasting	
6205	6148	British Telecom	
6206	6148	Brittany Ferries	
6207	6148	Budweiser	
6208	6148	Bugatti	
6209	6148	Bull	
6210	6148	Bureau des Recherches Géologiques & Minières	
6211	6148	Business Week	
6212	6148	Bénéteau	
6213	6148	Groupe Bruxelles Lambert	
6214	6043	ZZZZ_Entreprises C	
6215	6214	C&A	entreprise de vente de textile
6216	6214	CDR	
6217	6214	CEA-Industrie	
6218	6214	CEP Communication	groupe de presse et d'édition français
6219	6214	CEPME	
6220	6214	CLT-UFA	
6221	6214	CNN	
6222	6214	Cable and Wireless	
6223	6214	Caisse des dépôts et consignations	
6224	6214	Caisse française de développement	organisme qui gère l'aide française aux pays en développement
6225	6214	Caisse nationale de prévoyance	
6226	6214	Campenon-Bernard	
6227	6214	Canadair	
6228	6214	Canal France International	
6229	6214	Canon (entreprise)	
6230	6214	Cap Gemini Sogeti	
6231	6214	Carat	
6232	6214	Carbone Lorraine	
6233	6214	CarnaudMetalbox	
6234	6214	Carrefour (entreprise)	
6235	6214	Cartier	
6236	6214	Cash Converters	
6237	6214	Casino (groupe)	
6238	6214	Castorama	
6239	6214	Cegetel	
6240	6214	Century Fox	Compagnie de cinéma
6241	6214	Cerus	
6242	6214	Chanel	
6243	6214	Charbonnages de France	groupe minier qui se recycle dans l'électricité
6244	6214	Chargeurs International	ex-Chargeurs ,textile et industrie
6245	6214	Chase Manhattan Bank	
6246	6214	Chausson	
6247	6214	Chrysler	
6248	6214	Ciba Geigy	
6249	6214	Ciments français	
6250	6214	Cipa	
6251	6214	Cisi	
6252	6214	Citibank	
6253	6214	Clarins	groupe de cosmétique
6254	6214	Club Méditerranée	
6255	6214	Coca-Cola	
6256	6214	Cofidis	
6257	6214	Cogedim	
6258	6214	Cogema	
6259	6214	Colas (BTP)	
6260	6214	Comatec	entreprise de nettoyage industriel
6261	6214	Comex	entreprise de recherche sous-marine
6262	6214	Comipar	
6263	6214	Compagnie Financiere Edmond de Rothschild	
6264	6214	Compagnie Francaise de Sucrerie	
6265	6214	Compagnie Maritime D'Affrètement	
6266	6214	Compagnie bancaire	
6267	6214	Compagnie des signaux	
6268	6214	Compagnie du BTP	
6269	6214	Compagnie générale d'entreprises automobiles	
6270	6214	Compagnie générale de constructions téléphoniques	
6271	6214	Compagnie générale maritime	
6272	6214	Compagnie immobilière Phénix	
6273	6214	Compagnie nationale du Rhône	
6274	6214	Compaq	entreprise d'informatique
6275	6214	Compass	
6276	6214	Comptoir des entrepreneurs	
6277	6214	Comptoirs Modernes	
6278	6214	Condwear's	société de franchise de magasins de préservatifs basée à Paris
6279	6214	Condé Nast	
6280	6214	Conforama	
6281	6214	Continent (entreprise)	
6282	6214	Continental Airlines	
6283	6214	Conté (entreprise)	entreprise
6284	6214	Corbis	
6285	6214	Coressa	
6286	6214	Courrèges	
6287	6214	Cray Research	
6288	6214	Credito Italiano	
6289	6214	Cristallerie de Baccarat	
6290	6214	Crown Cork & Seal	
6291	6214	Crédit Commercial de France	
6292	6214	Crédit Industriel et Commercial	banque CIC
6293	6214	Crédit Lyonnais	
6294	6214	Crédit Lyonnais Bank Nederland	
6295	6214	Crédit agricole	
6296	6214	Crédit de l'Est	
6297	6214	Crédit du Nord	
6298	6214	Crédit foncier de France	
6299	6214	Crédit immobilier de France	
6300	6214	Crédit local de France	
6301	6214	Crédit martiniquais	
6302	6214	Crédit mutuel	banque
6303	6214	Crédit mutuel de Bretagne	
6304	6214	Crédit national	petite banque spécialisée dans les entreprises
6305	6214	Crédit suisse	
6306	6214	Cyan Incorporated	entreprise multimédia américaine
6307	6214	Cyrix	
6308	6214	Wendel Investissement	
6309	6043	ZZZZ_Entreprises D	
6310	6309	DB Finances	DB pour Domlinique Bouillon
6311	6309	DHL	
6312	6309	DMC	
6313	6309	Daewoo	constructeur coréen
6314	6309	Daimler-Benz	
6315	6314	Daimler-Benz Aerospace	constructeur aéronautique allemand
6316	6314	Mercedes-Benz	
6317	6309	Daiwa Banks	
6318	6309	Damart	
6319	6309	Danone	
6320	6309	Darty	marque d'électroménager
6321	6309	Dassault Industries	
6322	6321	Dassault Electronique	
6323	6309	Daum	
6324	6309	Dauphiné News	
6325	6309	De Beers	compagnie sud-africaine détenteur mondial de la vente de pierres précieuses
6326	6309	Deutsche Bank	
6327	6309	Deutsche Telekom	
6328	6309	Devanlay	
6329	6309	Digital Equipment	
6330	6309	Dim	
6331	6309	DirecTV	
6332	6309	Discol	denrées alimentaire/Essonne
6333	6309	Disney (compagnie)	
6334	6309	Distriborg	
6335	6309	Docks de France	
6336	6309	Doux (entreprise)	
6337	6309	Dreamworks SKG	entreprise de Steven Spielberg
6338	6309	Dresdner Bank	
6339	6309	Ducati	
6340	6309	Dumez international	
6341	6309	Duménil-Leblé	
6342	6309	Déminor	
6343	6043	ZZZZ_Entreprises F	
6344	6343	Facom	entreprise metallurgique
6345	6343	Fairlines	compagnie aérienne de François Arpels (Héritier de la joaillerie Van Cleef & Arpels)
6346	6343	Fauchon	magasin gastronomique de luxe parisien
6347	6343	Ferfin	
6348	6343	Ferrari	
6349	6343	Ferruzzi	
6350	6343	Fiat	
6351	6343	Fiducial	
6352	6343	Filesa	Affaire de fausses factures du PSOE espagnol
6353	6343	Fimalac	
6354	6343	Financière Agache	
6355	6343	Financière Immobilière Bernard Tapie	
6356	6343	Fininvest	
6357	6343	First Interstate Bancorp	
6358	6343	Fisons	
6359	6343	Fnac	
6360	6343	Focus	
6361	6343	Fokker	
6362	6343	Foote Cone Belding	groupe publicitaire américain
6363	6343	Ford	
6364	6343	Foron	
6365	6343	Forte	groupe britannique d'hôtellerie et de restauration
6366	6343	Fougerolles	entreprise de construction immobilière
6367	6343	Framatome	
6368	6343	France Télé Films	nouvelle chaine câblée thématique sur la fiction
6369	6343	France Télécom	
6370	6343	Française des jeux	
6371	6343	Fuji	
6372	6343	Fujitsu	
6373	6343	Fédération Continentale	
6374	6343	Félix Potin	
6375	6043	ZZZZ_Entreprises G	
6376	6375	GDF	
6377	6375	GMB	
6378	6375	GMF	
6379	6375	GPE Diffusion plus	PME de mailing de la région parisienne
6380	6375	GSI	
6381	6375	GTM	
6382	6375	GTM Entrepose	entreprise spécialisée dans les plate-formes off-shore
6383	6375	Galeries Lafayette	
6384	6375	Gardner Merchant	
6385	6375	Garouste & Bonetti	
6386	6375	Gascogne (entreprise)	
6387	6375	GaultMillau	
6388	6375	Gaumont	
6389	6375	Gazprom	societe russe
6390	6375	Geemac	
6391	6375	Gehe	distributeur allemand de médicaments
6392	6375	Gemina	
6393	6375	Gemplus	usine de fabrication de la carte à puce à La Ciotat
6394	6375	Gems	filiale de la GE
6395	6375	General Electric	
6396	6375	General Electric Company	
6397	6375	General Motors	
6398	6375	Generali	
6399	6375	Generali France holding	
6400	6375	Gestoval	
6401	6375	Gibert Joseph	librairie
6402	6375	Gifco	
6403	6402	Bretagne Loire Equipement	bureau d'études inculpé dans l'affaire Urba
6404	6402	Sicopar	
6405	6375	GigaStorage	
6406	6375	Gillette	
6407	6375	GlaxoSmithKline	
6408	6375	Glem Productions	
6409	6375	Gooding Electronique	
6410	6375	Granada	
6411	6375	Grand Metropolitan	
6412	6375	Grands Moulins de Paris	
6413	6375	Groupama	
6414	6375	Groupement Européen de Marketing	
6415	6375	Groupement foncier français	
6416	6375	Grow Group	
6417	6375	Grundig	
6418	6375	Gucci	
6419	6375	Guerlain	
6420	6375	Guinness	
6421	6375	Gédéon	
6422	6375	Générale Occidentale	dirigé par Françoise Sampermans
6423	6375	Générale Sucrière	
6424	6375	Générale de Banque	banque
6425	6375	groupe Valois	
6426	6043	ZZZZ_Entreprises H	
6427	6426	HSBC	
6428	6426	Habitat (entreprise)	
6429	6426	Hachette Filipacchi Médias	
6430	6426	Hamster production	
6431	6426	Harley Davidson	
6432	6426	Havas Advertising	
6433	6426	Heineken	
6434	6426	Heinz	
6435	6426	Hermès	
6436	6426	Hersant (groupe)	
6437	6426	Hewlett-Packard	
6438	6426	Hitachi	
6439	6426	Hochtief	
6440	6426	Hoechst	groupe chimique allemand
6441	6426	Hoffmann-Laroche	
6442	6426	Holvis	
6443	6426	Honda	constructeur moto et auto
6444	6426	Hoover	usine d'électroménager
6445	6426	Howmet	filiale américaine de Pechiney fabricant des éléments pour turbomoteur
6446	6426	Hyundaï	
6447	6426	Hédiard	
6448	6426	Héliot	Entreprise de fabrique de machines pour l'industrie textile fondée par Auguste Héliot
6449	6043	ZZZZ_Entreprises I	
6450	6449	Banque Indosuez	
6451	6449	IBM	
6452	6449	ICL	entreprise d'informatique
6453	6449	IDIA	
6454	6449	IG Farben	
6455	6449	IMR	société de prestation de services
6456	6449	ITT (entreprise)	
6457	6449	Iberia	
6458	6449	Idéal Loisirs	
6459	6449	Ikéa	
6460	6449	Ilias	maison d'édition de livres sur disquette PC ou Mac
6461	6449	Iliouchine	
6462	6449	Immopar	
6463	6449	Infogrames	
6464	6449	Inmac	entreprise de matériel informatique
6465	6449	Institut français du pétrole	
6466	6449	Intel	
6467	6449	Interdeco	régie publicitaire pour la presse magazine en Europe
6468	6449	Interdiscount	repreneur de Nasa Electronic
6469	6449	Intermarché	grande distribution
6470	6449	Internationale Nederlanden Groep	Premier groupe financier néerlandais
6471	6449	Intertechnique	
6472	6449	Intuit	société d'informatique de Californie
6473	6449	Irish Press Newspapers	groupe de presse irlandais
6474	6449	Itinéris	
6475	6449	Syngenta	groupe chimique britannique
6476	6043	ZZZZ_Entreprises J	
6477	6476	JC Decaux	
6478	6476	JP Morgan	
6479	6476	JRH Conseil	
6480	6476	JVC	groupe électronique japonais
6481	6476	Jacadi	
6482	6476	Jacob-Delafon	
6483	6476	Jaguar (automobile)	
6484	6476	Japan Airlines	compagnie aérienne japonaise
6485	6476	Jeanne Lanvin SA	
6486	6476	Jeanneau (entreprise)	
6487	6476	Jet Tours	
6488	6476	Johnson & Johnson	groupe pharmaceutique
6489	6043	ZZZZ_Entreprises K	
6490	6489	KDD	
6491	6489	KLM	Compagnie aérienne
6492	6489	Kalon	N°3 britannique de la peinture de décoration
6493	6489	Kaufman et Broad	
6494	6489	Kawasaki	
6495	6489	Kenitec	
6496	6489	Kickers	
6497	6489	Kimberly-Clark	
6498	6489	Kindy	
6499	6489	Kis	entreprise grenobloise de Serge Crasnianski
6500	6489	Kleinwort Benson	
6501	6489	Kodak	
6502	6489	Kohlberg Kravis and Robert	
6503	6489	Krema	ex-usine de fabrication de bonbon de Montreuil
6504	6043	ZZZZ_Entreprises L	
6505	6504	L'Oréal	
6506	6504	LBO	
6507	6504	LVMH	
6508	6504	La Hénin	
6509	6504	La Poste	
6510	6504	La Redoute	entreprise de VPC
6511	6504	La Rochette	
6512	6504	La Samaritaine	
6513	6504	La Signalisation	
6514	6504	La Vie Claire	
6515	6504	La Vie-Le Monde	
6516	6504	Labinal	
6517	6504	Laboratoires Pierre Fabre	
6518	6504	Lactalis	
6519	6504	Lafarge Coppée	
6520	6504	Lagardère Groupe	
6521	6504	Lajaunie	entreprise de cachou
6522	6504	Lancia	
6523	6504	Lancôme	
6524	6504	Lanvin (haute couture)	
6525	6504	Lapeyre	menuiseries
6526	6504	Lark Productions	Filiale SFP
6527	6504	Larousse	
6528	6504	Lazard Frères	banque et assurances
6529	6504	Le Bourget (entreprise)	
6530	6504	Leclerc (centres)	
6531	6504	Lego	
6532	6504	Legris industries	
6533	6504	Lesieur	industrie alimentaire, groupe qui appartient à Ferruzi
6534	6504	Leven	
6535	6504	Levi Strauss	
6536	6504	Ligett	
6537	6504	Limagrain	
6538	6504	Line Data Coref	entreprise spécialisée dans le publipostage et la cartographie des consommations
6539	6504	Lipha	
6540	6504	Lloyd's	
6541	6504	Lockheed	
6542	6504	Locovia	association française pour un train musical et festif à travers Cuba de juillet à octobre 1995
6543	6504	Lonrho	conglomérat industriel et financier britannique
6544	6504	Loockeed Martin	
6545	6504	Lotus (automobile)	
6546	6504	Lotus (éditeur de logiciels)	
6547	6504	Luchaire	
6548	6504	Lucky Strike	
6549	6504	Lufthansa	Compagnie aérienne
6550	6504	Lyonnaise de Banque	
6551	6504	Lyonnaise des eaux-Dumez	
6552	6504	Léo production	boîte de production qui monte des documentaires sur les animaux
6553	6504	la Mondiale	société d'assurances
6554	6043	ZZZZ_Entreprises M	
6555	6554	MBK	
6556	6554	MCI	
6557	6554	MK2	cinéma production
6558	6554	MTV	chaine musicale internationale
6559	6554	Macintosh	
6560	6554	Maillard et Duclos	
6561	6554	Majorette (entreprise)	
6562	6554	Make-Up Art Cosmetics	
6563	6554	Mannesmann	
6564	6554	Marceau Investissements	
6565	6554	Marie Brizard	
6566	6554	Marion Merrell Dow	
6567	6554	Marks and Spencer	
6568	6554	Marseillaise de crédit	
6569	6554	Massey Ferguson	
6570	6554	Matra	
6571	6554	Matra Défense Espace	filiale espace du groupe Matra
6572	6554	Matra-Hachette	
6573	6554	Matsushita	entreprise japonaise de l'électronique et du cinéma hollywoodien
6574	6554	Mattel	
6575	6554	Maurel et Prom	groupe agroalimentaire racheté par Bernard Pagezy
6576	6554	Maxi-Livres	
6577	6554	Maxwell (groupe)	
6578	6554	Mayoly-Spindler	labo pharmaceutique
6579	6554	Mazda	
6580	6554	McDonald	
6581	6554	McDonnell Douglas	
6582	6554	Mediobanca	banque d'affaires
6583	6554	Menier	chocolaterie dont la plus belle usine était située à Noisiel, maintenant appartient à la multinationale Nestlé
6584	6554	Merck	
6585	6554	Mercury	
6586	6554	Meridian Ferries	
6587	6554	Merlin Gerin	
6588	6554	Merrill Lynch	
6589	6554	Messageries lyonnaises de presse	
6590	6554	Metaleurop	filiale du groupe Preussag
6591	6554	Metro Goldwyn Mayer	
6592	6554	Michelin	
6593	6554	Microsoft	
6594	6554	Mitsubishi	
6595	6554	Mittal Steel	 
6596	6554	Mobil	
6597	6554	Mondial Assistance	
6598	6554	Monoprix	
6599	6554	Monsanto	
6600	6554	Montedison	
6601	6554	Montlaur	chaîne de supermarchés/sud-ouest
6602	6554	Moody's	
6603	6554	Morgan Grenfell	
6604	6554	Motorola	
6605	6554	Moulinex	
6606	6554	Multivision	chaîne de télévision câblée de pay per view
6607	6554	Myrys	
6608	6554	Mécatherm	
6609	6554	Méridien	
6610	6554	Métrologie International	grossiste informatique en difficulté financière
6611	6043	ZZZZ_Entreprises N	
6612	6611	NBC	333è network US
6613	6611	NEC	Electronique - Japon
6614	6611	NPI	
6615	6611	NTT	
6616	6611	Naf-Naf	
6617	6611	Nasa Electronique	
6618	6611	Natalys	entreprise de confection pour enfants
6619	6611	National Geographic	
6620	6611	Navigation Mixte	
6621	6611	Nestlé	
6622	6611	NetHold	
6623	6611	Netscape	
6624	6611	Newco	
6625	6611	Next	Groupe britannique d'habillement
6626	6611	Neyrpic	
6627	6611	Nicollin	
6628	6611	Nike	
6763	6727	Schlumberger	
6629	6611	Nintendo	groupe japonais de jeux vidéo
6630	6611	Nissan	Entreprise japonaise
6631	6611	Nomura	banque japonaise à Paris
6632	6611	Noos	filiale de la Lyonnaise des Eaux
6633	6611	Normed	
6634	6611	Northern Electric	
6635	6611	Northern Telecom	entreprise canadienne de télécom
6636	6611	Northumbrian Water	Distributeur d'eau britannique
6637	6611	Norwich Union	
6638	6611	Nouvelles Frontières	
6639	6611	Nouvelles Messageries de la presse parisienne	
6640	6611	Novalliance	
6641	6611	Novartis	
6642	6611	Némésia	société informatique vouée à la mémoire d'entreprise
6643	6043	ZZZZ_Entreprises O	
6644	6643	Olivetti	entreprise d'informatique
6645	6643	Opel	
6646	6643	Oracle	société américaine de logiciels informatiques
6647	6043	ZZZZ_Entreprises P	
6648	6647	PSA	
6649	6648	Citroën	
6650	6647	Packard Bell	
6651	6647	Pain Jacquet	
6652	6647	Pallas Stern	
6653	6647	Pampers	couche bébé
6654	6647	Pan Am	
6655	6647	PanAmSat	1ère société privée de service de compunications par satelilte
6656	6647	Papeteries du Limousin	
6657	6647	Paramount	
6658	6647	Paribas	
6659	6647	Pathé (ex-Chargeurs)	ex-Chargeurs , communication
6660	6647	Pearson	
6661	6647	Pepsi-Cola	
6662	6647	Peregrine Investment Holdings	
6663	6647	Pernod Ricard	
6664	6647	Perrier (boisson)	
6665	6647	Peugeot	
6666	6647	Pfizer	
6667	6647	Philips	
6668	6647	Piaggio	
6669	6647	Pinault-Printemps-La Redoute	
6670	6647	Pixibox	
6671	6647	Plastic Omnium	
6672	6647	Play Bac Presse	
6673	6647	Poliet	
6674	6647	Polygram	maison de disques
6675	6647	Pompes funèbres générales	
6676	6647	Porsche	
6677	6647	Potasses d'Alsace	
6678	6647	Power Computing	
6679	6647	Pratt and Whitney	
6680	6647	Printemps (entreprise)	
6681	6647	Prisa	
6682	6647	Prisma Presse	
6683	6647	Prisunic	
6684	6647	Procter et Gamble	distributeur de lessive
6685	6647	Prologos	
6686	6647	Promodès	n°4 de la distribution française
6687	6647	Pryca	Filiale espagnole de Carrefour
6688	6647	Prénatal	entreprise de confection pour enfants
6689	6647	Psion	
6690	6647	Puma (entreprise)	Marque sportive
6691	6647	Péchiney	
6692	6043	ZZZZ_Entreprises Q	
6693	6692	Quadral	
6694	6692	Québecor	
6695	6043	ZZZZ_Entreprises R	
6696	6695	RATP	
6697	6695	RDV	
6698	6695	RFF	
6699	6695	RJR Nabisco	
6700	6695	Radio télévision belge francophone	
6701	6695	Rallye (entreprise)	
6702	6695	Reader's Digest	
6703	6695	Reckitt & Colman	
6704	6695	Reebok	
6705	6695	Remafer	
6706	6695	Renault	
6707	6695	Renault Véhicules Industriels	
6708	6695	Revlon	
6709	6695	Rexel	distributeur de matériel électrique
6710	6695	Reydel Industries	
6711	6695	Reynolds (tabac)	groupe cigarettier français
6712	6695	Rheinbraun	
6713	6695	Rhodia	
6714	6695	Rhône Poulenc	
6715	6714	Rhône Poulenc Rorer	
6716	6695	Richemont	groupe appartenant à la famille sud-africaine Rupert et qui contrôle la plupart des marques de cigarettes
6717	6695	Rieter	
6718	6695	Ringier	groupe de presse Suisse
6719	6695	Rolls Royce	
6720	6695	Rothmans	fabricant de cigarettes
6721	6695	Rothschild et Cie	
6722	6695	Roussel Uclaf	
6723	6695	Rover	
6724	6695	Ruggieri (entreprise)	
6725	6695	Régie France Espace	
6726	6695	Rémy Cointreau	
6727	6043	ZZZZ_Entreprises S	
6728	6727	SA Riverland	
6729	6727	SA2B	entreprise en liquidation judiciaire
6730	6727	SCGPM	entreprise de travaux publics impliqués dans l'Affaire des fausses factures du RPR des Hauts de Seine
6731	6727	SCOA	
6732	6727	SCREG	
6733	6727	SDBO	
6734	6727	SDEI	
6735	6727	SEB	
6736	6727	SES	
6737	6727	SFR	
6738	6727	SG Warburg	
6739	6727	SGE	
6740	6727	SGS-Thomson	groupe franco-italien d'électronique
6741	6727	SKF	
6742	6727	SMH	
6743	6727	SNCF	
6744	6727	Saab	
6745	6727	Saatchi and Saatchi	
6746	6727	Safran	
6747	6727	Sagem	groupe électronique
6748	6727	Sagès	
6749	6727	Saint-Gobain	
6750	6727	Saint-Louis (entreprise)	
6751	6727	Salins du Midi	
6752	6727	Salomon Brothers	
6753	6727	Samsung	conglomérat sud-coréen de jeux vidéo
6754	6727	Samsung Aerospace	
6755	6727	Sandoz	
6756	6727	Sanofi Diagnostics Pasteur	
6757	6727	Sanofi-Aventis	
6758	6727	Sara Lee	
6759	6727	Sari-Seeri	
6760	6727	Sater	filiale d'Altus
6761	6727	Saur (entreprise)	
6762	6727	Scandinavian Airlines Systems	compagnie aérienne scandinave
6764	6727	Schneider Electric	
6765	6727	Schoeller und Hoesch	groupe allemand
6766	6727	Scholl	
6767	6727	Scor	
6768	6727	Seagram	entreprise américaine de spiritueux et de cinéma
6769	6727	Seat	Filiale de Volkswagen
6770	6727	Secm-Dol	PME de mécanique de Sarcelles qui embauche
6771	6727	Secodip	
6772	6727	Seerc	Filiale de la Lyonnaise des eaux
6773	6727	Sega	
6774	6727	Seita	
6775	6727	Sema group	
6776	6727	Semi-Tech	société de HongKong qui prend le contrôle d'Akaï
6777	6727	Senegest	affaire Schuller/Maréchal
6778	6727	Serel	
6779	6727	Sernam	société de transport dépendant de la SNCF
6780	6727	Sextant Avionique	
6781	6727	Shell	groupe pétrolier
6782	6727	Shopi	
6783	6727	Sideco	Société d'économie mixte du département du Val-de-Marne
6784	6727	Sidel	Fabricant de machines pour bouteilles en plastique
6785	6727	Siemens	
6786	6727	Silgan	producteur US d'emballages métalliques
6787	6727	Singapore Airlines	
6788	6727	Sirea	entreprise italienne qui a imité le cachou Lajaunie
6789	6727	Skis Rossignol	
6790	6727	Skoda	
6791	6727	Sligos	
6792	6727	Smith New Court	
6793	6727	Smithsonian Institute	organisme qui supervise l'ensemble des grands musées de Washington
6794	6727	Smurfit	entreprise irlandaise
6795	6727	Snecma	
6796	6727	Société des bains de mer	
6797	6727	Société européenne de propulsion	
6798	6727	Société française d'assurance crédit	
6799	6727	Société générale	
6800	6727	Société marseillaise de crédit	
6801	6727	Société nationale Corse Méditerranée	
6802	6727	Société nationale des poudres et explosifs	
6803	6727	Socotec	
6804	6727	Socpresse	
6805	6727	Sodexho	groupe de restauration
6806	6727	Sodiaal	groupe laitier qui contient Yoplait
6807	6727	Sofaris	
6808	6727	Sofirec	
6809	6727	Soganimes	société de Nîmes au coeur d'une affaire de corruption
6810	6727	Sogenal	
6811	6727	Sogerap	Filiale Elf Aquitaine
6812	6727	Sollac	
6813	6727	Somabat	
6814	6727	Sommer Allibert	groupe de transformation plastique
6815	6727	Sonacotra	
6816	6727	Sony	
6817	6727	Sony Music France	
6818	6727	South West Trains	
6819	6727	South Western Electricity	
6820	6727	Sovac	
6821	6727	Spedidam	
6822	6727	Spie-Batignolles	
6823	6727	Spir Communication	
6824	6727	Springer (groupe)	
6825	6727	Sprint (entreprise)	
6826	6727	Stéphane Kelian	
6827	6727	Sud-Ouest (presse)	Presse écrite
6828	6727	Suez (Groupe)	
6829	6727	Sumitomo	
6830	6727	Sun Microsystems	
6831	6727	Swiss	
6832	6727	Sélection du Reader's Digest	maison d'édition
6833	6043	ZZZZ_Entreprises T	
6834	6833	TAT European Airlines	filiale française de Bristish Airways
6835	6833	TCI	cablo-operateur US
6836	6833	TPS	Société qui réunit TF1,, M6, France Télévision, Lyonnaise Communication et CLT.
6837	6833	TV France International	
6838	6833	TWA	
6839	6833	Tati	
6840	6833	Technip	
6841	6833	Telefonica	
6842	6833	Templeton Global Investor	
6843	6833	Testut	
6844	6833	Thomson	
6845	6844	Thales	
6846	6844	Thomson Multimédia	
6847	6833	Thorn EMI	
6848	6847	EMI	
6849	6833	Thyssen	groupe sidérurgique allemand
6850	6833	Time Warner Inc	
6851	6833	Toshiba	
6852	6833	Total	
6853	6833	TotalFinaElf	
6854	6833	Toyota	voiture de rallye
6855	6833	Toys'R'Us	
6856	6833	Trema	
6857	6833	Trois Suisses	
6858	6833	Turboméca	
6859	6833	Turner Broadcasting System	
6860	6833	Téfal	
6861	6043	ZZZZ_Entreprises U	
6862	6861	UAP	compagnie d'assurance
6863	6861	UCB	
6864	6861	UGC (cinéma)	
6865	6861	Ugine	
6866	6861	Unilever	
6867	6861	Union des banques suisses	
6868	6861	Union industrielle de crédit	
6869	6861	Uniroyal	
6870	6861	Unisource	
6871	6861	United Airlines	
6872	6861	Universal Studios	
6873	6861	Upsa	labo pharmaceutique
6874	6861	Urba	
6875	6861	Usinor-Sacilor	
6876	6043	ZZZZ_Entreprises V	
6877	6876	VSD	hebdomadaire
6878	6876	Valeo	équipementier automobile
6879	6876	Vallourec	
6880	6876	Van Cleef et Arpels	haute joaillerie de la place Vendôme
6881	6876	Venturi	
6882	6876	Verreries ouvrières d'Albi	
6883	6876	Viacom	
6884	6876	Virgin	regroupe 5 magasins en France
6885	6876	Virgin Atlantic Airways	
6886	6876	Visa international	
6887	6876	Vivendi Universal Publishing	
6888	6876	Vivendi-Universal	
6889	6888	Compagnie générale de vidéo-communication	
6890	6888	Veolia Environnement	
6891	6876	Volkswagen	
6892	6891	Audi	
6893	6876	Volvo	
6894	6043	ZZZZ_Entreprises W	
6895	6894	Wagons-Lits	compagnie de trains de nuit
6896	6894	Wallenberg (entreprise)	
6897	6894	Wang (entreprise)	
6898	6894	Wells Fargo Bank	
6899	6894	Westinghouse	
6900	6894	Whirlpool	
6901	6894	Whitbread	
6902	6894	WorldCom	
6903	6894	Worms et compagnie	
6904	6043	ZZZZ_Entreprises X	
6905	6904	Xerox	
6906	6043	ZZZZ_Entreprises Y	
6907	6906	Yves Rocher	Groupe cosmétique français
6908	6906	Yves Saint Laurent	
6909	6043	ZZZZ_Entreprises Z	
6910	6909	ZDF	
6911	6909	Zannier	
6912	6909	Zodiac (entreprise)	
6913	\N	Affaire du juge Bernard Borrel	
6914	6913	Elisabeth Borrel	
6915	6913	Olivier Morice	
6916	6913	relation France Djibouti	
6917	\N	QFE	 
6918	\N	OSM	 
6919	\N	QAN	 
6920	\N	Affaire des déchets toxiques d'Abidjan	
6921	\N	Industrie	
6922	6921	politique industrielle	
6923	6922	ZZZZ_structure industrielle	
6924	6923	petite et moyenne industrie	
6925	6923	usine	
6926	6922	restructuration industrielle	
6927	6926	CIRI	
6928	6926	plan de restructuration	
6929	6926	reconversion industrielle	
6930	6922	stratégie industrielle	
6931	6930	diversification industrielle	
6932	6930	délocalisation	
6933	6930	espionnage industriel	
6934	6921	production industrielle	
6935	6934	norme	
6936	6935	AFNOR	
6937	6934	sous-traitance	
6938	6934	technique industrielle	
6939	6938	chantier	
6940	6938	manutention	
6941	6938	raffinage	
6942	6938	stockage	
6943	6921	produit industriel	
6944	6943	ZZZZ_bien intermédiaire	
6945	6944	acier	
6946	6944	matériau composite	
6947	6944	papier - carton	
6948	6944	verre	
6949	6943	bien d'équipement	
6950	6949	matériel	
6951	6950	matériel portable	
6952	6943	bien de consommation	
6953	6952	ZZZZ_cycle et motocycle	utiliser un terme plus précis
6954	6953	cyclomoteur	
6955	6953	moto	
6956	6953	scooter	
6957	6953	vélo	
6958	6953	vélo tout terrain	
6959	6952	bagage	
6960	6952	chaussure	
6961	6952	cigare	
6962	6952	cigarette	
6963	6952	cosmétique	
6964	6952	maroquinerie	
6965	6952	meuble	
6966	6952	produit d'entretien	
6967	6952	produit jetable	
6968	6952	équipement ménager	
6969	6968	appareil sanitaire	
6970	6968	électroménager	
6971	6943	défaut de fabrication	
6972	6921	secteur industriel	
6973	6972	Bâtiment et Travaux Publics	
6974	6973	bâtiment	
6975	6973	matériaux de construction	
6976	6972	armurerie	
6977	6976	arme individuelle	
6978	6972	aéronautique	
6979	6978	avion	
6980	6979	Concorde (avion)	
6981	6979	avion de transport régional	
6982	6978	hélicoptère	
6983	6972	climatisation	
6984	6972	construction navale	
6985	6984	chantier naval	
6986	6984	réparation navale	
6987	6972	céramique	
6988	6972	emballage	
6989	6988	aérosol	
6990	6972	horlogerie	
6991	6972	imprimerie	
6992	6972	industrie agroalimentaire	
6993	6992	alimentation animale	
6994	6992	biscuiterie	
6995	6992	brasserie	
6996	6992	charcuterie	
6997	6992	confiserie	
6998	6992	conserve alimentaire	
6999	6998	additif alimentaire	
7000	6992	produit surgelé	
7001	6972	industrie automobile	
7002	7001	automobile	
7003	7002	automobiliste	
7004	7002	monospace	
7005	7002	voiture décapotable	
7006	7002	voiture intelligente	
7007	7002	véhicule de collection	
7008	7002	véhicule tout terrain	
7009	7002	véhicule utilitaire	
7010	7002	véhicule électrique	
7011	7001	concessionnaire automobile	
7012	7001	diesel	
7013	7001	équipement automobile	
7014	6972	industrie chimique	
7015	7014	matière plastique	
7016	7014	peinture et vernis	
7017	6972	industrie culturelle	
7018	6972	industrie du bois	
7019	7018	bois exotique	
7020	6972	industrie du jouet	
7021	7020	jouet	
7022	6972	industrie du luxe	
7023	7022	bijouterie	
7024	7023	bijou	
7025	7022	fourrure	
7026	7022	parfumerie	
7027	6972	industrie informatique	
7028	6972	industrie mécanique	
7029	7028	forage	
7030	7028	industrie ferroviaire	
7031	7028	machine outil	
7032	7028	moteur	
7033	7028	outillage	
7034	6972	industrie pharmaceutique	
7035	7034	parapharmacie	
7036	7034	pharmacie (officine)	
7037	6972	industrie pétrolière	
7038	6972	industrie spatiale	
7039	6972	industrie textile	
7040	7039	fibre synthétique	
7041	7039	industrie de l'habillement	
7042	7041	lingerie	
7043	7041	vêtement	
7044	6972	industrie électrique	
7045	7044	ligne électrique	
7046	7044	éclairage	
7047	6972	isolation	
7048	6972	lunetterie	
7049	6972	métallurgie	
7050	7049	Union des industries métallurgiques et minières	
7051	6972	pneumatique	
7052	6972	sidérurgie	
7053	6972	électronique	
7054	7053	composant électronique	
7055	7053	radar	
7056	7053	électronique grand public	
7057	\N	EUROPE,WEU,ASIA,^OVR	 
7058	\N	T	 
7059	\N	Disparition du Docteur Godard	 
7060	\N	,^OVR	 
7061	\N	Drees	 
7062	\N	Jean-Paul Béchat	 
7063	\N	catastrophe écologique	 
7064	\N	Groupe information prisons	 
7065	\N	Comité d'action des prisonniers	 
7066	\N	Bernard Borrel	 
7067	\N	télévision mobile	 
7068	\N	Vietnam	 
7069	\N	créatrice	 
7070	\N	Villepin	 
7071	\N	Villepin dominique	 
7072	\N	PNUE	 
7073	\N	zouk	 
7074	\N	sans-papiers	 
7075	\N	import	 
7076	\N	low-cost	 
7077	\N	médias	 
7078	\N	cueilette	 
7079	\N	lutte (contre)	 
7080	\N	taux de crédit	 
7081	\N	non-inscrits	 
7082	\N	non-inscrit	 
7083	\N	non inscrit	 
7084	\N	Gus Van Sant	 
7085	\N	contôle aérien	 
7086	\N	contôle	 
7087	\N	pére	 
7088	\N	Affaire Borrel	 
7089	\N	XIIéme	 
7090	\N	Yann Arthus-Bertrand	 
7091	\N	quorum	 
7092	\N	infirmière	 
7093	\N	reconnaissance	 
7094	\N	comité de vigilance	 
7095	\N	decès	 
7096	\N	famille nombreuse	 
7097	\N	difficulté	 
7098	\N	déplacement (visite)	 
7099	\N	nommination	 
7100	\N	jurys	 
7101	\N	place	 
7102	\N	Ivry	 
7103	\N	sous-marin nucléaire	 
7104	\N	Nadine Gordimer	 
7105	\N	vidéo à la demande	 
7106	\N	loups	 
7107	\N	edition	 
7108	\N	obséques	 
7109	\N	delation	 
7110	\N	idéologie	 
7111	\N	vice-Premier ministre	 
7112	\N	forêt vierge	 
7113	\N	commission européenne	 
7114	\N	travestie	 
7115	\N	diabéte	 
7116	\N	Libération (journal)retraite	 
7117	\N	depense	 
7118	\N	delai	 
7119	\N	repassage	 
7120	\N	fiche pratique	 
7121	\N	malbouffe	 
7122	\N	Lluís Llach	 
7123	\N	De Palma	 
7124	\N	Patrimoine mondial	 
7125	\N	actreur	 
7126	\N	Hitchcock	 
7127	\N	feminisme	 
7128	\N	contumace	 
7129	\N	restaurant; obésité	 
7130	\N	cellule (biologie)eugénisme	 
7131	\N	conccurrence	 
7132	\N	relaion bilatérale	 
7133	\N	eu	 
7134	\N	directive européenne	 
7135	\N	Suéde	 
7136	\N	suspendu	 
7137	\N	éléve	 
7138	\N	Jean-Philippe Smet	 
7139	\N	ministre de la Santé	 
7140	\N	ogement	 
7141	\N	négociation de paix	 
7142	\N	campagne politique	 
7143	\N	journaalisme	 
7144	\N	experience	 
7145	\N	éxperience	 
7146	\N	experimentation	 
7147	\N	Marie-Georges Buffet	 
7148	\N	déclaratio	 
7149	\N	espionage	 
7150	\N	jeunsse	 
7151	\N	dééclaration	 
7152	\N	ministère de l'Education	 
7153	\N	Debbouez Jamel	 
7154	\N	Vilepinte	 
7155	\N	témoignage; Bretagne	 
7156	\N	Brtetagne	 
7157	\N	slovènie	 
7158	\N	Feminisme	 
7159	\N	crooner	 
7160	\N	décçs	 
7161	\N	^OVR	 
7162	\N	Ratp	 
7163	\N	suppressions d'emploi	 
7164	\N	sonade	 
7165	\N	pacte	 
7166	\N	altermondisaliste	 
7167	\N	meanace	 
7168	\N	etourage	 
7169	\N	Bayrou	 
7170	\N	Sarkozy Nicolas gaffe	 
7171	\N	maréé noire	 
7172	\N	Israêl	 
7173	\N	Truman Capote	 
7174	\N	Eurpoe 1	 
7175	\N	slamisme	 
7176	\N	radiothérapie	 
7177	\N	campagne électorale  militantisme	 
7178	\N	Sarkozy Nicolas UMP	 
7179	\N	inspecteurs du travail	 
7180	\N	procés	 
7181	\N	site web	 
7182	\N	Michel Polacco	 
7183	\N	historie	 
7184	\N	Jazz	 
7185	\N	projet de décret	 
7186	\N	hopital	 
7187	\N	Coetzee J. M.	 
7188	\N	Parti socialiste	 
7189	\N	lutt (action contre)	 
7190	\N	Sarkozyn	 
7191	\N	déclration	 
7192	\N	Le Pen Je	 
7193	\N	New-York (ville)  rock	 
7194	\N	UMP.	 
7195	\N	Coupe Louis-Vuitton	 
7196	\N	séléction	 
7197	\N	écoute	 
7198	\N	attenat	 
7199	\N	lterrorisme	 
7200	\N	territoire	 
7201	\N	raids	 
7202	\N	conseil de l'ordre des médecins	 
7203	\N	meutre	 
7204	\N	maladie chronique	 
7205	\N	video	 
7206	\N	protectionde l'environnement	 
7207	\N	excution capitale	 
7208	\N	éxcution capitale	 
7209	\N	éxecution capitale	 
7210	\N	éxécution capitale	 
7211	\N	action de groupe	 
7212	\N	sciences	 
7213	\N	élection présiedntielle	 
7214	\N	jeux vidéo	 
7215	\N	télé réalité	 
7216	\N	Assemblé Nationale	 
7217	\N	consmmation	 
7218	\N	marionnettes	 
7219	\N	RMN	 
7220	\N	éthiopie	 
7221	\N	carburant vert	 
7222	\N	invesstissement	 
7223	\N	séchersse	 
7224	\N	plan de suppression	 
7225	\N	Denis Olivennes	 
7226	\N	criket	 
7227	\N	medias	 
7228	\N	journalsye	 
7229	\N	journalste	 
7230	\N	'UMP	 
7231	\N	escuse	 
7232	\N	L'Equateur	 
7233	\N	Texaco	 
7234	\N	Rouen.	 
7235	\N	campagne électoral	 
7236	\N	ump	 
7237	\N	résulat	 
7238	\N	Alemagne	 
7239	\N	année 30	 
7240	\N	Mouvement Démocratique	 
7241	\N	ddéclaration	 
7242	\N	vétement	 
7243	\N	ethique	 
7244	\N	résulltat	 
7245	\N	communication politique	 
7246	\N	echec	 
7247	\N	Sarkozy Nicolas;	 
7248	\N	ntronisation	 
7249	\N	Champs-Elysée	 
7250	\N	L'Illinois	 
7251	\N	militante	 
7252	\N	empoisonné	 
7253	\N	ecréation d'emploi	 
7254	\N	Alain Lipietz	 
7255	\N	annivesraire	 
7256	\N	invesstiture	 
7257	\N	annéées 90	 
7258	\N	mre	 
7259	\N	fonds spéculatifs	 
7260	\N	fond spéculatif	 
7261	\N	éspèce menacée	 
7262	\N	surpêche	 
7263	\N	éspéce menacée	 
7264	\N	éspece menacée	 
7265	\N	Le Monde La Vie	 
7266	\N	festival cinéma	 
7267	\N	cumul des mandat	 
7268	\N	péche clandestin	 
7269	\N	condition de travaul	 
7270	\N	sans p	 
7271	\N	actrice	 
7272	\N	cinéma;	 
7273	\N	Ben Laden	 
7274	\N	vodéo	 
7275	\N	personne agée	 
7276	\N	tueurs en série	 
7277	\N	pivatisation	 
7278	\N	dipôme	 
7279	\N	assasinat	 
7280	\N	Règlement de comptes	 
7281	\N	statistique . Cnam	 
7282	\N	deputé	 
7283	\N	finance	 
7284	\N	sommaire	 
7285	\N	abstentioin	 
7286	\N	urgence humanitaire	 
7287	\N	chrétien-démocrate	 
7288	\N	George Busch	 
7289	\N	Busch George	 
7290	\N	Evrest	 
7291	\N	éxécution	 
7292	\N	CIa	 
7293	\N	télé realité	 
7294	\N	tv reality	 
7295	\N	abstentionisme	 
7296	\N	thése	 
7297	\N	Le Pérou	 
7298	\N	produiit dangereux	 
7299	\N	ZZZZ_Partis et mouvements politiques (liste)	Ne pas utiliser. Employer un terme plus précis.
7300	7299	ZZZZ_partis et mvts politiques en France (liste)	Ne pas utiliser. Employer un terme plus précis.
7301	7300	Action française	
7302	7300	Alliance (parti politique)	
7303	7300	Carrefour du gaullisme	association de gaullistes présidée par Roland Nungesser
7304	7300	Centre national des Indépendants	
7305	7300	Chasse pêche nature et traditions	
7306	7300	Convention pour une alternative progressiste	
7307	7300	Demain la France	
7308	7300	FLNC	
7309	7308	Accolta naziunale corsa	
7310	7308	Corsica Viva	
7311	7308	Cuncolta	
7312	7308	Fronte Ribellu	Organisation clandestine corse
7313	7308	Mouvement pour l'autodétermination	
7314	7300	FLNKS	
7315	7300	Front National	
7316	7315	Front National Jeunes	
7317	7300	GUD	Groupuscule d'extrême droite. Groupe Union Défense
7318	7300	Gauche républicaine	
7319	7300	Gauche socialiste	
7320	7300	Génération écologie	
7321	7300	Jeunesses nationalistes révolutionnaires	
7322	7300	Les Verts	
7323	7300	Ligue communiste révolutionnaire	
7324	7300	Lutte ouvrière	nom du parti de Arlette Laguiller et journal d'extrême-gauche
7325	7300	MNR	
7326	7300	Mouvement des réformateurs	
7327	7300	Mouvement démocrate (ex UDF)	 
7328	7300	Mouvement européen	
7329	7300	Mouvement pour la France	
7330	7300	Mouvement républicain et citoyen	
7331	7300	Mouvement écologiste indépendant	nouveau mouvement écologiste créé par Antoine Waechter
7332	7300	Nouvelle Résistance	
7333	7300	Oeuvre française	Mouvement d'extrème droite
7334	7300	Organisation armée secrète	
7335	7300	PNFE	Parti Nationaliste Français et Européen
7336	7300	PSU	ancien parti créé par Michel Rocard après Mai-68
7337	7300	Parti Communiste Français	
7338	7300	Parti Populaire Français	
7339	7300	Parti Radical de Gauche	
7340	7300	Parti de la loi naturelle	
7341	7300	Parti humaniste	
7342	7300	RPR	
7343	7300	Ras l'Front	
7344	7300	Rassemblement pour la France	
7345	7300	Rassemblement pour une autre politique	
7346	7300	Rassemblement-UMP	
7347	7300	Sampieru	
7348	7300	UDF	
7349	7348	Démocratie libérale (UDF)	
7350	7348	Force démocrate	
7351	7348	Parti populaire pour la démocratie française	club politique de l'UDF
7352	7348	Parti radical (UDF)	
7353	7300	UMP	
7354	7300	Union calédonienne	
7355	7300	Union du peuple corse	
7356	7299	ZZZZ_partis et mvts politiques étrangers (liste)	Ne pas utiliser. Employer un terme plus précis.
7357	7356	AFDL	
7358	7356	Al-Qaeda	
7359	7356	Alliance nationale	Parti néofasciste italien
7360	7356	Batasuna	
7361	7356	Bharatyia Janata Party	parti politique indien
7362	7356	Brigades rouges	
7363	7356	Congrès juif mondial	
7364	7356	Congrès national africain	
7365	7356	Congrès panafricain	
7366	7356	ETA	
7367	7356	FFS	
7368	7356	FLN	
7369	7356	FPLP	
7370	7356	Forces armées révolutionnaires de Colombie	
7371	7356	Forza Italia	
7372	7356	Fraction Armée Rouge	
7373	7356	Front Islamique du Salut	
7374	7373	Armée islamique du salut	
7375	7356	Front Polisario	
7376	7356	Front démocratique de libération de la Palestine	
7377	7356	Front démocratique du Burundi	
7378	7356	Front patriotique rwandais	
7379	7356	Front sandiniste de libération nationale	
7380	7356	GAL	
7381	7356	GIA	
7382	7356	Gamaat al-Islamiya	
7383	7356	Hamas	
7384	7383	Ezzedine el-Qassem	
7385	7356	Hezbollah	
7386	7356	INLA	
7387	7356	IRA	
7388	7356	Inkatha	
7389	7356	Jihad islamique	
7390	7356	Kadek	
7391	7356	Kadima	
7392	7356	LTTE	
7393	7356	Ligue du Nord	
7394	7356	Ligue nationale pour la démocratie	
7395	7356	Likoud	
7396	7356	Mohadjir National Movement	
7397	7356	Mouvement Démocratique des Forces Casamançaises	
7398	7356	OLP	
7399	7398	Fatah	
7400	7356	PDK	
7401	7356	PSOE	parti socialiste espagnol
7402	7356	Parti d'Action démocratique	parti musulman du président Alija Izetbegovic
7403	7356	Parti du Congrès	parti au pouvoir en Inde
7404	7356	Parti démocratique socialiste	
7405	7356	Parti libéral-démocrate	
7406	7356	Parti national	
7407	7356	Parti populaire	
7408	7356	Parti républicain (USA)	
7409	7356	Parti révolutionnaire institutionnel	parti mexicain
7410	7356	Parti travailliste	
7411	7356	RCD (parti algérien)	
7412	7356	Rassemblement National Démocratique	
7413	7356	Refah	
7414	7356	SDLP	parti irlandais
7415	7356	Shiv Sena	
7416	7356	Sinn Fein	
7417	7356	Syndicat Solidarité	
7418	7356	Taliban	
7419	7356	Tupac Amaru	Pérou
7420	7356	UCK	
7421	7356	UPK	
7422	7356	Unita (Angola)	
7423	7356	khmer rouge	
7424	7356	moudjahidin	
7425	7356	mouvement loyaliste	
7426	7356	zapatiste	
7427	\N	éxpèrience	 
7428	\N	ZZZZ_Personnalités (liste alphabétique)	
7429	7428	ZZZZ_Personnalités A	
7430	7429	ZZZZ_Personnalités AB	
7431	7430	Abacha Sani	
7432	7430	Abbado Claudio	Directeur de l'orchestre philarmonique de Berlin
7433	7430	Abbas Aboul	
7434	7430	Abbas Mahmoud	
7435	7430	Abbé Pierre	
7436	7430	Abdallah ben Abdel Aziz	
7437	7430	Abdallah de Jordanie	
7438	7430	Abdelhamid Mehri	
7439	7430	Abdeslam Ouili	Imam du quartier de la Duchère à Lyon
7440	7430	Abdi Ali Musa	
7441	7430	Abdoujaparov Djamolidine	
7442	7430	Abdoul Ali Mazari	
7443	7430	Abdurrahman Wahid	
7444	7430	Abe Shinzo	 
7445	7430	Abiola Moshood	
7446	7430	Abitbol William	
7447	7430	Abraham Behar	
7448	7430	Abraham-Kremer Bruno	
7449	7430	Abrahams Jim	
7450	7430	Abril Victoria	actrice
7451	7430	Abrioux Jean-Claude	
7452	7430	Abu Jamal Mumia	
7453	7430	Abuzeid Ali Mehmed	
7454	7429	ZZZZ_Personnalités AC	
7455	7454	Acconci Vito	
7456	7454	Accorsi Stéphane	militant nationaliste Corse
7457	7454	Accoyer Bernard	
7458	7454	Acord James	
7459	7429	ZZZZ_Personnalités AD	
7460	7459	Adams Gerry	Président du Sinn Féin
7461	7459	Adams John	
7462	7459	Adams Scott	
7463	7459	Addad Hakim Mohamed	Fondateur à Alger de l'association "Rassemblement, Action, Jeunesse"(RAJ)
7464	7459	Addala Michèle	
7465	7459	Adelbert Sautron-Ropy	candidat DOM-TOM/présidentielle 1995
7466	7459	Adelheid Hege	chercheuse à l'Ires et responsable de la revue "Chronique internationale"
7467	7459	Adjani Isabelle	
7468	7459	Adler Alexandre	
7469	7459	Adler Laure	ex-conseillère culturelle de Mitterrand et ex-animatrice du "Cercle de minuit"
7470	7459	Adolf Dresen	metteur en scène/opéra
7471	7459	Adonis	Ecrivain
7472	7459	Adorno Theodor Wiesengrund	
7473	7459	Adrien Philippe	
7474	7429	ZZZZ_Personnalités AF	
7475	7474	Afflelou Alain	
7476	7429	ZZZZ_Personnalités AG	
7477	7476	Agacinski Sylviane	
7478	7476	Agamben Giorgio	
7479	7476	Agassi André	
7480	7476	Age Madsen Svend	
7481	7476	Aghion Gabriel	
7482	7476	Agnelli Giovanni	pdg de Fiat
7483	7476	Agnelli Susanna	
7484	7476	Agnelli Umberto	PDG italien
7485	7476	Agostini Pierre	
7486	7476	Agoumi Sid Ahmed	
7487	7476	Agresti Alejandro	
7488	7476	Agret Roland	
7489	7476	Aguitton Christophe	
7490	7476	Agulhon Maurice	
7491	7476	Agusti Villaronga	Acteur et réalisateur Espagnol
7492	7429	ZZZZ_Personnalités AH	
7493	7492	Ahern Bertie	
7494	7492	Ahmadinejad Mahmoud	
7495	7429	ZZZZ_Personnalités AI	
7496	7495	Aidenbaum Pierre	
7497	7495	Aiken John	
7498	7495	Aillagon Jean-Jacques	
7499	7495	Ailleret François	
7500	7495	Aïdid Mohamed Farah	
7501	7495	Aït-Ahmed Hocine	
7502	7495	Aït-Menguellet Lounis	
7503	7429	ZZZZ_Personnalités AJ	
7504	7503	Ajello Aldo	
7505	7503	Ajmone Finestra	Maire MSI (Italie)
7506	7429	ZZZZ_Personnalités AK	
7507	7506	Akerman Chantal	
7508	7506	Akihito	
7509	7506	Akiyoshi Toshiko	
7510	7506	Akos Rethly	
7511	7429	ZZZZ_Personnalités AL	
7512	7511	Al Bano	Chanteur rock italien
7513	7511	Al Gore	
7514	7511	Al Hensen	
7515	7511	Al Lewis	créateur de la 1ère versin de la série télé Les Monstres
7516	7511	Al-Fayed Mohamed	
7517	7511	Al-Jaafari Ibrahim	
7518	7511	Al-Rantissi Abdelaziz	
7519	7511	Al-Waleed bin Talal bin Abdulaziz	prince saoudien de la famille Saoud
7520	7511	Al-Yaouar Ghazi	
7521	7511	Alagna Roberto	
7522	7511	Alarcon Fabian	
7523	7511	Albanel Christine	 
7524	7511	Albarède Michel	
7525	7511	Albee Edward	
7526	7511	Alberola Jean-Michel	
7527	7511	Albert II de Belgique	
7528	7511	Albert de Monaco	
7529	7511	Alberti Rafael	peintre et poète espagnol
7530	7511	Albertini Pierre	
7531	7511	Albright Madeleine	
7532	7511	Alda Alan	
7533	7511	Aldaya José Maria	
7534	7511	Aldrich Robert	
7535	7511	Aleman Arnoldo	
7536	7511	Alen Boksic	footballeur
7537	7511	Alesi Jean	coureur automobile de F1
7538	7511	Alexakis Art	chanteur d'Everclear
7539	7511	Alexakis Vassilis	
7540	7511	Alexander Lamar	
7541	7511	Alexander Montgomery Bernard	
7542	7511	Alexander Morrison	juge anglais
7543	7511	Alexandre Philippe	
7544	7511	Alexandre le Grand	
7545	7511	Alezard Gérard	
7546	7511	Alfarroba Catherine	maire-adjoint de Clichy
7547	7511	Alferi Pierre	
7548	7511	Alfonsi Philippe	
7549	7511	Alfonso Guerra	Numéro deux du Parti socialiste espagnol
7550	7511	Alfred North Whitehead	écrivain britannique
7551	7511	Alfreds Rubiks	
7552	7511	Algoud Albert	
7553	7511	Ali Abdallah Saleh	
7554	7511	Ali Agca Mehmet	
7555	7511	Ali Salmane	
7556	7511	Ali Vakili Rad	
7557	7511	Alia Ramiz	
7558	7511	Alighiero e Boetti	
7559	7511	Alim Qasimov	spécialiste du muqâm (oratorio avec règles très précises)
7560	7511	Allaoui Iyad	
7561	7511	Allen Paul	fondateur de Microsofts
7562	7511	Allen Rex	
7563	7511	Allen Woody	
7564	7511	Allende Salvador	Prédident socialiste du Chili assassiné en 1973 par les sbires de Pinochet.
7565	7511	Alliance Ethnik	
7566	7511	Alliez Eric	
7567	7511	Allio René	
7568	7511	Alliot Philippe	Pilote de Formule 1
7569	7511	Alliot-Marie Michèle	
7570	7511	Allouache Merzak	
7571	7511	Alloucherie Guy	
7572	7511	Alloula Abdelkader	
7573	7511	Allègre Claude	
7574	7511	Allégret Marc	
7575	7511	Almodovar Pedro	
7576	7511	Almunia Joaquim	Successeur de Felipe Gonzalez à la tête du Parti socialiste ouvrier espagnol en juin 1997.
7577	7511	Alois Mock	
7578	7511	Alphand Luc	
7579	7511	Alphandéry Claude	
7580	7511	Alphandéry Edmond	
7581	7511	Alpher Joseph	
7582	7511	Althusser Louis	
7583	7511	Altman Robert	cinéaste américain
7584	7511	Alègre Patrice	
7585	7511	Arrieta Alfo	
7586	7511	al Moki Majed	
7587	7429	ZZZZ_Personnalités AM	
7588	7587	Amado Jean	
7589	7587	Amado Jorge	
7590	7587	Amalric Mathieu	
7591	7587	Amar Paul	
7592	7587	Amara Fadela	
7593	7587	Amari Chawki	
7594	7587	Ameline Nicole	
7595	7587	Amelio Gilbert	pdg d'Apple
7596	7587	Amenabar Alejandro	
7597	7587	Amette Jacques-Pierre	
7598	7587	Amiel Jon	
7599	7587	Amiez Sébastien	ski alpin
7600	7587	Amila Jean	
7601	7587	Amin Dada Idi	
7602	7587	Amir Yigal	
7603	7587	Amirshahi Pouria	
7604	7587	Amor Behlis	paléobotaniste
7605	7587	Amos Tori	
7606	7587	Amouroux Henri	
7607	7587	Amouyal Simone	
7608	7587	Amr Moussa	
7609	7587	Amselle Jean-Loup	
7610	7587	Amédée VIII	
7611	7587	Améris Jean-Pierre	
7612	7587	Améziane Hammouche	graphiste-illustrateur
7613	7429	ZZZZ_Personnalités AN	
7614	7613	Anastasios Peponis	
7615	7613	Anderson Brett	leader du groupe rock Suede
7616	7613	Anderson Paul	
7617	7613	Andrade Mario de	écrivain brésilien
7618	7613	Andreotti Giulio	
7619	7613	Andreu Paul	architecte
7620	7613	Andreïev Léonid	
7621	7613	Andrieu Jean-Marie	
7622	7613	Andro Jean-Bernard	
7623	7613	Andros Josiane	
7624	7613	André Adeline	
7625	7613	André Jean-Marie	
7626	7613	Anelka Nicolas	
7627	7613	Anex Gilles	
7628	7613	Angelo Yves	
7629	7613	Angelopoulos Théo	
7630	7613	Anger Kenneth	
7631	7613	Angers David d'	
7632	7613	Anglade Jean-Hugues	
7633	7613	Anglade Jean-Jacques	
7634	7613	Angot André	
7635	7613	Angot Christine	
7636	7613	Angoulvent Pierre	président conseil de surveillance des PUF
7637	7613	Angoulvent-Michel Anne-Laure	
7638	7613	Angremy Jean-Pierre	
7639	7613	Anissimov Alexander	
7640	7613	Annakin Ken	
7641	7613	Annan Kofi	
7642	7613	Annaud Jean-Jacques	
7643	7613	Anne d'Angleterre	fille d'Elizabeth II
7644	7613	Annegarn Dick	
7645	7613	Ansari Soraya	
7646	7613	Anselmo Giovanni	
7647	7613	Antinori Severino	
7648	7613	Antona Henri	Conseiller régional RPR de Corse
7649	7613	Antonioni Michelangelo	
7650	7613	Antony Bernard	
7651	7613	Antunes Antonio Lobo	
7652	7613	Anymous	cinéaste
7653	7613	Anzani Martine	
7654	7613	Anémone	
7655	7429	ZZZZ_Personnalités AO	
7656	7655	Aoun Michel	
7657	7429	ZZZZ_Personnalités AP	
7658	7657	Aperghis Georges	
7659	7657	Apollinaria Souslova	écrivain et intellectuelle féministe russe
7660	7657	Appaix Georges	chorégraphe-danseur
7661	7657	Apple Fiona	
7662	7657	Apted Michael	
7663	7429	ZZZZ_Personnalités AR	
7664	7663	Arafat Souha	
7665	7663	Arafat Yasser	
7666	7663	Aragon Louis	
7667	7663	Arajol Jean-Louis	
7668	7663	Araki Gregg	
7669	7663	Araki Nobuyoshi	
7670	7663	Aranda Vicente	
7671	7663	Arap Moï Daniel	
7672	7663	Arazi Hicham	
7673	7663	Arbasino Alberto	
7674	7663	Arbore Renzo	
7675	7663	Arbour Louise	
7676	7663	Arcady Alexandre	
7677	7663	Archaos	
7678	7663	Archer Michael	
7679	7663	Ardant Fanny	actrice de cinéma
7680	7663	Ardant Philippe	
7681	7663	Ardanza José Antonio	
7682	7663	Ardisson Thierry	
7683	7663	Arditi Catherine	
7684	7663	Arditi Pierre	
7685	7663	Arenas Reinaldo	
7686	7663	Arendt Hannah	
7687	7663	Arestrup Niels	
7688	7663	Argento Dario	
7689	7663	Arias Alfredo	
7690	7663	Aristide Jean-Bertrand	
7691	7663	Arjun Singh	
7692	7663	Arkauz Arana Josu	
7693	7663	Arlen Specter	Sénateur de Pennsylvanie
7694	7663	Arlette Nepveu-Degas	
7695	7663	Arletty	
7696	7663	Arman	sculpteur
7697	7663	Armand Unger	Comparaît devant la Cour d'Assises de Strasbourg en mai 1995 pour répondre de l'assassinat d'une handicapée.
7698	7663	Armande Gobry-Valle	
7699	7663	Armando Roche Luis	Cinéaste Vénézuelien
7700	7663	Armani Giorgio	Célèbre styliste italien
7701	7663	Armitage Karole	
7702	7663	Armstrong Lance	
7703	7663	Armstrong Louis	
7704	7663	Armstrong Michael	
7705	7663	Arnault Bernard	patron du groupe de luxe LVMH
7706	7663	Arnim Elizabeth von	
7707	7663	Arnold Ben	
7708	7663	Arnold Jack	
7709	7663	Arnold Koller	
7710	7663	Arnold Munnich	
7711	7663	Arnstam Pierre-Henri	
7712	7663	Arom Simha	ethnomusicologue du CNRS
7713	7663	Aron Raymond	
7714	7663	Arp Jean	
7715	7663	Arquette Patricia	
7716	7663	Arreckx Maurice	
7717	7663	Arron Christine	
7718	7663	Arroyo Gloria	
7719	7663	Arsenijevic Vladimir	
7720	7663	Artaud Antonin	
7721	7663	Arteaga Rosalia	
7722	7663	Arthaud Florence	
7723	7663	Arthuis Jean	sénateur CDS de la Mayenne
7724	7663	Arthur	Animateur TV
7725	7663	Arthur H (musique)	
7726	7663	Arthur Joseph	
7727	7663	Arthur José	
7728	7663	Arthur L. Annecharico	producteur français des Monstres
7729	7663	Arthur Okun	
7730	7663	Arthur Taylor	batteur de jazz
7731	7663	Artus Patrick	Directeur des études économiques de la Caisse des Dépôts
7732	7663	Arzu Alvaro	
7733	7429	ZZZZ_Personnalités AS	
7734	7733	Aschieri André	
7735	7733	Asensi François	
7736	7733	Ashcroft John	
7737	7733	Ashdown Paddy	
7738	7733	Ashraoui Hanane	
7739	7733	Asim Hossein Por	joueur de tabla afghan
7740	7733	Askildsen Kjell	
7741	7733	Asloum Brahim	
7742	7733	Asma Jehangir	avocate pakistanaise pdte. commiss. droits de l'homme
7743	7733	Asquith Anthony	cinéaste britannique des années 50
7744	7733	Assaraf Robert	
7745	7733	Assayas Olivier	
7746	7733	Assouline David	
7747	7733	Assouline Pierre	
7748	7733	Astier Hubert	
7749	7733	Astier Pierre	
7750	7733	Asylum Soul	
7751	7429	ZZZZ_Personnalités AT	
7752	7751	Athey Ron	
7753	7751	Atlan Henri	scientifique, membre du Comité d'éthique
7754	7751	Atlas Natacha	
7755	7751	Attaf Ahmed	
7756	7751	Attal Yvan	
7757	7751	Attali Bernard	
7758	7751	Attali Jacques	
7759	7751	Attenborough Richard	
7760	7751	Attias Jean Christophe	
7761	7429	ZZZZ_Personnalités AU	
7762	7761	Aubart François	
7763	7761	Auberger Philippe	
7764	7761	Aubert Alain	
7765	7761	Aubert François d'	
7766	7761	Aubert Guy	
7767	7761	Aubert Jean-Pierre	
7768	7761	Aubert Jean-louis	
7769	7761	Aubert Marie-Hélène	
7770	7761	Aubert Raymond-Max	secrétaire d'Etat chargé du Développement rural
7771	7761	Aubier Pascal	
7772	7761	Aubin Stéphanie	Chorégraphe
7773	7761	Aubrac Lucie	
7774	7761	Aubrac Raymond	
7775	7761	Aubry Alain	déléguée CGT
7776	7761	Aubry Martine	
7777	7761	Aubry Sophie	
7778	7761	Audemars Simone	
7779	7761	Auden Wystan Hugh	poète anglais
7780	7761	Audiard Jacques	cinéma
7781	7761	Audiard Michel	
7782	7761	Audiberti Jacques	
7783	7761	Audouit Ludovic	
7784	7761	Aufaure Claude	
7785	7761	Aufray Hugues	
7786	7761	Auger Patrick	
7787	7761	Augier Sylvain	animateur du magazine "Faut pas rêver" sur France 3
7788	7761	Auguin Christophe	
7789	7761	August Bille	
7790	7761	Augustt Cornélius	
7791	7761	Augé Marc	
7792	7761	Aulagnon Thierry	
7793	7761	Aumont Michel	
7794	7761	Aung San Suu Kyi	
7795	7761	Aurillac Martine	
7796	7761	Auriol Didier	
7797	7761	Auriol Hubert	patron du Paris-Dakar
7798	7761	Auroux Jean	
7799	7761	Austen Jane	
7800	7761	Auster Paul	
7801	7761	Autant-Lara Claude	
7802	7761	Auteuil Daniel	
7803	7761	Autissier Isabelle	
7804	7429	ZZZZ_Personnalités AV	
7805	7804	Avary Roger	
7806	7804	Avedon Richard	
7807	7804	Averty Jean-Christophe	
7808	7804	Avramovic Dragoslav	
7809	7804	Avril Pierre	professeur de droit à l'université de Paris II Assas
7810	7804	Avrillier Raymond	
7811	7429	ZZZZ_Personnalités AX	
7812	7811	Axionov Vassili	
7813	7429	ZZZZ_Personnalités AY	
7814	7813	Ayache Alain	éditeur
7815	7813	Ayache Yehia	
7816	7813	Ayalon Ami	
7817	7813	Ayrault Jean-Marc	Président de l'Association des maires des grandes villes de France.Maire de Nantes, réélu en 1995
7818	7429	ZZZZ_Personnalités AZ	
7819	7818	Azad Rachid	
7820	7818	Azeddine Medjoubi	directeur du théâtre national algérien
7821	7818	Aziz Tarek	
7822	7818	Aznar José Maria	
7823	7818	Aznavour Charles	chanson
7824	7818	Azrié Abed	
7825	7818	Azzedine Amari	
7826	7818	Azéma Jean-Pierre	
7827	7818	Azéma Sabine	
7828	7428	ZZZZ_Personnalités B	
7829	7828	ZZZZ_Personnalités BA	
7830	7829	Ba Betty	
7831	7829	Ba Ibrahim	
7832	7829	Baba Sehgal	musicien indien
7833	7829	Babe Fabienne	
7834	7829	Babel Isaac	
7835	7829	Babilée Jean	
7836	7829	Babusiaux Christian	
7837	7829	Bacall Lauren	
7838	7829	Bach Jean-Sebastien	
7839	7829	Bachelet Jean-René	
7840	7829	Bachelet Michelle	
7841	7829	Bachelot Roselyne	
7842	7829	Bacon Francis	
7843	7829	Bacot Paul	politologue
7844	7829	Bacqué Marie-Frédérique	Présidente de l'association "Vivre son deuil", spécialisée dans le suivi des survivants des attentats aveugles
7845	7829	Bacre Waly Ndiaye	
7846	7829	Bacri Jean-Pierre	
7847	7829	Bacrot Etienne	
7848	7829	Badalamenti Angelo	producteur américain
7849	7829	Badham John	
7850	7829	Badinter Elisabeth	historienne, philosophe et écrivain
7851	7829	Badinter Robert	président du Conseil Constitutionnel
7852	7829	Badiou Alain	
7853	7829	Bae Soon Hoon	
7854	7829	Baeckroot Christian	
7855	7829	Baer Edouard	 
7856	7829	Baez Joan	
7857	7829	Baffie Laurent	
7858	7829	Bagarrella Leoluca	
7859	7829	Baggio Roberto	joueur de foot
7860	7829	Baggioni Jean	
7861	7829	Bagosora Théoneste	
7862	7829	Bagouet Dominique	Danse
7863	7829	Baier Lothar	
7864	7829	Bailet Honoré	
7865	7829	Bailey Donovan	
7866	7829	Bailly Jean-Christophe	auteur de théâtre
7867	7829	Bailly Jean-Paul	
7868	7829	Bailly Pascale	
7869	7829	Bainbridge Beryl	
7870	7829	Baker Chet	
7871	7829	Baker James	
7872	7829	Baker Joséphine	
7873	7829	Bakhtiar Chapour	
7874	7829	Bakiev Kourmanbek	
7875	7829	Balabagan Sarah	
7876	7829	Balaguer Joaquin	
7877	7829	Balanchine George	
7878	7829	Balasko Josiane	actrice
7879	7829	Baldelli Christopher	
7880	7829	Baldus Edouard	
7881	7829	Baldwin James	
7882	7829	Baldwin Stephen	
7883	7829	Balestre Jean-Marie	
7884	7829	Balibar Etienne	
7885	7829	Balibar Jeanne	
7886	7829	Balit Norbert	directeur de l'information de RMC
7887	7829	Balkany Isabelle	femme de Patrick/conseiller gal. Hauts-de-Seine
7888	7829	Balkany Patrick	
7889	7829	Balladur Edouard	
7890	7829	Balland Jean	archevêque de Lyon
7891	7829	Ballanger Felicia	
7892	7829	Ballard James Graham	
7893	7829	Balle Francis	
7894	7829	Ballen Roger	
7895	7829	Ballmer Steve	
7896	7829	Bally Sagoo	
7897	7829	Bals Huub	
7898	7829	Balthus	
7899	7829	Balza Gustavo	
7900	7829	Balzac Honoré de	
7901	7829	Bambuck Roger	Ex ministre des sports
7902	7829	Ban Ki-moon	 
7903	7829	Banderas Antonio	
7904	7829	Bangemann Martin	
7905	7829	Bangs Lester	
7906	7829	Banharn Silpa-archa	
7907	7829	Bani-Etemad Rakhshan	
7908	7829	Banks Russell	écrivain
7909	7829	Banuls Pierre-Jean	
7910	7829	Bao Ninh	écrivain vietnamien
7911	7829	Baptiste Eric	directeur général de RFI
7912	7829	Bar Illan David	
7913	7829	Bar-On Roni	
7914	7829	Barak Aharon	
7915	7829	Barak Ehud	
7916	7829	Baram Uzi	
7917	7829	Barat Jean	
7918	7829	Barbara	
7919	7829	Barbara Cassin	écrivain, philosophe
7920	7829	Barbara Masekala	conseillère de Nelson Mandela et nouvelle ambassadrice en France pour l'Afrique du Sud
7921	7829	Barbarito Diez	musicien cuba
7922	7829	Barbaroux Monique	
7923	7829	Barbas-Garcia Jorge	
7924	7829	Barber Eunice	
7925	7829	Barberis Pierre	
7926	7829	Barbie klaus	
7927	7829	Barbin Jean-Damien	
7928	7829	Barboza Raul	
7929	7829	Barbraud Pascal	
7930	7829	Barceló Miquel	
7931	7829	Bard Christine	écrivain
7932	7829	Bardet Jean	
7933	7829	Bardet Pierre Olivier	
7934	7829	Bardinet Thomas	
7935	7829	Bardon Claude	ancien directeur des RG
7936	7829	Bardot Brigitte	
7937	7829	Barenboïm Daniel	
7938	7829	Barety Jean-Paul	
7939	7829	Bargero Jean-Louis	maire communiste de Champigny-sur-marne
7940	7829	Barghouti Marwan	
7941	7829	Barghouti Moustafa	
7942	7829	Bariani Didier	
7943	7829	Baricco Alessandro	
7944	7829	Baril Jean-Pierre	
7945	7829	Barilari André	
7946	7829	Bariller Damien	
7947	7829	Barin Ljubomir	homme d'affaires croate/affaire Girondins de Bordeaux
7948	7829	Barlow Patrick	
7949	7829	Barma Claude	
7950	7829	Barnes Julian	
7951	7829	Barnet Boris Vasilevitch	cineaste russe
7952	7829	Barney Matthew	
7953	7829	Barney Simon	
7954	7829	Barnier Michel	
7955	7829	Baroin François	
7956	7829	Baron Supervielle Silvia	
7957	7829	Barrault Bernard	
7958	7829	Barrault Jean-Louis	
7959	7829	Barre Raymond	
7960	7829	Barreau Jean-Claude	Conseiller pour l'immigration de Jean-Louis Debré
7961	7829	Barrichello Rubens	
7962	7829	Barrie Taylor	
7963	7829	Barril Paul	
7964	7829	Barrionuevo Jose	
7965	7829	Barrot Jacques	
7966	7829	Barry Marion	maire de washington
7967	7829	Barrès Maurice	
7968	7829	Barré François	
7969	7829	Barré Laurent	
7970	7829	Barré Rémi	Directeur de l'OST
7971	7829	Barsacq Alain	Metteur en scène
7972	7829	Barshefsky Charlene	secrétaire d'Etat américain au commerce
7973	7829	Barsoukov Milkhaîl	
7974	7829	Bartabas	
7975	7829	Bartas Sharunas	
7976	7829	Barth Jean-Paul	
7977	7829	Barthes Roland	
7978	7829	Barthez Fabien	
7979	7829	Barto Bernard	
7980	7829	Bartok Bela	
7981	7829	Bartoli Cecilia	
7982	7829	Bartolomei Louis	magistrat
7983	7829	Bartoloméo Joël	
7984	7829	Bartolone Claude	
7985	7829	Bartosek Karel	
7986	7829	Baruch Goldstein	colon israëlien meurtrier
7987	7829	Baruch Marc-Olivier	
7988	7829	Baruk Stella	Stella Baruk est chercheur en pédagogie et auteur du Dictionnaire de mathéma-tiques élémentaires, Seuil.
7989	7829	Baryshnikov Mikhail	
7990	7829	Barzach Michèle	
7991	7829	Barzani Massoud	
7992	7829	Baré Jean-François	
7993	7829	Bas Philippe (UMP)	
7994	7829	Baselitz Georg	
7995	7829	Basescu Traian	
7996	7829	Bashmet Youri	
7997	7829	Bashung Alain	
7998	7829	Basil Hume	primat de l'église catholique de GB
7999	7829	Basile Roditis	
8000	7829	Baslé Hervé	
8001	7829	Basquiat Jean-Michel	
8002	7829	Bass Rick	
8003	7829	Bassaïev Chamil	
8004	7829	Basset-Chercot Pascal	
8005	7829	Bassett Angela	
8006	7829	Bassi Michel	
8007	7829	Bassot Sylvia	
8008	7829	Basta	
8009	7829	Bastide François-Régis	
8010	7829	Bastien Pierre	
8011	7829	Bastin Christine	chorégraphe
8012	7829	Bastos Augusto Roa	
8013	7829	Basutçu Mehmet	
8014	7829	Bataille Christian	
8015	7829	Bataille Georges	
8016	7829	Bataille Philippe	
8017	7829	Batard Marc	alpinisme
8018	7829	Batistuta Gabriel	
8019	7829	Bauby Jean-Dominique	rédacteur en chef d'un nouveau concept de magazine Homme-Femme
8020	7829	Baudelaire Charles	
8021	7829	Baudis Dominique	maire CDS de Toulouse
8022	7829	Baudis Pierre	
8023	7829	Baudouin Denis	
8024	7829	Baudrier Jacqueline	
8025	7829	Baudrillard Jean	
8026	7829	Bauer Alain	
8027	7829	Baulieu Etienne-Emile	
8028	7829	Baulon Marie-Anne	
8029	7829	Baum Ralph	cinéaste
8030	7829	Baumel Jacques	
8031	7829	Baumet Gilbert	député-maire de Pont-Saint-Esprit
8032	7829	Baupin Denis	
8033	7829	Baur Charles	
8034	7829	Bausch Pina	
8035	7829	Baxter Glen	
8036	7829	Baye Nathalie	
8037	7829	Bayen Bruno	
8038	7829	Bayer Leverkusen	entraîneur de foot du club allemand le Bayer Leverkusen
8039	7829	Baykal Deniz	
8040	7829	Bayle Jacques	
8041	7829	Bayle Jean-Michel	motocyclisme
8042	7829	Bayle Marc	
8043	7829	Baylet Evelyne	
8044	7829	Baylet Jean-Michel	
8045	7829	Bayon Louis	
8046	7829	Bayrou François	Ministre de l'education nationale
8047	7829	Bazeilles Pierre	haut-fonctionnaire
8048	7829	Bazin Hervé	
8049	7829	Bazin Janine	cinéaste
8050	7829	Bazire Nicolas	balladurien/chef de cabinet
8051	7829	Baïz Josette	
8052	7828	ZZZZ_Personnalités BD	
8053	8052	B. David (bande dessinée)	
8054	7828	ZZZZ_Personnalités BE	
8055	8054	Beach Boys	groupe rock
8056	8054	Beard Peter	
8057	8054	Beastie Boys	Groupe de musique
8058	8054	Beatcream	
8059	8054	Beatles	
8060	8054	Beaton Cecil	
8061	8054	Beaucé Thierry de	
8062	8054	Beaud Marie-Claude	directrice de l'American Center
8063	8054	Beaufret Jean-Pascal	
8064	8054	Beaufront Christophe	
8065	8054	Beauharnais Joséphine de	
8066	8054	Beaujour Jérôme	écrivain
8067	8054	Beaumarchais Pierre Augustin Caron de	
8068	8054	Beaumont Jean-Louis	maire de Saint-Maur-des-fossés
8069	8054	Beaumont René	
8070	8054	Beaune David	
8071	8054	Beaunesne Yves	
8072	8054	Beaussant Philippe	
8073	8054	Beauvoir Simone de	
8074	8054	Beauvois Xavier	réalisateur
8075	8054	Beaux Gilberte	
8076	8054	Bebeto José Roberto Gama de Oliveira	footballeur
8077	8054	Bebey Francis	
8078	8054	Beck	
8079	8054	Beck Béatrice	
8080	8054	Beck Francis	
8081	8054	Beck Xavier	
8082	8054	Beckenbauer Franz	
8083	8054	Becker Boris	
8084	8054	Becker Jacques	
8085	8054	Becker Jean	Cinéaste
8086	8054	Beckett Samuel	
8087	8054	Beckham David	
8088	8054	Becque Henry	
8089	8054	Bednawski Maxime	
8090	8054	Bedos Guy	
8091	8054	Bedos Michèle	
8092	8054	Beethoven Ludwig van	
8093	8054	Beffa Jean-Louis	
8094	8054	Begag Azouz	
8095	8054	Begley Louis	
8096	8054	Beigbeder Frédéric	
8097	8054	Beilin Yossi	
8098	8054	Beineix Jean-Jacques	
8099	8054	Bel Jérôme	
8100	8054	Belafonte Harry	
8101	8054	Belarbi Kader	
8102	8054	Belaval Philippe	
8103	8054	Belhaj Kacem Mehdi	
8104	8054	Belhassine Lotfi	
8105	8054	Belhouchet Omar	
8106	8054	Belin Philippe	
8107	8054	Belingard-Deybach Françoise	
8108	8054	Beljanski Mirko	
8109	8054	Bell Martin	
8110	8054	Bell Quentin	
8111	8054	Bellagamba Marie-José	avocate Corse
8112	8054	Bellanger Pierre	PDG de la radio Skyrock
8113	8054	Bellay Jérôme	
8114	8054	Belletante Michel	
8115	8054	Belletto René	
8116	8054	Bellini Giovanni	
8117	8054	Bello Yann	
8118	8054	Bellochio Marco	
8119	8054	Bellocq Ernest James	
8120	8054	Bellucci Monica	
8121	8054	Belly	groupe de rock
8122	8054	Belmondo Jean-Paul	
8123	8054	Belmont Bruno	
8124	8054	Belorgey Gérard	
8125	8054	Beltran Lola	
8126	8054	Belvaux Lucas	
8127	8054	Belvaux Rémy	
8128	8054	Bemba Sylvain Ntari	
8129	8054	Bemberg Maria Luisa	
8130	8054	Ben	
8131	8054	Ben Ami Schlomo	
8132	8054	Ben Barka Mehdi	Leader de l'opposition marocaine
8133	8054	Ben Bella Ahmed	
8134	8054	Ben Elissar Eliahu	
8135	8054	Ben Jelloun Tahar	
8136	8054	Ben Junior Joe	
8137	8054	Ben Laden Oussama	
8138	8054	Ben Zehava	
8139	8054	BenMessaoud Malik	
8140	8054	Benacquista Tonino	
8141	8054	Benamou Georges-Marc	fondateur de "Globe hebdo"
8142	8054	Benarbia Ali	football
8143	8054	Benavides Elisa	
8144	8054	Benayoun Maurice	
8145	8054	Benayoun Robert	
8146	8054	Benazzi Abdelatif	rugby
8147	8054	Benaïssa Slimane	
8148	8054	Benderson Bruce	
8149	8054	Bendongué Fred	
8150	8054	Bene Carmelo	
8151	8054	Benedetto André	
8152	8054	Beneix Jean-Jacques	
8153	8054	Benetton Luciano	
8154	8054	Benguigui Valérie	
8155	8054	Benguigui Yamina	
8156	8054	Benhadj Ali	
8157	8054	Benhamou Guy	
8158	8054	Benhamouda Boualem	
8159	8054	Benigni Roberto	cinéaste italien
8160	8054	Benitez El Cordobes Manuel	
8161	8054	Benjamin George	
8162	8054	Benjamin Péret	Ecrivain
8163	8054	Benjamin Walter	
8164	8054	Benmakhlouf Alexandre	
8165	8054	Benmansour Moustapha	
8166	8054	Benmussa simone	
8167	8054	Benn Gottfried	
8168	8054	Bennahmias Jean-Luc	
8169	8054	Benoist Alain de	
8170	8054	Benoist Henri de	fnsea
8171	8054	Benoist Thierry	
8172	8054	Benoit Ted	
8173	8054	Benoît Heimermann	écrivain sur l'aéropostale
8174	8054	Benoît Jean-Louis	
8175	8054	Benoît XVI	
8176	8054	Benqué Jean-Pierre	directeur exécutif d'EDF
8177	8054	Benrekassa Georges	
8178	8054	Bensalah Abdelkader	
8179	8054	Bensaïd Boualem	
8180	8054	Bensaïd Daniel	
8181	8054	Bensoussan Alain	
8182	8054	Benveniste Jacques	
8183	8054	Benvenisti Meron	
8184	8054	Benvenuto Cellini	sculpteur florentin du XVIe siècle
8185	8054	Benyamin Moshé	
8186	8054	Berberian Alain	
8187	8054	Berbizier Pierre	
8188	8054	Bercoff André	
8189	8054	Berda Claude	
8190	8054	Berendt John	
8191	8054	Berezovski Boris	
8192	8054	Bergala Alain	journaliste et réalisateur de cinema
8193	8054	Berger Gerhard	pilote de F1
8194	8054	Berger John	
8195	8054	Berger Michel	
8196	8054	Bergeron André	
8197	8054	Bergman Ingmar	cinéaste suédois
8198	8054	Bergman Ingrid	
8199	8054	Bergougnoux Jean	
8200	8054	Bergounioux Pierre	
8201	8054	Bergson Henri	philosophe
8202	8054	Bergsson Gudbergur	
8203	8054	Bergère Eric	
8204	8054	Bergès Michel	
8205	8054	Bergé Pierre	ex-patron de l'Opéra de Paris et de Globe
8206	8054	Berisha Sali	
8207	8054	Berl Emmanuel	
8208	8054	Berlandier René	
8209	8054	Berling Charles	
8210	8054	Berling Philippe	
8211	8054	Berlinguer Enrico	
8212	8054	Berlusconi Paolo	
8213	8054	Berlusconi Silvio	
8214	8054	Bernadac Marie-Laure	
8215	8054	Bernado Claudio	
8216	8054	Bernadotte Folke	
8217	8054	Bernal Martin	
8218	8054	Bernanke Ben	
8219	8054	Bernanos Georges	
8220	8054	Bernard Audouin	directeur divisionnaire des services fiscaux
8221	8054	Bernard Caiazzo	Président de l'Olympique de Marseille (foot)
8222	8054	Bernard Daniel	
8223	8054	Bernard Fisher	cancérologue spécialiste du cancer du sein
8224	8054	Bernard Foutrier	écrivain psy
8225	8054	Bernard Franck	Directeur général de la Compagnie des eaux de Paris
8226	8054	Bernard François	ancien DG de Hoover-France accusé d'avoir menti à son comité d'entreprise
8227	8054	Bernard Hance	
8228	8054	Bernard Jean-Philippe	
8229	8054	Bernard Jean-René	ex sous-gouverneur du Crédit foncier
8230	8054	Bernard Labbé	
8231	8054	Bernard Le Scour	
8232	8054	Bernard Legrand	Directeur des ressources humaines de Poliet
8233	8054	Bernard Lehideux	
8234	8054	Bernard Lewis	
8235	8054	Bernard Michel	PDG d'Air Inter
8236	8054	Bernard Norlain	général
8237	8054	Bernard Pierre	Maire de Montfermeil
8238	8054	Bernard Rose	cinéaste
8239	8054	Bernard Sarroca	Ancien chef de cabinet de Michel Noir
8240	8054	Bernard Ugatti	directeur aérodrome de Dieppe inculpé ds un trafic de Hasch
8241	8054	Bernardini François	Adjoint du Maire d'Istres
8242	8054	Bernardini Louis	
8243	8054	Bernardini Patrick	
8244	8054	Bernardino Zapponi	cinéaste italien
8245	8054	Bernardo Atxaga	écrivain espagnol
8246	8054	Bernardo Paul	
8247	8054	Bernhard Thomas	
8248	8054	Bernheim Antoine	
8249	8054	Bernheim François	
8250	8054	Bernier Alain	secrétaire général du Comité national des entreprises d'insertion
8251	8054	Bernstein Carl	
8252	8054	Bernstein Léonard	musicien
8253	8054	Bernès Jean-Pierre	affaire OM-VA
8254	8054	Berque Augustin	philosophe
8255	8054	Berque Jacques	spécialiste du monde arabe
8256	8054	Berri Claude	
8257	8054	Berri Nabih	
8258	8054	Berroyer Jackie	
8259	8054	Berry Chuck	rocker américain
8260	8054	Berry John	
8261	8054	Berry Jules	
8262	8054	Berry Richard	
8263	8054	Berson Michel	
8264	8054	Bertella-Geoffroy Marie-Odile	juge d'instruction dans l'affaire du sang contaminé
8265	8054	Berthelot Jean-Michel	Directeur de l'Institut d'études doctorales de l'université de Toulouse-Le Mirail. Spécialiste des questions scolaires
8266	8054	Berthon-Wartner Annie	
8267	8054	Bertin Roland	
8268	8054	Bertin Stéphane	réalisateur de cinéma
8269	8054	Bertini Gary	
8270	8054	Bertinotti Fausto	
8271	8054	Berto Juliet	
8272	8054	Bertolino Jean	
8273	8054	Bertolucci Bernardo	metteur en scène italien
8274	8054	Bertrand Coq	
8275	8054	Bertrand De Lapresle	général français à 5 étoiles
8276	8054	Bertrand Didier	auteur d'un rebonds dans le daté 8/2/95
8277	8054	Bertrand Hell	romancier, anthropologue
8278	8054	Bertrand Jacques	
8279	8054	Bertrand Jacques A.	
8280	8054	Bertrand Jacquillat	
8281	8054	Bertrand Jean-Pierre	collaborateur de Jean-Marie Cavada
8282	8054	Bertrand Labarre	
8283	8054	Bertrand Larera de Morel	PDG de l'Ifcic
8284	8054	Bertrand Maréchal	modéliste haute couture
8285	8054	Bertrand Philippe	
8286	8054	Bertrand Xavier	
8287	8054	Bertrand Yves	
8288	8054	Besancenot Olivier	
8289	8054	Besançon Alain	
8290	8054	Beslan Gantenirov	chef de l'opposition tchétchène
8291	8054	Besnier Jean-Marie	
8292	8054	Besnier Jean-Michel	philosophe, chercheur à l'école polytechnique et au CNRS
8293	8054	Besse François	
8294	8054	Besson Eric	 
8295	8054	Besson Louis	
8296	8054	Besson Luc	
8297	8054	Besson Patrick	
8298	8054	Bestard Gabriel	
8299	8054	Betancourt Ingrid	
8300	8054	Beteille Raoul	
8301	8054	Bettane Michel	
8302	8054	Bette Davis	actrice hollywoodienne
8303	8054	Bettelheim Bruno	
8304	8054	Bettencourt André	
8305	8054	Bettie Serveert	rock
8306	8054	Beucler André	
8307	8054	Beuys Joseph	
8308	8054	Bevinda	Chanteuse de folklore
8309	8054	Beyala Calixthe	
8310	8054	Bez Claude	ancien président des Girondins de Bordeaux
8311	8054	Bezace Didier	
8312	8054	Bezanilla Pablo Chapa	
8313	8054	Bezerra DA SILVA	Chanteur brésilien, en lutte contre le pouvoir. Une samba aux accents de provocation, au nom des pauvres des favelas.
8314	8054	Bezzerides Albert Isaac	
8315	8054	Bezzina Jean-Michel	
8316	8054	Béart Emmanuelle	comédienne
8317	8054	Béart Guy	
8318	8054	Béatrice Soulé	
8319	8054	Bébéar Claude	
8320	8054	Bécart Jean-Luc	
8321	8054	Bécaud Gilbert	
8322	8054	Bédard Thierry	
8323	8054	Bédarida François	
8324	8054	Bédier Pierre	chiraquien
8325	8054	Béjart Maurice	
8326	8054	Bénichou Fabrice	boxeur
8327	8054	Bénédicte Fossey	écrivain
8328	8054	Bénégui Laurent	
8329	8054	Bérégovoy Michel	
8330	8054	Bérégovoy Pierre	
8331	8054	Béteille Laurent	maire de Brunoy
8332	8054	Bézu Alain	
8333	7828	ZZZZ_Personnalités BH	
8334	8333	Bhattacharya Deben	
8335	8333	Bhutto Benazir	Premier ministre du Pakistan
8336	7828	ZZZZ_Personnalités BI	
8337	8336	Biaggi Max	
8338	8336	Bianciotti Hector	
8339	8336	Bianco Jean-Louis	
8340	8336	Biancucci Jean	
8341	8336	Bidermann Maurice	
8342	8336	Bidet Jacques	philosophe
8343	8336	Bidima Jean-Godefroy	
8344	8336	Bielyi Boris	
8345	8336	Biemel Walter	
8346	8336	Bierce Ambrose	
8347	8336	Biette Jean-Claude	
8348	8336	Bigelow Kathryn	
8349	8336	Bignand Thierry	ancien responsable d'Act-Up. Il s'exprime régulièrement sur les problèmes éthiques liés à la pathologie du sida.
8350	8336	Bignasca Giuliano	
8351	8336	Bila Vera	
8352	8336	Bilal Enki	
8353	8336	Bilalian Daniel	
8354	8336	Bildt Carl	
8355	8336	Bilger Pierre	
8356	8336	Billard Claude	
8357	8336	Billard Pierre	historien du cinéma
8358	8336	Billet Jean-Yves	
8359	8336	Billot Michel	
8360	8336	Billé Louis-Marie	
8361	8336	Binoche Juliette	
8362	8336	Biondi Fabio	
8363	8336	Bioulac Bernard	
8364	8336	Bioy Casares Adolfo	
8365	8336	Bird Antonia	
8366	8336	Birkin Jane	
8367	8336	Birnbaum Michel	
8368	8336	Birnhaum Pierre	
8369	8336	Birraux Claude	
8370	8336	Bischoff Manfred	président de Daimler Benz Aerospace
8371	8336	Bitov	
8372	8336	Bitton Charlie	
8373	8336	Bitton Simone	
8374	8336	Biya Paul	président camerounais
8375	8336	Bizet Georges	
8376	8336	Bizima Karaha	
8377	8336	Bizot Jean-François	
8378	8336	Biétry Charles	
8379	8336	Biéville Clémence de	
8380	7828	ZZZZ_Personnalités BJ	
8381	8380	Bjerke René	
8382	8380	Bjerregaard Ritt	
8383	8380	Bjoernvig Thorkild	
8384	8380	Björk	
8385	7828	ZZZZ_Personnalités BL	
8386	8385	Blachat Christian	
8387	8385	Blaes Christian	juge d'instruction des Affaires grenobloises de Carignon
8388	8385	Blagovoline Sergueï	
8389	8385	Blain Gérard	
8390	8385	Blain Patrick	
8391	8385	Blair Cherie	
8392	8385	Blair Tony	
8393	8385	Blais Marie-Claire	
8394	8385	Blaise Christiane	
8395	8385	Blaise Jean	
8396	8385	Blaise Mistler	homme politique balladurien
8397	8385	Blake Peter	skipper de Team New Zealand
8398	8385	Blake William	
8399	8385	Blamont François	
8400	8385	Blanc Christian	
8401	8385	Blanc Dominique	
8402	8385	Blanc Jacques (UDF)	
8403	8385	Blanc Laurent	
8404	8385	Blanc Michel (cinéma)	
8405	8385	Blanc Michel (tv)	Directeur général de France 3
8406	8385	Blanchard Olivier	professeur au MIT et économiste
8407	8385	Blanchet Pierre	Brasseur de Paris
8408	8385	Blanchot Maurice	
8409	8385	Blanckart Olivier	
8410	8385	Blanco Galo	
8411	8385	Blandin Marie-Christine	Présidente (Verts) de la région Nord-Pas-De-Calais
8412	8385	Blaskic Tihomir	
8413	8385	Blatter Joseph	
8414	8385	Blayau Pierre	
8415	8385	Blazevic Miroslav	
8416	8385	Bled Bernard	
8417	8385	Bled Edouard	
8418	8385	Blethyn Brenda	
8419	8385	Bleustein-Blanchet Marcel	
8420	8385	Blier Bernard	
8421	8385	Blier Bertrand	
8422	8385	Blisko Serge	
8423	8385	Blistène Bernard	
8424	8385	Bloch-Lainé Jean-Michel	
8425	8385	Bloche Patrick	
8426	8385	Blocher Christoph	
8427	8385	Blondel Marc	
8428	8385	Blondel Maurice	philosophe
8429	8385	Bloomberg Michael	
8430	8385	Blossfeldt Karl	
8431	8385	Blot Yvan	
8432	8385	Blotin Pierre	
8433	8385	Blow Kurtis	
8434	8385	Bloy	
8435	8385	Blum Léon	
8436	8385	Blumenfeld Erwin	Photographe (1897-1969)
8437	8385	Blunkett David	
8438	8385	Blur	
8439	8385	Bluteau Lothaire	
8440	8385	Bluwal Marcel	
8441	7828	ZZZZ_Personnalités BO	
8442	8441	Bo Jackson	
8443	8441	Boardman Chris	cycliste
8444	8441	Bob Gale	scénariste américain
8445	8441	Bob Stinson	musicien rock
8446	8441	Bobbio Norbert	
8447	8441	Bober Robert	
8448	8441	Boccara Frida	
8449	8441	Boccolini Laurence	
8450	8441	Bochco Steven	
8451	8441	Bockel Jean-Marie	
8452	8441	Bocquet Alain	
8453	8441	Bocuse Paul	
8454	8441	Bodart Jeff	
8455	8441	Boeno David	
8456	8441	Boesak Allan	
8457	8441	Boetsch Arnaud	
8458	8441	Bogart Humphrey	
8459	8441	Boggio Philippe	
8460	8441	Boghossian Alain	
8461	8441	Bohbot David	
8462	8441	Bohringer Richard	
8463	8441	Boishue Jean de	secrétaire d'Etat à l'Enseignement Supérieur
8464	8441	Boissard Sophie	
8465	8441	Boisseau Marie-Thérèse	
8466	8441	Boissel Christian	
8467	8441	Boisset Yves	
8468	8441	Boissier Jean-Louis	
8469	8441	Boissieu Christian de	Professeur d'économie à la Sorbonne
8470	8441	Boisson Christine	
8471	8441	Boissonnat Jean	
8472	8441	Boivin Dominique	
8473	8441	Boizette Edith	
8474	8441	Bokassa Catherine	
8475	8441	Bokassa Jean Bedel	
8476	8441	Bokros Lajos	
8477	8441	Boley George	
8478	8441	Bolger Jim	
8479	8441	Boli Basile	joueur de foot
8480	8441	Bolkestein Frits	
8481	8441	Bollack Jean	
8482	8441	Bollain Iciar	
8483	8441	Bolloré Vincent	
8484	8441	Bolognini Mauro	
8485	8441	Boltanski Christian	
8486	8441	Bolton John	
8487	8441	Bombard Alain	
8488	8441	Bompard Alain	
8489	8441	Bompard Jacques	
8490	8441	Bon François	
8491	8441	Bon Michel	Directeur général de l'ANPE
8492	8441	Bonafini Hebe de	
8493	8441	Bonaldi Jérôme	
8494	8441	Bonaly Surya	
8495	8441	Bonaparte Napoléon	
8496	8441	Bonaviri Giuseppe	
8497	8441	Bond Alan	
8498	8441	Bond Edward	
8499	8441	Bond James	
8500	8441	Bondy Luc	
8501	8441	Bonello Yves-Henri	avocat
8502	8441	Boney M	Groupe de musique disco
8503	8441	Bongo Omar	président du Gabon
8504	8441	Boniface Pascal	
8505	8441	Bonin Georges	
8506	8441	Bonino Emma	Commissaire européen en charge de la consommation
8507	8441	Bonitzer Pascal	
8508	8441	Bonnaffé Jacques	
8509	8441	Bonnaire Sandrine	
8510	8441	Bonnard Pierre	
8511	8441	Bonnaud Jean-Jacques	président du GAN
8512	8441	Bonnefoy Yves	
8513	8441	Bonnell Bruno	PdG d'Infogrames et responsable d'Infonie
8514	8441	Bonnell René	
8515	8441	Bonnemain François	
8516	8441	Bonnemaison Gilbert	
8517	8441	Bonnet Bernard	
8518	8441	Bonnet Christian	Sénateur
8519	8441	Bonnet Jacques	
8520	8441	Bonnet Jean-Luc	
8521	8441	Bonnet Roger-Maurice	directeur du programme scientifique de l'ESA
8522	8441	Bonnet Yves	
8523	8441	Bonté Patrick	
8524	8441	Bonvoisin Bernie	
8525	8441	Bonvoisin Bérangère	
8526	8441	Boo Radleys	
8527	8441	Boorda Jeremy	
8528	8441	Boorda Mike	
8529	8441	Boorman John	
8530	8441	Bootsy Collins	musicien de rock
8531	8441	Borde Raymond	
8532	8441	Bordier Hervé	
8533	8441	Borges Jorge Luis	
8534	8441	Boris Gromov	gal. russe
8535	8441	Boris Jean-Michel	
8536	8441	Boris Rybak	
8537	8441	Borloo Jean-Louis	
8538	8441	Bornstein Henri	
8539	8441	Borodine Alexandre	
8540	8441	Borotra Franck	pdt. conseil général des Yvelines
8541	8441	Borrell Josep	
8542	8441	Borzeix Jean-Marie	
8543	8441	Bosch Jérôme	
8544	8441	Bosco Barayagwiza Jean	
8545	8441	Bosetzky Horst	
8546	8441	Bosic Boro	
8547	8441	Bosman Jean-Marc	footballeur belge
8548	8441	Boss Hog	
8549	8441	Bossi Umberto	
8550	8441	Bosson Bernard	
8551	8441	Bost Roger-Yves	
8552	8441	Bot Yves	
8553	8441	Botchwey kwesi	
8554	8441	Botelho Joao	
8555	8441	Botero Fernando	
8556	8441	Botha Pieter	
8557	8441	Bothorel Jean	journaliste
8558	8441	Botta Mario	
8559	8441	Botte Marie-France	Mène une croisade contre la prostitution enfantine dans le monde.
8560	8441	Bottin Yves	inspecteur d'académie de la Seine-Saint-Denis
8561	8441	Botton Pierre	
8562	8441	Boubakeur Dalil	
8563	8441	Boublil Alain	
8564	8441	Bouchard Jacques	directeur des applications militaires au CEA
8565	8441	Bouchard Lucien	
8566	8441	Bouchardeau Huguette	
8567	8441	Bouchareb Rachid	Réalisateur
8568	8441	Bouchaud Michel	Proviseur du Lycée de St Ouen
8569	8441	Boucheron Jean-Michel (dép. Ille-et-Vilaine)	
8570	8441	Boucheron Jean-Michel (ex-maire Angoulême)	
8571	8441	Bouchet Paul	pdt. comm. contrôle des interceptions de sécurité (écoutes téléphoniques)
8572	8441	Bouchez Elodie	
8573	8441	Boudali Khaled	président de l'Association pour le développement des relations euro-arabes
8574	8441	Boudard Alphonse	
8575	8441	Boudiaf Mohamed	ancien chef de l'Etat algérien
8576	8441	Boudin Eugene	
8577	8441	Boudjedra Rachid	
8578	8441	Boudouani Laurent	boxeur
8579	8441	Bougnoux Daniel	écrivain politique
8580	8441	Bougrain-Dubourg Allain	
8581	8441	Bouguereau Jean-Marcel	
8582	8441	Bouhoud Imad	
8583	8441	Bouige Jean	
8584	8441	Bouillon Dominique	promoteur immobilier
8585	8441	Boujon Claude	
8586	8441	Boujut Michel	
8587	8441	Boukhrief Nicolas	
8588	8441	Boukovsky Vladimir	
8589	8441	Boukrouh Noureddine	
8590	8441	Boulanger Claude	
8591	8441	Boulanger Georges	
8592	8441	Boulanger Gérard	Avocat des partis civiles au procès Papon
8593	8441	Boulet Jean	météorologue du Mont Aigoual
8594	8441	Boulez Pierre	
8595	8441	Boulgakov Mikhail	
8596	8441	Boullata kamal	
8597	8441	Boumediene Hamid	
8598	8441	Bouquet Carole	
8599	8441	Bouquet Michel	
8600	8441	Bourachot Robert	
8601	8441	Bourada Safeh	
8602	8441	Bouras Djamel	
8603	8441	Bourcart Jean-Christian	
8604	8441	Bourdet Claude	
8605	8441	Bourdet Gildas	metteur en scene de théâtre
8606	8441	Bourdieu Pierre	
8607	8441	Bourdin Gilbert	
8608	8441	Bourdo Sacha	
8609	8441	Bourdon William	
8610	8441	Boureau Alain	historien
8611	8441	Bourg-Broc Bruno	
8612	8441	Bourgeade Pierre	
8613	8441	Bourgeat Pierrick	
8614	8441	Bourgeois Louise	
8615	8441	Bourges Hervé	
8616	8441	Bourgnon Laurent	
8617	8441	Bourgoin Gérard	
8618	8441	Bourgoin Jacques	Président de l'office HLM de Gennevilliers
8619	8441	Bourgois Christian	Editeur.
8620	8441	Bourgois Jean-Manuel	
8621	8441	Bourguignon Philippe	
8622	8441	Bourin François	éditeur
8623	8441	Bourlanges Jean-Louis	député européen UDF
8624	8441	Bourmaud Claude	
8625	8441	Bourne Matthew	
8626	8441	Bourre Jean-Paul	
8627	8441	Bourret Jean-Claude	
8628	8441	Boursicot Jean-Marie	
8629	8441	Bousquet François	Ancien président du syndicat d'agglomeration nouvelle d'Evry
8630	8441	Bousquet Jean	député-maire de Nïmes
8631	8441	Bousquet Jean-Claude	
8632	8441	Bousquet Joë	
8633	8441	Bousquet René	Secrétaire général à la Police sous Vichy, responsable de la rafle du Vel'd'Hiv, inculpé de crimes contre l'humanité, assassiné à Paris le 8 juin 1993 à l'âge de 84 ans.
8634	8441	Bousquet de Florian Pierre de	
8635	8441	Boussaguet Pierre	
8636	8441	Bousselham Hamid	
8637	8441	Boutang Pierre-André	
8638	8441	Bouteflika Abdelaziz	
8639	8441	Bouteiller Pierre	
8640	8441	Boutih Malek	
8641	8441	Boutin Christine	
8642	8441	Bouton Daniel	
8643	8441	Bouton Richard	
8644	8441	Boutros-Ghali Boutros	
8645	8441	Boutté Jean-Luc	acteur et metteur en scène de théâtre
8646	8441	Bouvard Philippe	producteur radio et chroniqueur de presse
8647	8441	Bouvet Jean-Christophe	
8648	8441	Bouvier Jean-Claude	
8649	8441	Bouvier Joëlle	
8650	8441	Bouvier Nicolas	
8651	8441	Bouygues Corinne	
8652	8441	Bouygues Francis	
8653	8441	Bouygues Martin	
8654	8441	Bouygues Nicolas	
8655	8441	Bouzerand Jacques	directeur de la communication à La Cinquième
8656	8441	Bove Emmanuel	
8657	8441	Bové José	
8658	8441	Bowe Riddick	Boxe
8659	8441	Bowie David	
8660	8441	Bowie Lester	musicien de jazz
8661	8441	Bowles Erskine	
8662	8441	Bowles Jane	
8663	8441	Bowles Paul	
8664	8441	Boyer Jean-François	
8665	8441	Boyer Laurent	
8666	8441	Boyer Myriam	
8667	8441	Boyle Danny	
8668	8441	Boyner Cem	
8669	8441	Boyon Jacques	
8670	8441	Boyon Michel	
8671	8441	Bozidar Maljkovic	entraîneur de basket du club de Limoges
8672	8441	Bozo Frédéric	Chargé de recherches à l'Institut français de relations internationales (Ifri)
8673	8441	Bozo Pierre-Jean	
8674	8441	Bozon Louis	animateur du Jeu des mille francs
8675	8441	Bozon Lucien	
8676	8441	Bozon Philippe	
8677	8441	Bozonnet Marcel	
8678	8441	Boëglin Bruno	
8679	8441	Böll Heinrich	
8680	7828	ZZZZ_Personnalités BR	
8681	8680	Braconnier Alain	psy spécialiste de la dépression des ados
8682	8680	Bradel Benoît	
8683	8680	Bradley Bill	
8684	8680	Brahim Bouarram	Marocain assassiné le 1er mai 1995 au cours de la manifestation du Front National à Paris.
8685	8680	Brahimi Lakhdar	
8686	8680	Brahm John	
8687	8680	Brahms Johannes	
8688	8680	Braibant Guy	
8689	8680	Braillon Marc	
8690	8680	Brainard Joe	
8691	8680	Branagh Kenneth	
8692	8680	Brancusi Constantin	sculpteur roumain
8693	8680	Brando Cheyenne	
8694	8680	Brando Marlon	
8695	8680	Brandt Carlo	metteur en scene
8696	8680	Branka Sovrlic	chanteuse populaire serbe
8697	8680	Branson Richard	
8698	8680	Braouezec Patrick	
8699	8680	Braque Georges	
8700	8680	Brard Jean-Pierre	
8701	8680	Brasillach Robert	
8702	8680	Brassaï	
8703	8680	Brassens Georges	
8704	8680	Brasseur Claude	
8705	8680	Brasseur Pierre	
8706	8680	Braudel Fernand	
8707	8680	Brauman Rony	
8708	8680	Brauner Victor	
8709	8680	Braunschweig Stéphane	
8710	8680	Bravo Christine	
8711	8680	Bravo Daniel	football psg
8712	8680	Brazzi Rossano	
8713	8680	Brecht Bertolt	auteur de théâtre
8714	8680	Bredin Frédérique	députée européen et maire PS de Fécamp
8715	8680	Bredin Jean-Denis	académicien
8716	8680	Breeders	groupe rock
8717	8680	Breillat Catherine	
8718	8680	Brel Jacques	
8719	8680	Brem Michel de	
8720	8680	Bremer Paul	
8721	8680	Brenan Gerald	
8722	8680	Brenner Jacques	
8723	8680	Brenot Lucien	
8724	8680	Bressane Julio	
8725	8680	Bresson Robert	
8726	8680	Brest Martin	
8727	8680	Bret Bertrand	
8728	8680	Breton André	
8729	8680	Breton Thierry	
8730	8680	Bretécher Claire	
8731	8680	Breuer Paul	
8732	8680	Breugnot Pascale	TV
8733	8680	Breuillac Florence-Patricia	
8734	8680	Breytenbach Breyten	
8735	8680	Brialy Jean-Claude	
8736	8680	Briat Jacques	
8737	8680	Briatore Flavio	
8738	8680	Briec Bounoure	coach brestois de l'équipe de hockey
8739	8680	Brigitte Demoulin	
8740	8680	Brigouleix Bernard	Conseiller de presse du Premier ministre Balladur
8741	8680	Brillaut Philippe	
8742	8680	Brillet Alain	
8743	8680	Brine Adrian	
8744	8680	Brinster Ralph	chercheur scientifique de l'université de Pennsylvanie
8745	8680	Brion Patrick	
8746	8680	Brisac Geneviève	
8747	8680	Brisard René	
8748	8680	Brisseau Jean-Claude	
8749	8680	Brittan Leon	politique GB
8750	8680	Britten Benjamin	auteur d'opéra
8751	8680	Brière Xavier	
8752	8680	Broch Hermann	
8753	8680	Brochard Laurent	
8754	8680	Broche Olivier	
8755	8680	Brochen Julie	
8756	8680	Brochet Anne	
8757	8680	Brodkey Harold	
8758	8680	Brodsky Joseph	
8759	8680	Brodsky Joseph Alexandrovitch	
8760	8680	Bromberg Serge	
8761	8680	Bromberger Dominique	spécialiste des Affaires étrangères notamment sur TF1
8762	8680	Bronfman Junior Edgar	
8763	8680	Bronner André	
8764	8680	Brook Michael	
8765	8680	Brook Peter	
8766	8680	Brooks Albert	
8767	8680	Brooks Richard	
8768	8680	Brosnan Pierce	
8769	8680	Brossard Jean-Louis	
8770	8680	Brossmann Jean-Pierre	
8771	8680	Broussard Robert	
8772	8680	Broué Pierre	
8773	8680	Brovelli Lydia	
8774	8680	Brown Andy	
8775	8680	Brown Carlinhos	
8776	8680	Brown Charles	
8777	8680	Brown Gordon	
8778	8680	Brown James	
8779	8680	Brown Trisha	
8780	8680	Brownback Sam	
8781	8680	Browne Frank	
8782	8680	Browning Tod	
8783	8680	Brucan Silviu	
8784	8680	Bruce Dickinson	chanteur de heavy metal
8785	8680	Bruce Lee	acteur clé du cinéma kung fu
8786	8680	Bruce Nelson	voile
8787	8680	Bruck Charles	
8788	8680	Brucker Gilles	
8789	8680	Bruckner Pascal	écrivain
8790	8680	Brueghel	artiste
8791	8680	Bruel Patrick	
8792	8680	Bruguera Sergi	
8793	8680	Bruguière Jean-Louis	
8794	8680	Bruly-Bouabré Frédéric	Auteur, dessinateur et penseur ivoirien
8795	8680	Brumachon Claude	
8796	8680	Brundtland Gro Harlem	
8797	8680	Brune Cécile	
8798	8680	Brunel Sylvie	
8799	8680	Brunet Jean-Baptiste	
8800	8680	Brunet Michel	paléontologue
8801	8680	Brunet Pierre	Maire de Saint-Aoustrille (Indre)
8802	8680	Brunet Roger	
8803	8680	Brunetti Eric	
8804	8680	Brunhes Bernard	consultant social
8805	8680	Brunhes Jacques	
8806	8680	Bruni-Tedeschi Valeria	
8807	8680	Brunner Aloïs	
8808	8680	Brunner Pascal	
8809	8680	Bruno Collet	maître fromager organisateur du Salon du fromage
8810	8680	Bruno Cotte	procureur de la République de Paris
8811	8680	Bruno Delaye	conseiller à l'Elysée pour les affaires africaines et nommé ambassadeur de France au Mexique
8812	8680	Bruno Frank	
8813	8680	Bruno Frappat	Directeur de la rédaction de "La Croix"
8814	8680	Bruno Laffargue	
8815	8680	Bruno Lasserre	conseiller d'Etat
8816	8680	Bruno Pezzey	football
8817	8680	Bruno Prats	président du syndicat des crus classés du Médoc
8818	8680	Bruno Remaury	écrivain
8819	8680	Bruno Ruiz	Pédophile.
8820	8680	Bruno Snell	écrivain, philosophe
8821	8680	Brunschwig Jacques	
8822	8680	Brusca Giovanni	
8823	8680	Brusini Hervé	Journaliste TV
8824	8680	Bruton John	premier ministre irlandais
8825	8680	Bruyneel Johan	
8826	8680	Bryars Gavin	
8827	8680	Bryce-Echnique Alfredo	
8828	8680	Brynner Yul	
8829	8680	Bryntsalov Vladimir	
8830	8680	Brzezinski Zbigniew	Ancien conseiller du président Jimmy Carter. Spécialiste des relations internationales.
8831	8680	Brèque Jean-Daniel	
8832	8680	Brégou Christian	
8833	8680	Bréguet Bruno	
8834	7828	ZZZZ_Personnalités BU	
8835	8834	Buache Freddy	
8836	8834	Buarque Chico	
8837	8834	Bubis Ignatz	
8838	8834	Bucaram Abdala	
8839	8834	Bucchini Dominique	
8840	8834	Buchanan Pat	candidat à la présidentielle américaine
8841	8834	Buchvald Claude	
8842	8834	Buckley Jeff	chanteur américain
8843	8834	Bucquoy Jan	
8844	8834	Buddy Holly	
8845	8834	Bueb Francis	créateur de l'association culturelle Paris-Sarajevo
8846	8834	Buetti Daniele	
8847	8834	Bufalino Gesualdo	
8848	8834	Buffet Marie-George	
8849	8834	Buffett Warren	
8850	8834	Bufford Bill	
8851	8834	Bugno Gianni	
8852	8834	Buirge Susan	
8853	8834	Buisson Georges	
8854	8834	Bukspan Elisabeth	
8855	8834	Bulatovic Momir	
8856	8834	Bullimore Tony	
8857	8834	Bullock Sandra	
8858	8834	Bulté Michel	
8859	8834	Buna Gilles	
8860	8834	Bungaard Peer F.	Bundgaard est chercheur au Centre de recherches sémiotiques, université d'Aarhus, Danemark.
8861	8834	Bunuel Luis	
8862	8834	Bur Yves	
8863	8834	Buren Daniel	
8864	8834	Burg Avraham	
8865	8834	Burgat François	
8866	8834	Burgelin Claude	
8867	8834	Burgelin Jean-François	
8868	8834	Burger Warren	
8869	8834	Burhanuddin Rabbani	président de l'Afghanistan
8870	8834	Burke Solomon	
8871	8834	Burke Steve	
8872	8834	Burl Ives	acteur
8873	8834	Burnett Charles	
8874	8834	Burnier Michel-Antoine	
8875	8834	Burnsztejn Sylvain	
8876	8834	Burosse Alain	responsable des programmes courts de Canal +
8877	8834	Burri Alberto	
8878	8834	Burrin Philippe	Historien
8879	8834	Burroughs William	
8880	8834	Burrows Jonathan	
8881	8834	Burtin Nicolas	
8882	8834	Burton Tim	
8883	8834	Buscemi Steve	
8884	8834	Bush George Jr	
8885	8834	Bush George Sr	Ancien président des Etats-Unis
8886	8834	Busquin Philippe	
8887	8834	Bussereau Dominique	 
8888	8834	Bustamante Jean-Marc	
8889	8834	Butel Michel	
8890	8834	Buten Howard	
8891	8834	Buthelesi Mangosuthu	
8892	8834	Butler George Lee	
8893	8834	Butler Richard	
8894	8834	Butler Robert Olen	
8895	8834	Butler Walter	
8896	8834	Butor Michel	
8897	8834	Buyoya Pierre	
8898	8834	Buzek Jerzy	
8899	8834	Büchner Georg	
8900	8834	Büttgen Philippe	
8901	7828	ZZZZ_Personnalités BY	
8902	8901	Byars James Lee	
8903	8901	Byatt Antonia S.	
8904	8901	Byrne Gabriel	
8905	7828	ZZZZ_Personnalités BZ	
8906	7428	ZZZZ_Personnalités C	
8907	8906	ZZZZ_Personnalités CA	
8908	8907	Caballero Francis	Avocat
8909	8907	Cabana Camille	
8910	8907	Cabana Yves	
8911	8907	Cabanel Guy	sénateur
8912	8907	Cabanes Pierre	
8913	8907	Cabannes Laurent	pilier de rugby de l'équipe de France
8914	8907	Cabrel Francis	
8915	8907	Cabrera Dominique	
8916	8907	Cabrol Christian	président de l'association France Transplant
8917	8907	Cabu	
8918	8907	Cacciari Massimo	
8919	8907	Cachao	contrebassiste cubain
8920	8907	Cachart Eric	
8921	8907	Cachin Françoise	
8922	8907	Cachin Olivier	
8923	8907	Cadiot Olivier	
8924	8907	Cage John	
8925	8907	Cage Nicolas	
8926	8907	Cahen Judith	
8927	8907	Cahen Michel	chercheur CNRS
8928	8907	Cahen Robert	
8929	8907	Cahun Claude	
8930	8907	Caillat Gérald	
8931	8907	Caillaud Dominique	
8932	8907	Caille Roger	patron de presse
8933	8907	Caillé Alain	sociologue
8934	8907	Caine Michael	
8935	8907	Caio Francesco	
8936	8907	Calaferte Louis	
8937	8907	Caldaguès Michel	
8938	8907	Calder Alexander	
8939	8907	Caldera Rafael	
8940	8907	Calderon Felipe	 
8941	8907	Caleb Carr	écrivain de polar
8942	8907	Calel Perechodnik	juif polonais, auteur d'un témoignagr sur l'Holocauste
8943	8907	Calet Henri	
8944	8907	Califano Christian	
8945	8907	Calimani Riccardo	
8946	8907	Callas Maria	
8947	8907	Calle Sophie	
8948	8907	Calmat Alain	
8949	8907	Calmels Didier	
8950	8907	Calmels Régis	
8951	8907	Calment Jeanne	
8952	8907	Calogero Mannino	ex-ministre italien mafieux
8953	8907	Calopresti Mimmo	
8954	8907	Calvet Jacques	
8955	8907	Calvino Italo	écrivain italien
8956	8907	Calvo Edmond-François	
8957	8907	Camara Cédric	
8958	8907	Camara Mohamed	
8959	8907	Cambadélis Jean-Christophe	
8960	8907	Cambindo Jhair	
8961	8907	Cambon Christian	
8962	8907	Cambus Claude	
8963	8907	Camdessus Michel	
8964	8907	Cameron David	
8965	8907	Cameron James	
8966	8907	Camille Paglia	
8967	8907	Cammas Franck	
8968	8907	Camon Ferdinando	
8969	8907	Campbell Alastair	
8970	8907	Campbell Naomi	
8971	8907	Campion Jane	
8972	8907	Camporesi Piero	
8973	8907	Campos Jean-François	
8974	8907	Camus Albert	
8975	8907	Camus Renaud	
8976	8907	Canat Jean-Pierre	
8977	8907	Canchy Jean-François de	
8978	8907	Cancès Claude	
8979	8907	Candas Viviane	
8980	8907	Candeloro Philippe	
8981	8907	Cangioni Pierre	
8982	8907	Canguilhem Georges	
8983	8907	Caniggia Claudio	footballeur du Benfica Lisbonne
8984	8907	Canin Ethan	
8985	8907	Canivet Guy	
8986	8907	Cano Lopez José Manuel	
8987	8907	Canova Antonio	sculpteur
8988	8907	Canson Philippe de	député RPR du Var
8989	8907	Canson Suzanne de	
8990	8907	Cantal-Dupart Michel	Urbaniste, cofondateur avec Roland Castro de Banlieues 89
8991	8907	Cantara Antoine	
8992	8907	Cantarella Robert	Metteur en scène
8993	8907	Cantet Laurent	cinéaste
8994	8907	Cantien Dominique	
8995	8907	Canto-Sperber Monique	
8996	8907	Cantona Eric	
8997	8907	Cantona Joël	footballeur,frère d'éric Cantona
8998	8907	Canudo Ricciotto	
8999	8907	Capa Robert	
9000	8907	Capote Truman	
9001	8907	Cappezone Christian	
9002	8907	Capra Frank	
9003	8907	Capriati Jennifer	Joueuse de tennis
9004	8907	Caradec Alain	
9005	8907	Caradec François	
9006	8907	Caravage (Le)	
9007	8907	Carax Leos	
9008	8907	Carayon Bernard	
9009	8907	Carballido Riton	
9010	8907	Cardenas Cuauhtémoc	
9011	8907	Cardenas Lazaro	
9012	8907	Cardin Pierre	
9013	8907	Cardinale Claudia	
9014	8907	Cardo Pierre	
9015	8907	Cardoso Fernando Henrique	
9016	8907	Carey Jim	
9017	8907	Carignon Alain	maire de Grenoble
9018	8907	Carignon Marie-Jo	
9019	8907	Carles Benavent	jazzmen flamenco
9020	8907	Carles Pierre	
9021	8907	Carlos	
9022	8907	Carlos Alberto Silva	entraîneur de football
9023	8907	Carlos Andrez Perez	ex-président du Venezuela
9024	8907	Carlos Busquets	gardien de but du FC Barcelone
9025	8907	Carlos Gimenez	homme de théâtre argentin
9026	8907	Carlos Juan	roi d'Espagne
9027	8907	Carlos Monzon	Boxeur mort le 08/01/95 dans un accident de voiture
9028	8907	Carlos Reutemann	pilote de F1
9029	8907	Carlos Roberto	
9030	8907	Carlos Valdés	musique
9031	8907	Carlos Vives	Musique latino
9032	8907	Carlsen Robert	
9033	8907	Carlson Carolyn	
9034	8907	Carlson John	president Cray Research
9035	8907	Carlsonn Ingvar	
9036	8907	Carmet Olivier	
9037	8907	Carmouze Patrice	
9038	8907	Carné Marcel	
9039	8907	Caro Anthony	
9040	8907	Caro Marc	
9041	8907	Carol Bellamy	américaine nommée à la tête de l'Unicef
9042	8907	Carol Cleveland	
9043	8907	Caroline Coon	peintre
9044	8907	Carolis Patrick de	
9045	8907	Caron Leslie	
9046	8907	Carpenter John	cinéaste
9047	8907	Carpenter Mary-Chapin	
9048	8907	Carpio Leon	
9049	8907	Carpita Paul	
9050	8907	Carrey Jim	
9051	8907	Carreyrou Gérard	
9052	8907	Carrington Dorothy	
9053	8907	Carrière Jean-Claude	
9054	8907	Carroll Lewis	
9055	8907	Carrère Emmanuel	écrivain
9056	8907	Carrère d'Encausse Hélène	
9057	8907	Carré Alain	cadre de la Française des Jeux
9058	8907	Carré Jean-Michel	
9059	8907	Carsen Robert	
9060	8907	Carter Jimmy	
9061	8907	Cartier-Bresson Henri	photographe
9062	8907	Cartland Barbara	écrivain britannique
9063	8907	Caruso David	
9064	8907	Carvalho Bernardo	
9065	8907	Casadesus Jean-Claude	
9066	8907	Casale Noël	
9067	8907	Casanova Gilbert	Président nationaliste de la CCI d'Ajacccio
9068	8907	Casanova Odette	
9069	8907	Casariego Santiago	
9070	8907	Casarès Maria	
9071	8907	Case Steve	
9072	8907	Casetta Louise-Yvonne	
9073	8907	Cassavetes John	
9074	8907	Cassavetes Nick	
9075	8907	Cassel Seymour	
9076	8907	Cassel Vincent	
9077	8907	Cassese Antonio	
9078	8907	Cassirer Ernst	
9079	8907	Cassisa Salvatore	archevêque de Monreale
9080	8907	Cast	
9081	8907	Castaignède Thomas	rugby
9082	8907	Castaneda Jean	
9083	8907	Castel Louis	
9084	8907	Castel Robert	sociologue
9085	8907	Castells Rolland	Maire UDF de Bagnères-de-Bigorres
9086	8907	Castille Gilbert	
9087	8907	Castillo Carmen	ancienne militante du MIR chilien et réalisatrice de documentaire
9088	8907	Castoriadis Cornelius	
9089	8907	Castries Henri de	
9090	8907	Castro Fidel	
9091	8907	Castro Raul	
9092	8907	Castro Roland	
9093	8907	Catala Nicole	
9094	8907	Cates Georgina	
9095	8907	Cathala Joël	
9096	8907	Cathala Jérôme	écrivain politique
9097	8907	Catoire Gilles	Maire PS de Clichy la Garenne
9098	8907	Cattaneo Peter	
9099	8907	Cattelan Maurizio	
9100	8907	Caubet Antoine	
9101	8907	Caubère Philippe	
9102	8907	Caujolle Christian	
9103	8907	Caunes Antoine de	
9104	8907	Cavaco Silva Anibal	
9105	8907	Cavada Jean-Marie	président de la Cinquième
9106	8907	Cavaillès Jean	
9107	8907	Cavalera Max	
9108	8907	Cavalier Alain	
9109	8907	Cavallo Domingo	
9110	8907	Cavanna Bernard	
9111	8907	Cave Nick	
9112	8907	Caviglioli François	
9113	8907	Cayard Paul	Voile
9114	8907	Cayeux Patrice	ìmpliqué dans l'affaire d'attributions d'HLM parisiens
9115	8907	Cayrol Jean	
9116	8907	Cazenave Richard	
9117	8906	ZZZZ_Personnalités CE	
9118	9117	Ceausescu Nicolae	
9119	9117	Ceaux Philippe	
9120	9117	Cebrian Juan Luis	
9121	9117	Ceccaldi-Raynaud Charles	
9122	9117	Ceccaty René de	
9123	9117	Cedomir Mihailovic	ancien membre des services secrets Serbes "repenti"
9124	9117	Cela Camilo José	
9125	9117	Celibidache Sergiu	
9126	9117	Cellier Alain	
9127	9117	Cellura Dominique	
9128	9117	Cendrars Blaise	
9129	9117	Censi Marc	
9130	9117	Centi César	chercheur au Centre d'études des relations sociales, université de la Méditerranée Aix-Marseille.
9131	9117	Cerdan Marcel	boxeur de légende mort en 1949
9132	9117	Cerez Thierry	
9133	9117	Cerpa Nestor	
9134	9117	Cestac Florence	
9135	9117	Ceton Jean-Pierre	
9136	9117	Cette Gilbert	professeur de sciences économiques
9137	9117	Ceylac Catherine	
9138	9117	Cécile Joubert	
9139	9117	Céline Géraud	jeune styliste au chômage
9140	9117	Céline Jourdan	enfant tuée en juillet 1988 à la Motte-du-Caire
9141	9117	Céline Louis-Ferdinand	
9142	9117	Céréda René	
9143	9117	Césaire Aimé	
9144	9117	Césaire Raymond	
9145	9117	César (César Baldaccini)	
9146	9117	Cézanne Paul	
9147	8906	ZZZZ_Personnalités CH	
9148	9147	Bukowski Charles	écrivain
9149	9147	Ch'oe Yun	écrivaine coréenne
9150	9147	Chaarawi Mohamed Metwalli	
9151	9147	Chabalier Hervé	PDG de CAPA
9152	9147	Chaban-Delmas Jacques	
9153	9147	Chabat Alain	cinéma français
9154	9147	Chabaud Catherine	
9155	9147	Chabert Henry	
9156	9147	Chaboche Dominique	
9157	9147	Chabot Arlette	
9158	9147	Chabrol Claude	
9159	9147	Chadia	
9160	9147	Chagall Marc	peintre biélorusse
9161	9147	Chahine Youssef	
9162	9147	Chai Ling	pasionaria/Tiananmen
9163	9147	Chaillou Philippe	conseiller à la cour d'appel de Paris.
9164	9147	Chailly Luciano	
9165	9147	Chailly Riccardo	
9166	9147	Chain Emmanuel	Animateur TV
9167	9147	Chaisemartin Yves de	groupe Socpresse et Figaro
9168	9147	Chaissac Gaston	
9169	9147	Chaker Charly	
9170	9147	Chalabi Ahmed	
9171	9147	Chalabi frères	
9172	9147	Chaliand Gérard	
9173	9147	Chaliapine Fédor	
9174	9147	Chalier Yves	
9175	9147	Challe Bernard	
9176	9147	Chalmin Philippe	économiste
9177	9147	Chalumeau Laurent	
9178	9147	Chalvon Demersay Sabine	
9179	9147	Chamard Jean-Yves	député de la Vienne , balladurien
9180	9147	Chambas Jean-Paul	
9181	9147	Chambaz Bernard	
9182	9147	Chamfort Alain	
9183	9147	Chammari Khemaïs	
9184	9147	Chammougon Edouard	
9185	9147	Chamoiseau Patrick	
9186	9147	Chamoun Dany	dirigeant chrétien assassiné au Liban
9187	9147	Champvert Maurice	Animateur radio (Skyrock)
9188	9147	Chan Jackie	
9189	9147	Chan Rany	réfugiée politique cambodgienne
9190	9147	Chanal Eric	
9191	9147	Chanal Pierre	
9192	9147	Chanas René	
9193	9147	Chancel Jacques	
9194	9147	Chandler Raymond	
9195	9147	Chang Hong Men Pierrot	
9196	9147	Chang Michael	tennisman
9197	9147	Changeux Jean-Pierre	neurobiologiste, président du Comité national d'éthique
9198	9147	Chantal Brenot	
9199	9147	Chantal Liennel	
9200	9147	Chantal Portillo	écrivain français
9201	9147	Chantal Poupaud	cinéaste
9202	9147	Chao Manu	
9203	9147	Chapier Henri	journaliste, spécialiste du cinéma
9204	9147	Chaplin Charlie	
9205	9147	Chapman Jake et Dinos	
9206	9147	Chapot Jean	
9207	9147	Chapuis Pierre-Alain	
9208	9147	Char René	
9209	9147	Charasse Michel	maire de Puy-Guillaume et ex-ministre du Budget
9210	9147	Charbonniaud Claude	
9211	9147	Chardonne Jacques	
9212	9147	Chardère Bernard	
9213	9147	Charensol Georges	
9214	9147	Charette Hervé de	
9215	9147	Charial Jean-André	
9216	9147	Charif Nawaz	
9217	9147	Charlatans the	
9218	9147	Charlebois Robert	
9219	9147	Charlemagne Manno	
9220	9147	Charles Bernard	maire (Radical) de Cahors
9221	9147	Charles Bigot	pdg d'Arianespace
9222	9147	Charles Bouzols	
9223	9147	Charles Bové	architecte
9224	9147	Charles Burchill	rock/Simple Minds
9225	9147	Charles Cré-Ange	
9226	9147	Charles Dantzig	écrivain
9227	9147	Charles Lionel	pdg du GEPM
9228	9147	Charles Pelletier	président de la chambre d'agriculture de Seine-et-Marne
9229	9147	Charles Quint	
9230	9147	Charles Ray	
9231	9147	Charles Reasoner	écrivain
9232	9147	Charles Wardle	sous-secrétaire d'Etat au commerce en Grande-Bretagne
9233	9147	Charles d'Angleterre	
9234	9147	Charles-Henri Favrod	
9235	9147	Charles-Roux Edmonde	
9236	9147	Charlier Jean-Michel	scénariste BD décédé en 1989
9237	9147	Charlot Bernard	
9238	9147	Charlot Jean	Professeur à l'Institut d'études politiques de Paris
9239	9147	Charlotte Delbo	écrivain sur Auschwitz
9240	9147	Charon Jean-Marie	sociologue de la presse et télé
9241	9147	Charret Christian	
9242	9147	Chartier Jean-Louis	président de la Cour régionale des comptes d'Ile-de-France
9243	9147	Charyn Jerome	
9244	9147	Charzat Michel	
9245	9147	Chateaubriand François René	
9246	9147	Chatel Philippe	
9247	9147	Chatelet Noëlle	
9248	9147	Chatellier Félix	
9249	9147	Chatiliez Etienne	
9250	9147	Chatilliez Etienne	
9251	9147	Chaumette François	
9252	9147	Chaumont Jacques	sénateur RPR
9253	9147	Chaurette Normand	
9254	9147	Chautemps Jean-Louis	
9255	9147	Chauvet Christine	secrétaire d'Etat au Commerce Extérieur
9256	9147	Chauvet Jean-Marie	
9257	9147	Chauviré Christiane	
9258	9147	Chauvy Gérard	
9259	9147	Chavanes Georges	maire d'Angoulême
9260	9147	Chavannes Georges	député UDF
9261	9147	Chavarria Daniel	
9262	9147	Chavez Hugo	
9263	9147	Chazal Claire	présentatrice télé et auteur d'un livre sur Balladur
9264	9147	Chazeaux Olivier de	
9265	9147	Chazer Roger	
9266	9147	Cheb Mami	chanteuse de raï
9267	9147	Chebel Malek	
9268	9147	Chechik Jeremiah	
9269	9147	Cheikh Ben Baz	Mufti d'Arabie Saoudite
9270	9147	Chelly Claude	
9271	9147	Chelsom Peter	
9272	9147	Chelton Tsilla	
9273	9147	Chemetov Paul	Architecte français
9274	9147	Chemical Brothers	
9275	9147	Chemillier-Gendreau Monique	
9276	9147	Chemin Jean-Claude	
9277	9147	Cheminade Jacques	
9278	9147	Chen William	
9279	9147	Chen Xitong	ex-chef du PCC de Pékin
9280	9147	Chen-sheng Lin	
9281	9147	Cheney Dick	
9282	9147	Chenna Achoura	
9283	9147	Cherifi Hacine	
9284	9147	Cherpin Marie-Hélène	
9285	9147	Cherry Don	
9286	9147	Cherry Neneh	
9287	9147	Chesbro George	
9288	9147	Chesneaux Jean	
9289	9147	Cheung Leslie	
9290	9147	Cheung Maggie	
9291	9147	Chevalier De La Barre	
9292	9147	Chevalier Dominique	
9293	9147	Chevalier Laurent	
9294	9147	Chevalier Maurice	
9295	9147	Chevalier Pierre	producteur cinéma
9296	9147	Chevallier Laurent	
9297	9147	Chevardnadze Edouard	
9298	9147	Chevillard Eric	
9299	9147	Chevènement Jean-Pierre	
9300	9147	Cheysson Claude	ancien ministre
9301	9147	Chibane Malik	
9302	9147	Chien Frédérick	
9303	9147	Childs Lucinda	Danse
9304	9147	Chillida Eduardo	
9305	9147	Chilton Alex	
9306	9147	Chiluba Fredrick	
9307	9147	Chiquet Pierre	
9308	9147	Chirac Bernadette	
9309	9147	Chirac Claude	
9310	9147	Chirac Jacques	
9311	9147	Chojnacka Elisabeth	
9312	9147	Cholet Cécile	
9313	9147	Cholley Jean	
9314	9147	Chomet Sylvain	auteur de BD
9315	9147	Chomsky Noam	
9316	9147	Chopin Frédéric	
9317	9147	Chopinot Régine	
9318	9147	Choquet Marie	chercheuse de l'Inserm spécialiste du suicide des jeunes
9319	9147	Chorfa Hamid	journaliste algérien
9320	9147	Chosson Arlette	
9321	9147	Chostakovitch Dmitri	
9322	9147	Chotard Yvon	
9323	9147	Chouaki Aziz	
9324	9147	Chouraqui Alain	chercheur au CNRS
9325	9147	Chouraqui Elie	
9326	9147	Chouraqui Jean	
9327	9147	Chowdhry Man Singh	metteur en scène indienne
9328	9147	Chris Evert	
9329	9147	Christel Delaval	compagne de Didier Schuller et activement recherchée par la justice
9330	9147	Christie Agatha	
9331	9147	Christie Lindford	
9332	9147	Christie William	directeur opéra
9333	9147	Christine Carrière	Réalisatrice française
9334	9147	Christine François	
9335	9147	Christine Selvi	adjointe à l'action sociale du maire de Nice
9336	9147	Christitch Kosta	écrivain
9337	9147	Christnacht Alain	
9338	9147	Christo	emballeur
9339	9147	Christo Jeanne-Claude	
9340	9147	Christoph Schoenborn	nommé "dauphin" du cardinal de Vienne accusé de pédophilie
9341	9147	Christophe	
9342	9147	Christophe Blanchard-Dignac	Directeur du Budget dans le gouvernement Juppé
9343	9147	Christophe Calame	
9344	9147	Christophe Campos	
9345	9147	Christophe Cocard	joueur de foot à Auxerre
9346	9147	Christophe Françoise	
9347	9147	Christophe Heili	réalise des documentaires
9348	9147	Christophe Petit	écrivain
9349	9147	Christopher Benfey	romancier
9350	9147	Christopher Dodd	désigné président général du Parti démocrate
9351	9147	Christopher Llewellyn-Smith	
9352	9147	Chrétien Jean	
9353	9147	Chrétien Jean-Loup	
9354	9147	Chrétien Raymond	
9355	9147	Chtcharanski Nathan	
9356	9147	Chun Doo-Hwan	
9357	9147	Chung Myung-Whun	
9358	9147	Churchill Winston	
9359	9147	Chylinski Mike	
9360	9147	Châtelet François	
9361	9147	Châtelet Gilles	philosophe, Paris VIII
9362	9147	Châtenet Aymar du	
9363	9147	Chéreau Patrice	
9364	9147	Chérifa	chanteuse Kabyle
9365	9147	Chérèque François	
9366	9147	Chêne Patrick	
9367	9147	cheikh Ali Salmane	
9368	9147	cheikh Mohammed Akl	
9369	8906	ZZZZ_Personnalités CI	
9370	9369	Ciampi Carlo Azeglio	ministre de l'économie italien, gouvernement Romano Prodi
9371	9369	Cicak Ivan Zvonimir	
9372	9369	Cieslewicz roman	
9373	9369	Ciftci Nevzat	
9374	9369	Ciller Tansu	
9375	9369	Cimino Michael	
9376	9369	Cimoszewicz Wlodzimierz	
9377	9369	Ciolina François	
9378	9369	Cioran Emil Michel	écrivain roumain francophone
9379	9369	Ciorbea Victor	
9380	9369	Cipollini Mario	
9381	9369	Cippolini Mario	
9382	9369	Cissé Madjiguène	
9383	9369	Cissé Souleymane	
9384	9369	Citati Pietro	
9385	9369	Civanyan Eric	
9386	9369	Civera Germana	
9387	9369	Cixous Hélène	
9388	8906	ZZZZ_Personnalités CL	
9389	9388	Claass Arnaud	
9390	9388	Claes Willy	secrétaire général de l'OTAN et ancien ministre Belge des Affaires Economiques
9391	9388	Claeys Agnès	
9392	9388	Claeys Alain	
9393	9388	Clail Gary	
9394	9388	Clair Jean	
9395	9388	Clair Jean-Noël René	
9396	9388	Clair René	Réalisateur
9397	9388	Claire Doutriaux	productrice d'un magazine de reportage pour la Cinquième
9398	9388	Claire Fontana	Militante traditionnaliste en lutte contre la pratique de l'avortement. Présidente du mouvement la Trêve de Dieu.
9399	9388	Claire Marienfeld	
9400	9388	Clam's	Groupe breton java-rock
9401	9388	Clapton Eric	
9402	9388	Clarice Lispector	écrivain brésilienne morte en 1977
9403	9388	Clark Larry	photographe
9404	9388	Clark Marcia	
9405	9388	Clark Nigel	
9406	9388	Clark Pascale	journaliste
9407	9388	Clark Sterling	
9408	9388	Clark Wesley	
9409	9388	Clarke Arthur C.	
9410	9388	Clarke Schirley	
9411	9388	Clary Alain	
9412	9388	Claudel Camille	sculpteur
9413	9388	Claudel Paul	
9414	9388	Claudia Nolte	
9545	9450	Contrada Bruno	
9415	9388	Claudio Léonardi	conseiller municipal socialiste de Chennevières-sur-Marne
9416	9388	Clavel Bernard	
9417	9388	Clavier Christian	
9418	9388	Claxton William F.	
9419	9388	Cleese John	
9420	9388	Cleitman René	
9421	9388	Clemens Brentano	écrivain romantique allemand (1778/1842)
9422	9388	Clerc Julien	
9423	9388	Clervoy Jean-François	
9424	9388	Clinton Bill	
9425	9388	Clinton Chelsea	fille du président américain
9426	9388	Clinton George	
9427	9388	Clinton Hillary	femme de Bill Clinton
9428	9388	Clooney George	
9429	9388	Cloos Hans Peter	
9430	9388	Close Glenn	
9431	9388	Closets François de	
9432	9388	Clottes Jean	préhistorien
9433	9388	Clouet Jean	
9434	9388	Clouzot Henri-Georges	
9435	9388	Cluzel Jean	
9436	9388	Cluzel Jean-Paul	directeur général de l'Opéra de Paris puis PDG de RFI
9437	9388	Cluzet François	
9438	9388	Clyde Drexler	basket/USA
9439	9388	Clémenceau Georges	
9440	9388	Clément Aurore	
9441	9388	Clément Jérôme	
9442	9388	Clément Pascal	
9443	9388	Clément Patrick	(Prénom : Patrick)
9444	9388	Clément René	
9445	9388	Clémenti Pierre	
9446	9388	Cléridès Glafcos	
9447	9388	Clérisseau Charles-Louis	
9448	9388	Clévenot Axel	réalisateur de documentaire
9449	9388	Clévenot Philippe	
9450	8906	ZZZZ_Personnalités CO	
9451	9450	Cobain Kurt	
9452	9450	Cocciante Richard	
9453	9450	Cochet Yves	militant des Verts
9454	9450	Cochran Johnnie	
9455	9450	Cocker Jarvis	
9456	9450	Cocker Joe	
9457	9450	Cocteau Jean	
9458	9450	Cocteau Twins	
9459	9450	Codaccioni Colette	
9460	9450	Codaccioni Michel	
9461	9450	Coelho Paulo	
9462	9450	Coen Ethan	
9463	9450	Coen Joel	
9464	9450	Coencas Michel	
9465	9450	Coffe Jean-Pierre	
9466	9450	Cognée Philippe	
9467	9450	Cohen Albert	
9468	9450	Cohen Daniel	Economiste
9469	9450	Cohen Elie	
9470	9450	Cohen Jean-Louis	
9471	9450	Cohen Léonard	chanteur
9472	9450	Cohen William	
9473	9450	Cohen-Solal Lyne	
9474	9450	Cohen-Tannoudji Claude	
9475	9450	Cohen-Tanuggi Pierre	
9476	9450	Cohn-Bendit Daniel	
9477	9450	Cohn-Bendit Gabriel	
9478	9450	Coindé Henri	
9479	9450	Colardelle Michel	
9480	9450	Colby William	
9481	9450	Cole Freddy	
9482	9450	Cole Lloyd	
9483	9450	Coleman Bill	
9484	9450	Coleman Ornette	
9485	9450	Coleman Ray	
9486	9450	Colette	
9487	9450	Colic Pero	
9488	9450	Colin Delavaux	Professeur de géopolitique
9489	9450	Colin Ferguson	meurtrier raciste noir américain
9490	9450	Colin Michel	
9491	9450	Colin Philippe	PDG/procès/Nancy
9492	9450	Colin Turbot	porte-parole de l'association des inspecteurs des finances
9493	9450	Colin Vincent	
9494	9450	Collard Cyril	
9495	9450	Collard Emmanuel	sport
9496	9450	Collard Gilbert	
9497	9450	Colleter Patrick	joueur de football
9498	9450	Colli Giogio	
9499	9450	Colli Jean-Claude	
9500	9450	Collins Joan	
9501	9450	Collins Phil	
9502	9450	Collomb Gérard	
9503	9450	Collombet Isabelle	
9504	9450	Collor Fernando	
9505	9450	Colomb Denise	
9506	9450	Colombani Jean-Marie	
9507	9450	Colombel Jeannette	ex-dirigeante du PCF ; Philosophe, écrivain dernier ouvrage paru:Michel Foucault, la clarté de la mort, 1994, éditions Odile Jacob.
9508	9450	Colonna Catherine	
9509	9450	Colonna Yvan	
9510	9450	Coluche	
9511	9450	Colé Gérard	Président de la Française des Jeux entre 1989 et1993
9512	9450	Comaneci Nadia	
9513	9450	Combo Ayouba	
9514	9450	Comencini Luigi	
9515	9450	Compagnoni Deborah	skieuse italienne
9516	9450	Compain Pascal	inspecteur de police qui a tué un jeune Zaïrois
9517	9450	Companeez Nina	
9518	9450	Compaoré Blaise	
9519	9450	Comparini Anne-Marie	
9520	9450	Compay Segundo	
9521	9450	Comte-Sponville André	
9522	9450	Comés Didier	
9523	9450	Conde Mario	
9524	9450	Condon Paul	
9525	9450	Condorcet	philosophe et mathématicien
9526	9450	Congar Yves-Marie	Cardinal
9527	9450	Conigliaro Giuseppe	
9528	9450	Conlon James	Chef permanent de l'orchestre de l'Opéra de Paris
9529	9450	Connery Sean	
9530	9450	Connolly Bernard	
9531	9450	Connor Joseph	
9532	9450	Conrad Joseph	
9533	9450	Conrath Philippe	
9534	9450	Conroy Maddox	peintre anglais et surréaliste
9535	9450	Cons Marie-Elisabeth	
9536	9450	Conso Pierre	
9537	9450	Constable John	
9538	9450	Constance Delaunay	
9539	9450	Constant Benjamin	
9540	9450	Constantinescu Emil	
9541	9450	Constantinoff Génia	
9542	9450	Contassot Yves	
9543	9450	Conte Paolo	
9544	9450	Conticini Christian	chef de la Table d'Anvers à Paris
9546	9450	Contreras Manuel	
9547	9450	Conté Lansana	
9548	9450	Convert Pascal	artiste français
9549	9450	Conway Jack	
9550	9450	Conway Martin	
9551	9450	Cooder Ry	
9552	9450	Cook Elisha	
9553	9450	Cook Robin	
9554	9450	Cook Trish	
9555	9450	Cools André	
9556	9450	Cooper Gary	
9557	9450	Coosje Van Bruggen	Artiste sculptrice femme du sculpteur Claes Oldenburg
9558	9450	Copeau Jacques	
9559	9450	Copin Noël	
9560	9450	Coppens Yves	paléontogue
9561	9450	Coppola Francis Ford	
9562	9450	Copé Jean-François	Président du comité Chirac à Meaux
9563	9450	Coq Guy	
9564	9450	Corbalis Brendan	
9565	9450	Corbeau Roger	
9566	9450	Corbin Alain	
9567	9450	Cordeiro Edson	
9568	9450	Cordelle Dominique	
9569	9450	Cordier Alain	
9570	9450	Cordier Daniel	
9571	9450	Cordon Publio	
9572	9450	Cordopatri Teresa	
9573	9450	Corea Chick	
9574	9450	Corentin Martins	joueur de foot d'Auxerre
9575	9450	Corinne Krajewski	attachée parlementaire du député-maire Jacques Mellick
9576	9450	Cormann Enzo	
9577	9450	Cornand Brigitte	Journaliste et réalisatrice
9578	9450	Corneau Alain	réalisateur/cinéma
9579	9450	Corneille Pierre	
9580	9450	Cornell Chris	
9581	9450	Cornillet Thierry	
9582	9450	Cornucopia	Compagnie de théâtre de Lisbonne
9583	9450	Cornwell Patricia	
9584	9450	Cornéa Aurel	
9585	9450	Corot Jean-Baptiste Camille	
9586	9450	Corouge Hélène	
9587	9450	Corretja Alex	
9588	9450	Corsetti Giorgio Barberio	
9589	9450	Corsini Catherine	
9590	9450	Cortez Jayne	
9591	9450	Corvin Michel	
9592	9450	Costa José Fonseca e	
9593	9450	Costa Pedro	
9594	9450	Costa-Gavras	
9595	9450	Costantini Costanzo	
9596	9450	Costantini Daniel	
9597	9450	Costis Stéphanopoulos	président de la République Grèque
9598	9450	Costner Kevin	
9599	9450	Cotta Michèle	
9600	9450	Cottet Jean-Pierre	
9601	9450	Cotti Flavio	
9602	9450	Cottonmouth	
9603	9450	Couderc Anne-Marie	
9604	9450	Couderc Raymond	
9605	9450	Coudreau Dominique	
9606	9450	Coulon Jean-Marie	
9607	9450	Coulthard David	
9608	9450	Coupal Jean-Paul	
9609	9450	Coupat Françoise	
9610	9450	Coupé Annick	
9611	9450	Courbet Gustave	
9612	9450	Courbet Julien	
9613	9450	Courbis Rolland	
9614	9450	Courcol Jean-Pierre	
9615	9450	Courier Jim	
9616	9450	Courroye Philippe	
9617	9450	Courson Charles-Amédée de	
9618	9450	Cousin Bertrand	
9619	9450	Cousseau Henry-Claude	
9620	9450	Cousteau Jacques-Yves	
9621	9450	Coutard Anne	
9622	9450	Coutts Russell	
9623	9450	Couture Xavier	
9624	9450	Couvelair Alexandre	
9625	9450	Couvelaire Alexandre	
9626	9450	Couvreux Christian	
9627	9450	Couzy Henri André	
9628	9450	Cova Charles	maire de Chelles
9629	9450	Coward Noël	producteur ciné britannique
9630	9450	Cozan Jean-Yves	
9631	9450	Cozma Miron	
9632	9450	Côte Laurence	
9633	8906	ZZZZ_Personnalités CR	
9634	9633	Craenhals François	
9635	9633	Cragg Tony	
9636	9633	Craig Carl	
9637	9633	Craig Venter	généticien américain
9638	9633	Crasnianski Serge	PdG de Kis impliqué dans l'affaire Botton
9639	9633	Cravan Arthur	
9640	9633	Crawford Cindy	
9641	9633	Craxi Bettino	ancien leader socialiste italien réfugié en Tunisie
9642	9633	Cray Robert	
9643	9633	Creek Morgan	
9644	9633	Crespin Régine	
9645	9633	Cressole Michel	
9646	9633	Cresson Edith	
9647	9633	Creton Michel	
9648	9633	Crevel René	
9649	9633	Crews Harry	
9650	9633	Crichton Charles	
9651	9633	Crichton Michael	
9652	9633	Crimson King	
9653	9633	Croce Laurent	
9654	9633	Crombecque Alain	
9655	9633	Cromwell John	
9656	9633	Cronenberg David	
9657	9633	Croquet Nadia	
9658	9633	Crosby John	
9659	9633	Crozemarie Jacques	Président de l'ARC
9660	9633	Cruise Tom	
9661	9633	Crumb Robert	dessinateur de BD
9662	9633	Cruyff Johan	entraîneur du FC Barcelone
9663	9633	Cruz Celia	Chanteuse de salsa, exilée cubaine en France.
9664	9633	Crécy Nicolas de	auteur de BD
9665	9633	Crémieux-Brihac Jean-Louis	
9666	9633	Crépeau Michel	membre de Radical
9667	9633	Crétier Jean-Luc	
9668	8906	ZZZZ_Personnalités CS	
9669	8906	ZZZZ_Personnalités CU	
9670	9669	Cuau Emmanuelle	
9671	9669	Cubadda Marie-France	
9672	9669	Cuccia Enrico	
9673	9669	Cuevas Armand de las	
9674	9669	Cukor George	cinéaste
9675	9669	Culkin Macaulay	
9676	9669	Cultiaux Didier	
9677	9669	Cummings Irving	
9678	9669	Cumunel Chantal	
9679	9669	Cunanan Andrew	
9680	9669	Cunningham Merce	
9681	9669	Cuny Alain	
9682	9669	Cuny Bertrand	
9683	9669	Cunéo Anne	
9684	9669	Cupillard Jean-Guy	vice-président du conseil général de l'Isère
9685	9669	Cuq Henri	
9686	9669	Cure (rock)	groupe de rock
9687	9669	Curie Marie	
9688	9669	Curie Pierre	
9689	9669	Curien Hubert	
9690	9669	Curnier Jean-Paul	
9691	9669	Curtis Ian	
9692	9669	Curtis Tony	
9693	9669	Curtiz Michael	
9694	9669	Curtsinger Bill	
9695	9669	Curwood James Olivier	écrivain américano-canadien
9696	9669	Cuvelier Paul	
9697	9669	Cuvilliez Christian	
9698	8906	ZZZZ_Personnalités CY	
9699	9698	Cyprian Kamil Norwid	Ecrivain
9700	8906	ZZZZ_Personnalités CZ	
9701	7428	ZZZZ_Personnalités D	
9702	9701	ZZZZ_Personnalités D'	
9703	9702	D'Alema Massimo	personnalité
9704	9702	D'Almeida Nicole	universitaire
9705	9702	D'Amato Alfonso	
9706	9702	D'Arcy Wentworth Thompson	savant zoologiste-géomètre (1860/1948)
9707	9701	ZZZZ_Personnalités DA	
9708	9707	Dabadie Jean-Loup	
9709	9707	Dacoury Richard	sport
9710	9707	Daeninckx Didier	écrivain et copain de Maurice
9711	9707	Daft Punk	
9712	9707	Dag	Groupe de musique funk
9713	9707	Dagerman Stig	écrivain suédois
9714	9707	Dagnaud Monique	Membre du CSA
9715	9707	Dahan Olivier	
9716	9707	Dahik Alberto	
9717	9707	Dahl John	cinéaste US
9718	9707	Dahmani Arezki	
9719	9707	Daho Etienne	
9720	9707	Dahrendorff Ralph Lord	
9721	9707	Dai Xuezhong	membre de l'association chinoise des Droits de l'homme
9722	9707	Dailly Etienne	sénateur, membre du Conseil constitutionnel
9723	9707	Daisaku Ikeda	
9724	9707	Daley Richard M.	
9725	9707	Dali Salvador	
9726	9707	Dallaire Roméo	
9727	9707	Dalle Béatrice	
9728	9707	Damisch Hubert	
9729	9707	Damon Matt	
9730	9707	Dan Farmer	informaticien de Silicon Graphics et créateur du logiciel des hadckers, "Satan"
9731	9707	Dan Quayle	
9732	9707	Dana	chanteuse israélienne
9733	9707	Dana Philippe	présentateurTV/radio
9734	9707	Daneliuc Mircea	réalisateur roumain
9735	9707	Danet Alain	
9736	9707	Daney Serge	
9737	9707	Daniel Boulanger	
9738	9707	Daniel Colliard	
9739	9707	Daniel Jean	
9740	9707	Daniel Laurent	
9741	9707	Danjoux Bruno	
9742	9707	Dantec Maurice G.	
9743	9707	Dany Carrel	Actrice
9744	9707	Daoud Abou	
9745	9707	Daoudi Ivane	
9746	9707	Darche Hélène	
9747	9707	Darchen Bernadette	apidologue et myrmécologue
9748	9707	Darcos Xavier	
9749	9707	Dard Frédéric	
9750	9707	Dardenne Jean-Pierre	
9751	9707	Dardenne Luc	
9752	9707	Darger Henry	
9753	9707	Darie Boutboul	
9754	9707	Darley Emmanuel	
9755	9707	Darmet Guy	
9756	9707	Darmon Claude	
9757	9707	Darmon Eric	
9758	9707	Darmon Gérard	
9759	9707	Darmon Jean-Claude	
9760	9707	Darrason Olivier	
9761	9707	Darrieussecq Marie	
9762	9707	Darrieux Danielle	
9763	9707	Darrigrand André	
9764	9707	Darroussin Jean-Pierre	 
9765	9707	Dartigues Bernard	
9766	9707	Darwin Charles	
9767	9707	Dassault Olivier	
9768	9707	Dassault Serge	
9769	9707	Dassier Jean-Claude	
9770	9707	Dati Rachida	 
9771	9707	Daudet Alphonse	
9772	9707	Daudet Lionel	alpinisme
9773	9707	Daudet Léon	
9774	9707	Daugherty Michael	
9775	9707	Daumal René	
9776	9707	Dauman Anatole	
9777	9707	Daumas Jean-Louis	Directeur de maison d'arrêt
9778	9707	Daure-Serfaty Christine	
9779	9707	Dauriac Christian	
9780	9707	Daurès Pierre	
9781	9707	Dausset Jean	prix Nobel de médecine en 1980
9782	9707	Dautremay Jean	
9783	9707	Dauvé Gilles	
9784	9707	Dauzier Pierre	président du groupe Havas
9785	9707	Davant Jean-Pierre	médecin, pdt de la Mutualité française
9786	9707	Dave Mustaine	Musique "métal"
9787	9707	Dave Wyndorf	chanteur guitariste du groupe de rock Monster Magnet
9788	9707	Davenas Laurent	
9789	9707	Davenport Lindsay	
9790	9707	Daves Delmer	
9791	9707	David Avidan	Poète Israélien
9792	9707	David Bruce	opposant togolais
9793	9707	David Carson	cinéaste
9794	9707	David Catherine	
9795	9707	David Collenette	Ministre de la Défense canadien
9796	9707	David Dalton	
9797	9707	David Gedge	
9798	9707	David Hilemon	
9799	9707	David Hope	évêque anglican/Londres
9800	9707	David Jacques Louis	1748-1825 . Peintre
9801	9707	David Jacques-Henri	
9802	9707	David Koresh	
9803	9707	David Lytel	conseiller de Clinton venu en France pour étudier le Minitel
9804	9707	David Parent	
9805	9707	David Pharao	réalisateur/téléfilm
9806	9707	David Rivers	basket/Antibes
9807	9707	David Tremlett	peintre
9808	9707	David Weeks	neuropsychiatre anglais
9809	9707	David-Weill Michel	
9810	9707	Davies Jonathan	joueur de rugby
9811	9707	Davies Robertson	
9812	9707	Davies Terence	
9813	9707	Davis Andrew	
9814	9707	Davis Angela	 
9815	9707	Davis Geena	
9816	9707	Davis Miles	
9817	9707	Davoli Ninetto	
9818	9707	Davydov Oleg	
9819	9707	Dayan Assi	fils de moshé
9820	9707	Dayan Josée	
9821	9707	Dayan Moshé	
9822	9707	Dayan Roland	
9823	9707	Dazzi Gualtiero	
9824	9707	Deneche Abdelkrim	
9825	9701	ZZZZ_Personnalités DE	
9826	9825	De Almeida Joaquim	
9827	9825	De Benedetti Carlo	
9828	9825	De Bont Jan	
9829	9825	De Felice Jean-Jacques	avocat
9830	9825	De Keersmaeker Anne Teresa	
9831	9825	De Klerk Frederik	
9832	9825	De Luca Erri	
9833	9825	De Niro Robert	
9834	9825	De Palma Brian	
9835	9825	De Santis Guiseppe	
9836	9825	De Souza Faria Romario	
9837	9825	De Stephano Giorgio	
9838	9825	De Velde Henk	champion de voile hollandais
9839	9825	De Waal Frans	primatologue
9840	9825	De la Rua Fernando	
9841	9825	DeVille Willy	
9842	9825	DeVito Danny	
9843	9825	Deal Kelley	
9844	9825	Dean Howard	
9845	9825	Dean James	
9846	9825	Dean Rusk	chef de la diplomatie américaine de 1961 à 1969
9847	9825	Debaecker Estelle	
9848	9825	Debard Max	
9849	9825	Debarge Marcel	
9850	9825	Debarre Anne	architecte
9851	9825	Debauche Pierre	
9852	9825	Debbasch Charles	
9853	9825	Debbouze Jamel	 
9854	9825	Debord Guy	
9855	9825	Debout Jean-Jacques	
9856	9825	Debray Régis	
9857	9825	Debré Bernard	ministre français de la Coopération
9858	9825	Debré Jean-Louis	
9859	9825	Debré Michel	
9860	9825	Debussy Claude	
9861	9825	Decaux Alain	
9862	9825	Dechavanne Christophe	
9863	9825	Declan Donellan	Metteur en scène
9864	9825	Decoin Henri	
9865	9825	Decouflé Philippe	
9866	9825	Dedieu René	fermier
9867	9825	Dee Dee Bridgewater	chanteuse de jazz
9868	9825	Defert Daniel	
9869	9825	Defferre Gaston	
9870	9825	Deforges Régine	
9871	9825	Dega Gérard	
9872	9825	Degas Edgar	
9873	9825	Degroat Andy	
9874	9825	Deguy Michel	écrivain
9875	9825	Dehaene Jean-Luc	
9876	9825	Dehecq Jean-François	
9877	9825	Dehix Jean-Claude	
9878	9825	Dejammet Alain	
9879	9825	Dejan Savicevic	footballeur
9880	9825	Dejouany Guy	PDG de la Compagnie générale des eaux
9881	9825	Dekhar Aldelhakim	
9882	9825	Del Piero Alessandro	
9883	9825	Del Ponte Carla	
9884	9825	Del Ruth Roy	
9885	9825	Delacampagne Christian	
9886	9825	Delacroix Eugène	peintre
9887	9825	Delage Christian	
9888	9825	Delage Guy	
9889	9825	Delahaye Luc	
9890	9825	Delahaye Marie-Claude	Enseignante en biologie cellulaire à Jussieu
9891	9825	Delahaye Valérie	
9892	9825	Delaigue Philippe	
9893	9825	Delaitre Olivier	
9894	9825	Delalande Jean-Pierre	député-maire de Deuil-la-Barre
9895	9825	Delamare Daniel	
9896	9825	Delannoy Jean	
9897	9825	Delanoë Bertrand	
9898	9825	Delaporte Didier	
9899	9825	Delaporte Florence	
9900	9825	Delarue Jean-Claude	
9901	9825	Delarue Jean-Luc	
9902	9825	Delassus Jean-François	
9903	9825	Delattre Francis	député-maire de Franconville
9904	9825	Delbée Anne	
9905	9825	Delcampe Armand	
9906	9825	Deleau Pierre-Henri	
9907	9825	Delebarre Michel	pdt. conseil national PS
9908	9825	Delebois Jacques	
9909	9825	Delecour Bruno	
9910	9825	Delente Maryse	
9911	9825	Delepine Benoît	auteur des "Guignols de l'info"
9912	9825	Deleu Alain	Président de la CFTC
9913	9825	Deleuze Gilles	
9914	9825	Delevoye Jean-Paul	
9915	9825	Delfau Gérard	
9916	9825	Delfour Jean-Jacques	
9917	9825	Delibes Miguel	
9918	9825	Deligne Pierre	mathématicien Belge, médaille Fields 1978
9919	9825	Deligny Fernand	
9920	9825	Deliss Clementine	
9921	9825	Dell'Utri Marcello	
9922	9825	Delli Fiori Julien	
9923	9825	Delluc louis	
9924	9825	Delmas Jean-Michel	Maire UDF de Mende en Lozère
9925	9825	Delmas Philippe	conseiller référendaire à la Cour des Comptes.
9926	9825	Delmoly Jacques	
9927	9825	Delon Alain	
9928	9825	Delorme Christian	
9929	9825	Delorme Dominique	
9930	9825	Delors Jacques	
9931	9825	Delouvrier Paul	
9932	9825	Delphine Haber-Mignard	chercheuse de l'Inra
9933	9825	Delpire Robert	
9934	9825	Delpy Julie	Actrice.
9935	9825	Dely Valdes Julio Cesar	
9936	9825	Demaret Jacques	cosmologiste/astrophysique
9937	9825	Demarle Philippe	
9938	9825	Demessine Michèle	
9939	9825	Demigneux Jean-Loup	
9940	9825	Demirel Suleyman	
9941	9825	Demme Jonathan	
9942	9825	Demongeot Mylène	
9943	9825	Demouy Vanessa	
9944	9825	Demouzon Alain	
9945	9825	Demuynck Christian	Sénateur de Seine-Saint-Denis
9946	9825	Demy Jacques	
9947	9825	Demy Mathieu	
9948	9825	Denard Bob	
9949	9825	Denel Francis	directeur de l'Inathèque
9950	9825	Deneuve Catherine	
9951	9825	Deng Rong	
9952	9825	Deng Xiaoping	
9953	9825	Deng Zhifang	Fils du numero un chinois Deng Xiaoping.
9954	9825	Deniau Jean-Charles	
9955	9825	Deniau Jean-François	
9956	9825	Deniau Sophie	
9957	9825	Denicourt Marianne	
9958	9825	Deniel Jacques	
9959	9825	Denis Claire	
9960	9825	Denis Jean-Pierre	
9961	9825	Denisot Michel	directeur de Canal Plus et président du PSG
9962	9825	Denktash Rauf	
9963	9825	Denner Charles	
9964	9825	Dennis Conner	Skipper de Stars and Stripes
9965	9825	Dennis Cordell-Laverack	producteur de groupes rock
9966	9825	Dennis Ron	
9967	9825	Dennis Wise	Foot Grande-Bretagne
9968	9825	Denoix de Saint-Marc Renaud	
9969	9825	Denoueix Raynald	
9970	9825	Denoyan Gilbert	
9971	9825	Denvers Alain	
9972	9825	Denys Henderson	President du groupe chimique britannique ICI
9973	9825	Depardieu Elisabeth	
9974	9825	Depardieu Guillaume	
9975	9825	Depardieu Gérard	acteur français
9976	9825	Depardon Raymond	photographe et cinéaste
9977	9825	Depeche Mode	
9978	9825	Depp Johnny	
9979	9825	Deprats Jean-Michel	
9980	9825	Deprez Léonce	
9981	9825	Deran Sarafian	réalisateur de cinéma
9982	9825	Deray Jacques	
9983	9825	Deren Maya	
9984	9825	Derey Alain	
9985	9825	Deri Arieh	
9986	9825	Derieux Emmanuel	
9987	9825	Derlich Didier	
9988	9825	Dermagne Jacques	
9989	9825	Dern Laura	
9990	9825	Derochette Patrick	
9991	9825	Deroy Michel	
9992	9825	Derrida Jacques	
9993	9825	Des Forêts Louis-René	
9994	9825	Desailly Marcel	
9995	9825	Desarthe Agnès	
9996	9825	Desarthe Gérard	
9997	9825	Descamps Philippe	journaliste de FR3
9998	9825	Descarpentries Jean-Marie	
9999	9825	Descartes René	
10000	9825	Deschamps Didier	footballeur
10001	9825	Deschamps Jean-Dominique	
10002	9825	Deschamps Jérôme	
10003	9825	Deschamps Maurice	
10004	9825	Deschamps Michel	
10005	9825	Deschiens	
10006	9825	Descours Charles	
10007	9825	Descours Jean-Louis	
10008	9825	Desiderio Monsu	
10009	9825	Desmarest Alain	PCF/Kremlin-Bicêtre
10010	9825	Desmarest Thierry	
10011	9825	Desmure Patrick	
10012	9825	Desnos Robert	
10013	9825	Despentes Virginie	auteur de polar
10014	9825	Despessailles Pierre	
10015	9825	Desplechin Arnaud	
10016	9825	Desplechin Marie	
10017	9825	Desprez Bertrand	
10018	9825	Desproges Pierre	
10019	9825	Dessaint Pascal	
10020	9825	Dessay Natalie	
10021	9825	Destivelle Catherine	alpiniste
10022	9825	Destot Michel	
10023	9825	Destrade Jean-Pierre	conseiller général et ancien député socialistesdes Pyrénées-Atlantiques
10024	9825	Detambel Régine	
10025	9825	Dethier Jean	
10026	9825	Deuba Bahadur	
10027	9825	Deum Beb	
10028	9825	Deutsch Michel	
10029	9825	Devaquet Alain	
10030	9825	Devaux Monique	
10031	9825	Deve Gowda H.D	
10032	9825	Devedjian Patrick	
10033	9825	Devereux Georges	
10034	9825	Devers Claire	
10035	9825	Deviers-Joncour Christine	
10036	9825	Deville Michel	
10037	9825	Devlin Bernadette	
10038	9825	Devos Emmanuelle	
10039	9825	Devos Raymond	
10040	9825	Dewez Jacques	
10041	9825	Dexter Pete	
10042	9825	Deylaud Christophe	
10043	9825	Dezoteux Michel	
10044	9825	Déroulède Paul	Ecrivain et homme politique français
10045	9825	dEUS	
10046	9825	de Carvalho Otelo	
10047	9825	de la Barra Pablo	
10048	9825	del Vecchio Leonardo	
10049	9701	ZZZZ_Personnalités DH	
10050	9701	ZZZZ_Personnalités DI	
10051	10050	Di Caprio Leonardo	
10052	10050	Di Caro Marco	
10053	10050	Di Falco Jean-Michel	
10054	10050	Di Giovinne Emilio	
10055	10050	Di Pietro Antonio	
10056	10050	Di Rupo Elio	
10057	10050	Di Sciullo Pierre	
10058	10050	DiCillo Tom	
10059	10050	Diabaté Toumani	
10060	10050	Diagana Stéphane	
10061	10050	Diamacoune Augustin	
10062	10050	Diamanti Ilvo	professeur de sociologie politique à l'université de Padoue
10063	10050	Diatchenko Tatiana	
10064	10050	Diaz Guillermo	
10065	10050	Diaz Jesus	
10066	10050	Diaz Simon	
10067	10050	Diaz Yanes Agustin	
10068	10050	Dibala Diblo	
10069	10050	Dibango Manu	
10070	10050	Dick Lowry	
10071	10050	Dick Philip K.	
10072	10050	Dickens Charles	
10073	10050	Didi Evelyne	
10074	10050	Didi-Huberman Georges	
10075	10050	Didier Christian	
10076	10050	Didym Michel	
10077	10050	Dieter Runkel	champion du monde de cyclo-cross
10078	10050	Dietrich Marlène	
10079	10050	Dieudonné	
10080	10050	Dieutre Vincent	
10081	10050	Diez Rolo	auteur de polars argentin
10082	10050	Digard Jean-Pierre	
10083	10050	Dijkstra Rineke	
10084	10050	Dikongué Henri	
10085	10050	Dillais Louis-Pierre	
10086	10050	Dillard Annie	
10087	10050	Diller Barry	homme de télévision américain
10088	10050	Dillon Fence	groupe derock américain
10089	10050	Dillon John Francis	
10090	10050	Dillon Matt	
10091	10050	Dimier Yves	ski alpin
10092	10050	Dimitrov Bisser	
10093	10050	Dindo Richard	réalisateur de télé suisse
10094	10050	Dinelli Raphaël	
10095	10050	Ding Zilin	
10096	10050	Dini Lamberto	ex-ministre de l'économie italien appellé pour former un nouveau gouvernement
10097	10050	Diniz Pedro	
10098	10050	Dion Céline	chanteuse québécoise
10099	10050	Dionne Farris	Chanteuse soul
10100	10050	Dionne Warwick	
10101	10050	Dior Christian	
10102	10050	Diouf Abdou	
10103	10050	Dirceu José	
10104	10050	Disney Walt	
10105	10050	Dityvon Claude	Photographe
10106	10050	Diverrès Catherine	
10107	10050	Divine Comedy	
10108	10050	Dix Otto	
10109	10050	Dizambourg Bernard	
10110	9701	ZZZZ_Personnalités DJ	
10111	10110	Djamel Fezzaz	cinéaste algérien
10112	10110	Djamel Khirmimoune	Jeune franco-algérien mort au mitard de la prison de Fresnes le 28/12/94
10113	10110	Djamel Malti	Algérien, retenu au dépôt des étrangers où il aurait été frappé par des policiers
10114	10110	Djamel Ziani	
10115	10110	Djian Philippe	auteur de polars
10116	10110	Djindjic Zoran	
10117	10110	Djohar Saïd	
10118	10110	Djordjadze Nana	
10119	10110	Djorkaeff Youri	
10120	10110	Djukanovic Milo	
10121	10110	Djukic Djordje	
10122	9701	ZZZZ_Personnalités DO	
10123	10122	Dobtchev Ivan	
10124	10122	Doc Gynéco	
10125	10122	Docking Jill	
10126	10122	Dodgy	Rock
10127	10122	Dodine Lev	
10128	10122	Doherty Willie	
10129	10122	Doillon Jacques	
10130	10122	Doisneau Robert	
10131	10122	Doizelet Sylvie	écrivain Français
10132	10122	Dole Elizabeth	
10133	10122	Dole Robert	leader républicain du Sénat
10134	10122	Dolle Jean-Paul	philosophe
10135	10122	Dom Calvet Gérard	prêtre
10136	10122	Domange Jean	président de la Fédération Française du Bâtiment et vice-président du CNPF
10137	10122	Dombasle Arielle	
10138	10122	Domecq Jean-Philippe	
10139	10122	Domenach Jean-Luc	
10140	10122	Domenech Raymond	
10141	10122	Domergue Jean-François	directeur du PSG
10142	10122	Dominati Jacques	
10143	10122	Dominati Laurent	
10144	10122	Domingo Placido	
10145	10122	Dominguez Cendrine	
10146	10122	Dominguez Marcelo	Boxeur argentin champion du monde WBC / Catégorie Lourds-légers 1995
10147	10122	Dominguin Luis Miguel	
10148	10122	Dominici Gaston	
10149	10122	Dominici Marcel	
10150	10122	Dominico Guérini	ex-directeur de l'OPIHLM
10151	10122	Dominique A	
10152	10122	Don Pierre Nicoli	propriétaire d'une carrière en Corse inculpé pour escroquerie
10153	10122	Don Pullen	Jazz
10154	10122	Donald Fleming	Danse
10155	10122	Donald Pleasance	acteur britannique
10156	10122	Donatoni Franco	
10157	10122	Dondoux Jacques	
10158	10122	Donen Stanley	
10159	10122	Doniol-Valcroze Jacques	cinéaste
10160	10122	Donn Jorge	
10161	10122	Donnadieu Bernard-Pierre	
10162	10122	Donnedieu de Vabres Renaud	
10163	10122	Donner Richard	
10164	10122	Donnigan Cumming	Photographe
10165	10122	Donoso José	
10166	10122	Donovan	
10167	10122	Doobie brothers	
10168	10122	Doohan Michael	
10169	10122	Dor Maureen	
10170	10122	Dor Xavier	médecin militant actif des commandos anti-IVG
10171	10122	Doris Duke	ex-héritière de l'empire American Tobacco
10172	10122	Doris Lauer	Ecrivain
10173	10122	Dormann Genevieve	
10174	10122	Dorn Thomas	
10175	10122	Dory Rotnemer	Epouse du rabbin Marc-Alain Ouaknin. Co-auteur de "La Bible de l'humour juif".
10176	10122	Dos Santos Eduardo	
10177	10122	Dostom Abdul Rachid	
10178	10122	Dostoïevski Fiodor	
10179	10122	Dotti Vittorio	
10180	10122	Douadi Atout	supporter du football club berbère tué lors d'un match
10181	10122	Doubinine Sergueï	
10182	10122	Doubrovsky Serge	
10183	10122	Douchet Jean	
10184	10122	Doucé Joseph	
10185	10122	Doudaïev Alla	
10186	10122	Doudaïev Djokhar	
10187	10122	Doug Peterson	
10188	10122	Douillet David	
10189	10122	Douin Jean-Philippe	Chef d'état-major des armée
10190	10122	Douroux Lucien	
10191	10122	Dourthe Richard	
10192	10122	Douste-Blazy Philippe	
10193	10122	Douzou Laurent	
10194	10122	Dover Eric	
10195	10122	Dowell Coleman	écrivain américain
10196	10122	Downset	groupe de rap
10197	10122	Doye Eric	
10198	10122	Döblin Alfred	
10199	9701	ZZZZ_Personnalités DR	
10200	10199	Dr. John	
10201	10199	Dragacci Demetrius	
10202	10199	Dragan Zivadinov	
10203	10199	Dragojevic Srdjan	
10204	10199	Draskovic Vuk	
10205	10199	Dray Julien	
10206	10199	Draï Raphaël	Raphaël Draï est doyen de la faculté de droit et des sciences politiques d'Amiens.
10207	10199	Dreyer Carl	
10208	10199	Dreyfus Alfred	
10209	10199	Dreyfus Jean-Claude	
10210	10199	Dreyfus Pierre	
10211	10199	Dreyfus Tony	
10212	10199	Dridi Karim	Cinéaste
10213	10199	Dridi Mounir	
10214	10199	Drieu La Rochelle Pierre	
10215	10199	Driss Basri	Ministre de l'intérieur marocain
10216	10199	Droit Roger-Pol	
10217	10199	Dror Liat	
10218	10199	Drot Jean-Marie	
10219	10199	Drouin Michel	
10220	10199	Droukarova Dinara	
10221	10199	Droulers Pierre	
10222	10199	Drovnesk Janez	
10223	10199	Drucker Jean	PDG de M6
10224	10199	Drucker Michel	animateur télé
10225	10199	Druillet Philippe	
10226	10199	Drut Guy	Député maire RPR de Coulommiers
10227	10199	Drèze Alain	
10228	10199	Dréhan Patrick	directeur du festival de la côte d'Opale
10229	10199	Dréville Jean	cinéaste
10230	10199	Dréville Valérie	
10231	9701	ZZZZ_Personnalités DU	
10232	10231	Du Pont John	
10233	10231	Du Pont de Nemours	
10234	10231	Du Roy Albert	
10235	10231	Duato Nacho	
10236	10231	Dub War	Groupe rock
10237	10231	Duban Felix	architecte
10238	10231	Dubernard Jean-Michel	
10239	10231	Dubet François	Sociologue français, chercheur au CNRS, spécialiste de la jeunesse
10240	10231	Dubillard Roland	
10241	10231	Duboc Odile	
10242	10231	Dubois Jean-Paul	
10243	10231	Dubois Jean-Yves	
10244	10231	Dubois Michel	
10245	10231	Dubois Thierry	
10246	10231	Dubouchet Karine	ski
10247	10231	Dubroux Daniel	cinéaste
10248	10231	Dubroux Danièle	
10249	10231	Dubrule Paul	maire de Fontainebleau
10250	10231	Dubrulle Christophe	
10251	10231	Dubuffet Jean	
10252	10231	Duby Georges	
10253	10231	Ducamin Bernard	
10254	10231	Ducasse Alain	
10255	10231	Duchamp Marcel	
10256	10231	Ducrot Oswald	
10257	10231	Ducruet Daniel	Mari de Stéphanie de Monaco
10258	10231	Dufau Bernard	
10259	10231	Duffy stephen	
10260	10231	Duflot Cécile	 
10261	10231	Dufoix Georgina	
10262	10231	Dufour Bernard	
10263	10231	Dufour Christian	
10264	10231	Dufour François	
10265	10231	Dufourcq Elisabeth	secrétaire d'Etat à la Recherche
10266	10231	Dufourt Hugues	
10267	10231	Dugarry Christophe	
10268	10231	Dugied Fabrice	
10269	10231	Dugoin Xavier	pdt. conseil général de l'Essonne
10270	10231	Dugowson Martine	
10271	10231	Duguay Christian	
10272	10231	Duguépéroux Jacky	
10273	10231	Duhalde Eduardo	
10274	10231	Duhamel Alain	
10275	10231	Duhamel Marcel	écrivain et créateur de la Série Noire
10276	10231	Duhamel Olivier	
10277	10231	Duhamel Patrice	
10278	10231	Duhamel Pierre-Mathieu	
10279	10231	Duhême Jacqueline	
10280	10231	Duisenberg Wim	
10281	10231	Dujardin Hubert	
10282	10231	Dulany Parker	
10283	10231	Dumas Alexandre	
10284	10231	Dumas Franck	football
10285	10231	Dumas Mireille	
10286	10231	Dumas Roland	
10287	10231	Dumay Augustin	
10288	10231	Dumay Jean-Charles	
10289	10231	Dumay Pascale	
10290	10231	Dumayet Pierre	
10291	10231	Dumazier Joffre	auteur d'un projet de restructuration de l'école
10292	10231	Dumez Brigitte	
10293	10231	Dumitru Iuga	leader du principal syndicat de la télévision roumaine
10294	10231	Dumond Claude	
10295	10231	Dumont Bruno	
10296	10231	Dumont Eric	
10297	10231	Dumont Lionel	
10298	10231	Dumont René	
10299	10231	Dumézil Georges	
10300	10231	Duncan Andrew	Directeur adjoint de l'institut international des études statégiques (IISS) de Londres depuis 1987.
10301	10231	Dunn Lydia	Personnalité de Hong-Kong, première à avoir été anoblie.
10302	10231	Dunoyer François	
10303	10231	Duong Thu Huong	écrivain dissidente,vietnamienne
10304	10231	Dupeyroux Jean-Jacques	directeur de la revue "Droit social"
10305	10231	Dupin Marc-Olivier	
10306	10231	Duplantier Alain	
10307	10231	Dupond Patrick	
10308	10231	Dupont Hubert	
10309	10231	Duport Jean-Pierre	
10310	10231	Dupouy Alexandre	
10311	10231	Dupuydauby Jacques	
10312	10231	Duquenne Pascal	
10313	10231	Duquennoy Jacques	
10314	10231	Duquesne Benoît	
10315	10231	Duquesne Jacques	
10316	10231	Duran Roberto	
10317	10231	Durand Guillaume	
10318	10231	Durand Régis	
10319	10231	Durand Serge	
10320	10231	Duras Marguerite	
10321	10231	Durel Alain	
10322	10231	Durieux Bruno	
10323	10231	Durif Eugène	
10324	10231	Duris Romain	 
10325	10231	Durocher Hugues	
10326	10231	Duroure Jean-François	auteur de théâtre
10327	10231	Duroux Axel	
10328	10231	Duroy Lionel	
10329	10231	Durr André	
10330	10231	Durrel Lawrence	
10331	10231	Durringer Xavier	écrivain
10332	10231	Durupt Gilles	coordinateur du projet de Gatti a Strasbourg
10333	10231	Durão Barroso José Manuel	
10334	10231	Dusapin Pascal	
10335	10231	Dussolier André	
10336	10231	Dussollier André	
10337	10231	Dutaret Jean-Louis	
10338	10231	Duteil Yves	
10339	10231	Duteurtre Benoît	écrivain, amoureux des vaches
10340	10231	Duthilleul Laure	
10341	10231	Dutoit Christian	
10342	10231	Dutournier Alain	
10343	10231	Dutreil Renaud	
10344	10231	Dutronc Jacques	
10345	10231	Dutroux Marc	Pédophile belge
10346	10231	Duval François	
10347	10231	Duval Mohamed	
10348	10231	Duvalier Jean-Claude	
10349	10231	Duvert Tony	
10350	10231	Duvillard Adrien	
10351	10231	Duviols Pierre	ethnohistorien spécialiste des Incas
10352	10231	Duvivier Julien	
10353	10231	Dürer Albrecht	
10354	10231	Dürrenmatt Friedrich	
10355	10231	du Peloux Cyrille	
10356	9701	ZZZZ_Personnalités DW	
10357	10356	Dwoskin Stephen	cinéaste américain
10358	9701	ZZZZ_Personnalités DY	
10359	10358	Dylan Bob	
10360	9701	ZZZZ_Personnalités DZ	
10361	10360	Dzhuna	astrologue russe
10362	7428	ZZZZ_Personnalités E	
10363	10362	ZZZZ_Personnalités EA	
10364	10363	Ea Sola	
10365	10363	Earl Powell III	
10366	10363	Earle Steve	
10367	10363	Earthling	
10368	10363	Eastwood Clint	
10369	10363	Eaton Robert	PdG de Chrysler
10370	10363	Eavis Michael	
10371	10363	Eazy E	Rappeur cofondateur du groupe NWA (Niggers With Attitude)
10372	10362	ZZZZ_Personnalités EB	
10373	10372	Ebner Martin	
10374	10372	Ebrahim Forouzesh	cinéaste iranien
10375	10362	ZZZZ_Personnalités EC	
10376	10375	Ecevit Bülent	
10377	10375	Echenoz Jean	
10378	10375	Echobelly	
10379	10375	Eco Umberto	
10380	10375	Ecoffard Michel	
10381	10362	ZZZZ_Personnalités ED	
10382	10381	Edberg stefan	
10383	10381	Edelman Frédéric	
10384	10381	Edgar Grospiron	skieur
10385	10381	Edgar Munhall	Conservateur de la Frick Collectino à NY
10386	10381	Edgar Reitz	
10387	10381	Edgard Pisani	
10388	10381	Edgardo Cozarinski	Documentariste
10389	10381	Edika (Carali Edmond)	
10390	10381	Edmundo	joueur de foot brésilien
10391	10381	Edson Araujo Tavares	
10392	10381	Eduardo Scilingo	capitaine de frégate argentin qui a avoué le meurtre d'opposants durant la dictature militaire
10393	10381	Edward Steichen	photographe
10394	10381	Edwards Blake	
10395	10381	Edwards John	
10396	10381	Edzoa Titus	
10397	10362	ZZZZ_Personnalités EF	
10398	10397	Efendic Murat	
10399	10397	Efrain Bamaca Velasquez	leader de la guerilla au Guatemala
10400	10362	ZZZZ_Personnalités EG	
10401	10400	Eggert Heinz	personnalité
10402	10400	Egoyan Atom	Cinéaste
10403	10362	ZZZZ_Personnalités EH	
10404	10403	Ehlers Freddy	
10405	10403	Ehrenberg Alain	sociologue
10406	10362	ZZZZ_Personnalités EI	
10407	10406	Eichel Hans	
10408	10406	Eid Abou Bakr Abdel Rahim	
10409	10406	Eidel Philippe	
10410	10406	Einaudi Jean-Luc	
10411	10406	Einhorn Ira	
10412	10406	Einstein Albert	
10413	10406	Eisenstaedt Alfred	
10414	10406	Eisner William Erwin	
10415	10406	Eizenstat Stuart	
10416	10362	ZZZZ_Personnalités EK	
10417	10416	Ekassi Norbert	boxeur franco-camérounais
10418	10416	Ekeus Rolf	
10419	10416	Ekhanourov Iouri	 
10420	10416	Ekman Ulf	
10421	10362	ZZZZ_Personnalités EL	
10422	10421	El Azan Nabil	
10423	10421	El Halia	
10424	10421	El-Bisatie Mohamed	
10425	10421	El-Hindi	
10426	10421	Elastica	Groupe rock
10427	10421	Elcka	
10428	10421	Eleb Monique	sociologue
10429	10421	Elgey Georgette	
10430	10421	Eliade Mircea	
10431	10421	Elisabeth Esteve-Coll	
10432	10421	Elisabeth II	
10433	10421	Elkabbach Jean-Pierre	
10434	10421	Elkins Doug	
10435	10421	Elkrief Ruth	
10436	10421	Ellemann-Jensen Uffe	
10437	10421	Ellenberger Michel	
10438	10421	Elliott Stephan	réalisateur australien
10439	10421	Ellis Brett Easton	
10440	10421	Ellison Larry	
10441	10421	Ellroy James	auteur américain de romans noirs
10442	10421	Elmer Brok	chrétien démocrate allemand, membre du parlement européen
10443	10421	Elorriaga Javier	
10444	10421	Eloy Michel	
10445	10421	Elsa	
10446	10421	Eltsine Boris	
10447	10421	Eluard Paul	
10448	10421	el-Assad Bachar	
10449	10421	el-Assad Hafez	
10450	10421	el-Bechir Omar	
10451	10421	el-Mahdi Sadeq	
10452	10362	ZZZZ_Personnalités EM	
10453	10452	Emilfork Daniel	
10454	10452	Emilio Lussu	écrivain italien
10455	10452	Emin Patrick	
10456	10452	Eminem	
10457	10452	Emma Tennant	romancière anglaise
10458	10452	Emmanuel Aubert	
10459	10452	Emmanuelle (soeur)	
10460	10452	Emmanuelli Henri	Parti Socialiste
10461	10452	Emmanuelli Xavier	
10462	10452	Emmerich Roland	réalisateur de cinéma américain
10463	10452	Empereur Jean-Yves	Egyptologue, spécialiste d'Alexandrie
10464	10452	Laborit Emmanuelle	
10465	10362	ZZZZ_Personnalités EN	
10466	10465	Encrevé Pierre	
10467	10465	Enderle Peter	
10468	10465	Endfield Cyril Raker	
10469	10465	Engel André	
10470	10465	Enghien duc d'	
10471	10465	Englander Jean-Loup	maire de St-Michel-sur-Orge
10472	10465	Engleman Tom	
10473	10465	Eno Brian	
10474	10465	Enqvist Thomas	tennis
10475	10465	Enrico Robert	Réalisateur
10476	10465	Enrique Vargas	metteur en scène
10477	10465	Ensor James	
10478	10465	Enzensberger Hans Magnus	
10479	10362	ZZZZ_Personnalités EP	
10480	10479	Bourdon (Lucien et Marcelle)	collectionneur de peinture
10481	10479	Ephron Nora	
10482	10362	ZZZZ_Personnalités ER	
10483	10482	Erbakan Necmettin	
10484	10482	Erdemovic Drazen	
10485	10482	Erdmann Nikolaï	
10486	10482	Erdogan Recep Tayyip	
10487	10482	Erfan Ali	
10488	10482	Erlo Louis	Directeur de l'Opéra de Lyon
10489	10482	Ernaux Annie	
10490	10482	Ernst Marx	
10491	10482	Ershad Mohammad	
10492	10482	Ertl Martina	
10493	10362	ZZZZ_Personnalités ES	
10494	10493	Esambert Bernard	
10495	10493	Escande Jean-Paul	personnalites es
10496	10493	Escatha Yannick	
10497	10493	Eschyle	
10498	10493	Escrivar Amalia	
10499	10493	Escudé Nicolas	
10500	10493	Eskénazi Gérard	
10501	10493	Espalioux Jean-Marc	
10502	10493	Espanol René	
10503	10493	Espinasse Jacques	pdg de CEDP
10504	10493	Espinosa German	
10505	10493	Esposito Franck	
10506	10493	Esprit Jacques	
10507	10493	Esquivié Jean-Louis	gendarme de la cellule de l'Elysée
10508	10493	Estefan Gloria	
10509	10493	Esterhazy Péter	
10510	10493	Estier Claude	
10511	10493	Estrada Joseph	Président des Philippines
10512	10493	Estrosi Christian	
10513	10493	Estève Daniel	chercheur scientifique
10514	10493	Estève Gilbert	
10515	10362	ZZZZ_Personnalités ET	
10516	10515	Etaix Pierre	
10517	10515	Etchegaray Françoise	
10518	10515	Etchegoyen Alain	
10519	10515	Etheridge Melissa	
10520	10515	Etienne Bruno	
10521	10515	Etienne Jean-Louis	
10522	10515	Etoré Alain	
10523	10362	ZZZZ_Personnalités EU	
10524	10523	Euclide	mathématicien grec
10525	10523	Eugen Drewermann	
10526	10523	Eugene De Kock	Afrique du sud/procès/apartheid/ANC
10527	10523	Eugène Polevoï	négociant russe en France abattu avec toute sa famille par son fils à Louveciennes
10528	10523	Eugène Ysaÿe	
10529	10523	Eurythmics	Groupe de rock dissous.
10530	10523	Eustache Jean	
10531	10362	ZZZZ_Personnalités EV	
10532	10531	Evangelista Linda	
10533	10531	Evans Gareth	
10534	10531	Evans Nick	
10535	10531	Evelyn Ferreira	militant (Vert) parisien/ affaire appartement Chirac
10536	10531	Evelyne Galtié	
10537	10531	Eveno Bertrand	
10538	10531	Everett Rupert	
10539	10531	Evils Superstars	
10540	10531	Evin Claude	homme politique
10541	10531	Evora Cesaria	musique soul/Cap-Vert
10542	10531	Evren Kenan	
10543	10362	ZZZZ_Personnalités EX	
10544	10362	ZZZZ_Personnalités EY	
10545	10544	Ey Henri	
10546	10544	Eyal Berkowitz	joueur de foot israélien
10547	10544	Eydelie Jean-Jacques	footballeur
10548	10544	Eyraud Jean-Baptiste	
10549	10544	Eyrolles Serge	
10550	10544	Eytan Raphaël	
10551	10362	ZZZZ_Personnalités EZ	
10552	7428	ZZZZ_Personnalités F	
10553	10552	ZZZZ_Personnalités FA	
10554	10553	Fabian Françoise	
10555	10553	Fabien Onteniente	Réalisateur de cinéma français
10556	10553	Fabio Capello	entraineur du Milan AC
10557	10553	Fabius Laurent	
10558	10553	Fabre Jan	
10559	10553	Fabre Michel	adjoint à la mairie de Chelles
10560	10553	Fabre-Aubrespy Hervé	
10561	10553	Fabrice Nora	directeur général du "Parisien"
10562	10553	Fabrizio Calvi	écrivain-journaliste, ex-Libé
10563	10553	Fabrizio Sabelli	
10564	10553	Fabro Luciano	
10565	10553	Fabulous Trobadors	
10566	10553	Facchetti Paul	
10567	10553	Fahd d'Arabie Saoudite	
10568	10553	Faith No More	
10569	10553	Faith Popcorn	
10570	10553	Faithfull Marianne	
10571	10553	Faivre Antoine	
10572	10553	Faivre d'Arcier Bernard	
10573	10553	Falcone Giovanni	juge anti-mafia
10574	10553	Faletti François	
10575	10553	Faliu Odile	
10576	10553	Falk Peter	
10577	10553	Fall Jean-Claude	
10578	10553	Fallahian Ali	
10579	10553	Fallaux Emile	
10580	10553	Fanck Arnold	
10581	10553	Fang Lizhi	
10582	10553	Fangio Juan Manuel	
10583	10553	Fante Dan	
10584	10553	Fante John	
10585	10553	Fanton André	
10586	10553	Farah Fawcett	
10587	10553	Fargette Jean-Louis	
10588	10553	Farhad Khosrokhavar	auteur d'un essai sur le foulard
10589	10553	Farmer Gary	
10590	10553	Farmer Mylène	
10591	10553	Farouk Kadoumi	Chef du département politique de l'OLP
10592	10553	Farrakhan Louis	leader américain de Nation de l'islam
10593	10553	Farrow Mia	
10594	10553	Farrugia Dominique	
10595	10553	Fassbinder Rainer Werner	
10596	10553	Fatih Saribas	photographe à Reuter
10597	10553	Fatiha Habchi	styliste, responsable du département achat du Printemps
10598	10553	Fatou Hélène	
10599	10553	Fattoumi Héla	danse
10600	10553	Fauchois Gwen	
10601	10553	Faucon Philippe	réalisateur français
10602	10553	Faudel	musicien raï
10603	10553	Faulkner Shannon	
10604	10553	Faulkner William	écrivain américain
10605	10553	Faure Roland	
10606	10553	Faurisson Robert	
10607	10553	Fauroux Roger	
10608	10553	Faurre Pierre	
10609	10553	Faustino Asprilla	footballeur
10610	10553	Fauvet Christian	
10611	10553	Favier Ivan	
10612	10553	Favier Jean	
10613	10553	Favier Jean-Jacques	
10614	10553	Favier Philippe	
10615	10553	Favier Sophie	
10616	10553	Faye Jean-Pierre	
10617	10553	Fayolle Eric	
10618	10552	ZZZZ_Personnalités FE	
10619	10618	Febvre Lucien	historien/économiste/sociologue mort en 1956
10620	10618	Fechner Christian	
10621	10618	Federico Pena	
10622	10618	Federle Helmut	
10623	10618	Fejtö François	
10624	10618	Fekete Ibolya	
10625	10618	Fela	
10626	10618	Feliciano Hector	
10627	10618	Fellini Federico	
10628	10618	Fellous Elie	Ex bras droit de Bernard Tapie
10629	10618	Fenech Roger	
10630	10618	Ferdinand Chaffart	PdG de la Générale de Banque
10631	10618	Ferdinand Nahimana	rwandais ex-animateur de la radio des mille collines et accusé de génocide par le tribunal international
10632	10618	Ferdinand Ossendowski	Ecrivain Polonais.
10633	10618	Ferebee Tom	
10634	10618	Ferenczi Sandor	
10635	10618	Ferguson Larry	
10636	10618	Ferguson Sarah	
10637	10618	Ferhat Mehenni	Chanteur algérien
10638	10618	Fernand Baguet	Spécialiste des poissons lumineux à l'université catholique de Louvain
10639	10618	Fernandel	
10640	10618	Fernandez Jean-Claude	
10641	10618	Fernandez Leonel	
10642	10618	Fernandez Luis	entraîneur de foot du Paris Saint Germain
10643	10618	Fernandez Mary Joe	
10644	10618	Fernandez Nilda	
10645	10618	Fernandez Roque	
10646	10618	Ferniot Jean	
10647	10618	Ferran Catherine	
10648	10618	Ferran Pascale	
10649	10618	Ferrara Abel	metteur en scène américain
10650	10618	Ferre Gianfranco	
10651	10618	Ferreira Barbosa Laurence	
10652	10618	Ferreira Wayne	tennis
10653	10618	Ferreri Marco	
10654	10618	Ferri Lucien	
10655	10618	Ferro Marc	
10656	10618	Ferry Jean-Marc	
10657	10618	Ferry Luc	
10658	10618	Ferré Léo	
10659	10618	Fesch (cardinal)	
10660	10618	Feydeau Georges	auteur de pièce de théâtre
10661	10618	Feyerabend Paul	
10662	10618	Félix Maria	
10663	10618	Fénelon	
10664	10618	Féraud Louis	
10665	10618	Féret Dominique	
10666	10618	Féval Philippe	
10667	10552	ZZZZ_Personnalités FI	
10668	10667	Fichera Massimo	
10669	10667	Fidel Ramos	Président des Philippines.
10670	10667	Field Michel	
10671	10667	Fiennes Ralph	Acteur
10672	10667	Figard Celine	
10673	10667	Figueroa Ruben	
10674	10667	Fijen Hedwig	
10675	10667	Fikret Abdic	
10676	10667	Fila Ivan	
10677	10667	Filali Fouad	
10678	10667	Filipacchi Daniel	
10679	10667	Filippeddu frères	
10680	10667	Filippi Jean-François	
10681	10667	Filippini Mireille	
10682	10667	Filleul Jean-Jacques	député ps d'Indre-et-Loire et maire de Montlouis-sur-Loire
10683	10667	Fillinger Gilbert	
10684	10667	Fillon François	Ministre de l'enseignement supérieur
10685	10667	Filoche Gérard	
10686	10667	Financière Robur	
10687	10667	Finch Nigel	
10688	10667	Fincher David	
10689	10667	Findley Timothy	écrivain
10690	10667	Fini Gianfranco	leader du MSI
10691	10667	Fink Mathias	physique fondamentale
10692	10667	Finkelstein Arthur	
10693	10667	Finkielkraut Alain	
10694	10667	Fiodorov Sviatoslav	
10695	10667	Fiorentino Linda	actrice américaine
10696	10667	Fiorio Giorgia	
10697	10667	Fisbach Frédéric	
10698	10667	Fischer Ivan	
10699	10667	Fischer Joschka	
10700	10667	Fischer Leni	
10701	10667	Fischer-Dieskau Dietrich	
10702	10667	Fischler Claude	sociologue
10703	10667	Fischler Franz	Commissaire européen à l'Agriculture
10704	10667	Fishbone	
10705	10667	Fisher Terence	
10706	10667	Fiterman Charles	
10707	10667	Fitoussi Jean-Paul	Président de l'OFCE
10708	10667	Fitzgerald Ella	
10709	10667	Fitzgerald Francis Scott	
10710	10667	Fize Michel	Michel Fize est sociologue au CNRS et a été membre du Comité pour la consultation nationale des jeunes.
10711	10552	ZZZZ_Personnalités FL	
10712	10711	Flaherty Robert	
10713	10711	Flament Roger	
10714	10711	Flammarion Charles-Henri	
10715	10711	Flanagan Barry	
10716	10711	Flatto-Sharon Shmuel	
10717	10711	Flaubert Gustave	
10718	10711	Flavin Dan	
10719	10711	Fleder Gary	
10720	10711	Fleischer Richard	cinéaste américain
10721	10711	Fleiss Heidi	
10722	10711	Fleisser Marieluise	
10723	10711	Fleming Renée	
10724	10711	Fleming Victor	
10725	10711	Fleury Cathy	
10726	10711	Flick (famille)	
10727	10711	Flis-Treves Muriel	médecin psychologue spécialiste des femmes enceintes
10728	10711	Flohic Catherine	
10729	10711	Flor Contemplacion	immigrée philippine pendue à Singapour
10730	10711	Florent Pagny	
10731	10711	Flores Lola	
10732	10711	Flosse Gaston	
10733	10711	Fléouter Claude	
10734	10552	ZZZZ_Personnalités FO	
10735	10734	Fo Dario	
10736	10734	Foccart Jacques	Homme politique, chargé sous De Gaulle des Affaires Africaines
10737	10734	Fogiel Marc-Olivier	
10738	10734	Fokin Valeri	
10739	10734	Fokine Mikhail	
10740	10734	Folco Michel	
10741	10734	Folds Ben	
10742	10734	Foll Olivier	
10743	10734	Folz Jean-Martin	
10744	10734	Fomenko Piotr	
10745	10734	Fonda Jane	
10746	10734	Font Patrick	
10747	10734	Fontaine André	
10748	10734	Fontaine Anne	
10749	10734	Fontaine Brigitte	
10750	10734	Fontaine Marcel	
10751	10734	Fontaine Nicole	
10752	10734	Fontanarosa Patrice	
10753	10734	Fontane Theodor	
10754	10734	Fontcuberta Joan	photographe catalan
10755	10734	Foo Fighters	Groupe de rock
10756	10734	Footsbarn Travelling Théatre	
10757	10734	Forbes Malcom Steve Junior	
10758	10734	Ford Harrison	
10759	10734	Ford John	
10760	10734	Ford Madox Ford	
10761	10734	Ford Richard	
10762	10734	Ford Robben	
10763	10734	Forde Eugene	cinéaste
10764	10734	Foreman George	boxeur US
10765	10734	Foreman Richard	
10766	10734	Forgeard Noël	
10767	10734	Forget Guy	
10768	10734	Forman Milos	
10769	10734	Forni Raymond	
10770	10734	Forrester Viviane	
10771	10734	Forsyth Frederick	
10772	10734	Forsythe William	
10773	10734	Fort Géraldine	écrivain
10774	10734	Fortier Denis	Denis Fortier, directeur d'unité de programme à Infogrames et expert près les tribunaux.
10775	10734	Fortunato Pires Francisco	
10776	10734	Fortune Robert	metteur en scène d'opéra
10777	10734	Foscale Giancarlo	
10778	10734	Fosse Bob	
10779	10734	Fosse Jon	
10780	10734	Fossen Maïté	
10781	10734	Fosso Samuel	
10782	10734	Foster Henri	personnalité
10783	10734	Foster Jodie	
10784	10734	Foster Norman	architecte anglais
10785	10734	Foster Robert	
10786	10734	Foucart François	
10787	10734	Foucauld Jean-Baptiste de	commissaire au Plan
10788	10734	Foucault Jean-Pierre	
10789	10734	Foucault Léon	Physicien français, spécialiste en astrophysique, a pour la 1ère fois établit le mouvement de rotation de la Terre grâce à un pendule suspendu au dôme du Panthéon. (1819/1868)
10790	10734	Foucault Michel	
10791	10734	Foucher Michèle	
10792	10734	Fouché Pascal	
10793	10734	Foucras Sébastien	
10794	10734	Fougea Frédéric	
10795	10734	Fouillaud Patrice	
10796	10734	Fouilloux Etienne	
10797	10734	Foulquier Jean-Louis	
10798	10734	Fouquet Thierry	
10799	10734	Fourcade Jean-Pierre	
10800	10734	Fourneau Alain	metteur en scène
10801	10734	Fournet-Fayard Jean	
10802	10734	Fournier Dominique	directeur des programmes de TV5
10803	10734	Fournier Jacques	administrateur et membre du bureau de la Fédération Nationale des travaux publics (FNTP), mais sans rapport avec l'ex-président de la SNCF, dont il est le simple homonyme
10804	10734	Fournier Jean-Jacques	
10805	10734	Fournier Jean-Louis	réalisateur de télévision
10806	10734	Fournier Marc	
10807	10734	Fouroux Jacques	personnalites fo
10808	10734	Fourtou Jean-René	pdg de Rhône-Poulenc
10809	10734	Fox Vicente	
10810	10552	ZZZZ_Personnalités FR	
10811	10810	Fra Bartolommeo	peintre dominicain italien 1472/1517, disciple de Savonarole
10812	10810	Fragonard Bertrand	
10813	10810	Fragonard Jean-Honoré	
10814	10810	Fraisse Geneviève	philosophe
10815	10810	Frakes Jonathan	
10816	10810	Frame Janet	
10817	10810	Franc Alain	gendarme assassiné
10818	10810	Franc Régis	
10819	10810	Francastel Pierre	
10820	10810	Francelet Marc	
10821	10810	Francesco Smalto	couturier italien/affaire
10822	10810	Francis Guillot	
10823	10810	Francis Lopez	
10824	10810	Francis Rui	rugbyman
10825	10810	Francis Sam	
10826	10810	Francisci Roland	
10827	10810	Franciszek Piper	
10828	10810	Franck Dan	
10829	10810	Franco Audrito	architecte designer des années 60
10830	10810	Franco Bahamonde (général)	
10831	10810	Franco Ballerini	coureur cycliste
10832	10810	Franco Baresi	footballeur
10833	10810	Franco Modigliani	prix Nobel d'économie
10834	10810	Francois Yves-Noel	
10835	10810	Francq Philippe	
10836	10810	Franju Georges	
10837	10810	Frank Adisson	
10838	10810	Frank Anne	
10839	10810	Frank Bernard	
10840	10810	Frank Cottrell Boyce	cinéaste anglais
10841	10810	Frank Henriet	
10842	10810	Frank Herz	
10843	10810	Frank Hoffmann	Metteur en scène
10844	10810	Frank Robert	
10845	10810	Frankenheimer John	
10846	10810	Franklin Aretha	
10847	10810	Franquet Jacques	
10848	10810	Franquin André	
10849	10810	Frans Bonhomme	
10850	10810	François Aron	universitaire et historien, médiateur dans le conflit de La Poste
10851	10810	François Arpels	héritier de la joaillerie Van Cleef & Arpels et pdg de la compagnie aérienne privée Fairlines
10852	10810	François Ballestracci	militant PS
10853	10810	François Boisrond	peintre
10854	10810	François Cacault	collectionneur d'art
10855	10810	François Chartier	
10856	10810	François Claude	
10857	10810	François Delecour	Pilote automobile
10858	10810	François Frédéric	
10859	10810	François Gautier	
10860	10810	François Gremy	professeur de sant publique, rapporteur sur le scandale du sang contaminé et le rôle du corps médical
10861	10810	François Hiffler	
10862	10810	François Korber	
10863	10810	François Kosciusko-Morizet	coseiller municipal de Sèvres
10864	10810	François Leguat	Ecrivain.
10865	10810	François Lemasson	
10866	10810	François Parrot	
10867	10810	François Rouan	peintre spécialisé dans les vitraux
10868	10810	François Sedan	
10869	10810	François Sottet	
10870	10810	François Trollat	restaurateur
10871	10810	François-Poncet Jean	ancien ministre des affaires étrangères
10872	10810	François-Poncet Marie-Thérèse	
10873	10810	Françoise Adret	
10874	10810	Françoise Colmez	
10875	10810	Françoise Detay-Lanzmann	écrivain scientifique
10876	10810	Françoise Jollant	conseillère du département arts du XXe siècle au Musée des Arts Décoratifs
10877	10810	Françoise Levie	réalisatrice télé
10878	10810	Françoise Léadouze	
10879	10810	Françoise Richard	ex-maire de Noisy-le-Grand mise en cause pour sa gestion
10880	10810	Françoise Romand	
10881	10810	Françon Alain	
10882	10810	Frappé Benoît	
10883	10810	Fraser Jane	
10884	10810	Fratoni Jean-Dominique	affaire/casino
10885	10810	Fraysse Marc	Député RPR du Rhône
10886	10810	Freak power	Groupe de musique funk
10887	10810	Frears Stephen	cinéaste anglais
10888	10810	Fred	
10889	10810	Fred Perry	tennisman
10890	10810	Freda Riccardo	
10891	10810	Freeman Cathy	
10892	10810	Freeman Morgan	
10893	10810	Fregoli	music-hall 1900
10894	10810	Frei Eduardo	Président chilien
10895	10810	Freleng Isadore	
10896	10810	Fremlin Celia	
10897	10810	Frentzen Heinz-Harald	
10898	10810	Frenàk pal	
10899	10810	Fresco Paolo	
10900	10810	Fresnel Michel	
10901	10810	Fressange Inès de la	
10902	10810	Freud Lucian	
10903	10810	Freud Sigmund	
10904	10810	Freulet Gérard	
10905	10810	Freund Gisèle	
10906	10810	Freund Maurice	
10907	10810	Frey Gerhard	
10908	10810	Frey Sami	
10909	10810	Freyche Michel	
10910	10810	Friday Garvin	
10911	10810	Friedan Betty	
10912	10810	Friedkin William	
10913	10810	Friedman Kinky	
10914	10810	Friedman Milton	
10915	10810	Friedmann Jacques	
10916	10810	Friedrich Caspar David	peintre
10917	10810	Frigerio Ezio	
10918	10810	Frin Jean-Marie	
10919	10810	Fripp Robert	
10920	10810	Frisch Max	
10921	10810	Frize Nicolas	Compositeur. Travaille sur l'environnement sonore et sur la musique à l'hôpital
10922	10810	Frizot Michel	
10923	10810	Froment Jean-Louis	
10924	10810	Froment-Meurice François	
10925	10810	Fromental Jean-Luc	
10926	10810	Frossard André	
10927	10810	Frot Dominique	
10928	10810	Fry Stephen	
10929	10810	Frydman Jean	
10930	10810	Frydman Monique	
10931	10810	Frye Mia	
10932	10810	Frykowski Baretk	
10933	10810	Fréchette Louise	
10934	10810	Frédéric Ditis	Figure de l'édition française
10935	10810	Frédéric Goldsmith	
10936	10810	Frédéric II	
10937	10810	Frédéric Ocqueteau	
10938	10810	Frédéric-Dupont Edouard	
10939	10810	Frêche Georges	
10940	10810	Fröhlich Margot	
10941	10552	ZZZZ_Personnalités FU	
10942	10941	Fu Shenqi	
10943	10941	Fuentes Carlos	
10944	10941	Fugain Michel	
10945	10941	Fugazi	groupe de hard rock
10946	10941	Fugees	
10947	10941	Fuhrman Mark	
10948	10941	Fujimori Alberto	
10949	10941	Fujita Akiro	
10950	10941	Fuksas Massimiliano	
10951	10941	Fukuda Jun	
10952	10941	Fuller Samuel	
10953	10941	Fumaroli Marc	
10954	10941	Furet François	Ecrivain
10955	10941	Furey Lewis	
10956	7428	ZZZZ_Personnalités G	
10957	10956	ZZZZ_Personnalités GA	
10958	10957	GAN	
10959	10957	Gaarder Jostein	philosophe norvégien
10960	10957	Gabily Didier-Georges	
10961	10957	Gabin Jean	
10962	10957	Gabor Eva	
10963	10957	Gabor Fodor	
10964	10957	Gaborit Jean-René	
10965	10957	Gaborit Pierre	
10966	10957	Gabriadze Rézo	
10967	10957	Gabriel Arnaud	Peintre chansonnier
10968	10957	Gabriel Dewalle	Responsable de la Confédération paysanne
10969	10957	Gabriel Mille	
10970	10957	Gabriel Peter	
10971	10957	Gabriel Yacoub	
10972	10957	Gabrielle Pauli	Chef du service pneumologie à Strasbourg
10973	10957	Gaccio Bruno	
10974	10957	Gada Mohammand	joueur de dôtar afghan
10975	10957	Gadamer Hans-Georg	
10976	10957	Gaddis William	
10977	10957	Gadella rik	
10978	10957	Gades Antonio	
10979	10957	Gadji G. Opely	G. Opely Gadji est professeur de mathématiques.
10980	10957	Gadmer Frédéric	
10981	10957	Gadonneix Pierre	
10982	10957	Gaetano Donizetti	
10983	10957	Gagnaire Pierre	
10984	10957	Gaillard Anne	
10985	10957	Gaillard Philippe	Historien
10986	10957	Gaillot Jacques	
10987	10957	Gailly Christian	
10988	10957	Gainsbourg Charlotte	
10989	10957	Gainsbourg Serge	
10990	10957	Gal Nir Ben	
10991	10957	Galan Diego	
10992	10957	Galavielle Jean-Pierre	Directeur du Centre Mendès-France, Université Paris I
10993	10957	Galfione Jean	
10994	10957	Galindo Enrique Rodriguez	
10995	10957	Gall Hugues	directeur délégué de l'Opéra de Paris
10996	10957	Gallagher Noel	
10997	10957	Gallagher Rory	
10998	10957	Galland Jean-Pierre	Responsable du Collectif d'information et de recherche cannabique (CIRC)
10999	10957	Galland Olivier	Sociologue
11000	10957	Galland Philippe	
11001	10957	Galland Yves	
11002	10957	Gallant Mavis	
11003	10957	Gallaz Christophe	Christophe Gallaz est écrivain, auteur de la Parole détruite, médias et violence; Zoé, genève, 1995.
11004	10957	Galley Robert	
11005	10957	Galliano John	
11006	10957	Gallimard Antoine	
11007	10957	Gallimard Simone	
11008	10957	Gallois Louis	
11009	10957	Gallotta Jean-Claude	
11010	10957	Galy-Dejean René	Député RPR
11011	10957	Galzain Loïc de	
11012	10957	Gambaccini Paul	
11013	10957	Gamblin Jacques	
11014	10957	Gamsakhourdia Zviad	
11015	10957	Gance Abel	
11016	10957	Gandhi (Mahatma)	
11017	10957	Gandhi (famille Nehru Gandhi)	
11018	10957	Gandois Jean	
11019	10957	Gans Christophe	
11020	10957	Ganz Axel	
11021	10957	Ganz Bruno	
11022	10957	Garaud Marie-France	Ancienne conseillere de Jacques Chirac
11023	10957	Garaudy Roger	
11024	10957	Garbage	
11025	10957	Garbo Greta	
11026	10957	Garcia Lorca Federico	
11027	10957	Garcia Marquez Gabriel	écrivain colombien
11028	10957	Garcia Nicole	
11029	10957	Garde Paul	écrivain
11030	10957	Gardel Carlos	
11031	10957	Gardner Danielle	
11032	10957	Gargouri Mondher	
11033	10957	Garing Philippe	Ex directeur de la police de la région Alsace mis en examen pour escroquerie ...
11034	10957	Garner Jay	
11035	10957	Garnett David	
11036	10957	Garnett Tay	
11037	10957	Garnier Etienne	
11038	10957	Garnier Laurent	
11039	10957	Garran Gabriel	
11040	10957	Garrec René	
11041	10957	Garrel Louis	 
11042	10957	Garrel Philippe	
11043	10957	Garrel Thierry	
11044	10957	Garreton Roberto	
11045	10957	Garrett Peter	
11046	10957	Garretta Michel	
11047	10957	Garth Brooks	musicien de country
11048	10957	Garwin Richard	rapport US/essais nucléaires
11049	10957	Gary Coward	
11050	10957	Gary Milhollin	spécialiste américain de la prolifération des armes nucléaires dans le monde
11051	10957	Gary Rex Lauck	
11052	10957	Gary Romain	
11053	10957	Garzon Baltasar	
11054	10957	Gasc André	caméraman de France 3
11055	10957	Gasc Jean-Pierre	sous-directeur du laboratoire d'anatomie comparée au Muséum d'Histoire Naturelle de Paris
11056	10957	Gascoigne Paul	
11057	10957	Gascon Pierre	adjoint au maire de Grenoble
11058	10957	Gaspard Françoise	ancien maire de Dreux
11059	10957	Gasquet Richard	
11060	10957	Gassman Vittorio	
11061	10957	Gassée Jean-Louis	
11062	10957	Gast Léon	
11063	10957	Gaston Calmette	
11064	10957	Gates Bill	PDG de Microsoft
11065	10957	Gatien Jean-Philippe	
11066	10957	Gatlif Tony	
11067	10957	Gattaz Yvon	
11068	10957	Gatti Armand	
11069	10957	Gatti Stéphane	
11070	10957	Gaubert Patrick	législation antiraciste
11071	10957	Gaud Bernard	co-président de La Vie, distributeur de produit agricole biologique
11072	10957	Gaudin Henri	architecte
11073	10957	Gaudin Jean-Claude	Président PR de la région PACA
11074	10957	Gaudino Antoine	
11075	10957	Gauguin Paul	peintre
11076	10957	Gaul Hartmut	
11077	10957	Gaul Ingrid	
11078	10957	Gaulle Charles de	
11079	10957	Gaulle-Anthonioz Geneviève de	
11080	10957	Gaullier Xavier	sociologue
11081	10957	Gaultier Jean-Paul	Couturier
11082	10957	Gaumer Patrick	
11083	10957	Gauron André	ex-conseiller de Bérégovoy
11084	10957	Gautier Alain	
11085	10957	Gautier Xavier	
11086	10957	Gavalda Jean-François	
11087	10957	Gavin Hastings	Buteur de rugby
11088	10957	Gavin Patrick	
11089	10957	Gaymard Hervé	député de Savoie, chiraquien
11090	10957	Gayssot Jean-Claude	
11091	10957	Gazeau Denis	témoin de l'Affaire Alcatel-CIT
11092	10957	Gazzara Ben	
11093	10957	Gaétan Deodato	
11094	10957	Gaïdar Egor	
11095	10956	ZZZZ_Personnalités GB	
11096	11095	Gbagbo Laurent	
11097	11095	Gbezera-Bria Michel	
11098	10956	ZZZZ_Personnalités GE	
11099	11098	Geagea Samir	
11100	11098	Gebresilassie Haile	
11101	11098	Geertz Clifford	
11102	11098	Gefen Aviv	
11103	11098	Geffen David	
11104	11098	Geiger Eric	
11105	11098	Geindre François	
11106	11098	Geleynse Wyn	
11107	11098	Geluck Philippe	
11108	11098	Genet Jean	
11109	11098	Geneviève Domenach-Chich	
11110	11098	Geneviève Gontier	
11111	11098	Genoud François	
11112	11098	Genscher Hans-Dietrich	
11113	11098	Gente Philippe	
11114	11098	Gentil Didier	
11115	11098	Gentil Francisque	
11116	11098	Gentilini Marc	directeur du département des maladies tropicales de la Pitié-Salpêtrière
11117	11098	Genvrin Emmanuel	
11118	11098	Geoffrey Parsons	musicien
11119	11098	Geoges Tzoanos	
11120	11098	George Susan	
11121	11098	Gerbault Alain	Ecrivain-navigateur
11122	11098	Gere François	Maître de recherches au Crest-Ecole polytechnique, auteur de la Prolifération nucléaire, PUF, 1995.
11123	11098	Gere Richard	
11124	11098	Geremek Bronislaw	
11125	11098	Gergiev Valery	
11126	11098	Gerhard Bohner	
11127	11098	Gerhard Hahn	
11128	11098	Gerima Haïle	
11129	11098	Germa Michel	
11130	11098	Germain Jean	
11131	11098	Germon Claude	maire PS de Massy
11132	11098	Germon Magdeleine	
11133	11098	Gerold Tandler	
11134	11098	Gerrard Lisa	
11135	11098	Gershwin George	
11136	11098	Gest Alain	
11137	11098	Gette Paul-Armand	
11138	11098	Getty Balthazar	
11139	11098	Gélin Daniel	
11140	11098	Gélinet Patrice	
11141	11098	Géniteau Alain	
11142	11098	Généreux Jacques	
11143	11098	Gérard Aldebert	secrétaire général de la mairie de Nîmes
11144	11098	Gérard Auzet	Boulanger artisanal
11145	11098	Gérard Delteil	écrivain
11146	11098	Gérard Gasiorowski	Peintre
11147	11098	Gérard Jean-Pierre	
11148	11098	Gérard Kébabdjian	économiste
11149	11098	Gérard Probert	maire de clichy
11150	11098	Gérard Quesnel	
11151	11098	Gérard Soulier	Ecrivain
11152	11098	Gérard Trémège	élu à la tête des CCI de France
11153	11098	Gérard Vandystadt	photographe spécialiste du sport
11154	11098	Gérard Voitey	
11155	11098	Gérarld Asaria	
11156	11098	Géraud Jacques	
11157	11098	Géva Caban	Ecrivain
11158	10956	ZZZZ_Personnalités GH	
11159	11158	Ghani Yalouz	
11160	11158	Ghedina Kristian	skieur italien
11161	11158	Gheerbrant Denis	documentariste
11162	11158	Gheorghiu Angela	
11163	11158	Ghezzi Enrico	directeur festival de Taormina
11164	11158	Ghislain Mollet-Viéville	
11165	11158	Ghorab-Volta Zaïda	
11166	11158	Ghosn Carlos	
11167	11158	Ghosn Georges	
11168	10956	ZZZZ_Personnalités GI	
11169	11168	Giacometti Alberto	
11170	11168	Giacometti Pierre	
11171	11168	Gian Maria Volonte	
11172	11168	Gianluca Bortolami	
11173	11168	Gianni Locatelli	
11174	11168	Gianni de Michelis	
11175	11168	Giap Vo Nguyen	
11176	11168	Gibault Claire	
11177	11168	Gibson Brian	
11178	11168	Gibson Mel	
11179	11168	Gibson William	
11180	11168	Gicquel Roger	
11181	11168	Gide André	
11182	11168	Giersch Pierre	
11183	11168	Giesbert Franz-Olivier	
11184	11168	Gifford Barry	
11185	11168	Giger Fabrice	
11186	11168	Gigli Romeo	
11187	11168	Gil Gilberto	
11188	11168	Gil Vicente	Fondateur du théâtre portugais
11189	11168	Gil-Robles Jose Maria	
11190	11168	Gilardi Thierry	
11191	11168	Gilbert Danièle	
11192	11168	Gilbert Duclos-Lassalle	coureur cycliste
11193	11168	Gildas Philippe	
11194	11168	Gilg Candice	skieuse
11195	11168	Gili Gérard	
11196	11168	Gillain Marie	
11197	11168	Gille Elisabeth	
11198	11168	Gilleron Pierre-Yves	commissaire de la DST
11199	11168	Gilliam Terry	
11200	11168	Gilligan John	
11201	11168	Gillot Dominique	
11202	11168	Gilone Brune	metteur en scène
11203	11168	Gilot Françoise	
11204	11168	Gilou Thomas	
11205	11168	Ginette Sainderichin	
11206	11168	Gingrich Newt	
11207	11168	Ginisty Bernard	
11208	11168	Ginola David	
11209	11168	Ginsberg Allen	romancier anglais
11210	11168	Ginzburg Carlo	
11211	11168	Ginzburg Milton Moses	
11212	11168	Giocante Vahina	
11213	11168	Giono Jean	écrivain
11214	11168	Giordano Isabelle	
11215	11168	Giorgi Jean-Pierre	
11216	11168	Giorgione	
11217	11168	Giotto	
11218	11168	Giovanni Borsato	
11219	11168	Giovanni Cannizzo	perssonnage de la mafia catanaise
11220	11168	Giovanni Gentile	ministre italien de Mussolini, philosophe et assassiné par la Résistance en 1944
11221	11168	Giovanni Morelli	critique italien de peinture (1816/1891)
11222	11168	Giovannoni Jean-Louis	
11223	11168	Gipsy Kings	groupe de flamenco-rock
11349	11270	Gouteyron Adrien	senateur RPR
11224	11168	Girard Bernard	consultant en organisation d'entreprises
11225	11168	Girard Christophe	Secrétaire général d'Yves Saint-Laurent et d'Ensemble contre le sida
11226	11168	Girard Dominique	
11227	11168	Girardin Brigitte	
11228	11168	Girardot Annie	
11229	11168	Giraud Michel	Ministre du travail en 1994/1995
11230	11168	Giraudoux Jean	
11231	11168	Girault Noël	
11232	11168	Girel Gérard	
11233	11168	Giresse Alain	directeur technique du Toulouse football club
11234	11168	Girls Against Boys	
11235	11168	Giron Sylvie	
11236	11168	Gironès Claudine	
11237	11168	Giroud Françoise	
11238	11168	Giroux André	
11239	11168	Giscard d'Estaing Charles	neveu de VGE et mouillé dans l'affaire Botton
11240	11168	Giscard d'Estaing Olivier	
11241	11168	Giscard d'Estaing Valéry	
11242	11168	Gisserot Hélène	
11243	11168	Gisèle Escourrou	climatologue de la pollution
11244	11168	Gisèle Gelbert	neurologue/aphasiologue
11245	11168	Gisèle Halimi	
11246	11168	Gitaï Amos	
11247	11168	Giuily Eric	
11248	11168	Giuliani Jean-Dominique	
11249	11168	Giuliani Rudolph	
11250	11168	Giulietta Masina	actrice italienne
11251	11168	Giuseppe Garibaldi	résistant italien
11252	11168	Giustiniani Josua	
11253	11168	Givenchy Hubert de	
11254	11168	Gizenga Antoine	
11255	10956	ZZZZ_Personnalités GL	
11256	11255	Glandier Bernard	
11257	11255	Glass Philip	
11258	11255	Glavany Jean	secrétaire national du PS à la communication
11259	11255	Gleb Yakounine	Prêtre orthodoxe russe
11260	11255	Glemp Jozef	
11261	11255	Glen Marla	
11262	11255	Glenn Gould	
11263	11255	Gligorov Kiro	
11264	11255	Glissant Edouard	
11265	11255	Glover Savion	
11266	11255	Glucksmann André	
11267	11255	Gluckstein Daniel	
11268	11255	Glueck Alois	
11269	10956	ZZZZ_Personnalités GN	
11270	10956	ZZZZ_Personnalités GO	
11271	11270	Go Chok Tong	
11272	11270	Goasguen Claude	
11273	11270	Goblot Jean-Jacques	
11274	11270	Godard Christian	
11275	11270	Godard Jean-Luc	
11276	11270	Godderidge Philippe	
11277	11270	Godement François	François Godement est maître de recherche à l'Institut français des relations internationales (Ifri).
11278	11270	Godet Michel	prof au Conservatoire National des Arts et Métiers
11279	11270	Godfrain Jacques	
11280	11270	Godino Roger	Roger Godino est ancien doyen de l'Insead, ex-conseiller auprès de Michel Rocard à Matignon et secrétaire général du Centre international Pierre Mendès France pour l'étude des mutations.
11281	11270	Godounov Alexandre	
11282	11270	Godtfred Kirk Christiansen	
11283	11270	Goebbels Heiner	
11284	11270	Goethe Johann Wolfgang Von	
11285	11270	Goetschel Roland	
11286	11270	Goeudevert Daniel	
11287	11270	Goitschel Marielle	
11288	11270	Gokaltay Turan	journaliste Turc
11289	11270	Goldberg Whoopi	
11290	11270	Goldenberg Jorge	
11291	11270	Goldfarb Lucienne	
11292	11270	Goldhagen Daniel Jonah	
11293	11270	Goldin Nan	
11294	11270	Golding Mike	
11295	11270	Goldman Jean-Jacques	chanteur musico
11296	11270	Goldman Pierre	
11297	11270	Goldman Sachs	
11298	11270	Goldoni Carlo	
11299	11270	Goldsmith James	
11300	11270	Goldsmith Jemima	fille de Jimmy Goldsmith
11301	11270	Goldsworthy Andy	
11302	11270	Gollnisch Bruno	secrétaire général du Front national
11303	11270	Golmard Jérôme	joueur de tennis Français
11304	11270	Golon Anne	
11305	11270	Gombrowicz Witold	
11306	11270	Gomes Flora	
11307	11270	Gomez Alain	patron de Thomson-CSF
11308	11270	Gomez Geneviève	
11309	11270	Gomez Michel	
11310	11270	Gomez Ortega José	
11311	11270	Gomez Pena	
11312	11270	Goncourt Edmond et Jules	
11313	11270	Gondi Paul de	
11314	11270	Gonnot François-Michel	
11315	11270	Gontchar Viktor	
11316	11270	Gontcharova Nathalie S.	peintre
11317	11270	Gonzalez Felipe	
11318	11270	Gonzalez-Torres Felix	
11319	11270	Goossens Daniel	
11320	11270	Gorbatchev Mikhaïl	
11321	11270	Gordimer Nadine	
11322	11270	Gordin Jacob	
11323	11270	Gordon Hinckley	Président de l'église mormone
11324	11270	Gordon Thomas	Ecrivain britanique
11325	11270	Gorris Marleen	
11326	11270	Gorse Georges	
11327	11270	Gorz André	
11328	11270	Gos Jean-Claude	
11329	11270	Goscinny René	
11330	11270	Goss Pete	
11331	11270	Goss Porter	
11332	11270	Got Claude	
11333	11270	Gothar Peter	
11334	11270	Gotlib Marcel	
11335	11270	Gotscho	
11336	11270	Gotzev Vassil	
11337	11270	Goude Jean-Paul	
11338	11270	Goulaine Robert de	
11339	11270	Goupil Romain	
11340	11270	Gour Batya	
11341	11270	Gouraud Jean-Louis	
11342	11270	Gourdault-Montagne Maurice	
11343	11270	Gourmet Olivier	
11344	11270	Gourvennec Jocelyn	Foot
11345	11270	Gousseau Maurice	
11346	11270	Goussinski Vladimir	
11347	11270	Goustat André	Président du mouvement de chasseurs CPNT
11348	11270	Goutard Noël	
11350	11270	Gouyon Jean-Luc	
11351	11270	Gouyou-Beauchamps Xavier	
11352	11270	Gowda Deve	
11353	11270	Goya Francisco de	peintre
11354	11270	Goyard Philippe	
11355	11270	Goyette Patrick	
11356	11270	Goytisolo Juan	
11357	11270	Göncz Arpad	
11358	10956	ZZZZ_Personnalités GR	
11359	11358	Grabbe Christian Dietrich	
11360	11358	Graeme Obree	champion cycliste
11361	11358	Graf Jurgen	
11362	11358	Graf Steffi	
11363	11358	Graham Larry	
11364	11358	Graham Martha	
11365	11358	Graham Paul	
11366	11358	Graham Rodney	
11367	11358	Grainville Patrick	
11368	11358	Gramm Phil	
11369	11358	Gramsci Antonio	
11370	11358	Grand Alain-Michel	
11371	11358	Grand Amélie	directrice festival de danse : Les Hivernales
11372	11358	Grandperret Patrick	
11373	11358	Grandville Camille	
11374	11358	Grandville Olivia	
11375	11358	Granié Bernard	
11376	11358	Grass Günter	
11377	11358	Grasset Alain	
11378	11358	Grateful Dead	
11379	11358	Gratien-Marin Patrick	
11380	11358	Gratton Jean	
11381	11358	Gravel Robert	
11382	11358	Gravelaine Xavier	
11383	11358	Gray Martin	
11384	11358	Gray Peter	
11385	11358	Graziani Paul	
11386	11358	Grazyna Pawlak	
11387	11358	Greef Alain de	
11388	11358	Green Julien	écrivain
11389	11358	Green Pauline	
11390	11358	Greenaway Peter	
11391	11358	Greene Graham	
11392	11358	Greene Maurice	
11393	11358	Greenspan Alan	président de la Fed
11394	11358	Greg Louganis	plongeur
11395	11358	Greg Taylor	sculpteur australien
11396	11358	Greggory Pascal	
11397	11358	Gremetz Maxime	
11398	11358	Griaule Marcel	
11399	11358	Grier Pamela	
11400	11358	Griffith D.W.	
11401	11358	Griffith-Joyner Florence	
11402	11358	Grigely Joseph	
11403	11358	Grigori Medvedev	ingénieur atomiste irradié en 1986 et auteur de plusieurs livres sur Tchernobyl
11404	11358	Grimaldi Stéphanie	
11405	11358	Grimault Hubert	
11406	11358	Grimault Paul	
11407	11358	Grimblat Pierre	
11408	11358	Grimfeld Alain	médecine
11409	11358	Grimm	auteur de contes peut-être pour enfants
11410	11358	Grinberg Anouk	
11411	11358	Griotteray Alain	
11412	11358	Grippo Victor	
11413	11358	Griscelli Claude	
11414	11358	Grisham John	
11415	11358	Grmek Mirko	généticien , historien de la médecine
11416	11358	Grobbelaar Bruce	
11417	11358	Grohl David	
11418	11358	Groot Bob de	
11419	11358	Grooteclaes Hubert	
11420	11358	Grosbard Ulu	
11421	11358	Grosdidier François	député chiraquien
11422	11358	Grosjean Sébastien	
11423	11358	Grosos Gérard	
11424	11358	Gross Gilbert	
11425	11358	Grosser Alfred	
11426	11358	Grossman David	
11427	11358	Grossouvre François de	
11428	11358	Grothendieck Alexandre	mathématicien
11429	11358	Grotowski Jerzy	
11430	11358	Groult Benoîte	
11431	11358	Grove Andy	PdG d'Intel
11432	11358	Grubbe Peter	
11433	11358	Grumbach Antoine	
11434	11358	Grunberg Serge	
11435	11358	Gruninger Paul	
11436	11358	Gruss Alexis	
11437	11358	Grèce Constantin de	
11438	11358	Grémillon Jean	réalisateur cinéma
11439	11358	Gréville Edmond T.	
11440	11358	Grüber Klaus Michael	
11441	10956	ZZZZ_Personnalités GU	
11442	11441	Guaino Henri	commissaire au Plan france
11443	11441	Guattari Félix	
11444	11441	Guazzelli Jean-Claude	
11445	11441	Gubern Roman	
11446	11441	Gubler Claude	
11447	11441	Gudin Claude	biologiste
11448	11441	Guediguian Robert	
11449	11441	Gueirard Pierre	
11450	11441	Guelfi André	
11451	11441	Gueneron Hervé	
11452	11441	Guerin Veronica	
11453	11441	Guerini Jean-Noêl	
11454	11441	Guerman Alexeï	
11455	11441	Guerrin Jean	
11456	11441	Guerrini Alain	Diffuseur de l'enseignement musical
11457	11441	Guetta Bernard	
11458	11441	Guevara Ernesto	
11459	11441	Gueï Robert	
11460	11441	Gueïdar Aliev	président de l'Azerbaïdjan
11461	11441	Guibert Géraud	
11462	11441	Guibert Hervé	
11463	11441	Guibert Noëlle	
11464	11441	Guichard Antoine	
11465	11441	Guichard Olivier	
11466	11441	Guichard Roger	
11467	11441	Guichardin François	
11468	11441	Guichet Pierre	
11469	11441	Guidicelli Jean-Claude	avocat/affaire Yann Piat
11470	11441	Guidoni Jean	
11471	11441	Guidoni Pierre	ex-ambassadeur de France en Espagne
11472	11441	Guignols de l'info	
11473	11441	Guigou Elisabeth	
11474	11441	Guigou Jean-Louis	
11475	11441	Guilaine Jean	Jean Guilaine, professeur au Collège de France
11476	11441	Guilhaumon Jean-Louis	
11477	11441	Guillarme Bertrand	
11478	11441	Guillaume Alexandre	
11479	11441	Guillaume François	
11480	11441	Guillaume Vincent	réalisateur
11481	11441	Guillaume Wolf	graphiste-illustrateur
11482	11441	Guillebaud Jean-Claude	
11483	11441	Guillem Sylvie	
11484	11441	Guillen Pierre	
11485	11441	Guillermo Ossandon	dirigeant du groupe armé Lautaro au Chili
11486	11441	Guillet Jean-Jacques	
11487	11441	Guillon Claude	
11488	11441	Guilloux Louis	
11489	11441	Guimaraes Manoel	
11490	11441	Guimaraes Rosa Joao	
11491	11441	Guimard Cyrille	
11492	11441	Guimard Paul	
11493	11441	Guinness Alec	
11494	11441	Guinot François	
11495	11441	Guitry Sacha	
11496	11441	Guittier Marief	
11497	11441	Guitton Jean	
11498	11441	Guivarc'h Stéphane	
11499	11441	Gulbuddin Hekmatyar	
11500	11441	Gunther Parche	agresseur de Monica Seles
11501	11441	Guralnick Peter	
11502	11441	Gurlitt Manfred	
11503	11441	Gusmao Xanana	
11504	11441	Guston Philip	
11505	11441	Guterres Antonio	
11506	11441	Gutierrez Alea Tomas	Cinéaste
11507	11441	Gutmann Francis	
11508	11441	Guy Accoceberry	rugbyman
11509	11441	Guy Scherrer	dirigeant du club de fott de Nantes, le FC Nantes , et PdG de la Biscuiterie Nantaise (BN)
11510	11441	Guyard Jacques	
11511	11441	Guyau Luc	président de le FNSEA
11512	11441	Guéant Claude	
11513	11441	Guérin Vincent	Footballeur
11514	11441	Guézou Pierre-Yves	capitaine de la cellule antiterroriste de l'Elysée
11515	11441	Güney Yilmaz	cinéaste turc décédé à Paris en 1984
11516	11441	Günter Deckert	chef des néo-nazis allemands
11517	11441	Günter Guillaume	espion/ex-RDA
11518	11441	Günter Wallraff	écrivain allemand
11519	11441	Günther Mader	skieur
11520	10956	ZZZZ_Personnalités GY	
11521	11520	Gyllenhammar Pehr	
11522	11520	Gyula Horn	
11523	11520	Gyurcsany Ferenc	
11524	7428	ZZZZ_Personnalités H	
11525	11524	ZZZZ_Personnalités HA	
11526	11525	Haas Pavel	
11527	11525	Haas Philippe	
11528	11525	Haberer Jean-Yves	
11529	11525	Habermas Jürgen	
11530	11525	Habibi Emile	
11531	11525	Habibie Yusuf	
11532	11525	Habrioux Marc	
11533	11525	Habré Hissène	
11534	11525	Habsbourg (famille)	
11535	11525	Haby Jean-Yves	
11536	11525	Habyarimana Juvénal	pdt. du Rwanda tué le 06/04/94
11537	11525	Hachani Abdelkader	FIS
11538	11525	Hachemi Chérif	
11539	11525	Hacker Andrew	
11540	11525	Haddad Mezri	Chercheur en philosophie morale et politique et Directeur du mensuel La Voix de l'audace
11541	11525	Haddam Anouar	
11542	11525	Hadeln Moritz de	
11543	11525	Haden Josh	
11544	11525	Hadid Zaha	
11545	11525	Hadida Samuel	
11546	11525	Haendel Georg Friedrich	musique
11547	11525	Haenel Hubert	
11548	11525	Hafsa Zinaï Koudil	Réalisatrice algérienne
11549	11525	Hagman Larry	
11550	11525	Hague William	
11551	11525	Haider Jörg	
11552	11525	Haigneré Claudie	
11553	11525	Hain Guy	
11554	11525	Haines Luke	
11555	11525	Hajdenberg Henri	
11556	11525	Hakan Hardenberger	
11557	11525	Hakeem Olajuwon	joueur NBA de basket-ball américain
11558	11525	Hakim Adel	
11559	11525	Hakkar Abdelhamid	
11560	11525	Hakkinen Mika	
11561	11525	Halard Julie	tennis woman
11562	11525	Halberstadt Michèle	
11563	11525	Halberstam David	
11564	11525	Haleb Christophe	
11565	11525	Half Japanese	
11566	11525	Hallais Jean-Pierre	promoteur immobilier
11567	11525	Hallet-Eghayan Michel	
11568	11525	Halley Paul-Louis	
11569	11525	Hallier Jean-Edern	
11570	11525	Hallin Jean-François	
11571	11525	Hallyday Johnny	
11572	11525	Halonen Tarja	
11573	11525	Halphen Eric	
11574	11525	Halter Marek	
11575	11525	Halvor Moxnes	professeur en théologie et homosexuel norvégien
11576	11525	Hamaide Chantal	
11577	11525	Hamdani Smaïl	
11578	11525	Hamel Gérard	
11579	11525	Hamidi Youcef	
11580	11525	Hamilton Chico	
11581	11525	Hammami Hamma	
11582	11525	Hammel Francis	
11583	11525	Hammett Samuel Dashiell	romancier américain
11584	11525	Hamoutène Frank	
11585	11525	Hampton Christopher	
11586	11525	Hampâté Bâ Amadou	
11587	11525	Hamsun Knut	
11588	11525	Han Dongfang	
11589	11525	Hancock Herbie	
11590	11525	Handke Peter	écrivain
11591	11525	Haneke Michael	
11592	11525	Hanin Roger	
11593	11525	Haniyeh Ismaïl	 
11594	11525	Hanks Tom	acteur américain
11595	11525	Hannah Barry	
11596	11525	Hannes Vogel	généticien
11597	11525	Hanno Harnisch	porte-parole du PDS
11598	11525	Hannoun Michel	
11599	11525	Hanot Jean	Adjoint à la sécurité dans la ville de Nice
11600	11525	Hanoun Louisa	
11601	11525	Hans Fricke	scientifique et cinéaste naturaliste
11602	11525	Hans Hermann Groer	cardinal-archevêque de Vienne
11603	11525	Hans Hollein	architecte
11604	11525	Hans Werner Kilz	
11605	11525	Hansenne Hubert	
11606	11525	Hansjoerg Derx	
11607	11525	Harang Bernard	
11608	11525	Harari Simone	
11609	11525	Harding Tonya	
11610	11525	Hardot Pierre	
11611	11525	Hardy Françoise	
11612	11525	Hardy Oliver	
11613	11525	Hardy René	
11614	11525	Hardy Thomas	
11615	11525	Harel Philippe	
11616	11525	Harfaux Arthur	
11617	11525	Harfouch Corinna	
11618	11525	Haring Keith	
11619	11525	Hariri Rafic	ministre libanais
11620	11525	Hariri Saad	
11621	11525	Haris Silajdzic	
11622	11525	Harlem Désir	
11623	11525	Harlin Renny	
11624	11525	Harms Daniil	
11625	11525	Harnoncourt Nikolaus	
11626	11525	Haroun Tazieff	
11627	11525	Harper Ben	
11628	11525	Harper Stephen	 
11629	11525	Harpman Jacqueline	
11630	11525	Harriman George	
11631	11525	Harriman Pamela	
11632	11525	Harris Eddie	
11633	11525	Harris George	
11634	11525	Harris James B.	
11635	11525	Harris Robert	
11636	11525	Harrison George	
11637	11525	Harrison Jim	écrivain américain
11638	11525	Harrison Matthew	
11639	11525	Harrisson Matthew	
11640	11525	Harron Mary	
11641	11525	Harry Deborah	
11642	11525	Harry Dent	
11643	11525	Harry Mitchell	coureur du BOC challenge porté disparu
11644	11525	Hart Ian	
11645	11525	Hart Steve	
11646	11525	Hartley Hal	
11647	11525	Harvey Brian	
11648	11525	Harvey C. Mansfield Jr	
11649	11525	Harvey Polly Jean	
11650	11525	Has Wojciech	
11651	11525	Hascoët Guy	
11652	11525	Hashimoto Ryutaro	
11653	11525	Haskell Francis	
11654	11525	Hass Karl	
11655	11525	Hassan Hussein Kamel	
11656	11525	Hassan II	
11657	11525	Hassan Laaraj	
11658	11525	Hassan Tourabi	leader soudanais
11659	11525	Hassan al-Bolkiah Muizzaddin Waddaulah	
11660	11525	Hassan al-Tourabi	
11661	11525	Hassner Pierre	
11662	11525	Hatem Fabrice	économiste
11663	11525	Hathaway Henry	cinéaste
11664	11525	Hatzfeld Jean	journaliste Libé
11665	11525	Haudepin Didier	
11666	11525	Haussmann	
11667	11525	Haut Claude	
11668	11525	Haut Gérard	
11669	11525	Havel Vaclav	
11670	11525	Hawatmeh Nayef	
11671	11525	Hawking Stephen	
11672	11525	Hawks Howard	cinéaste hollywoodien
11673	11525	Hawthorne Nigel	
11674	11525	Hayat Jean-Michel	
11675	11525	Hayden Bill	
11676	11525	Hayek Nicolas	
11677	11525	Hayek Salma	
11678	11525	Hayes Isaac	
11679	11525	Haynes Graham	
11680	11525	Haynes Todd	
11681	11525	Hazan Adeline	
11682	11525	Hazera Hélène	pigiste Libé
11683	11525	Haïm Cohen	pédiatre de la crèche de l'Elysée
11684	11525	Häni Hanspeter	
11685	11525	Hänsch Klaus	personnalité
11686	11525	Hänsel Marion	
11687	11524	ZZZZ_Personnalités HE	
11688	11687	He Ping	
11689	11687	Heaney Seamus	
11690	11687	Heaulme Francis	criminel
11691	11687	Hector Rolland	ancien député gaulliste
11692	11687	Hees Jean-Luc	
11693	11687	Hegel Georg Wilhelm Friedrich	
11694	11687	Heidegger Martin	
11695	11687	Hein Christoph	
11696	11687	Heine Henri	
11697	11687	Heinrich Jean	
11698	11687	Heinz Kinigardner	motocross
11699	11687	Heisbourg François	François Heisbourg est président du Comité français de l'Institut international d'études stratégiques (IISS).
11700	11687	Helen Terry	
11701	11687	Hella S. Haasse	Romancière hollandaise
11702	11687	Helmer Jean-Yves	
11703	11687	Hemingway Ernest	Ecrivain américain.
11704	11687	Hemleb Lukas	
11705	11687	Henderson Douglas	
11706	11687	Henderson Ian	Britannique, il est directeur des services secrets de Bahrein (émirat) depuis 1970.
11707	11687	Henderson Joseph	
11708	11687	Hendricks John S.	
11709	11687	Hendrik Dreekmann	tennisman
11710	11687	Hendrix Jimi	
11711	11687	Henin Jean-Francois	
11712	11687	Henk Prins	Médecin Néerlandais
11713	11687	Hennezel Marie de	
11714	11687	Hennig Jean-Luc	
11715	11687	Henrard Jacques	
11716	11687	Henri Benguigui	
11717	11687	Henri Bourguinat	Economiste et prof à Bordeaux
11718	11687	Henri Brigitte	
11719	11687	Henri De Bodinat	Directeur de la stratégie et du marketing du Club Méditerranée
11720	11687	Henri Dedon	
11721	11687	Henri Denis	
11722	11687	Henri Ducloux	cuisinier
11723	11687	Henri Gault	
11724	11687	Henri Ghéon	poète
11725	11687	Henri Godard	écrivain
11726	11687	Henri Guérin	ex-entraîneur des Bleus
11727	11687	Henri IV	
11728	11687	Henri Stambouli	entraîneur de l'OM
11729	11687	Henri-Albert Jacques	
11730	11687	Henri-Jean Jacomet	
11731	11687	Henri-Paul Puel	
11732	11687	Henrion Roger	
11733	11687	Henrot Francois	
11734	11687	Henry Foster	gynécologue américain, coordonne les politiques de santé publique
11735	11687	Henry Judith	
11736	11687	Henry Loaeza	
11737	11687	Henry Patrick	
11738	11687	Henry Pierre	
11739	11687	Henry Thierry	
11740	11687	Henry Wolf	maire sortant UDF de Meudon
11741	11687	Hepburn Katharine	
11742	11687	Herbillon Michel	maire UDF de Maisons Alfort
11743	11687	Hergé	
11744	11687	Herman J. Mankiewicz	scénariste américain
11745	11687	Hermange Marie-Thérèse	
11746	11687	Hermanville Elisabeth	
11747	11687	Hermier Guy	
11748	11687	Hermlin Stephan	
11749	11687	Hermon Michel	
11750	11687	Hernandez Felisberto	
11751	11687	Hernu Charles	
11752	11687	Hernu Patrice	
11753	11687	Herr Patrick	
11754	11687	Herr Stéphane	enseignant en Sciences Sociales
11755	11687	Herreweghe Philippe	
11756	11687	Herriman George	
11757	11687	Hersant Philippe	
11758	11687	Hersant Robert	
11759	11687	Hertzog Gilles	membre du comité de rédaction de La règle du jeu
11760	11687	Hervieu Bertrand	sociologue
11761	11687	Hervieu Dominique	
11762	11687	Hervé Alain	auteur d'une étude et d'un livre sur les palmiers
11763	11687	Hervé André	Maire RPR d'Arpajon
11764	11687	Hervé Diasnas	chorégraphe
11765	11687	Hervé Edmond	maire PS de Rennes et ancien ministre
11766	11687	Hervé Godignon	cavalier équestre
11767	11687	Hervé Le Pichon	
11768	11687	Herzl Theodor	
11769	11687	Herzog Chaim	
11770	11687	Herzog Jacques	
11771	11687	Herzog Maurice	
11772	11687	Herzog Philippe	
11773	11687	Herzog Roman	Président de la république d'Allemagne
11774	11687	Herzog Werner	
11775	11687	Heschung Christian	
11776	11687	Heseltine Michael	
11777	11687	Hess Rudolph	
11778	11687	Hesse Hermann	
11779	11687	Hessel Stéphane	
11780	11687	Heston Charlton	acteur américain
11781	11687	Heuclin Jacques	
11782	11687	Heumann Eric	
11783	11687	Heuvelmans Bernard	
11784	11687	Hewitt Lleyton	
11785	11687	Heydorf Michèle	
11786	11687	Heym Stefan	
11787	11687	Heynnemann Laurent	
11788	11687	Hélène Delebecque	
11789	11687	hedayat sadegh	
11790	11524	ZZZZ_Personnalités HI	
11791	11790	Hidalgo Anne	
11792	11790	Hidalgo Michel	
11793	11790	Hideo Murai	N°2 de la secte Aum
11794	11790	Hidouci Ghazi	
11795	11790	Higelin Jacques	
11796	11790	Higgins Clark Mary	
11797	11790	High Llamas	
11798	11790	Highsmith Patricia	
11799	11790	Hikmet Nazim	
11800	11790	Hilaire Michel	conservateur du Musée Fabre à Montpellier
11801	11790	Hilberg Raul	
11802	11790	Hilda Muir	Aborigène
11803	11790	Hill Christopher	
11804	11790	Hill Damon	pilote de F1
11805	11790	Hill Gary	
11806	11790	Hill Jack	
11807	11790	Hillaire Norbert	critique d'art
11808	11790	Hinault Bernard	
11809	11790	Hindemith Paul	
11810	11790	Hines Gerald	
11811	11790	Hingis Martina	
11812	11790	Hintze Peter	
11813	11790	Hiroshi Nakajima	directeur général de l'OMS
11814	11790	Hirsch Georges-François	
11815	11790	Hirsch Martin	
11816	11790	Hirschfeld Ariel	
11817	11790	Hirschhorn Thomas	
11818	11790	Hirst Damien	
11819	11790	Hislaire Bernard	
11820	11790	Hitchcock Alfred	
11821	11790	Hitler Adolf	
11822	11524	ZZZZ_Personnalités HO	
11823	11822	Ho David	
11824	11822	Ho Yim	
11825	11822	Hoang-Ngoc Liêm	économiste
11826	11822	Hobbes Thomas	
11827	11822	Hockney David	
11828	11822	Hocquart Jean-Jacques	
11829	11822	Hocquenghem Guy	
11830	11822	Hodginou Djombol	
11831	11822	Hodgins Jack	
11832	11822	Hoeffel Daniel	
11833	11822	Hoeg Peter	
11834	11822	Hoffman Dustin	
11835	11822	Hogarth Burne	
11836	11822	Hoghe Raimund	
11837	11822	Holbrooke Richard	
11838	11822	Holder Eric	
11839	11822	Hole	groupe de rock de Courtney Love
11840	11822	Holeindre Roger	
11841	11822	Holiday Billie	
11842	11822	Holland Agnieszka	
11843	11822	Holland Merlin	
11844	11822	Hollande François	PS et mari de Ségolène Royal
11845	11822	Holmes Sherlock	
11846	11822	Holtz Gérard	
11847	11822	Holyfield Evander	boxeur, ancien champion du monde, catégorie Lourds
11848	11822	Holzman Marie	journaliste/écrivain
11849	11822	Homolka Karla	
11850	11822	Homère	
11851	11822	Honda Inoshiro	
11852	11822	Hong Song-Nam	
11853	11822	Hopkins Anthony	
11854	11822	Hoppe Marianne	
11855	11822	Hopper Dennis	
11856	11822	Hopper Edward	
11857	11822	Horace Silver	musicien de jazz
11858	11822	Horackova Bojena	
11859	11822	Horn Rebecca	
11860	11822	Horst Siebert	Président de l'institut de l'économie mondiale de Kiel
11861	11822	Horta Rui	
11862	11822	Hortefeux Brice	 
11863	11822	Horville Josyane	
11864	11822	Hory Jean-François	
11865	11822	Hoskins Bob	
11866	11822	Hossein Robert	
11867	11822	Hossien Yasdan-Seta	
11868	11822	Hostalier Françoise	
11869	11822	Hou Hsiao-Hsien	
11870	11822	Houellebecq Michel	
11871	11822	Houillon Philippe	
11872	11822	Houllebecq Michel	
11873	11822	Houphouët-Boigny Félix	
11874	11822	Hourcade Bernard	
11875	11822	Hourdin Georges	
11876	11822	Hourdin Jean-Louis	
11877	11822	Houssin Didier	Directeur de l'établissement français des greffes
11878	11822	Houston Anjelica	
11879	11822	Houston Whitney	
12012	12006	Isabelle Quignaux	
11880	11822	Howard Carter	basketteur américain de Pau-Orthez
11881	11822	Howard Collins	rugby (Gallois)
11882	11822	Howard Davies	
11883	11822	Howard John	
11884	11822	Howard Michael	
11885	11822	Howard Ron	
11886	11822	Howarth Alan	
11887	11822	Hoxha Enver	
11888	11822	Hoyer Werner	
11889	11822	Höller Carsten	
11890	11524	ZZZZ_Personnalités HR	
11891	11890	Hrabal Bohumil	
11892	11890	Hraoui Elias	Président du Liban
11893	11524	ZZZZ_Personnalités HU	
11894	11893	Hu Jintao	
11895	11893	Huang George	
11896	11893	Huang Yong Ping	
11897	11893	Hubert Bals	créateur du festival de cinéma de Rotterdam
11898	11893	Hubert Elisabeth	Ministre de la Santé 1er gouvernement Chirac
11899	11893	Hubert Flahaut	nouveau président du tribunal de commerce de Paris
11900	11893	Hubert Knapp	réalisateur TV
11901	11893	Hubert Laetitia	
11902	11893	Huchon Jean-Paul	
11903	11893	Huddleston Trevor	
11904	11893	Hue Robert	
11905	11893	Hugh Grant	
11906	11893	Hughes Ted	
11907	11893	Hugo Victor	
11908	11893	Hugues Beauzile	alpiniste
11909	11893	Huguier Françoise	
11910	11893	Huillet Danièle	
11911	11893	Hulme Keri	
11912	11893	Hulot Nicolas	
11913	11893	Hulsker Jan	
11914	11893	Humbert Jean-François	
11915	11893	Hume John	initiateur du processus de paix en Irlande du Nord
11916	11893	Humperdinck Engelbert	
11917	11893	Hun Sen	
11918	11893	Hunebelle André	
11919	11893	Hunter Holly	
11920	11893	Huntington Samuel	
11921	11893	Huppert Isabelle	
11922	11893	Hurand Henri	
11923	11893	Hureau Serge	metteur en scène de théâtre
11924	11893	Hurley Elizabeth	
11925	11893	Hurt William	
11926	11893	Hurteau Gilles	
11927	11893	Hussein Adel	écrivain égytpien
11928	11893	Hussein Oudaï	fils de Saddam Hussein
11929	11893	Hussein Saddam	dictateur Irakien
11930	11893	Hussein de Jordanie	
11931	11893	Husseini Fayçal	
11932	11893	Husserl Edmund	
11933	11893	Huster Francis	
11934	11893	Huston Anjelica	
11935	11893	Huston John	
11936	11893	Huwart François	
11937	11893	Huy Jean-Marie D'	
11938	11893	Huynh Emmanuelle	
11939	11893	Huèges Danièle	
11940	11524	ZZZZ_Personnalités HW	
11941	11940	Hwang Jang-yop	
11942	11524	ZZZZ_Personnalités HY	
11943	11942	Hybert Fabrice	
11944	11942	Hytner Nicholas	
11945	11942	Hytner Nicolas	
11946	11942	Hyvernat Gilbert	
11947	11942	Hyvernaud Georges	
11948	7428	ZZZZ_Personnalités I	
11949	11948	ZZZZ_Personnalités IA	
11950	11949	IAM	
11951	11949	Ian Smith	
11952	11949	Ian Wright	
11953	11949	Iandarbaïev Zelimkhan	
11954	11949	Iavlinski Grigori	
11955	11948	ZZZZ_Personnalités IB	
11956	11955	Ibargüengoitia Jorge	
11957	11955	Ibrahim al-Takriti Barzan	
11958	11955	Ibsen Henrik	
11959	11948	ZZZZ_Personnalités IC	
11960	11959	Ice T	
11961	11948	ZZZZ_Personnalités ID	
11962	11961	Idigoras Jon	
11963	11961	Idir	Musicien de variété kabyle
11964	11961	Idrac Anne-Marie	
11965	11961	Idriss Déby	
11966	11948	ZZZZ_Personnalités IG	
11967	11966	Iggy Pop	
11968	11966	Iglesias Julio	
11969	11966	Iglésias René	
11970	11966	Igor Minaiev	Cinéaste Ukrainien
11971	11948	ZZZZ_Personnalités IL	
11972	11971	Iliescu Ion	
11973	11971	Illy Ricardo	
11974	11971	Ilya Kulik	patineur sur glace
11975	11971	Ilyouchenko Alexeï	
11976	11948	ZZZZ_Personnalités IM	
11977	11976	Imache Tassadit	écrivain
11978	11976	Imaev Ousmane	
11979	11976	Imaizumi Zenshô	artiste céramiste japonais
11980	11976	Imamura Shohei	
11981	11976	Imbert Claude	
11982	11976	Imbert Henri-François	
11983	11976	Imhaus Patrick	
11984	11976	Imperial Drag	
11985	11948	ZZZZ_Personnalités IN	
11986	11985	Inder Kumar Gujral	Premier ministre indien
11987	11985	Indro Montanelli	journaliste italien
11988	11985	Indurain Miguel	
11989	11985	Indyk Martin	
11990	11985	Ingo Steuer	patineur
11991	11985	Ingvar Carlsson	Premier ministe suédois
11992	11985	Inonu Erdal	Ministre des affaires étrangères du gouvernement turc
11993	11948	ZZZZ_Personnalités IO	
11994	11993	Ionesco Eugène	
11995	11993	Ionesco Marie-France	
11996	11993	Iosseliani Djaba	
11997	11993	Iosseliani Otar	
11998	11993	Iouchtchenko Victor	
11999	11948	ZZZZ_Personnalités IR	
12000	11999	Irene Pivetti	présidente de la Chambre des députés italienne
12001	11999	Irigaray Luce	
12002	11999	Irina Privalova	athlète russe
12003	11999	Irons Jeremy	
12004	11999	Irving Shulman	
12005	11999	Irène Frain	
12006	11948	ZZZZ_Personnalités IS	
12007	12006	Isaak Chris	,
12008	12006	Isabelle Bouillot	Numéro 2 de la Caisse des dépôts et consignations.
12009	12006	Isabelle Duluc-Bizoi	chercheuse scientifique
12010	12006	Isabelle Jeanneret	
12011	12006	Isabelle Laffont	
12013	12006	Isabet Jacques	
12014	12006	Iselin Nassima	
12015	12006	Islam Morshedul	
12016	12006	Ismaël Kirui	coureur
12017	12006	Israël Jean-Paul	
12018	12006	Issa Ben Salmane al-Khalifa	
12019	12006	Issorat Claude	sport
12020	12006	Istvan Kiszely	Ethnologue budapestois
12021	11948	ZZZZ_Personnalités IT	
12022	12021	Itamar Franco	politique brésilien
12023	12021	Ito Lance	
12024	11948	ZZZZ_Personnalités IV	
12025	12024	Ivanisevic Goran	
12026	12024	Ivens Joris	
12027	12024	Ivory James	
12028	11948	ZZZZ_Personnalités IZ	
12029	12028	Izard Jean	
12030	12028	Izetbegovic Alija	
12031	12028	Izzi Eugene	
12032	7428	ZZZZ_Personnalités J	
12033	12032	ZZZZ_Personnalités JA	
12034	12033	Jabra Ibrahim Jabra	
12035	12033	Jack Lane	directeur du MoMA
12036	12033	Jack Wolfman	
12037	12033	Jackson Colin	athlète anglais
12038	12033	Jackson Janet	
12039	12033	Jackson Jesse	
12040	12033	Jackson Joe	
12041	12033	Jackson Michael (chanteur)	
12042	12033	Jackson Michael (général)	
12043	12033	Jackson Samuel L.	
12044	12033	Jacob Baal-Teshuva	écrivain
12045	12033	Jacob Catherine	
12046	12033	Jacob Christian	
12047	12033	Jacob François	
12048	12033	Jacob Gilles	
12049	12033	Jacob Max	poète
12050	12033	Jacob Yvon	
12051	12033	Jacobs David	
12052	12033	Jacobs Edgar-Pierre	
12053	12033	Jacopo Carucci	
12054	12033	Jacq Christian	
12055	12033	Jacquard Albert	
12056	12033	Jacque Olivier	moto
12057	12033	Jacqueline Martin	handicapée
12058	12033	Jacqueline Meyson	juge d'instruction à la section financière du tribunal de Paris
12059	12033	Jacqueline Schalit	Rédactrice en chef du Reader's Digest Paris
12060	12033	Jacqueline Thome-Patenôtre	maire de Rambouillet pendant 36 ans, ancien ministre
12061	12033	Jacques Brigitte	
12062	12033	Jacquet Aimé	
12063	12033	Jacquot André	Secrétaire départemental du Front National dans le Doubs
12064	12033	Jacquot Benoît	
12065	12033	Jaffré Jérôme	sondeur en chef de la Sofrès
12066	12033	Jaffré Philippe	Pdg du groupe Elf Aquitaine
12067	12033	Jagamarra Malcolm	
12068	12033	Jagger Mick	
12069	12033	Jagland Thorbjoern	
12070	12033	Jahnn Hans Henny	
12071	12033	Jake Shillingford	meneur de My life story
12072	12033	Jakubowicz Alain	
12073	12033	Jalabert Laurent	coureur cycliste
12074	12033	Jalili Abolfazl	
12075	12033	Jamal Ahmad	
12076	12033	James Henry	écrivain britannique
12077	12033	James Phyllis Daphné	
12078	12033	Jan Bauch	Peintre et sculpteur tchèque
12079	12033	Jan Guillou	
12080	12033	Jan Videnov	
12081	12033	Janacek Leos	
12082	12033	Jane Lagier	réalisatrice de documentaires
12083	12033	Jane Ryder	
12084	12033	Janetti Maurice	
12085	12033	Janicot Christian	
12086	12033	Jankelevitch Vladimir	
12087	12033	Jankovski Henryk	Ancien aumônier de Solidarité (Pologne).
12088	12033	Jankowski Henryck	
12089	12033	Janna Wenner	fondateur du magazine "Rolling Stones"
12090	12033	Janowski Kris	
12091	12033	Januz Bryczkowski	milliardaire polonais
12092	12033	Janvier Afrika	"repenti" du génocide rwandais
12093	12033	Janvier Bernard	
12094	12033	Jaoui Agnès	
12095	12033	Jaoul Belisa	
12096	12033	Japhet N'Doram	Joueur de football
12097	12033	Jaque Christian	Réalisateur
12098	12033	Jaques Brigitte	metteur en scène/théâtre
12099	12033	Jardin Alexandre	
12100	12033	Jardin Pascal	Ecrivain.
12101	12033	Jarman Derek	
12102	12033	Jarmusch Jim	
12103	12033	Jarre Jean-Michel	
12104	12033	Jarre Maurice	
12105	12033	Jarreau Al	
12106	12033	Jarrett Keith	
12107	12033	Jarry Alfred	
12108	12033	Jaruzelski Wojciech	
12109	12033	Jasjit Singh	Directeur de l'institut de défense de New Delhi
12110	12033	Jaskula Zenon	
12111	12033	Jaspers Karl	
12112	12033	Jaubert Alain	
12113	12033	Jaulin Yannick	
12114	12033	Jaurès Jean	
12115	12033	Javeau Claude	
12116	12033	Javier Castillejo	boxeur
12117	12033	Javier de la Rosa	
12118	12033	Jaworski Philippe	
12119	12033	Jay Gould Stephen	
12120	12033	Jay Michael	
12121	12033	Jayalalitha Jayaram	
12122	12033	Jayle Didier	
12123	12033	Jazouli Adil	directeur de Banlieuscopies
12124	12033	Jaïbi Fadhel	
12125	12032	ZZZZ_Personnalités JE	
12126	12125	Jeambar Denis	journaliste du Point,directeur d'Europe 1 (17/07/95)
12127	12125	Jean Amoretti	directeur de cabinet du maire UDF de Jean Bousquet à Nîmes
12128	12125	Jean Azzopardi	maire CDS de la Grand-Combe (Gard)/affaire
12129	12125	Jean Blocquaux	
12130	12125	Jean Boivin	Ecrivain
12131	12125	Jean Bourlès	économiste
12132	12125	Jean Boutier	historien
12133	12125	Jean Hugo	peintre
12134	12125	Jean Itard	médecin ayant observé un enfant "sauvage"
12135	12125	Jean Levi	
12136	12125	Jean Lion	maire socialiste de Meaux
12137	12125	Jean Marin	ancien PdG de l'AFP
12138	12125	Jean Meunier	
12139	12125	Jean Mohr	Photographe
12140	12125	Jean Negulesco	cinéaste américain
12141	12125	Jean Oehler	adjoint au maire de Strasbourg
12142	12125	Jean Philippe	
12143	12125	Jean Robert	
12144	12125	Jean Rosselot	député RPR et chiraquiens
12145	12125	Jean Sagols	réalisateur de série télévisée
12146	12125	Jean Toulat	prêtre , écrivain et journaliste
12147	12125	Jean Tournier-Lasserve	
12148	12125	Jean Ueberschlag	
12149	12125	Jean de Broglie	ancien ministre assassiné le 29 décembre 1979
12150	12125	Jean-André Sulli	retraité de Briey avec un héritage à problèmes
12151	12125	Jean-Baptise Carlotti	
12152	12125	Jean-Charles Thomas	évêque de Versailles
12153	12125	Jean-Christophe Klotz	réalisateur de documentaire pour la télévision
12154	12125	Jean-Clet Martin	Philosophe, spécialiste du monde médiéval.
12155	12125	Jean-Daniel Marzolf	dir.gal. CCI/Paris
12156	12125	Jean-Daniel Rainhorn	directeur du centre de recherche et d'études pour le développement de la santé
12157	12125	Jean-Francis Pasini	chauffeur du poids-lourd qui a tué 9 personnes à Andorre
12158	12125	Jean-Hervé Lorenzi	économiste
12159	12125	Jean-Loup Martin	réalisateur télé
12160	12125	Jean-Loup Trassard	écrivain espagnol
12161	12125	Jean-Luc Delahaye	
12162	12125	Jean-Luc Prévost	réalisateur
12163	12125	Jean-Luc Reichmann	animateur sur France 2
12164	12125	Jean-Marc Bauduin	
12165	12125	Jean-Marc Jourdain	a crée la pomme electronique
12166	12125	Jean-Marc Pinson	responsablde station RATP et philosophe
12167	12125	Jean-Marc Simon	directeur de cabinet (Ministère dela coopération)
12168	12125	Jean-Marie Beckius	tribunal de grande instance de Thionville
12169	12125	Jean-Marie Boimond	
12170	12125	Jean-Marie Bourre	
12171	12125	Jean-Marie Cotteret	
12172	12125	Jean-Marie Kuhn	ex-PdG de Nasa Electronic
12173	12125	Jean-Marie Lhôte	
12174	12125	Jean-Marie Vanlerenberghe	
12175	12125	Jean-Mathieu Michel	
12176	12125	Jean-Maurice Agnelet	affaire/casino
12177	12125	Jean-Michel Boullier	
12178	12125	Jean-Michel Braquet	otage français, assassiné par les Khmers rouges
12179	12125	Jean-Michel Béhar	
12180	12125	Jean-Michel Chappes	réalisateur de documentaires
12181	12125	Jean-Michel Ferri	football/Nantes
12182	12125	Jean-Michel Ripa	président de la société anonyme à objet sportif
12183	12125	Jean-Michel Rollot	chef de cabinet d'Henri Emmanuelli
12184	12125	Jean-Michel Sallmann	professeur d'Histoire moderne à Nanterre et spécialiste de l'Italie et des madones aux larmes
12185	12125	Jean-Noël Tassez	PDG de la Sofirad
12186	12125	Jean-Paul Caverni	
12187	12125	Jean-Paul Figer	
12188	12125	Jean-Paul Guetny	directeur de publication d'un mensuel catholique
12189	12125	Jean-Paul II	
12190	12125	Jean-Paul Marat	
12191	12125	Jean-Paul Schimpf	trésorier occulte de Didier Schuller
12192	12125	Jean-Paul Staub	
12193	12125	Jean-Paul Viguier	
12194	12125	Jean-Paul Virapoullé	député UDF de l'île de la Réunion
12195	12125	Jean-Pierre Thierry	
12196	12125	Jean-Raoul Ismael	
12197	12125	Jean-René Pallacio	beau-frère de Carignon et président d'une association de Grenoble, Spectacles
12198	12125	Jeancourt-Galignani Antoine	
12199	12125	Jeanmaire Zizi	
12200	12125	Jeanpierre Julien	
12201	12125	Jeantot Philippe	
12202	12125	Jeffray Gérard	
12203	12125	Jegat Bernard	
12204	12125	Jelev Jelio	
12205	12125	Jelinek Elfriede	
12206	12125	Jennifer Harbury	femme du leader guérillero du Guatemala disparu mystérieusement
12207	12125	Jenö Lévay	
12208	12125	Jerry Dewayne Williams	américain, voleur de pizza
12209	12125	Jess Stacy	jazzman
12210	12125	Jeunesse Lucien	
12211	12125	Jeunet Jean-Pierre	Réalisateur
12212	12125	Jewell Richard	
12213	12125	Jewison Norman	
12214	12125	Jégo Yves	
12215	12125	Jégou Jean-Jacques	
12216	12125	Jéol Michel	
12217	12125	Jérôme Rivière	candidat rpr dans les hauts-de-seine (municipales 95)
12218	12032	ZZZZ_Personnalités JI	
12219	12218	Jiang Yang	
12220	12218	Jiang Zemin	Président de Chine populaire
12221	12218	Jim Clark	créateur de Netscape sur le Web
12222	12218	Jim Kerr	rock/Simple Minds
12223	12218	Jirinovski Vladimir	
12224	12032	ZZZZ_Personnalités JO	
12225	12224	Joannon Léo	
12226	12224	Joaquin Cuadra	
12227	12224	Jobic Yves	
12228	12224	Jobs Steve	
12229	12224	Joe Masteroff	auteur de la comédie musicale "Cabaret"
12230	12224	Joe Montana	footballeur américain
12231	12224	Joe Slovo	
12232	12224	Joffrin Laurent	
12233	12224	Johanet Gilles	
12234	12224	Johansson Lennart	président de l'UEFA
12235	12224	Johansson Thomas	
12236	12224	John Elton	musicien
12237	12224	Johns Jasper	
12238	12224	Johnson Ben	
12239	12224	Johnson Daniel	
12240	12224	Johnson Michael	américain spécialiste du 400m
12241	12224	Johnson-Sirleaf Ellen	
12242	12224	Johnston Donald	ocde
12243	12224	Johnston Joe	réalisateur de dessin animé
12244	12224	Jolas Betsy	
12245	12224	Jolibois Charles	
12246	12224	Jolivet Pierre	
12247	12224	Jollès Georges	
12248	12224	Joly Alain	PDG de L'Air liquide
12249	12224	Joly Eva	
12250	12224	Joly Françoise	restauratrice
12251	12224	Joly Sandrine	décède lors d'une intervention chirurgicale bénigne
12252	12224	Jomaron Jacqueline de	
12253	12224	Jonas Hans	
12254	12224	Jonasz Michel	
12255	12224	Jonathan Aitken	secrétaire d'Etat au Trésor britannique
12256	12224	Jones Bill T.	chorégraphe
12257	12224	Jones Chuck	
12258	12224	Jones David	PDG du groupe britannique d'habillement Next
12259	12224	Jones Harmon	
12260	12224	Jones Keziah	
12261	12224	Jones Marion	
12262	12224	Jones Mark	
12263	12224	Jones Paula	
12264	12224	Jones Rickie Lee	
12265	12224	Jones Stephen	
12266	12224	Jones Steven	
12267	12224	Jones Tom	
12268	12224	Jones Tommy Lee	
12269	12224	Jonke Gert	
12270	12224	Jonquet Thierry	
12271	12224	Joplin Janis	
12272	12224	Jordan Michael	Basket
12273	12224	Jordan Neil	
12274	12224	Jordane Benjamin	
12275	12224	Jordi Villacampa	
12276	12224	Jorge Artur	
12277	12224	Jorge Jean-Paul	
12278	12224	Jorge Luis Gonzalez	
12279	12224	Jorge Pardo	jazzmen flamenco
12280	12224	Jorge Rodriguez Orejuela	frère des chefs présumés du cartel de Cali
12281	12224	Jorland Gérard	directeur de recherche au CNRS
12282	12224	Jose Ignacio Wert	politologue espagnol, directeur d'un institut de sondages, "Démoscopia"
12283	12224	Josef Haslinger	écrivain anti-raciste autrichien
12284	12224	Joseph Caillaux	
12285	12224	Joseph Duval	
12286	12224	Joseph Klifa	
12287	12224	Joseph Ortiz	
12288	12224	Joseph Sciorra	auteur de fresques murales sur les murs de NY
12289	12224	Joseph Shieh	ex-policier/ex-prisonnier/écrivain chinois
12290	12224	Jospin Lionel	
12291	12224	Josse Alain	maire RPR de Montgeron
12292	12224	Josselin Charles	
12293	12224	Josèphe Pascal	
12294	12224	José Francisco Ruiz Massieu	Mexique/secr.gal. du PRI assassiné
12295	12224	José Luis Lopez Aranguren	
12296	12224	José Luis Raymond	
12297	12224	José Luis Sampedro	écrivain espagnol
12298	12224	José Touré	
12299	12224	Jouanneau Joël	metteur en scène de théâtre
12300	12224	Joubert Suzanne	
12301	12224	Jouffa François	
12302	12224	Jouffa Yves	
12303	12224	Jouhaud Edmond	
12304	12224	Jourdain (frères)	
12305	12224	Jourdheuil Jean	
12306	12224	Journet Alain	Président PS du conseil général
12307	12224	Journiac Michel	
12308	12224	Jouve Valérie	
12309	12224	Jouvet Louis	
12310	12224	Jouyet Jean-Pierre	
12311	12224	Jovanovic Vladislav	personnalité
12312	12224	Joxe Pierre	
12313	12224	Joyce James	
12314	12224	Joyeux Odette	
12315	12224	Joyon Francis	
12316	12224	Jozef Oleksy	polonais pressenti pour être Premier ministre
12317	12224	Jozef Venglos	Selectionneur de l'équipe de football slovaque
12318	12224	Joël Bats	entraîneur-adjoint du PSG
12319	12224	Joël Collado	météorologiste
12320	12224	Joël Dragutin	directeur de théâtre/Cergy
12321	12224	Joël Grisward	médiéviste et préfacier des ouvrages posthumes de Georges Dumézil
12322	12224	Joël Lambert	Dendrochronologue au labo de chrono-écologie du CNRS de Besançon
12323	12224	Joël Martin	ex-chercheur scientifique devenu spécialiste des jeux de mots au Canard Enchaîné
12324	12224	Joëlle Matos	
12325	12032	ZZZZ_Personnalités JU	
12326	12325	Jubert Daniel	
12327	12325	Jublin Jacques	
12328	12325	Judith Schlanger	professeur de lettres à l'université de Jérusalem
12329	12325	Judt Tony	
12330	12325	Jugnot Gérard	
12331	12325	Juha Kankkunen	pilote de rallye
12332	12325	Juhem Philippe	DEA sur les relations amoureuses
12333	12325	Juillard André	
12334	12325	Juillet Pierre	Ancien conseiller de Jacques Chirac
12335	12325	Jules Simon	inventeur des HLM
12336	12325	Julia Didier	député RPR de Fontainebleau
12337	12325	Julie Henderson	
12338	12325	Juliet Charles	
12339	12325	Juliette	
12340	12325	Julio Ramon Ribeyro	écrivain péruvien
12341	12325	Julliard Jacques	directeur du Nouvel Observateur
12342	12325	Jullien François	
12343	12325	July Serge	
12344	12325	Jun Ichikawa	cinéaste japonais qui a obetnu le 1er prix au festival du cinéma japonais d'Orléans
12345	12325	Juncker Jean-Claude	
12346	12325	Jung Carl G.	
12347	12325	Junot Michel	
12348	12325	Juppé Alain	
12349	12325	Juppé Isabelle	
12350	12325	Juppé Patrick	cousin germain d'Alain Juppé
12351	12325	Juppé-Leblond Christine	directrice de la Femis
12352	12325	Juvet Patrick	
12353	12325	Jünger Ernst	
12354	12325	Jürgen Lodemann	réalisateur de documentaire
12355	12325	Jürgen Stark	secrétaire d'Etat aux Finances allemand
12356	7428	ZZZZ_Personnalités K	
12357	12356	ZZZZ_Personnalités KA	
12358	12357	Kaas Patricia	Chanteuse.
12359	12357	Kabakov Ilya	
12360	12357	Kabila Joseph	
12361	12357	Kabila Laurent-Désiré	
12362	12357	Kaboré Gaston	
12363	12357	Kaci Rachid	Ancien médiateur des HLM des Hauts-de-Seine
12364	12357	Kaczynski Lech	
12365	12357	Kadaré Ismaïl	
12366	12357	Kadda Chérif Hadria	
12367	12357	Kadhafi Mouammar	
12368	12357	Kadri Gursel	journaliste à l'AFP, enlevé par le PKK
12369	12357	Kaestler Dirk	
12370	12357	Kafelnikov Evgueni	
12371	12357	Kafka Franz	
12372	12357	Kagame Paul	
12373	12357	Kahena Attia	monteuse (cinéma noir)
12374	12357	Kahlo Frida	
12375	12357	Kahn Albert	
12376	12357	Kahn Axel	
12377	12357	Kahn Cédric	
12378	12357	Kahn Jean	
12379	12357	Kahn Jean-François	
12380	12357	Kahn Philippe	
12381	12357	Kaige Chen	cinéaste chinois
12382	12357	Kalatozov Mikhaïl	
12383	12357	Kali (musique)	
12384	12357	Kamel André	
12385	12357	Kamel Chérif	théâtre associatif
12386	12357	Kaminski Piotr	
12387	12357	Kandinsky Wassily	
12388	12357	Kanevski Vitali	
12389	12357	Kanno Kenji	
12390	12357	Kant Emmanuel	Philosophe
12391	12357	Kantor Mickey	
12392	12357	Kantor Tadeusz	
12393	12357	Kanza Lokua	
12394	12357	Kaplan Leslie	
12395	12357	Kaplan Steven	
12396	12357	Kaprisky Valérie	
12397	12357	Kapur Shekhar	
12398	12357	Kar-Wai Wong	cineaste chinois
12399	12357	Karadzic Radovan	
12400	12357	Karaganov Serguéï	Serguéï Karaganov est membre du Conseil présidentiel, directeur adjoint de l'Institut de l'Europe près l'Académie des sciences de Russie.
12401	12357	Karajan Herbert Von	
12402	12357	Karasek Horst	
12403	12357	Karatson André	
12404	12357	Karbachi Gholam Hussein	
12405	12357	Karel Fajfr	entraîneur allemand de patinage artistique
12406	12357	Karel William	
12407	12357	Karembeu Christian	football/Nantes
12408	12357	Karen Chaussard	Chanteuse française exilée au Maroc, devenue star de la musique berbère.
12409	12357	Karen Nathanson	coordonatrice pour la France de la Fondation Spielberg ou Fondation Survivants de la Shoah
12410	12357	Karge Manfred	metteur en scène de théâtre berlinois
12411	12357	Karim Jader	
12412	12357	Karimov Islam	président Ouzbekistan
12413	12357	Karl Zéro	
12414	12357	Karlin Daniel	
12415	12357	Karman Jean-Jacques	
12416	12357	Karmitz Marin	
12417	12357	Karoutchi Roger	 
12418	12357	Karpov Anatoli	
12419	12357	Karun Shaji N.	
12420	12357	Karzai Hamid	
12421	12357	Kasa Vubu Justine	
12422	12357	Kasagic Rajko	
12423	12357	Kasdan Laurence	
12424	12357	Kashoggi Adnam	
12425	12357	Kasparov Garry	
12426	12357	Kaspereit Gabriel	
12427	12357	Kaspi André	Directeur de laboratoire de recherche du CNRS
12428	12357	Kassiré Coumakoye Nouradine	
12429	12357	Kassovitz Mathieu	Acteur
12430	12357	Katherine Anne Porter	Ecrivain
12431	12357	Katherine Hibbs	
12432	12357	Katia Lopez	ZAC des Amandiers/XXe ardt./association
12433	12357	Katlama Christine	
12434	12357	Katoucha Niane	
12435	12357	Katrin Krabbe	athlète d'ex-RDA suspendue pour dopage
12436	12357	Katzenberg Jeffrey	
12437	12357	Kauffmann Jean-Paul	
12438	12357	Kauffmann Joëlle	
12439	12357	Kaufman Philip	
12440	12357	Kaufmann Jean-Claude	
12441	12357	Kaurismaki Aki	
12442	12357	Kay Jay	
12443	12357	Kayser Bernard	
12444	12357	Kazakov Alexandre	
12445	12357	Kazan Alexandra	
12446	12357	Kazan Elia	
12447	12357	Kazuyoshi Funaki	skieur
12448	12356	ZZZZ_Personnalités KE	
12449	12448	Keane Molly	
12450	12448	Keating Paul	Premier ministre australien
12451	12448	Keaton Buster	
12452	12448	Keaton Diane	
12453	12448	Keb'Mo	
12454	12448	Kebir Rabah	
12455	12448	Kebzabo Saleh	
12456	12448	Kechat Larbi	imam de la mosquée Adda'wa, dans le XIXe à Paris
12457	12448	Kedadouche Zaïr	
12458	12448	Keene James	
12459	12448	Keita Salif	
12460	12448	Keita Seydou	
12461	12448	Keitel Harvey	
12462	12448	Keith Wood	Talonneur de l'équipe d'Irlande de rugby
12463	12448	Kelemenis Michel	Chorégraphe
12464	12448	Kelkal Khaled	
12465	12448	Keller Fabienne	
12466	12448	Kelly Ellsworth	
12467	12448	Kelly Gene	
12468	12448	Kelly Grace	
12469	12448	Kemal Yasar	
12470	12448	Kemener Yann-Fanch	
12471	12448	Kemp Jack	
12472	12448	Kenedy Daniel	
12473	12448	Kengo Wa Dondo Léon	
12474	12448	Kennedy Jackie	
12475	12448	Kennedy John	
12476	12448	Kenneth Clarke	chancelier de l'échiquier
12477	12448	Kenneth Eriksson	pilote de rallye
12478	12448	Kenovic Adémir	
12479	12448	Kensit Patsy	
12480	12448	Kent	
12481	12448	Kentridge William	
12482	12448	Keping Wang	
12483	12448	Kerbane Kamr Eddine	
12484	12448	Kerekou Mathieu	
12485	12448	Kergoat Jacques	
12486	12448	Kern David	
12487	12448	Kerouac Jack	
12488	12448	Kerry John	
12489	12448	Kersauson Olivier de	
12490	12448	Kersauson Yves de	
12491	12448	Kervasdoué Jean de	ancien directeur des hôpitaux au ministère de la Santé de 1981 à 1986
12492	12448	Kessel Patrick	Grand maître du Grand Orient de France
12493	12448	Kessels Willy	
12494	12448	Kessler Denis	
12495	12448	Kessler Philippe	président de l'association Entreprise et Progrès
12496	12448	Kessous Roland	magistrat
12497	12448	Kevorkian Jack	
12498	12448	Keynes John Maynard	
12499	12356	ZZZZ_Personnalités KH	
12500	12499	Khaldeï Evgueni	
12501	12499	Khaled Ben Sultan	
12502	12499	Khaled Cheb	
12503	12499	Khaled Leila	
12504	12499	Khalida Messaoudi	algérienne, vice-présidente du Mouvement pour la République et condamnée à mort par les Islamistes
12505	12499	Khalifa bin Hamad al-Thani	
12506	12499	Khalil Samiha	
12507	12499	Khalilzad Zalmay	
12508	12499	Khamenei Ali	
12509	12499	Khan Imran	pakistanais, ancien champion de cricket, se marie avec la fille de Jimmy Goldsmith
12510	12499	Khasboulatov Rouslan	
12511	12499	Khatami Mohammed	
12512	12499	Khatib Ghassan	
12513	12499	Khattab (commandant)	
12514	12499	Khazizian Claude	
12515	12499	Khaznadar Chérif	
12516	12499	Kheddam Chérif	
12517	12499	Khemaïs Chamari	
12518	12499	Khodorkovski Mikhaïl	
12519	12499	Khomeiny Ruhullah	
12520	12499	Khotinenko Vladimir	
12521	12499	Khun Sa	dit le "roi de l'opium". 1er producteur mondial d'opium et d'héroïne
12522	12356	ZZZZ_Personnalités KI	
12523	12522	Kiarostami Abbas	
12524	12522	Kibaki Mwai	
12525	12522	Kiberlain Sandrine	Actrice
12526	12522	Kidder Ray	rapport US/essais nucléaires
12527	12522	Kidjo Angélique	
12528	12522	Kidman Nicole	
12529	12522	Kidron Beeban	
12530	12522	Kieffer Guy-André	
12531	12522	Kieffer Philippe	
12532	12522	Kieffer Tina	
12533	12522	Kiejman Georges	
12534	12522	Kierkegaard Soren	philosophe
12535	12522	Kieslowski Krzysztof	
12536	12522	Kiffer Jean	
12537	12522	Kilby John	
12538	12522	Killy Jean-Claude	Ancien champion olympique de ski
12539	12522	Kilmer Val	
12540	12522	Kim Dae-jung	
12541	12522	Kim Il-sung	
12542	12522	Kim Jong-Il	
12543	12522	Kim Young-Sam	Pdt. Corée du Sud
12544	12522	Kimiavi Parviz	
12545	12522	King Henry	cinéaste
12546	12522	King Larry	
12547	12522	King Martin Luther	
12548	12522	King Stephen	
12549	12522	Kinkel Klaus	
12550	12522	Kinnock Neil	commissaire européen aux Transports
12551	12522	Kipling Rudyard	
12552	12522	Kirbassova Maria	
12553	12522	Kirch Leo	
12554	12522	Kirchner Nestor	
12555	12522	Kirienko Sergueï	
12556	12522	Kirk Kerkorian	milliardiare texan
12557	12522	Kirkeby Per	
12558	12522	Kirov	ballet russe
12559	12522	Kisase Ngandu André	
12560	12522	Kisho Kurokawa	Architecte japonais
12561	12522	Kiss (musique)	
12562	12522	Kissinger Henry	ancien secrétaire d'Etat américain devenu consultant pour les grandes entreprises américaines
12563	12522	Kitano Takeshi	Cinéaste japonais
12564	12522	Kivelidi Ivan	
12565	12356	ZZZZ_Personnalités KJ	
12566	12565	Kjus Lasse	Sportif
12567	12356	ZZZZ_Personnalités KL	
12568	12567	Klapisch Cédric	
12569	12567	Klarsfeld Arno	Avocat dans le procés Touvier. Fils de Serge et Beate.
12570	12567	Klarsfeld Serge	historien
12571	12567	Klaus Vaclav	
12572	12567	Klee Paul	
12573	12567	Kleeberg Michael	
12574	12567	Klein Calvin	
12575	12567	Klein Gérard	
12576	12567	Klein Hans-Joachim	
12577	12567	Klein Jean-Pierre	
12578	12567	Klein Joe	
12579	12567	Klein William	realisateur
12580	12567	Klein Yves	peintre spécialiste de la couleur bleue
12581	12567	Kleist Heinrich von	auteur de théâtre
12582	12567	Klemensiewicz Piotr	
12583	12567	Klestil Thomas	
12584	12567	Klima Viktor	
12585	12567	Klingelhöller Harald	
12586	12567	Klinger Thierry	
12587	12567	Klingsberg Marcus	
12588	12567	Klinsmann Jürgen	Footballeur anglais
12589	12567	Klossowski Pierre	
12590	12567	Kléber Malecot	
12591	12356	ZZZZ_Personnalités KN	
12592	12591	Knobelspiess Roger	
12593	12356	ZZZZ_Personnalités KO	
12594	12593	Kobakhidzé Mikhaïl	
12595	12593	Kobal John	
12596	12593	Kobayashi Masaki	
12597	12593	Koch Basile de	Jalons
12598	12593	Koechlin Lionel	
12599	12593	Koechlin Philippe	
12600	12593	Koering René	
12601	12593	Koestler Arthur	
12602	12593	Kohl Helmut	
12603	12593	Kohler Raphaël	
12604	12593	Koizumi Junichiro	
12605	12593	Kok Wim	
12606	12593	Kokkos Iannis	metteur en scène de théâtre
12607	12593	Kolelas Bernard	
12608	12593	Kollhoff Hans	
12609	12593	Koltay Gabor	
12610	12593	Koltès Bernard-Marie	auteur/théâtre
12611	12593	Kolwane Mantu	
12612	12593	Komar Chris	
12613	12593	Komar Georges	
12614	12593	Komatis Henri	
12615	12593	Kombouaré Antoine	
12616	12593	Komen Daniel	
12617	12593	Konan Bédié Henri	
12618	12593	Konaré Alpha Omar	
12619	12593	Konchalovsky Andrei	
12620	12593	Kono Yohei	
12621	12593	Konopnicki Guy	
12622	12593	Konté Mamadou	
12623	12593	Kopciowski Michel	élu local
12624	12593	Kopp Magdalena	
12625	12593	Korda Petr	
12626	12593	Korinman Michel	
12627	12593	Korjakov Alexandre	
12628	12593	Korman Charles	
12629	12593	Koschnick Hans	
12630	12593	Koscina Sylva	
12631	12593	Kostikov Viatcheslav	
12632	12593	Kostner Isolde	ski alpin
12633	12593	Kostov Ivan	
12634	12593	Kostunica Vojislav	
12635	12593	Koteas Elias	
12636	12593	Kotzwinkle William	
12637	12593	Kouchner Bernard	
12638	12593	Koukoui Tola	
12639	12593	Koulikov Anatoli	
12640	12593	Kounen Jan	
12641	12593	Kournikova Anna	
12642	12593	Koussa Karim	
12643	12593	Koutchma Leonid	président ukrainien
12644	12593	Kovac Michal	
12645	12593	Kovalev Sergueï Adamovitch	conseiller russe
12646	12593	Kozyrev Andreï	
12647	12356	ZZZZ_Personnalités KR	
12648	12647	Kraftwerk	
12649	12647	Krajisnik Momcilo	
12650	12647	Kral Ivan	
12651	12647	Krall Diana	
12652	12647	Kramer Robert	
12653	12647	Kramnik Vladimir	
12654	12647	Kraouche Moussa	pdt. Fraternité algérienne en France
12655	12647	Kravitz Lenny	
12656	12647	Kremer Gidon	
12657	12647	Krenz Egon	
12658	12647	Krief Alain	Président de la Guilde des scénaristes
12659	12647	Krief Bernard	
12660	12647	Kriegel Blandine	philosophe
12661	12647	Kriss	
12662	12647	Kristeva Julia	
12663	12647	Kristin Hersch	rockeuse
12664	12647	Krivine Alain	
12665	12647	Krivopissko Guy	
12666	12647	Krystyna Janda	
12667	12647	Krzaklewski Marian	
12668	12647	Krüger Michael	
12669	12356	ZZZZ_Personnalités KU	
12670	12669	Kubelik Rafael	
12671	12669	Kubrick Stanley	
12672	12669	Kucheida Jean-Pierre	
12673	12669	Kudlak Bernard	
12674	12669	Kuerten Gustavo	
12675	12669	Kula Shaker	
12676	12669	Kumaratunga Chandrika	présidente du Sri Lanka
12677	12669	Kums Ennri	
12678	12669	Kundera Milan	
12679	12669	Kupfer Jacques	PDG de Citizen France et président de la section française du Hérout (parti israélien)
12680	12669	Kureishi Hanif	
12681	12669	Kurosawa Akira	
12682	12669	Kurosawa Kiyoshi	
12683	12669	Kurt Schwitters	Auteur de théâtre
12684	12669	Kurtag György	
12685	12669	Kurtz Efrem	
12686	12669	Kurys Diane	
12687	12669	Kushner Tony	
12688	12669	Kusturica Emir	
12689	12356	ZZZZ_Personnalités KW	
12690	12689	Kwann Michelle	
12691	12689	Kwasniewski Alexandre	chef du SLD/Pologne
12692	12689	Kwon Young-kil	
12693	12689	Kwon-taek Im	
12694	12356	ZZZZ_Personnalités KY	
12695	12694	Kyle Shannon	éditeur d'un journal de ville multimédia sur NY
12696	12694	Kylian Jiri	
12697	7428	ZZZZ_Personnalités L	
12698	12697	ZZZZ_Personnalités LA	
12699	12698	La Cava Gregory	
12700	12698	La Fontaine Jean de	
12701	12698	La Martinière Dominique de	
12702	12698	La Martinière Hervé de	
12703	12698	La Patellière Denys de	cinéaste français
12704	12698	La Plaine José	
12705	12698	La Rosière Jacques de	
12706	12698	La Tour Georges de	peintre lorrain de la 1ère moitié du XVIIe siècle
12707	12698	Labarde Philippe	Directeur de l'information au "Monde", démissionnaire
12708	12698	Labarrère André	maire de Pau
12709	12698	Labarthe André S.	cinéaste, membre du CSA
12710	12698	Labaune Patrick	Député RPR
12711	12698	Labiche Eugène	
12712	12698	Labrecque Thomas	
12713	12698	Labro Michel	
12714	12698	Labro Philippe	
12715	12698	Labrune Jeanne	
12716	12698	Lacabarats Alain	vice-président tribunal de Paris
12717	12698	Lacan Jacques	
12718	12698	Lacascade Eric	
12719	12698	Lacassagne Jacques	
12720	12698	Lacayo Antonio	
12721	12698	Lacaze Jeannou	Général, ancien chef d'état-major des armées
12722	12698	Lachenaud Jean-Philippe	
12723	12698	Lachmann Henri	
12724	12698	Laclos Pierre Choderlos de	
12725	12698	Laclotte Michel	
12726	12698	Laconi Régis	Sport
12727	12698	Lacoste Pierre	
12728	12698	Lacoste Yves	
12729	12698	Lacour Laurence	
12730	12698	Lacour Pierre	
12731	12698	Lacouture Jean	historien
12732	12698	Lacroix Christian	
12733	12698	Lacroix Jean-Pierre	
12734	12698	Lacy Steve	
12735	12698	Ladoucette Philippe de	pdg Charbonnages de France
12736	12698	Ladreit de Lacharrière Marc	
12737	12698	Lady Diana	si vous ne la connaissez pas, passez directement au service du personnel, vous êtes VIRE!
12738	12698	Lafaille Jean-Christophe	alpiniste
12739	12698	Lafay Gérard	économiste
12740	12698	Laffont Frédéric	
12741	12698	Lafitte Guy	
12742	12698	Lafleur Jacques	
12743	12698	Lafond Jean-Pierre	Maire UDF de la Ciotat
12744	12698	Lafont Bernadette	
12745	12698	Lafont Hubert	
12746	12698	Lafont Patrice	
12747	12698	Lafontaine Oskar	
12748	12698	Laforgue Jules	
12749	12698	Lafosse Roger	
12750	12698	Lafouge Jacques	
12751	12698	Lafouge Philippe	
12752	12698	Lagaf Vincent	
12753	12698	Lagarce Jean-Luc	
12754	12698	Lagarde Christine	
12755	12698	Lagarde Francis	
12756	12698	Lagarde Ludovic	
12757	12698	Lagardère Arnaud	
12758	12698	Lagardère Jean-Luc	
12759	12698	Lagayette Philippe	
12760	12698	Lagerfeld Karl	
12761	12698	Lagerlöf Selma	
12762	12698	Lagisquet Patrice	
12763	12698	Lagos Ricardo	
12764	12698	Lagrange Pierre	historien de la science
12765	12698	Laguiller Arlette	
12766	12698	Laguérie Philippe	
12767	12698	Lahaie Brigitte	
12768	12698	Lahlou Nordine	
12769	12698	Lahontàa Thierry	
12770	12698	Lahoud Emile	
12771	12698	Laignel André	
12772	12698	Lainé Rémi	
12773	12698	Laisné Yves	président de l' AFRP
12774	12698	Lajko Félix	
12775	12698	Lajoinie André	
12776	12698	Lake Anthony	
12777	12698	Lalonde Brice	
12778	12698	Laloë Jacques	maire communiste d'Ivry-sur-seine
12779	12698	Lalumière Catherine	
12780	12698	Lam Ringo	
12781	12698	Lama Bernard	
12782	12698	Lamarche-Vadel Bernard	
12783	12698	Lamari Mohamed	
12784	12698	Lamarque Patrick	ancien haut fonctionnaire au ministère de la Défense.
12785	12698	Lamarque Pierre	Conseiller général PR du Loiret
12786	12698	Lamassoure Alain	ministre des affaires euro.
12787	12698	Lamazou Titouan	voile (nautisme)
12788	12698	Lambarek Boumaarafi	sous-lieutenant, assassin présumé de Mohamed Boudiaf
12789	12698	Lambert Alain	
12790	12698	Lambert Christiane	
12791	12698	Lambert Christophe (comédien)	
12792	12698	Lambert Marion	
12793	12698	Lambert Yvon	
12794	12698	Lambours Xavier	
12795	12698	Lamers Karl	
12796	12698	Lamfalussy Alexandre	
12797	12698	Lamia Ziadé	écrivain
12798	12698	Lamm Richard	
12799	12698	Lamour Catherine	
12800	12698	Lamour Jean-François	
12801	12698	Lamoureux Eric	danse
12802	12698	Lamy Jean-Claude	
12803	12698	Lamy Pascal	
12804	12698	Lana Turner	
12805	12698	Lancry Yehouda	
12806	12698	Landau Martin	
12807	12698	Landis John	
12808	12698	Landowski Marcel	
12809	12698	Landrieu Bertrand	
12810	12698	Landry Bernard	Vice-premier ministre et Ministre des affaires internationales du Québec (1994), membre du Parti québecois.
12811	12698	Landsbergis Vitautas	
12812	12698	Lane Abigail	
12813	12698	Lanfranchi Jean-Pierre	
12814	12698	Lang Carl	
12815	12698	Lang Fritz	
12816	12698	Lang Helmut	Couturier
12817	12698	Lang Jack	
12818	12698	Lang Michel	réalisateur de téléfilm
12819	12698	Lang Pierre	
12820	12698	Lang-Lessing Sebastian	
12821	12698	Lange Jessica	
12822	12698	Lange Monique	
12823	12698	Lange Richard de	
12824	12698	Langer Alexander	
12825	12698	Langhoff Matthias	metteur en scène de théâtre
12826	12698	Langlois Henri	
12827	12698	Langlois-Glandier Janine	
12828	12698	Lanne Pierre	Responsable du centre Tibériade
12829	12698	Lanson Gustave	
12830	12698	Lanteri Roger Xavier	
12831	12698	Lanvin Gérard	
12832	12698	Lanxade Jacques	
12833	12698	Lanzmann Claude	
12834	12698	Lanzmann Jacques	écrivain
12835	12698	Lançon Christian	
12836	12698	Lapasset Bernard	président du XV de France de Rugby
12837	12698	Lapid Tommy	
12838	12698	Lapidus Olivier	
12839	12698	Lapidus Ted	
12840	12698	Lapierre Dominique	
12841	12698	Lapierre Nicole	
12842	12698	Laplace Yves	
12843	12698	Laplasse Irma	
12844	12698	Lapointe Boby	
12845	12698	Lapointe Eric	
12846	12698	Laporte Bernard	
12847	12698	Lapping Brian	
12848	12698	Laqueur Walter	historien
12849	12698	Laramée Alain	Secrétaire général de 4 STV
12850	12698	Larbaud Valery	poète et romancier
12851	12698	Larcher Alain	
12852	12698	Larcher Gérard	sénateur RPR des Yvelynes
12853	12698	Larcher Philippe	
12854	12698	Larcher Thierry	trader français qui a détourné 2MF du CA de Caen
12855	12698	Larché Jacques	président du conseil général de Seine et Marne
12856	12698	Lareine Éric	musicien, chanteur, auteur
12857	12698	Larionov Michel F.	peintre
12858	12698	Larissa Lazutina	Skieuse
12859	12698	Laroche Alain	
12860	12698	Laroche Joubert Martine	
12861	12698	Laroque Michèle	
12862	12698	Laroque Pierre	
12863	12698	Larosière Jacques de	présidet de la BERD
12864	12698	Laroui Fouad	
12865	12698	Larqué Jean-Michel	
12866	12698	Larrieu Daniel	
12867	12698	Larrouturou Pierre	
12868	12698	Larry David	scenariste américain
12869	12698	Larry Kramer	Dramaturge scénariste américain fondateur d'Act-up
12870	12698	Lars Michaelsen	coureur cycliste
12871	12698	Lartigue Marceline	
12872	12698	Larue Anne	
12873	12698	Larue Fabrice	
12874	12698	Larue Tony	sénateur
12875	12698	Lasne Claire	
12876	12698	Lassalle Jacques	
12877	12698	Laszlo Bekesi	Ministre des Finances Hongrois
12878	12698	Latarjet Bernard	
12879	12698	Latife Tekin	écrivain turque
12880	12698	Latour Bruno	sociologue de la technique
12881	12698	Latour Geneviève	Veuve du comédien Pierre Latour
12882	12698	Latoya Jackson	chanteuse, soeur de Michael
12883	12698	Latraverse Plume	
12884	12698	Lau Emily	
12885	12698	Lauda Niki	ancien pilote de F1 conseiller chez Ferrari
12886	12698	Lauder Evelyn	
12887	12698	Lauer Jean-Philippe	
12888	12698	Laure Mandeville	
12889	12698	Laurel Stan	
12890	12698	Lauren Ralph	
12891	12698	Laurence Guillaume	jeune femme tuée et violée le 8 mai 1991 près de Metz
12892	12698	Laurens Camille	
12893	12698	Laurent Benezech	rugby
12894	12698	Laurent Carceles	
12895	12698	Laurent Christine	
12896	12698	Laurent Farcy-Briant	président des jeunes du CDS, devenu chiraquien
12897	12698	Laurent Goldberg	
12898	12698	Laurent Heynemann	
12899	12698	Laurent Jacques	
12900	12698	Laurent Jean-Luc	
12901	12698	Laurent Léo	
12902	12698	Laurent Wetzel	
12903	12698	Lautner Georges	
12904	12698	Lauvergeon Anne	
12905	12698	Lauzier Gérard	
12906	12698	Lavanant Dominique	
12907	12698	Lavanchy Pascal	
12908	12698	Lavant Denis	
12909	12698	Lavaudant Georges	metteur en scène
12910	12698	Lavelli Jorge	
12911	12698	Lavier Bertrand	
12912	12698	Laville Bettina	
12913	12698	Lawruszenko Jean	professeur de sciences économiques et sociales à l'université de Reims
12914	12698	Laye Camara	
12915	12698	Lazar Marc	professeur à l'université de Nanterre et à l'IEP de Paris. Il est chercheur associé au Ceri.
12916	12698	Lazar Philippe	
12917	12698	Lazareff Pierre	
12918	12698	Lazarenko Pavel	
12919	12698	Lazennec Jean-Yves	
12920	12698	Lazin Milos	
12921	12698	Laïdi Zaki	
12922	12697	ZZZZ_Personnalités LE	
12923	12922	Le Bihan Samuel	
12924	12922	Le Bolloc'h Yvan	
12925	12922	Le Bot Yvon	sociologue, directeur de recherche au CNRS
12926	12922	Le Bris Albert	
12927	12922	Le Bris Michel	
12928	12922	Le Cam Jean	
12929	12922	Le Carré John	David Cornwell de son vrai nom.
12930	12922	Le Chevallier Cendrine	
12931	12922	Le Chevallier Jean-Marie	
12932	12922	Le Clézio JMG	
12933	12922	Le Corbusier	
12934	12922	Le Crom Jean-Pierre	
12935	12922	Le Diberder Alain	directeur programme multimédia à C+, ancien de Libé
12936	12922	Le Déaut Jean-Yves	
12937	12922	Le Floch-Prigent Loïk	
12938	12922	Le Forestier Maxime	
12939	12922	Le Friant Philippe	
12940	12922	Le Gac Jean	peintre
12941	12922	Le Gallou Jean-Yves	
12942	12922	Le Gallou Philippe	
12943	12922	Le Garrec Jean	
12944	12922	Le Goff Alain	
12945	12922	Le Goff Jacques	
12946	12922	Le Goff Jean-Claude	directeur Cogedim/Ile-de-France
12947	12922	Le Goff Jean-Pierre	sociologue
12948	12922	Le Graët Noël	président de la ligue nationale de foot
12949	12922	Le Guen Jean-Marie	
12950	12922	Le Guenno Bernard	chercheur de l'Institut Pasteur
12951	12922	Le Guillerm Johann	homme de théâtre
12952	12922	Le Gunehec Christian	
12953	12922	Le Lay Patrick	PDG de TF1
12954	12922	Le Luron Thierry	
12955	12922	Le Marcis Monique	
12956	12922	Le Mauff Patrick	
12957	12922	Le Minh Ngoc	membre du PC vietnamien
12958	12922	Le Néouannic Guy	
12959	12922	Le Pen Jean-Marie	
12960	12922	Le Pen Marie-Caroline	
12961	12922	Le Pen Marine	
12962	12922	Le Pensec Louis	
12963	12922	Le Pilouer François	directeur du théâtre national de Bretagne
12964	12922	Le Pors Anicet	
12965	12922	Le Quintrec Fabrice	
12966	12922	Le Roux Agnès	affaire
12967	12922	Le Roux Bruno	présenté à la succession de la mairie d'Epinay par Gilbert Bonnemaison (PS)
12968	12922	Le Roux Hervé	
12969	12922	Le Roy Ladurie Emmanuel	Collège de France
12970	12922	Le Scornet Daniel	
12971	12922	Le Vert Dominique	
12972	12922	Le Vert Laurence	juge antiterroriste
12973	12922	Leacock Richard	
12974	12922	Leacock Robert	
12975	12922	Leakey Richard	
12976	12922	Lean David	cinéaste
12977	12922	Leary Timothy	
12978	12922	Lebeau André	
12979	12922	Lebeau Yves	
12980	12922	Lebed Alexandre Ivanovitch	chef des troupes russes en Transnistrie
12981	12922	Lebel Jean-Patrick	
12982	12922	Leblanc Jean-Marie	
12983	12922	Leblanc Luc	
12984	12922	Leboutte Valérie	
12985	12922	Lebranchu Marylise	
12986	12922	Lebrun Michel	
12987	12922	Lebuy Jean-Luc	
12988	12922	Lecanuet Jean	
12989	12922	Lecas Gérard	
12990	12922	Lecat Jean-Philippe	
12991	12922	Leccia Ange	
12992	12922	Leclerc Félix	
12993	12922	Leclerc Gérard	écrivain
12994	12922	Leclerc Henri	avocat
12995	12922	Leclerc Michel-Edouard	
12996	12922	Leclerc Philippe	général de la 2eme guerre mondiale
12997	12922	Leclercq François	
12998	12922	Leconte Daniel	
12999	12922	Leconte Patrice	
13000	12922	Leconte henri	
13001	12922	Lecoq Jean-Pierre	Maire du 6e arr.
13002	12922	Lecourt Dominique	professeur de philosophie
13003	12922	Led Zeppelin	
13004	12922	Ledoyen Virginie	
13005	12922	Leduc France	
13006	12922	Leduc Violette	
13007	12922	Lee Ang	
13008	12922	Lee Hooker John	
13009	12922	Lee Hsien-long	
13010	12922	Lee Iacocca	
13011	12922	Lee Kuan Yew	
13012	12922	Lee Martin	
13013	12922	Lee Spike	
13014	12922	Lee Teng-hui	
13015	12922	Lee William	Avocat américain
13016	12922	Leenhardt Arnaud	président de la commission sociale du CNPF
13017	12922	Leenhardt Etienne	
13018	12922	Leesong James	
13019	12922	Lefait Philippe	
13020	12922	Lefebvre Cyril	
13021	12922	Lefort Gérard	
13022	12922	Lefuel Hector-Martin	
13023	12922	Lefèvre Brigitte	
13024	12922	Legendre Pierre	
13025	12922	Leger Fernand	
13026	12922	Leghari Farouk	
13027	12922	Legoux Alain	
13028	12922	Legrand Michel	
13029	12922	Legras Guy	
13030	12922	Legris Guy	
13031	12922	Lehideux Martine	
13032	12922	Leibowitch Jacques	
13033	12922	Leigh Jennifer Jason	
13034	12922	Leigh Mike	
13035	12922	Leiris Michel	
13036	12922	Leisen Mitchell	
13037	12922	Lejeune Max	
13038	12922	Lejeune Philippe	
13039	12922	Lelardoux Hervé	
13040	12922	Lellouch Emmanuel	astronome de l'Observatoire de Meudon
13041	12922	Lellouche Pierre	
13042	12922	Lelong Michel	
13043	12922	Lelong Stéphane	
13044	12922	Lelouch Claude	
13045	12922	Lely Gilbert	
13046	12922	Lema Ray	
13047	12922	Lemaire Gilles	
13048	12922	Lemarchand Philippe	cartographe
13049	12922	Lemaître Georges	inventeur de la conception du Big Bang en 1931
13050	12922	Lemercier Valérie	
13051	12922	Lemerre Roger	
13052	12922	Lemesle Claude	
13053	12922	Lemierre Jean	
13054	12922	Lemoine Annie	
13055	12922	Lemoine François-Didier	
13056	12922	Lemonheads	
13057	12922	Lemper Ute	
13058	12922	Lendl Ivan	
13059	12922	Lennon John	
13060	12922	Lenoir Bernard	
13061	12922	Lenoir Noëlle	
13062	12922	Leny Claude	
13063	12922	Leo Gros	repreneur de Bidermann
13064	12922	Leo Sisti	écrivain
13065	12922	Leoluca Orlando	maire de Palerme
13066	12922	Leon Garfield	auteur de roman pour enfants et adaptateur de BD
13067	12922	Leonard Elmore	
13068	12922	Leonard Herman	
13069	12922	Leonardo (Nascimento de Araujo)	football
13070	12922	Lepa Brena	chanteuse populaire serbe
13071	12922	Lepage Corinne	
13072	12922	Lepage Robert	
13073	12922	Lepeltier Serge	
13074	12922	Lepercq Arnaud	
13075	12922	Lepers Julien	Animateur TV
13076	12922	Leport Jacques	Vice-président CDS du conseil général des Yvelines
13077	12922	Lequiller Pierre	
13078	12922	Leroi-Gourhan André	ethnologue et préhistorien
13079	12922	Leroux Didier	
13080	12922	Leroy Eugène	
13081	12922	Leroy Maurice	
13082	12922	Leroy Véronique	styliste
13083	12922	Les Blank	réalisateur américain,roi du documentaire
13084	12922	Les Inconnus	
13085	12922	Lescure Jean	
13086	12922	Lescure Pierre	
13087	12922	Lesieur Jean	
13088	12922	Lesko Claude	
13089	12922	Leskov Nikolaï	
13090	12922	Lesourne Jacques	ex-directeur du Monde et professeur au Conservatoire des Arts et Métiers
13091	12922	Lessing Doris	écrivain
13092	12922	Lester Young	Personnalités
13093	12922	Letelier Orlando	
13094	12922	Letertre Jacques	
13095	12922	Letterman David	presentateur tv us
13096	12922	Leung Laurence	
13097	12922	Leung Tony	
13098	12922	Levallet Didier	
13099	12922	Levaï Ivan	journaliste à France Inter
13100	12922	Leveau Rémy	
13101	12922	Leven Jeremy	
13102	12922	Levert Jean-Claude	Inspecteur divisionnaire de la direction centrale de la police judiciaire (DCPJ)
13103	12922	Levi Jean-Daniel	
13104	12922	Levi Montalcini Rita	prix Nobel médecine
13105	12922	Levi Primo	
13106	12922	Levinas Emmanuel	
13107	12922	Levine James	
13108	12922	Levine Ted	
13109	12922	Levinson Barry	
13110	12922	Levitte Jean-David	
13111	12922	Levreau Jean-Louis	foot
13112	12922	Levy Pierre-Oscar	
13113	12922	Levy-Lang André	PdG de Paribas
13114	12922	Levêque Sylvain	courtier, neveu de Jean-Maxime Levêque
13115	12922	Lewinsky Monica	
13116	12922	Lewis Carl	
13117	12922	Lewis Edward B.	Prix Nobel de médecine 1995
13118	12922	Lewis Jerry	
13119	12922	Lewis Jerry Lee	
13120	12922	Leyla Zana	ex-députée kurde de Diyarbakir
13121	12922	Leymergie William	
13122	12922	Leys Simon	
13123	12922	Leyzour Félix	
13124	12922	Leïla	
13125	12922	Léaud Jean-Pierre	
13126	12922	Léautaud Paul	
13127	12922	Lénine	
13128	12922	Léonard Gérard	
13129	12922	Léonard Herbert	
13130	12922	Léonard Nyangoma	ministre burundais devenu chef de maquis
13131	12922	Léonce Mout	
13132	12922	Léontieff Alexandre	
13133	12922	Léotard François	
13134	12922	Léotard Philippe	
13135	12922	Lépine Jean-Luc	
13136	12922	Lépront Catherine	
13137	12922	Lévi-Strauss Claude	
13138	12922	Lévin Sam	
13139	12922	Lévrier Philippe	
13140	12922	Lévy Benny	
13141	12922	Lévy Bernard-Henri	
13142	12922	Lévy David	
13143	12922	Lévy Jean-Claude	
13144	12922	Lévy Jean-Paul	avocat
13145	12922	Lévy Maurice	
13146	12922	Lévy Raymond	ex-pdg de Renault
13147	12922	Lévy-Lang Nathalie	
13148	12922	Lévêque Claude	
13149	12922	Lévêque Jean-Maxime	ex-directeur du Crédit Lyonnais
13150	12697	ZZZZ_Personnalités LH	
13151	13150	Lhermitte Thierry	
13152	12697	ZZZZ_Personnalités LI	
13153	13152	Li Blanca	
13154	13152	Li Gong	
13155	13152	Li Lanqing	
13156	13152	Li Peng	Premier ministre de Chine
13157	13152	Lia Cavalcanti	responsable de l'association Ego, aide aux drogués
13158	13152	Libera Alain de	
13159	13152	Libert Etienne	
13160	13152	Liberti François	
13161	13152	Libon Jean	
13162	13152	Licari Pascal	
13163	13152	Licht Sonja	
13164	13152	Lichtenstein Roy	
13165	13152	Licoys Eric	
13166	13152	Liddell Siobhan	
13167	13152	Lieberman Avigdor	
13168	13152	Lieberman Joseph	
13169	13152	Liebermann Rolf	
13170	13152	Liebman Charles	
13171	13152	Lien Chan	
13172	13152	Lienemann Marie-Noëlle	
13173	13152	Ligeti György	
13174	13152	Ligier Guy	
13175	13152	Likulia Bolongo	
13176	13152	Lilic Zoran	
13177	13152	Lilio Lauricella	promoteur italien
13178	13152	Lim Eng Kiat	acteur d'opéra chinois
13179	13152	Lima Ronaldo da	
13180	13152	Limosin Jean-Pierre	
13181	13152	Limouzy Jacques	
13182	13152	Linda Lê	écrivain
13183	13152	Lindberg Magnus	
13184	13152	Lindenberg Daniel	
13185	13152	Lindeperg Gérard	
13186	13152	Lindgren Torgny	
13187	13152	Lindon Jérôme	
13188	13152	Lindon Vincent	
13189	13152	Lindseth Peter L.	
13190	13152	Linford Christie	athlétisme
13191	13152	Linton Kwesi Johnson	
13192	13152	Lio	
13193	13152	Lion Robert	
13194	13152	Lion Yves	
13195	13152	Lionel Dreksler	manager du Parc des Princes
13196	13152	Lionel Fleury	Président-directeur général de l'AFP
13197	13152	Lionel Hampton	vibraphoniste de jazz
13198	13152	Liotard Jean-Etienne	
13199	13152	Lipietz Alain	économiste
13200	13152	Lipinski Tara	patiange sur glace
13201	13152	Lipkowski Jean-Noël de	
13202	13152	Lipponen Paavo	homme politique finlandais
13203	13152	Lisa Braziel	
13204	13152	Lisa Germano	Musique
13205	13152	Lise Deramond	
13206	13152	Lise-Lotte Rebel	femme et évêque danoise
13207	13152	Lisimachio Jean-Louis	
13208	13152	Lissner Stéphane	
13209	13152	Lissouba Pascal	
13210	13152	Lista Giovanni	
13211	13152	Listiev Vladimir	Directeur de la télévision russe. Assassiné le 1er mars 1995
13212	13152	Littell Jonathan	 
13213	13152	Little Axe	
13214	13152	Little Richard	
13215	13152	Littré Emile	
13216	13152	Liu Gang	Un des principaux leaders du printemps de Pékin
13217	13152	Livingstone Ken	
13218	13152	Livio Didier	
13219	13152	Lizarazu Bixente	
13220	13152	Liévaux Alain	
13221	12697	ZZZZ_Personnalités LL	
13222	13221	Llabres Claude	
13223	13221	Llorca Denis	
13224	13221	Lloyd Geoffrey	
13225	13221	Lloyd Webber Andrew	
13226	12697	ZZZZ_Personnalités LO	
13227	13226	Loach Ken	réalisateur de film
13228	13226	Lobstein Pierre	
13229	13226	Locard Henri	écrivain
13230	13226	Lodge David	
13231	13226	Loeb Sébastien	
13232	13226	Loetscher Hugo	
13233	13226	Loichemol Hervé	
13234	13226	Loiseau Bernard	Restaurateur
13235	13226	Loko Patrice	
13236	13226	Lombard Alain	
13237	13226	Lombardo Bernard	
13238	13226	Lomu Jonah	
13239	13226	London Artur	
13240	13226	Londres Albert	
13241	13226	Long Marceau	
13242	13226	Longo Jeannie	
13243	13226	Longo Robert	
13244	13226	Longuet Gérard	
13245	13226	Longuet Marx Anne	Maître de conférence
13246	13226	Longval Jean-Marc	réalisateur cinéma
13247	13226	Lonsdale Michael	
13248	13226	Loos François	
13249	13226	Lopez Sergi	
13250	13226	Lopez de Arriortura José Ignacio	
13251	13226	Loppion Jacques	
13252	13226	Lorca Massine	
13253	13226	Lords of Acid	
13254	13226	Lorentz Francis	
13255	13226	Lorenzi Jean-Louis	
13256	13226	Lorenzi Pierre-Louis	
13257	13226	Lorenzoni Marcel	
13258	13226	Loretan Erhard	
13259	13226	Loridant Paul	
13260	13226	Lormeau Jean-Yves	
13261	13226	Lorna Ferguson	
13262	13226	Losey Joseph	
13263	13226	Losfeld Joëlle	
13264	13226	Lothar Matthaeus	capitaine de l'équipe d'Allemagne de football
13265	13226	Loti Pierre	
13266	13226	Loubry Veronika	
13267	13226	Loudmer Guy	Commissaire priseur
13268	13226	Louette Pierre	
13269	13226	Louhichi Taïeb	
13270	13226	Louis Bériot	
13271	13226	Louis Daquin	
13272	13226	Louis Marie-Victoire	chercheuse au CNRS
13273	13226	Louis Patrice	Nom de famille: Louis
13274	13226	Louis Reboul	Maire socialiste de Roissy-en-Brie
13275	13226	Louis XIV	
13276	13226	Louis-Dreyfus Robert	
13277	13226	Loujkov Iouri	maire de Moscou
13278	13226	Loukachenko Alexandre	
13279	13226	Loukanov Andrei	
13280	13226	Loukos Yorgos	Directeur du festival de danse à Cannnes; également directeur du Lyon Opéra Ballet
13281	13226	Loulou Gasté	
13282	13226	Lounguine Pavel	
13283	13226	Lounès Matoub	chanteur kabyle
13284	13226	Loup Durand	Auteur de polars
13285	13226	Loustallot Dann	
13286	13226	Louvin Gérard	patron de Glem Productions
13287	13226	Love Courtney	chanteuse de rock, épouse de Kurt Cobain
13288	13226	Lowe Paul	Photographe de l'agence Magnum
13289	13226	Loïk Stéphanie	
13290	13226	Löffler Manuel	
13291	12697	ZZZZ_Personnalités LU	
13292	13291	Lu Cont Jacques	
13293	13291	Luba Frederick	ancienne infirmière ayant sauvé la vie de 46 enfants juifs
13294	13291	Lubbers Ruud	
13295	13291	Lubitsch Ernst	
13296	13291	Lucas Claude	
13297	13291	Lucas George	
13298	13291	Lucas Michel	
13299	13291	Lucet Elise	
13300	13291	Luchini Fabrice	
13301	13291	Luciano Violante	vice-président de la chambre des députés italiens et ex-président de la commission de lutte contre la Mafia
13302	13291	Lucien Deveaux	
13303	13291	Lucien Neuwirth	
13304	13291	Ludmila Hols	régisseur souffleur de théâtre
13305	13291	Ludovic Germain	auteur d'une étude sur le bruit des objets
13306	13291	Ludwig Binswanger	psychiatre ami de Freud
13307	13291	Luhrmann Baz	
13308	13291	Luigi Valadier	Orfèvre et fondeur du XVIIIe siècle
13309	13291	Luis Donaldo Colosio	
13310	13291	Luis Donaldo Coloso	Mexique/assassinat
13311	13291	Luis Garcia Meza	ancien dictateur de Bolivie (1980/1981)
13312	13291	Luis Miguel	Musique latino
13313	13291	Luis Miguel Cintra	acteur portugais
13314	13291	Luisada Jean-Marc	pianiste
13315	13291	Lula da Silva Luis Inacio	
13316	13291	Lumbroso Daniela	
13317	13291	Lumet Sidney	
13318	13291	Lumière Auguste et Louis	
13319	13291	Lumley Henry de	directeur du Museum d'Histoire Naturelle
13320	13291	Luna Bigas	
13321	13291	Luo Ji	
13322	13291	Lupino Ida	
13323	13291	Lursel Dominique	
13324	13291	Luscious Jackson	musicien de rap
13325	13291	Lush	
13326	13291	Lusiette Kondi	
13327	13291	Lussac Elodie	gymnaste
13328	13291	Lustiger Jean-Marie	
13329	13291	Lutens Serge	
13330	13291	Luton Jean-Marie	
13331	13291	Lux Guy	
13332	12697	ZZZZ_Personnalités LV	
13333	13332	Lvovsky Noémie	
13334	12697	ZZZZ_Personnalités LY	
13335	13334	Lydia Perréal	
13336	13334	Lynch David	cineaste américain
13337	13334	Lynch Edouard	
13338	13334	Lyne Adrian	
13339	13334	Lynn Hunt	Ecrivain
13340	13334	Lyon Danny	
13341	13334	Lyonnel Gineste	jeune fille de 16 ans retrouvée morte
13342	13334	Lyotard Jean-François	
13343	7428	ZZZZ_Personnalités M	
13344	13343	ZZZZ_Personnalités MA	
13345	13344	Ma Junren	
13346	13344	Ma Yo-Yo	
13347	13344	Maazel Lorin	
13348	13344	Mac Dowell Andie	
13349	13344	Mac Millan James	
13350	13344	Mac Taggart David	président honoraire de Greenpeace International
13351	13344	MacArthur Ellen	
13352	13344	MacDonald Hettie	
13353	13344	Maccanico Antonio	
13354	13344	Macdonald David	mammalogiste d'Oxford
13355	13344	Mach Ernst	
13356	13344	Machado Maria	
13357	13344	Machado de Assis	écrivain brésilien mort en 1908
13358	13344	Machel Graca	
13359	13344	Macherey Monique	
13360	13344	Machhour Moustapha	
13361	13344	Machiavel	
13362	13344	Machover Jacobo	journaliste et écrivain cubain
13363	13344	Macias Enrico	
13364	13344	Mackerras Charles	
13365	13344	Macé Béatrice	
13366	13344	Macé Gérard	
13367	13344	Madame Grès	
13368	13344	Madani Abassi	président du FIS
13369	13344	Maddin Guy	
13370	13344	Madec Roger	
13371	13344	Madeleine Lagadec	Infirmière française assassinée en 1989 à San Vincente au Salvador.
13372	13344	Madelin Alain	homme politique du PR, ministre des PME sous Balladur 1
13373	13344	Madelin Henri	
13374	13344	Madhavrao Scindia	homme politique indien
13375	13344	Madiot Marc	
13376	13344	Madonna	
13377	13344	Madoz Chema	
13378	13344	Madredeus	
13379	13344	Madrenas Jean-Claude	
13380	13344	Maeterlinck Maurice	
13381	13344	Maffioli Claude	
13382	13344	Magda Marinko	
13383	13344	Magic Johnson	ancienne star US de basket
13384	13344	Magnard Pierre	
13385	13344	Magnaval Bernard	CDS/Villeurbanne/affaire
13386	13344	Magoudi Ali	
13387	13344	Magris Claudio	
13388	13344	Magritte René	
13389	13344	Maguire Donna	,
13390	13344	Maharbiz Julio	
13391	13344	Mahdi Ali	
13392	13344	Maheu Jean	PDG radio france
13393	13344	Mahfouz Naguib	
13394	13344	Mahiou Embarek	
13395	13344	Mahmoud Mestiri	envoyé spécial des Nations Unies en Afghanistan
13396	13344	Mahmut Alinak	député kurde
13397	13344	Maier Hermann	
13398	13344	Mailer Norman	
13399	13344	Maillan Jacqueline	
13400	13344	Maillant Raphaël	
13401	13344	Maillard de la Morandais Alain	
13402	13344	Maillol Aristide	
13403	13344	Maillot Jacques (PDG)	PdG de Nouvelles Frontières
13404	13344	Maillot Jacques (cinéaste)	
13405	13344	Mailly Jean-Claude	
13406	13344	Maire Edmond	
13407	13344	Mairowitz David Zane	
13408	13344	Mairé Jacques	
13409	13344	Majoli Iva	tennis
13410	13344	Major John	
13411	13344	Major Norma	personnalité
13412	13344	Major René	
13413	13344	Makhlouf Boukhzar	journaliste algérien
13414	13344	Makhmalbaf Mohsen	
13415	13344	Makine Andréï	
13416	13344	Makinen Tommi	
13417	13344	Makis Warlamis	créateur de meubles pour enfants
13418	13344	Makomé M'Bowolé	Jeune Zaïrois mort à la suite d'une bavure policière
13419	13344	Makéïeff Macha	
13420	13344	Malagugini Silvia	
13421	13344	Malan Magnus	
13422	13344	Malangi David	
13423	13344	Malaterre Jacques	
13424	13344	Malaurie Jean	
13425	13344	Malavoy Christophe	
13426	13344	Malberg Henri	
13427	13344	Malcolm X	
13428	13344	Malek Abdel	
13429	13344	Malet Léo	
13430	13344	Malgoire Jean-Claude	
13431	13344	Malherbe Guy	
13432	13344	Malhuret Claude	maire de Vichy
13433	13344	Malinvaud Edmond	
13434	13344	Malkovich John	
13435	13344	Mallarmé Stéphane	
13436	13344	Mallart Alain	PDG de Novalliance
13437	13344	Malle Louis	
13438	13344	Mallet Daniel	
13439	13344	Mallet Jean-Bernard	
13440	13344	Mallet Jean-Claude	Président de la Caisse nationale d'assurance maladie
13441	13344	Malone Eduardo	
13442	13344	Malpas Robert	
13443	13344	Malraux André	
13444	13344	Malterre Jean-Louis	avocat
13445	13344	Malvy Martin	pdt. groupe PS/Assemblée Nationale
13446	13344	Mamdouh Alia	
13447	13344	Mamet David	
13448	13344	Mamine Youri	
13449	13344	Mamou Jacky	
13450	13344	Mamoulian Rouben	
13451	13344	Mamour Jan	chef militaire des talibans (Afghanistan)
13452	13344	Mamy Jean	Directeur scientifique de l'INRA
13453	13344	Mamère Jean	journaliste sportif de France 2
13454	13344	Mamère Noël	
13455	13344	Man Mohan Adhikari	Premier ministre du Népal
13456	13344	Manara	BD
13457	13344	Manaudou Laure	
13458	13344	Manbar Nahum	
13459	13344	Manceaux François	
13460	13344	Manceaux Michèle	
13461	13344	Mancel Jean-François	RPR
13462	13344	Manchette Jean-Patrick	
13463	13344	Manchevski Milcho	
13464	13344	Mancini Ange	
13465	13344	Mancini Giorgio	
13466	13344	Mancio Eric	
13467	13344	Mandel Ernest	
13468	13344	Mandela Nelson	
13469	13344	Mandela Winnie	femme de Nelson
13470	13344	Mandelbrot Benoît	mathématicien
13471	13344	Mandelkern Dieudonné	
13472	13344	Mandelson Peter	
13473	13344	Mandelstam Ossip	
13474	13344	Mandon Thierry	
13475	13344	Mandy Woetzel	patineuse
13476	13344	Manet Edouard	
13477	13344	Mangeot Philippe	
13478	13344	Mangin Bernard	
13479	13344	Mangin David	architecte-urbaniste
13480	13344	Mangold James	metteur en scène américain
13481	13344	Maniaty Tony	Correspondant pour l'Europe de la chaîne de télévision australienne SBS en 1991 et 1992, Tony Maniaty vit aujourd'hui à Sydney, où il écrit des romans et des scénarios.
13482	13344	Manic Street Preachers	rock
13483	13344	Manker Paulus	
13484	13344	Mankiewicz Joseph	cinéaste
13485	13344	Mann Anthony	
13486	13344	Mann Klaus	
13487	13344	Mann Michael	
13488	13344	Mann Thomas	
13489	13344	Mano Jean-Luc	
13490	13344	Mano Negra	
13491	13344	Manotti Dominique	
13492	13344	Manoukian Vazguen	
13493	13344	Manoury Philippe	
13494	13344	Manset Gérard	
13495	13344	Mansito Fernando	
13496	13344	Manson Charles	
13497	13344	Mansouroff Paul	
13498	13344	Mantelet Jean	
13499	13344	Manzanares	
13500	13344	Manzor René	Réalisateur
13501	13344	Mao Zedong	
13502	13344	Maoudj Danièle	
13503	13344	Maouli Nordine	
13504	13344	Mapplethorpe Robert	
13505	13344	Maracineanu Roxane	
13506	13344	Maradona Diego	joueur de football
13507	13344	Marais Jean	
13508	13344	Maratrat Alain	
13509	13344	Marboeuf Jean	
13510	13344	Marceau Marcel	
13511	13344	Marceau Sophie	actrice de cinéma
13512	13344	Marchais Georges	
13513	13344	Marchais Olivier	Fils de Georges
13514	13344	Marchal Paul	
13515	13344	Marchal Pierre	
13516	13344	Marchand Dominique	PdG mouillé dans l'affaire Botton
13517	13344	Marchand Guy	
13518	13344	Marchand Nicolas	secrétaire fédéral du PC parachuté en val-de-marne
13519	13344	Marchand Pierre	
13520	13344	Marchand Xavier	
13521	13344	Marchand Yves	directeur de l'IGPN
13522	13344	Marchelli Paul	
13523	13344	Marchi Jean-Pierre	
13524	13344	Marchiani Jean-Charles	
13525	13344	Marcinkiewicz Kazimierz	 
13526	13344	Marcos (commandant zapatiste)	
13527	13344	Marcos Ferdinand	
13528	13344	Marcos Imelda	Veuve du dictateur philippin Ferdinand Marcos.
13529	13344	Marcuse Herbert	
13530	13344	Marcuson Michel	
13531	13344	Marek Raoul	
13651	13344	Mashraoui Rachid	
13652	13344	Maskhadov Aslan	
13532	13344	Marelle Pereira	fille de Fernando Pereira, tué dans l'explosion du Rainbow Warrior en 1985
13533	13344	Marenches Alexandre de	
13534	13344	Margarit Angels	
13535	13344	Margie Clavo Peralta	Sentier lumineux/Pérou
13536	13344	Marguerite Eymery	écrivain
13537	13344	Maria Novaro	
13538	13344	Mariani Guy	
13539	13344	Mariani Paul	
13540	13344	Mariani Thierry	député RPR,président des chorégies d'Orange.
13541	13344	Marianne Cornevin	historienne, africaniste
13542	13344	Marias Javier	
13543	13344	Marie Bunel	
13544	13344	Marie Epstein	
13545	13344	Marie Rucki	Directrice du studio Berçot, atelier de mode
13546	13344	Marie-Ange Guillaume	
13547	13344	Marie-Annick Ramassamy-Vergès	Avocate de Carlos
13548	13344	Marie-Françoise Blain	responsable du Soudan à la section française d'Amnesty Internationale
13549	13344	Marin Christian	
13550	13344	Marin Maguy	danse
13551	13344	Marinelli Jacques	
13552	13344	Marini Giovanna	
13553	13344	Marini Philippe	
13554	13344	Marini Pierre	
13555	13344	Mario Praz	décorateur auteur de livres illustrés
13556	13344	Mario Reiter	
13557	13344	Mario Ruiz Massieu	ex-procureur du Mexique en fuite pour inculpation de trafic de drogue
13558	13344	Marion Challier	écrivain
13559	13344	Marion Dönhoff	
13560	13344	Marion Roger	chef de la lutte antiterroriste de Pasqua
13561	13344	Marion Segaud	sociologue
13562	13344	Mariou Jean-Michel	
13563	13344	Marivaux	
13564	13344	Mark Mary Ellen	
13565	13344	Mark Twain	romancier
13566	13344	Mark Van Doren	Ancien prof d'université. Eut pour élèves Jack Kerouac et Allen Ginsberg.
13567	13344	Marker Chris	
13568	13344	Markovic Mihaylo	
13569	13344	Markovic Milosevic Mira	
13570	13344	Marleau Denis	Homme de théâtre
13571	13344	Marley Bob	
13572	13344	Marliere Patrick	
13573	13344	Marlin Franck	
13574	13344	Marlowe Christopher	Auteur de théâtre
13575	13344	Marmot Jean	Haut fonctionnaire - réforme de la sécu - 1995
13576	13344	Marnas Catherine	
13577	13344	Marneffe Christine	
13578	13344	Marousse Marina	
13579	13344	Marquet Albert	
13580	13344	Marquet Christophe	
13581	13344	Marrus Michael	
13582	13344	Marsalis Branford	
13583	13344	Marsalis Wynton	
13584	13344	Marsaud Alain	
13585	13344	Marsaudon Jean	
13586	13344	Marseille Jacques	historien
13587	13344	Marsh Jon	
13588	13344	Marsh Mike	
13589	13344	Marshall Gary	
13590	13344	Marshall George	
13591	13344	Marshall Tonie	
13592	13344	Marsé Juan	écrivain espagnol
13593	13344	Martel Frédéric	écrivain
13594	13344	Martelli Roger	
13595	13344	Martha Cooper	auteur de fresques funéraires à N.Y.
13596	13344	Marthaler Christoph	
13597	13344	Marthe Barraco	psychologue spécialiste des enfants battus
13598	13344	Marthouret François	
13599	13344	Marti José	
13600	13344	Martic Milan	"Président" des Serbes de Krajina, inculpé de crimes de guerre par le Tribunal pènal international de la Haye.
13601	13344	Martin Andreu	
13602	13344	Martin Christian	
13603	13344	Martin Daniel	
13604	13344	Martin Dean	
13605	13344	Martin Even	conseiller d'Hervé Bourges
13606	13344	Martin Jacques (BD)	
13607	13344	Martin Jacques (télé)	
13608	13344	Martin Ledinsky	réalisateur de TV hongrois
13609	13344	Martin Levis Egglestone	joueur de basket noir américain
13610	13344	Martin Patino Basilio	
13611	13344	Martin Patrice	
13612	13344	Martin Patricia	
13613	13344	Martin Paul	
13614	13344	Martin Richard	
13615	13344	Martin Steve	
13616	13344	Martin Stéphane	directeur de la musique et de la danse au Ministère de la culture
13617	13344	Martin Valérie	
13618	13344	Martin-Gousset Nasser	
13619	13344	Martinand Claude	directeur des Affaires économiques et sociales au Ministère de l'économie
13620	13344	Martinelli Jean-Louis	metteur en scène/théâtre
13621	13344	Martinez Conchita	
13622	13344	Martinez Jean-Claude	
13623	13344	Martinez Olivier	
13624	13344	Martinez Pierre	
13625	13344	Martinez Rosco	
13626	13344	Martinez Serge	
13627	13344	Martinez Vincent	
13628	13344	Martini Mia	
13629	13344	Martino Bernard	
13630	13344	Martone Mario	
13631	13344	Martre Henri	
13632	13344	Marty-Lavauzelle Arnaud	pdt. de Aides
13633	13344	Marvel	
13634	13344	Marx Brothers	
13635	13344	Marx Karl	créateur de la pensée marxiste
13636	13344	Marylin H. Mallowes	réalisatrice de documentaire
13637	13344	Marzak Ahmed	
13638	13344	Marzolff Cathy	(Plusieurs écritures du nom)
13639	13344	Marzouk Moussa Abou	
13640	13344	Maréchal E. Chapochnikov	
13641	13344	Maréchal Jean-Pierre	
13642	13344	Maréchal Marcel	metteur en scène et chef de troupe théâtrale
13643	13344	Maréchal Samuel	
13644	13344	Masahiro Shinoda	Cinéaste japonais
13645	13344	Masami Hata	auteur de BD américano-nippon
13646	13344	Masao Miyamoto	Haut fonctionnaire au ministère de la santé
13647	13344	Mascret Dominique	
13648	13344	Masekela Barbara	
13649	13344	Masharawi Rashid	
13650	13344	Mashkov Vladimir	
13653	13344	Masnada Florence	
13654	13344	Maspero François	écrivain
13655	13344	Massa Pierre	
13656	13344	Massart Clémence	
13657	13344	Masseret Jean-Pierre	
13658	13344	Massilia Sound System	
13659	13344	Massimo Montanari	historien de l'alimentation
13660	13344	Massimo Schuster	metteur en scène de théâtre
13661	13344	Massin Isabelle	Maire de Cergy
13662	13344	Massive Attack	rock
13663	13344	Masson André	
13664	13344	Masson Jean-Louis	
13665	13344	Masson Laetitia	
13666	13344	Massoni Philippe	
13667	13344	Massoud Ahmed Shah	chef des Moudjahidins Afghans
13668	13344	Massé Michel	
13669	13344	Massé Philippe	
13670	13344	Masséna Jean	adjoint au maire de Nice
13671	13344	Mastroianni Chiara	
13672	13344	Mastroianni Marcello	acteur italien
13673	13344	Masure Bruno	journaliste TV
13674	13344	Masure Georges	
13675	13344	Matagrin Dominique	
13676	13344	Matamoros Joséphine	
13677	13344	Matard-Bonucci Marie-Anne	
13678	13344	Matausch Catherine	
13679	13344	Matheson Richard	
13680	13344	Matheson Richard Christian	
13681	13344	Mathieu Anita	
13682	13344	Mathieu Paul-Henri	
13683	13344	Mathus Didier	
13684	13344	Mathy Mimie	
13685	13344	Matillon Jeanine	
13686	13344	Matisse Henri	peintre
13687	13344	Matouk Jean	
13688	13344	Mattei Enrico	
13689	13344	Mattei Jean-François	
13690	13344	Mattei Jean-Pierre	
13691	13344	Mattei Marie-Hélène	
13692	13344	Matthews Dave	
13693	13344	Matthias Glasner	cinéaste allemand
13694	13344	Mattila Karita	
13695	13344	Mattioli Francesco Paolo	
13696	13344	Mattéoli Jean	
13697	13344	Matvejevitch Fredrag	Predrag Matvejevitch est écrivain ex-yougoslave et croate, il vit actuellement à Rome. Ouvrages récemment parus chez Fayard: Epistolaire de l'autre Europe et Bréviaire méditerranéen (prix du meilleur livre étranger 1993, réédité récemment en collection d
13698	13344	Matvejevitch Predrag	
13699	13344	Mau Mau	Groupe rock
13700	13344	Maud Linder	fille de Max Minder et réalisatrice de court métrage
13701	13344	Mauduit Chantal	
13702	13344	Mauer Michel	PDG de la Cogedim
13703	13344	Mauger Thierry	
13704	13344	Maulnier Thierry	
13705	13344	Mauléon Martine	
13706	13344	Maura Carmen	
13707	13344	Maurane	
13708	13344	Mauresmo Amélie	
13709	13344	Mauriac Claude	
13710	13344	Mauriac François	
13711	13344	Maurice Aicardi	nommé à la tête d'une commission sur le marché de l'Art
13712	13344	Maurice Bonneau	
13713	13344	Maurice Core	
13714	13344	Maurice Croisat	Ecrivain
13715	13344	Maurice Florian	
13716	13344	Maurice Gibb	frère d'Andy avec qui il formait le groupe les Bee Gees
13717	13344	Maurice Goldstein	président du Comité international d'Auschwitz
13718	13344	Maurice Hunt	réalisateur de dessin animé
13719	13344	Maurice Saatchi	
13720	13344	Maurice Tabard	photographe
13721	13344	Maurice Templier	
13722	13344	Maurin Christian	
13723	13344	Mauro Gianetti	coureur cycliste Suisse-Italien
13724	13344	Mauro Silva	footballeur
13725	13344	Mauroy Pierre	
13726	13344	Maurras Charles	
13727	13344	Mauss Marcel	
13728	13344	Max Azoulay	
13729	13344	Max Dhéry	éditeur spécialisé dans le numérique
13730	13344	Max Frérot	
13731	13344	Max Genève	écrivain
13732	13344	Max Linder	
13733	13344	Max Siméoni	
13734	13344	Maxime Dmitriev	
13735	13344	Maxime Gelifier	
13736	13344	Mayawati	
13737	13344	Mayer Daniel	
13738	13344	Mayereau Isabelle	
13739	13344	Mayette Muriel	
13740	13344	Mayhew Patrick	ministre brittanique à l'Irlande du Nord
13741	13344	Mayor Laurence	
13742	13344	Mayoux Jacques	
13743	13344	Mazeaud Pierre	Président de la commission des lois de l'Assemblée nationale
13744	13344	Mazenod Xavier de	Xavier de Mazenod est président du Cercle Jean Bodin, groupement de prospective politique et sociale.
13745	13344	Mazens Michel	
13746	13344	Mazzucchelli David	
13747	13344	Maïnassara Ibrahim Baré	
13748	13344	Maïté	animatrice sur France 3
13749	13344	Mâche François-Bernard	
13750	13343	ZZZZ_Personnalités MB	
13751	13750	Mbeki Thabo	
13752	13343	ZZZZ_Personnalités MC	
13753	13752	MC Gregor Ewan	
13754	13752	MC Solaar	
13755	13752	Mc Enroe Patrick	
13756	13752	McAleese Mary	
13757	13752	McCain John	
13758	13752	McCall Olivier	boxe
13759	13752	McCarey Léo	cinéaste américain
13760	13752	McCarthy Cormac	
13761	13752	McCarthy Mary	
13762	13752	McCartney Paul	
13763	13752	McCulloch Ian	
13764	13752	McDormand Frances	
13765	13752	McGuinness Martin	
13766	13752	McNamara Robert	homme politique américain
13767	13752	McQueen Alexander	
13768	13752	McQueen Steve	
13769	13752	McRae Colin	
13770	13752	McTiernan John	
13771	13752	McVeigh Timothy	
13772	13343	ZZZZ_Personnalités ME	
13773	13772	Meatyard Ralph Eugene	
13774	13772	Meciar Vladimir	
13775	13772	Meckert Jean	
13776	13772	Med Hondo	cinéaste mauritanien
13777	13772	Meddour Azzedine	
13778	13772	Medgyessy Peter	
13779	13772	Medvedev Andrei	joueur de tennis
13780	13772	Mehdi Bazargan	ancien Premier ministre iranien
13781	13772	Mehdi Zana	Kurde de Turquie, emprisonné et torturé pendant onze années.
13782	13772	Mehl Dominique	
13783	13772	Mehldau Brad	
13784	13772	Meier Richard	
13785	13772	Meinesz Alexandre	directeur du labo environnement marin littoral - CNRS à l'université de Nice-Sophia Antipolis
13786	13772	Meirieu Philippe	
13787	13772	Meister Bernard	
13788	13772	Mejdani Rexhep	
13789	13772	Mekas Jonas	
13790	13772	Melchior Ndadaye	
13791	13772	Melin Daniel	
13792	13772	Mellac Bénédicte	
13793	13772	Mellencamp John	
13794	13772	Mellick Jacques	
13795	13772	Melville Herman	
13796	13772	Melville Jean-Pierre	
13797	13772	Melvin Franklin	créateur du groupe les Temptations
13798	13772	Memduh Un	cinéaste turc
13799	13772	Memling Hans	peintre primitif flamand
13800	13772	Menchu Rigoberta	prix Nobel de la paix
13801	13772	Mendaille Georges	
13802	13772	Mendes Chico	
13803	13772	Mendes Pereira Antonio	
13804	13772	Mendy Jean-Baptiste	
13805	13772	Mendès France Marie-Claire	
13806	13772	Mendès France Pierre	
13807	13772	Menegatti Beppe	
13808	13772	Menem Carlos	
13809	13772	Menem Eduardo	
13810	13772	Menendez (frère)	
13811	13772	Mengistu Hailé Mariam	
13812	13772	Menoyo Eloy Gutierrez	
13813	13772	Mens Dominique	
13814	13772	Menswear	groupe de pop anglais
13815	13772	Menu Jean-Christophe	
13816	13772	Menuhin Yehudi	
13817	13772	Menzel Jiri	Réalisateur tchécoslovaque
13818	13772	Mer Francis	
13819	13772	Mercier Jean-Pierre	
13820	13772	Mercier Philippe	
13821	13772	Mercouri Melina	
13822	13772	Mercurio Stéphane	réalisateur télé
13823	13772	Mercury Freddie	
13824	13772	Merejkowski Pierre	
13825	13772	Merkel Angela	
13826	13772	Merlant Philippe	
13827	13772	Merle Jean-François	maire de Chatenay-Malabry
13828	13772	Merle Olivier	Joueur de rugby
13829	13772	Merleau-Ponty Maurice	philosophe
13830	13772	Merlin Marc-Michel	
13831	13772	Merlin Serge	
13832	13772	Mermaz Louis	
13833	13772	Mermet Daniel	
13834	13772	Mertens Pierre	
13835	13772	Meschonnic Henri	écrivain et traducteur
13836	13772	Mesguich Daniel	
13837	13772	Mesic Stipe	
13838	13772	Mesili Alain	
13839	13772	Mesliand Claude	Claude Mesliand est ancien recteur de l'académie de Nancy-Metz.
13840	13772	Meslot Damien	
13841	13772	Mesrine Jacques	
13842	13772	Messager Annette	artiste
13843	13772	Messiaen Olivier	compositeur de musique liturgique
13844	13772	Messier Jean-Marie	
13845	13772	Messmer Pierre	
13846	13772	Mestrallet Gérard	
13847	13772	Metallica	
13848	13772	Metraux Alfred	
13849	13772	Mexandeau Louis	
13850	13772	Meyer Michel	conseiller du président de RFI
13851	13772	Meyer Philippe	
13852	13772	Meyer Ron	
13853	13772	Meyer Vaisman	
13854	13772	Meyssat Bruno	
13855	13772	Meyssonnier Jérome	
13856	13772	Meï Roger	
13857	13772	Mère Teresa	
13858	13772	Mécheri Hervé	
13859	13772	Méchet Philippe	
13860	13772	Mécili Ali	
13861	13772	Méda Dominique	
13862	13772	Médecin Jacques	
13863	13772	Médecin Pierre	
13864	13772	Mégret Bruno	
13865	13772	Mégret Catherine	
13866	13772	Méhaignerie Pierre	
13867	13772	Mélenchon Jean-Luc	PS/maire-adjoint de Massy
13868	13772	Méliès Georges	
13869	13772	Ménage Gilles	
13870	13772	Ménil Georges de	
13871	13772	Mérand Pierre	
13872	13772	Mérimée Jean-Bernard	
13873	13772	Méry Jean-Claude	
13874	13343	ZZZZ_Personnalités MI	
13875	13874	Michael Carns	général américain
13876	13874	Michael Foot	Ancien leader du parti travailliste dans les annees 80 en Grande-Bretagne
13877	13874	Michael George	
13878	13874	Michael Hordern	
13879	13874	Michael Lehmann	Réalisateur américain
13880	13874	Michael Mandelbaum	universitaire américain
13881	13874	Michael Richardson	
13882	13874	Michael Rose	
13883	13874	Michael Spindler	Patron d'Apple
13884	13874	Michael Young	Basketteur américain du CSP Limoges.
13885	13874	Michaela Watteaux	journaliste
13886	13874	Michaux Agnès	
13887	13874	Michaux Henri	
13888	13874	Michaux Pierre	
13889	13874	Michaux bernard	philosophe
13890	13874	Michaux-Chevry Lucette	
13891	13874	Michaël Fréminet	Auteur présumé de l'assassinat de Brahim Bouarram
13892	13874	Michel Aglietta	
13893	13874	Michel Ameller	ex-secr.gal. de l'Assemblée nationale/membre du Conseil constitutionnel
13894	13874	Michel Armand	ex-chercheur au CNRS et en procès pour des droits d'auteur
13895	13874	Michel Beuzon	DU SYNDICAT FO DES CADRES DE LA PéNITENTIAIRE
13896	13874	Michel Bonnet	directeur du marché international du film de Cannes
13897	13874	Michel Bourel	
13898	13874	Michel Bruneau	cuisinier du restaurant Le Bourride à Caen
13899	13874	Michel Buono	
14027	14025	Moati Serge	
13900	13874	Michel Cadoret	policier de La Rochelle en prison pour violence et faux à magistrat
13901	13874	Michel Cagnion	directeur général de la Fédération française de football
13902	13874	Michel Cerda	metteur en scène de théâtre
13903	13874	Michel Cicurel	
13904	13874	Michel Corajoud	
13905	13874	Michel Dary	
13906	13874	Michel Embareck	Ecrivain
13907	13874	Michel Godefroy	
13908	13874	Michel Grossiord	journaliste à Europe 1
13909	13874	Michel Guez	
13910	13874	Michel Henri	foot
13911	13874	Michel Jaouen	Prêtre antidrogue
13912	13874	Michel Jarnoux	président de l'Andac qui s'est tiré avec la caisse
13913	13874	Michel Jean-Pierre	
13914	13874	Michel Joulin	chaudronnier
13915	13874	Michel Khleifi	Réalisateur
13916	13874	Michel Kriloff	horticulteur, créateur d'une variété de rose, la "Lara"
13917	13874	Michel Larivière	
13918	13874	Michel Launois	scientifique spécialiste des criquets
13919	13874	Michel Legland	glaciologue travaillant sur le glacier d'Argentière
13920	13874	Michel Lemercier	policier lyonnais, l'une des têtes de "gang des postiches"
13921	13874	Michel Level	
13922	13874	Michel Marciset	
13923	13874	Michel Maurice-Bokanowski	Sénateur des Hauts-De-Seine
13924	13874	Michel Naudy	
13925	13874	Michel Neuve Eglise	pdg de la filiale informatique de Matra
13926	13874	Michel Scheller	nommé directeur dans l'aéronautique
13927	13874	Michel Sfez	auteur d'un ouvrage texte+photos sur Paris
13928	13874	Michel Smack	
13929	13874	Michel de Roumanie	
13930	13874	Michel-Ange	sculpteur italien
13931	13874	Michelet Jules	
13932	13874	Michelin Edouard	
13933	13874	Michelin François	
13934	13874	Micheline Welter	
13935	13874	Michelle Aubert	
13936	13874	Michelle Torr	chanteuse
13937	13874	Michnik Adam	Polonais et ex- de Solidarité, directeur de Gazeta
13938	13874	Michon Pierre	
13939	13874	Michot Yves	
13940	13874	Migaud Didier	
13941	13874	Migeon Céline	
13942	13874	Mignon Jean-Claude	
13943	13874	Miguet Nicolas	
13944	13874	Mikhalkov Nikita	
13945	13874	Miklos Mészöly	
13946	13874	Miles Hyman	
13947	13874	Milestone Lewis	
13948	13874	Milet Jean-Pierre	
13949	13874	Milianti Alain	metteur en scène
13950	13874	Milin Gildas	
13951	13874	Miljkovic Slobodan	
13952	13874	Milken Mike	
13953	13874	Millar Robin	
13954	13874	Miller Arthur	
13955	13874	Miller Claude	
13956	13874	Miller Dominique	psychanalyste
13957	13874	Miller George	
13958	13874	Miller Gérard	
13959	13874	Miller Henry	
13960	13874	Miller Lee	
13961	13874	Millet Gilles	
13962	13874	Millon Charles	
13963	13874	Millot Eric	
13964	13874	Mills Crispian	
13965	13874	Milner Jean-Claude	
13966	13874	Milo Jean-Roger	
13967	13874	Milosevic Slobodan	
13968	13874	Milovan Djilas	
13969	13874	Milovanoff Jean-Pierre	
13970	13874	Milroy Lisa	
13971	13874	Milutinovic Milan	
13972	13874	Miléo Thierry	
13973	13874	Mimouni Rachid	Mort le 12/02/95. Ecrivain
13974	13874	Minc Alain	
13975	13874	Minda de Gunzburg	Historienne et amateur d'art et aussi nom du prix international qui récompense les catalogues d'exposition
13976	13874	Ming Josserrand	compositeur
13977	13874	Minghella Anthony	
13978	13874	Minh Ngoc	
13979	13874	Minkowski Marc	
13980	13874	Minnelli Vincente	
13981	13874	Mino Jean	
13982	13874	Minvielle Yvon	sociologue
13983	13874	Miossec Christophe	
13984	13874	Miot Jean	
13985	13874	Miou-Miou	
13986	13874	Miquel André	
13987	13874	Miquel Jean-Pierre	
13988	13874	Miquel Pierre	
13989	13874	Mireille	
13990	13874	Mireille Chalvon	
13991	13874	Mireille Durocher-Bertin	opposante haïtienne assassinée
13992	13874	Mireille Mercier-Balaz	
13993	13874	Miro Joan	
13994	13874	Miron Gaston	
13995	13874	Mirsaïdov Choukhroullo	
13996	13874	Mishal Saïd	
13997	13874	Mishima Yukio	
13998	13874	Misia	
13999	13874	Misuari Nur	
14000	13874	Mitaine François	
14001	13874	Mitchell Eddy	
14002	13874	Mitchell George	
14003	13874	Mitchell Joni	
14004	13874	Mitchell Margaret	romancière américaine
14005	13874	Mitchum Robert	acteur américain
14006	13874	Mitnick Kevin	
14007	13874	Mitrani Michel	Cinéaste et homme de télévision
14008	13874	Mitrovitsa Redjep	
14009	13874	Mitsuzuka Hiroshi	
14010	13874	Mitterrand Danielle	
14011	13874	Mitterrand François	
14012	13874	Mitterrand Frédéric	
14013	13874	Mitterrand Jacques	
14014	13874	Mitterrand Jean-Christophe	
14015	13874	Mitzna Amram	
14016	13874	Miyake Issey	
14017	13874	Miyazaki Hayao	
14018	13874	Mizoguchi Kenji	
14019	13874	Miéville Anne-Marie	
14020	13343	ZZZZ_Personnalités ML	
14021	14020	Mladenova Margarita	
14022	14020	Mladic Ratko	
14023	13343	ZZZZ_Personnalités MN	
14024	14023	Mnouchkine Ariane	
14025	13343	ZZZZ_Personnalités MO	
14026	14025	Moada Mohamed	
14028	14025	Mobutu Sese Seko	
14029	14025	Moby	
14030	14025	Mocchi Emile	
14031	14025	Mocky Jean-Pierre	Réalisateur
14032	14025	Modiano Patrick	
14033	14025	Modigliani Amadeo	
14034	14025	Modine Matthew	
14035	14025	Modotti Tina	
14036	14025	Modrow Hans	
14037	14025	Moebius	
14038	14025	Mohammed VI	
14039	14025	Moholy-Nagy Laszlo	
14040	14025	Moinard Marc	Procureur de la république au tribunal de Bobigny
14041	14025	Moinet Jean-Marie	
14042	14025	Moix Yann	
14043	14025	Molière	
14044	14025	Moll Dominik	
14045	14025	Mona Sahlin	Vice Premier ministre suédois
14046	14025	Monate Gérard	ex-PDG d'Urba
14047	14025	Moncassin Frédéric	
14048	14025	Monclar Jacques	entraîneur de basket ball du club Olympique d'Antibes
14049	14025	Mondrian Pieter Cornelis	peintre
14050	14025	Mondy Pierre	
14051	14025	Monet Claude	
14052	14025	Moninot Bernard	
14053	14025	Moniotte Sophie	
14054	14025	Monk Thelonious	
14055	14025	Monks John	 
14056	14025	Monnier Mathilde	
14057	14025	Monod Jérôme	PDG de la Lyonnaise des Eaux
14058	14025	Monod Théodore	
14059	14025	Monory Jacques	
14060	14025	Monory René	
14061	14025	Monroe Marilyn	
14062	14025	Montagnier Luc	
14063	14025	Montaigne	
14064	14025	Montaldo Jean	pamphlétaire attitré du président de la République
14065	14025	Montalvo José	
14066	14025	Montanari Jean-Paul	
14067	14025	Montand Yves	
14068	14025	Montdargent Robert	maire d'Argenteuil
14069	14025	Montebourg Arnaud	
14070	14025	Monteil Jean-Marc	
14071	14025	Monteil Martine	
14072	14025	Monteiro Joào Cesar	
14073	14025	Montet Bernardo	
14074	14025	Montgolfier Eric de	
14075	14025	Montherlant Henry de	
14076	14025	Monti Mario	
14077	14025	Montiel Bernard	
14078	14025	Monty Python	
14079	14025	Moon Sarah	
14080	14025	Moore Demi	
14081	14025	Moore Henry	
14082	14025	Moore Julianne	
14083	14025	Moore Michael	
14084	14025	Moore Mike	
14085	14025	Moore Roger	
14086	14025	Moracchini Marie-Paule	juge d'instruction
14087	14025	Morales Evo	
14088	14025	Morandini Jean-Marc	
14089	14025	Morceli Nourredine	
14090	14025	Mordillat Gérard	cinéaste
14091	14025	Moreau Jeanne	
14092	14025	Moreau Yolande	
14093	14025	Morel Chantal	
14094	14025	Morel François	
14095	14025	Morel Gaël	
14096	14025	Morelle Aquilino	écrivain
14097	14025	Morellet François	
14098	14025	Moreno Roland	
14099	14025	Moretti Nanni	
14100	14025	Morgan Michèle	
14101	14025	Mori Yoshiro	
14102	14025	Morillon Philippe	
14103	14025	Morin Edgar	
14104	14025	Morin Hervé	 
14105	14025	Moro Aldo	
14106	14025	Morris (BD)	
14107	14025	Morris Robert	
14108	14025	Morrison Toni	
14109	14025	Morrissey Stephen	
14110	14025	Morrisson Jim	
14111	14025	Morrot Bernard	
14112	14025	Mortier Gérard	
14113	14025	Moscovici Pierre	rénovateur PS
14114	14025	Mosley Max	
14115	14025	Motton Gregory	
14116	14025	Mouada Mohamed	
14117	14025	Moubarak Hosni	président Egyptien
14118	14025	Mougeotte Etienne	
14119	14025	Mouillot Michel	maire de Cannes
14120	14025	Moulin Jean	
14121	14025	Moullet Luc	
14122	14025	Mouraud Tania	
14123	14025	Mouriéras Claude	
14124	14025	Mourleau Philippe	
14125	14025	Mourousi Yves	
14126	14025	Moustic Jules-Edouard	
14127	14025	Mowlan Mo	
14128	14025	Moya Carlos	
14129	14025	Mozart Wolfgang Amadeus	 
14130	14025	Mötorhead	
14131	13343	ZZZZ_Personnalités MU	
14132	14131	Mucic Zdravko	
14133	14131	Mudhoney	
14134	14131	Mudrooroo	écrivain aborigène australien
14135	14131	Muet Pierre-Alain	dir. dpt. économétrie/ANPE
14136	14131	Mugabe Robert	
14137	14131	Mugesera Léon	
14138	14131	Mugica Fernando	
14139	14131	Mugler Thierry	haute couture
14140	14131	Muir Mike	
14141	14131	Muller Bernard	
14142	14131	Muller-Arnaud de Genestoux Eva	
14143	14131	Mulliez Gérard	PDG d'Auchan
14144	14131	Mulligan Gerry	
14145	14131	Mulligan Robert	
14146	14131	Munch Edvard	
14147	14131	Munro Alice	
14148	14131	Muntadas Antoni	
14149	14131	Munyeshyaka Wenceslas	
14150	14131	Muracciole Florence	écrivain
14151	14131	Murakami Ryû	
14152	14131	Murat Bernard	
14153	14131	Murat Jean-Louis	
14154	14131	Muratova Kira	
14155	14131	Muratovic Hasan	
14156	14131	Murdoch Iris	
14157	14131	Murdoch Rupert	
14158	14131	Murer Fredi	
14159	14131	Muriel Boulay	
14160	14131	Murnau Friedrich Wilhelm	
14161	14131	Murray Bill	
14162	14131	Murtin Pascale	
14163	14131	Museeuw Johan	coureur cycliste
14164	14131	Muselier Renaud	
14165	14131	Museveni Yoweri	
14166	14131	Musharraf Pervez	
14167	14131	Music Zoran	
14168	14131	Musil Robert	
14169	14131	Musin Albert	
14170	14131	Musset Alfred de	
14171	14131	Musset Julien	
14172	14131	Musso François	
14173	14131	Mussolini Benito	
14174	14131	Mustafa Kemal	
14175	14131	Mustapha Hanza	
14176	14131	Mustapha Mohamadi	
14177	14131	Mustar Philippe	
14178	14131	Muster Thomas	Joueur de tennis, Autrichien
14179	14131	Muti Ornella	
14180	14131	Muvrini I	
14181	14131	Muzy Frank	
14182	14131	Mühl Otto	
14183	14131	Müller Heiner	
14184	14131	Müller Marco	
14185	14131	Müntefering Franz	
14186	13343	ZZZZ_Personnalités MY	
14187	14186	Myard Jacques	
14188	14186	Mystics	
14189	7428	ZZZZ_Personnalités N	
14190	14189	ZZZZ_Personnalités NA	
14191	14190	Nabe Marc-Edouard	écrivain
14192	14190	Nabila Djahnine	
14193	14190	Nabokov Vladimir	écrivain russe
14194	14190	Nabuo Ishihara	homme politique japonais
14195	14190	Naceri Samy	
14196	14190	Nachagyn Bagabandi	
14197	14190	Nadas Peter	
14198	14190	Nadaud Alain	
14199	14190	Nader Ralph	Avocat américain, lutte pour la défense des droits du consommateur.
14200	14190	Nadj Joseph	
14201	14190	Nagano Kent	chef d'orchestre
14202	14190	Nagore Mugika Maria	
14203	14190	Nagui	Animateur TV
14204	14190	Nahnah Mahfoud	
14205	14190	Nahon Pierre	
14206	14190	Nahum Henri	
14207	14190	Naigeon Philippe	
14208	14190	Naipaul V.S.	Ecrivain et journaliste indien.
14209	14190	Nair Mira	
14210	14190	Najib Bengounia	
14211	14190	Najibullah Mohammed	
14212	14190	Najman Charles	
14213	14190	Nallet Henri	
14214	14190	Nam June Paik	
14215	14190	Nam-Hun Sung	sud-coréen, photographe
14216	14190	Namias Robert	directeur de la rédaction de TF1
14217	14190	Nance jack	
14218	14190	Nancy Jean-Luc	
14219	14190	Nancy Kerrigan	
14220	14190	Nano Fatos	
14221	14190	Nansen Fridtjof	
14222	14190	Nanty Isabelle	
14223	14190	Naoto Kan	
14224	14190	Naouri Jean-Charles	
14225	14190	Napoléon III	
14226	14190	Naraghi Eshan	
14227	14190	Narasimha Rao P.V.	Premier ministre indien
14228	14190	Narayanan Kocheril Raman	
14229	14190	Narcy Jean-Claude	
14230	14190	Nas	
14231	14190	Nasrallah Yousry	
14232	14190	Nasreen Taslima	
14233	14190	Nass Henri	
14234	14190	Nasse Philippe	
14235	14190	Nasser Gamal Abdel	
14236	14190	Nassib Sélim	écrivain
14237	14190	Nastase Ilie	
14238	14190	Natali Paul	
14239	14190	Natalia Bessmertnova	ballerine au Bolchoi
14240	14190	Natché Mustapha	
14241	14190	Nategh-Nouri Ali Akbar	président du parlement iranien
14242	14190	Nathalie Bailleux	écrivain
14243	14190	Nathalie Lamblin	
14244	14190	Nathalie Santamaria	jeune chanteuse française
14245	14190	Nathan Tobie	Ethno-psychiatre
14246	14190	Nathaniel Hawthorne	écrivai américain
14247	14190	Navarre Ludovic	
14248	14190	Navarria Antonio	
14249	14190	Navarro Dave	guitariste du groupe de rock Red Hot Chili Peppers.
14250	14190	Navratilova Martina	tennis
14251	14190	Nay Catherine	
14252	14190	Nayim	
14253	14190	Nazarbaïev Noursoultan	Président du Kazakhstan
14254	14190	Nazradenko Evgueni	
14255	14190	Naïm Kassem	Hezbollah
14256	14190	Naïr Sami	
14257	14189	ZZZZ_Personnalités ND	
14258	14257	N'Dour Youssou	
14259	14257	NDiaye Marie	
14260	14257	Ndayizeye Domitien	 
14261	14189	ZZZZ_Personnalités NE	
14262	14261	Nebbiolo Marina	
14263	14261	Nebiolo Primo	
14264	14261	Neel Doff	écrivain hollandaise
14265	14261	Neeman Yaakov	
14266	14261	Negri Toni	
14267	14261	Negroponte John	
14268	14261	Negroponte Nicholas	créateur du Media Lab au MIT
14269	14261	Neiertz Véronique	
14270	14261	Nelly Kalfayan	vedette de la télé égyptienne qui anime les fawazir (spectacle de soirée de ramadan)
14271	14261	Nelly Kaplan	
14272	14261	Nelly Rodi	styliste
14273	14261	Nelson John	
14274	14261	Nemarq Alain	repreneur de Bidermann
14275	14261	Nemours Aurélie	
14276	14261	Nemtsov Boris	
14277	14261	Nenad Perunicic	handball
14278	14261	Nermin Tulic	acteur bosniaque
14279	14261	Neruda Pablo	
14280	14261	Neschling John	
14281	14261	Nesin Aziz	
14282	14261	Nespoulous Henri	
14283	14261	Nestor Burma	
14284	14261	Netanyahou Benyamin	chef du Likoud
14285	14261	Neuhaus max	
14286	14261	Neuville Colette	membre du Conseil de surveillance de Paribas/actionnaire minoritaire/fondatrice de l'Adam
14287	14261	Newby Chris	
14288	14261	Newell Mike	
14289	14261	Newman Joseph M	cinéaste
14290	14261	Newman Paul	
14291	14261	Newton Helmut	
14292	14261	Nezzar Khaled	
14293	14261	Nègre Marie-Paule	
14294	14261	Néaoutyine Paul	
14295	14261	Négresses vertes	
14296	14261	Névache Guy	
14297	14189	ZZZZ_Personnalités NG	
14298	14297	Ngandu Kisassi-André	
14299	14297	Ngor Haing	
14300	14297	Ngotty Bruno	
14301	14297	Ngoupandé Jean-Paul	1er ministre Centrafricain
14302	14297	Nguyen Huu Khoa	
14303	14297	Nguyên Huy Thiêp	
14304	14189	ZZZZ_Personnalités NI	
14305	14304	Niang Thierry	
14306	14304	Nichet Jacques	
14307	14304	Nichols Mike	
14308	14304	Nichols Terry	Un des deux frères suspectés d'avoir aidé l'attentat d'Oklahoma City
14309	14304	Nicholson Jack	
14310	14304	Nick Christophe	
14311	14304	Nick Leeson	le trader qui a coulé sa banque
14312	14304	Nick Skelton	cavalier britannique
14313	14304	Nico	
14314	14304	Nicolas Corre	journaliste
14315	14304	Nicolas Dessum	saut à ski
14316	14304	Nicolas Flamel	écrivain public mort en 1418
14317	14304	Nicolas Luttiau	
14318	14304	Nicolas Sanchez-Albornoz	directeur de l'Institut Cervantes à Madrid
14319	14304	Nicolas Theis	
14320	14304	Nicole Bobek	Patinage artistique
14321	14304	Nicole Edelman	écrivain
14322	14304	Nicole Guillemet	responsable du Sundance
14323	14304	Nicole Priollaud	
14324	14304	Nicole Schoeller	CE de Peugeot Sochaux
14325	14304	Nicolella John	
14326	14304	Nicoletti Raymond	maire de Salernes (Var)
14327	14304	Nicolin Yves	député UDF de la Loire
14328	14304	Niermans Edouard	
14329	14304	Nietzsche Friedrich	
14330	14304	Nigel Benn	boxeur
14331	14304	Nigel Mansell	
14332	14304	Niggers With Attitude	
14333	14304	Nihoul Jean-Michel	
14334	14304	Nijdam Henri	
14335	14304	Nijinski Vaslav	Chorégraphe.
14336	14304	Nikita Mandryka	créateur de BD et du concombre masqué
14337	14304	Nikitine Alexandre	
14338	14304	Nimier Roger	
14339	14304	Nine Inch Nails	
14340	14304	Niogret Corinne	
14341	14304	Nirvana	Groupe de rock
14342	14304	Nisand Israël	
14343	14304	Nitschke Philip	
14344	14304	Nixon Richard	
14345	14304	Nizon Paul	écrivain
14346	14189	ZZZZ_Personnalités NK	
14347	14189	ZZZZ_Personnalités NO	
14348	14347	Noah Yannick	
14349	14347	Nobuya Nemoto	économiste japonais
14350	14347	Nobuyuki Idei	Président de Sony
14351	14347	Nobécourt Jacques	
14352	14347	Noelle-Neumann Elisabeth	
14353	14347	Noemi Lapzeson	Chorégraphe
14354	14347	Noetinger Jérôme	
14355	14347	Noguez Dominique	
14356	14347	Nohain Jean	
14357	14347	Noir Anne-Valérie	fille de Michel Noir
14358	14347	Noir Désir	
14359	14347	Noir Michel	
14360	14347	Noiret Michèle	
14361	14347	Noiret Philippe	
14362	14347	Nokku Yokoyama	gouverneur d'Osaka
14363	14347	Nol de Ruiter	entraîneur néerlandais de l'équipe de football égyptienne, les Pharaons
14364	14347	Nolde Emil	peintre danois
14365	14347	Nooteboom Cees	
14366	14347	Nora Pierre	
14367	14347	Nordey Stanislas	
14368	14347	Nordine Meddahi	
14369	14347	Nordmann Jean-Gabriel	
14370	14347	Nordmann Joë	
14371	14347	Nordmann Marielle	
14372	14347	Noriega Manuel	
14373	14347	Norman Greg	
14374	14347	Norman Jessye	
14375	14347	Norman Lewis	écrivain gallois
14376	14347	Norman Magnus	
14377	14347	Norman Z. McLeod	cinéaste américain
14378	14347	Norodum Sirivudh	
14379	14347	Norredine Gaham	éducateur-sociologue-observateur/banlieue d'Amiens
14380	14347	North Oliver	
14381	14347	Norén Lars	
14382	14347	Notat Nicole	
14383	14347	Nothias Jean-Christophe	
14384	14347	Nothomb Amélie	
14385	14347	Nougaro Claude	
14386	14347	Nourissier François	
14387	14347	Nouveau Bertrand	
14388	14347	Nouvel Jean	architecte
14389	14347	Nova Heather	
14390	14347	Novak Kim	
14391	14347	Novarina Valère	Ecrivain et homme de théâtre
14392	14347	Novelli Hervé	député UDF
14393	14347	Novotna Jana	
14394	14347	Noyer Christian	
14395	14347	Nozière Michel	
14396	14347	Nozolino Paulo	
14397	14189	ZZZZ_Personnalités NT	
14398	14397	NTM	
14399	14397	Ntibantunganya Sylvestre	
14400	14189	ZZZZ_Personnalités NU	
14401	14400	Nunn Sam	
14402	14400	Nunn Trevor	
14403	14400	Nuridsany Claude	cinéaste
14404	14400	Nuridsany Michel	critique art au Figaro et directeur artistique pour 95 aux rencontres d'Arles
14405	14400	Nuttea Daddy	
14406	14400	Nuyts Jan	
14407	14400	Nüsslein-Volhard Christiane	Prix Nobel de médecine 1995
14408	14189	ZZZZ_Personnalités NY	
14409	14408	Nyssen Hubert	
14410	7428	ZZZZ_Personnalités O	
14411	14410	ZZZZ_Personnalités O'	
14412	14411	O'Brian Patrick	
14413	14411	O'Brien Flann	Ecrivain irlandais.
14414	14411	O'Connor Sinead	Chanteuse de rock irlandaise.
14415	14411	O'Neal Shaquille	joueur NBA
14416	14411	O'Neill Eugene	
14417	14411	O'Selznick David	producteur Hollywoodien
14418	14410	ZZZZ_Personnalités OA	
14419	14418	Oasis (rock)	
14420	14410	ZZZZ_Personnalités OB	
14421	14420	Obadia Régis	
14422	14420	Obas Beethova	
14423	14420	Obasanjo Olusegun	
14424	14420	Obispo Pascal	
14425	14420	Obuljen Nikola	maire de Dubrovnik - Août 1995
14426	14410	ZZZZ_Personnalités OC	
14427	14426	Ocalan Abdullah	
14428	14426	Ochoa Arnaldo	
14429	14426	Ochoa Eliades	
14430	14426	Ockrent Christine	
14431	14426	Octave Mirbeau	
14432	14410	ZZZZ_Personnalités OD	
14433	14432	Odette Bréant	
14434	14432	Odile Arcauz-Hiriart	
14435	14432	Odile Decq	architecte responsable de l'aménagement du port de Gennevilliers
14436	14410	ZZZZ_Personnalités OE	
14437	14436	Oé Kenzaburô	écrivain
14438	14410	ZZZZ_Personnalités OF	
14439	14438	Offenbach Jacques	
14440	14410	ZZZZ_Personnalités OG	
14441	14440	Ogata Sadako	
14442	14440	Ogawa Yôko	
14443	14440	Ogier Bulle	
14444	14410	ZZZZ_Personnalités OH	
14445	14444	Ohana Maurice	
14446	14410	ZZZZ_Personnalités OK	
14447	14446	Okamoto Kozo	
14448	14446	Okri Ben	
14449	14446	Oksana Baiul	Patineuse
14450	14446	Okuyama Kazuyoshi	
14451	14410	ZZZZ_Personnalités OL	
14452	14451	Olano Abraham	cyclisme
14453	14451	Oldenburg Claes	
14454	14451	Oldman Gary	
14455	14451	Oleg Lobov	Secrétaire du Conseil de sécurité russe
14456	14451	Olga Nakkas	
14457	14451	Olievenstein Claude	professeur spécialisé dans la drogue et Sida
14458	14451	Olin Lena	
14459	14451	Olin Nelly	maire RPR de Garges
14460	14451	Oliva Michel	
14461	14451	Oliveira Manoel de	
14462	14451	Olivennes Denis	
14463	14451	Oliver Hoare	marchand d'art britannique
14464	14451	Olivier Agid	sculpteur
14465	14451	Olivier André	Militant d'Action directe
14466	14451	Olivier Beaud	
14467	14451	Olivier Corpet	fondateur et administrateur de l'Imec
14468	14451	Olivier Fillieule	spécialiste des mouvements sociaux
14469	14451	Olivier Guillemin	créateur de mode
14470	14451	Olivier Labrosse	médecin écrivain
14471	14451	Olivier Le Guisquet	
14472	14451	Olivier Lorelle	
14473	14451	Olivier Margot	écrivain
14474	14451	Olivier Robert De Massy	Directeur des affaires sociales de l'Association française des Banques
14475	14451	Olivier Swenne	Artiste illustrateur. Auteur de la Carte Blanche du Magazine n°8.
14476	14451	Ollivier Alain	
14477	14451	Olmert Ehud	
14478	14451	Olmeta Pascal	
14479	14451	Oltra Jean	
14480	14410	ZZZZ_Personnalités OM	
14481	14480	Omar Mohammad	
14482	14480	Omirbaev Darejan	
14483	14410	ZZZZ_Personnalités ON	
14484	14483	Onassis Aristote	
14485	14483	Onat Kutlar	écrivain
14486	14483	Onetti Juan Carlos	
14487	14483	Onfray Michel	
14488	14483	Ono Yoko	
14489	14410	ZZZZ_Personnalités OP	
14490	14489	Ophuls Marcel	réalisateur français
14491	14489	Ophuls Max	
14492	14489	Oppel Jean-Hugues	
14493	14489	Oppenheim Dennis	
14494	14410	ZZZZ_Personnalités OR	
14495	14494	Orban Viktor	
14496	14494	Orkin Rut	
14497	14494	Ormesson Héloïse d'	
14498	14494	Ormesson Jean d'	
14499	14494	Ormesson Olivier d'	
14500	14494	Orozco Gabriel	
14501	14494	Orsenna Erik	
14502	14494	Orsoni Alain	
14503	14494	Ortega Daniel	
14504	14494	Orwell George	
14505	14410	ZZZZ_Personnalités OS	
14506	14505	Osamu Tezuka	cartooniste japonais
14507	14505	Osborne Joan	
14508	14505	Osborne John	
14509	14505	Oshima Nagisa	Cinéaste japonnais
14510	14505	Osinski Jacques	metteur en scène
14511	14505	Oskar Bätschmann	Ecrivain
14512	14505	Ossang F.J.	
14513	14505	Ossard Claudie	
14514	14505	Ostende Jean-Pierre	
14515	14505	Ostrovski Alexandre Nikolaïevitch	dramaturge russe
14516	14505	Oswald Lee Harvey	
14517	14410	ZZZZ_Personnalités OT	
14518	14517	Otchakovsky-Laurens Paul	
14519	14517	Ottavi Jean-Louis	
14520	14517	Otte Jean-Pierre	
14521	14517	Otter Anne Sophie von	
14522	14517	Ottey Merlene	
14523	14517	Otzenberger Christophe	
14524	14410	ZZZZ_Personnalités OU	
14525	14524	Ouaki Fabien	
14526	14524	Ouaknin Marc-Alain	
14527	14524	Ouattara Alassane	
14528	14524	Oudougov Movladi	
14529	14524	Ouedraogo Idrissa	cinéaste africain
14530	14524	Oufkir Abdellatif	
14531	14524	Oufkir Fatima	
14532	14524	Oufkir Malika	
14533	14524	Oufkir Maria-Inan	
14534	14524	Oufkir Mohamed	
14535	14524	Oufkir Myriam	
14536	14524	Oufkir Raouf	
14537	14524	Oufkir Soukaina	
14538	14524	Ould Abdallah Ahmedou	Ambassadeur au Burundi et représentant du secrétaire général des Nations Unies
14539	14524	Ould Taya Maaouya	
14540	14524	Oum Kalsoum	
14541	14524	Oury Gérard	
14542	14524	Oury Jean-Marc	
14543	14524	Ousman Imaïev	
14544	14524	Ousmane Mahamane	
14545	14524	Ouyahia Ahmed	
14546	14410	ZZZZ_Personnalités OV	
14547	14546	Ovidi Montllor	chanteur catalan
14548	14546	Ovitz Michael	
14549	14410	ZZZZ_Personnalités OW	
14550	14549	Owen David	Ancien médiateur européen pour l'Ex-Yougoslavie
14551	14549	Owens Louis	
14552	14410	ZZZZ_Personnalités OX	
14553	14552	Oxenbury Helen	
14554	14410	ZZZZ_Personnalités OZ	
14555	14554	Oz Amos	
14556	14554	Ozawa Ichiro	
14557	14554	Ozden Tomris	
14558	14554	Ozerov Lev	
14559	14554	Ozgür Ulke	
14560	14554	Ozon François	
14561	14554	Ozouf Mona	écrivain
14562	14554	Ozu Yasujiro	Cinéaste
14563	7428	ZZZZ_Personnalités P	
14564	14563	ZZZZ_Personnalités PA	
14565	14564	Pa Kin	
14566	14564	Pabst Georg Wilhelm	
14567	14564	Pacary Michel	affaire politico-financière
14568	14564	Pacchioni Henri	
14569	14564	Pacciani Pietro	
14570	14564	Pacino Al	
14571	14564	Packwood Robert	
14572	14564	Paco Rabanne	
14573	14564	Pacquement Alfred	
14574	14564	Pacé Bertrand	skipper
14575	14564	Padilla José	
14576	14564	Padioleau Jean G.	chercheur au Groupe d'études des méthodes de l'analyse sociologique (Gemas-CNRS)
14577	14564	Paecht Arthur	
14578	14564	Paez Fito	
14579	14564	Page Jimmy	
14580	14564	Pagezy Bernard	grand patron, ex-Axa et maintenant dans l'agroalimentaire
14581	14564	Pagliere Rodolfo	
14582	14564	Pagnol Marcel	
14583	14564	Pagès Jean-François	
14584	14564	Pagès Yves	Ecrivain
14585	14564	Pailhas Géraldine	
14586	14564	Paillole Paul	
14587	14564	Paillé Dominique	Député CDS des Deux-Sèvres
14588	14564	Paine Christopher	rapport US/essais nucléaires
14589	14564	Paisley Ian	unioniste protestant , initiateur du processusu de paix en Irlande du Nord
14590	14564	Pajon Michel	
14591	14564	Pajot Marc	
14592	14564	Paksas Rolandas	
14593	14564	Paladino Mimmo	
14594	14564	Paley Grace	
14595	14564	Pallier Denis	
14596	14564	Palmade Pierre	acteur
14597	14564	Palme Olof	
14598	14564	Pamuk Orhan	écrivain turc
14599	14564	Panafieu Françoise de	
14600	14564	Panafieu Guy de	
14601	14564	Panahi Jafar	
14602	14564	Pandraud Robert	
14603	14564	Pandy Andras	
14604	14564	Pangalos Théodore	
14605	14564	Panis Olivier	sport
14606	14564	Panizza Oscar	
14607	14564	Pankratov Denis	
14608	14564	Pannella Marco	
14609	14564	Panofsky Erwin	
14610	14564	Pantalacci Noël	
14611	14564	Pantani Marco	
14612	14564	Paoli Dominique	journaliste
14613	14564	Paoli Philippe	
14614	14564	Paoli Stéphane	
14615	14564	Paolini Nonce	 
14616	14564	Paolo Heusch	
14617	14564	Paolo Maldini	
14618	14564	Papandréou Andréas	
14619	14564	Papandréou Dimitra	
14620	14564	Papandréou Georges	
14621	14564	Papas Irène	
14622	14564	Papatakis Nico	
14623	14564	Papin Jean-Pierre	
14624	14564	Papon Maurice	
14625	14564	Pappalardo Michèle	
14626	14564	Pappano Antonio	
14627	14564	Paquet Gill	
14628	14564	Paquet Gérard	
14629	14564	Parachine Sergueï	directeur de la centrale de Tchernobyl
14630	14564	Paradis Vanessa	
14631	14564	Paradjanov Sergeï	
14632	14564	Paramo Pedro	
14633	14564	Paramonova Tatiana	
14634	14564	Paredes Marisa	Actrice
14635	14564	Parent Claude	
14636	14564	Parent Kevin	
14637	14564	Parera Vincent	
14638	14564	Paretti Giancarlo	
14639	14564	Pariente Gérard	
14640	14564	Pariente Patrick	
14641	14564	Parigot Michel	
14642	14564	Paris Jean	
14643	14564	Parisot Laurence	PdG de l'Ifop
14644	14564	Parizeau Jacques	
14645	14564	Park Nick	
14646	14564	Parker Alan	
14647	14564	Parker Bowles Camilla	
14648	14564	Parker Charlie	
14649	14564	Parker Dorothy	
14650	14564	Parker Maceo	
14651	14564	Parker Robert	
14652	14564	Parker William	
14653	14564	Parlier Yves	voile (nautisme)
14654	14564	Parly Florence	
14655	14564	Parmiggiani Claudio	
14656	14564	Parola Catherine	juge d'instruction des Affaires grenobloises de Carignon
14657	14564	Parr Martin	
14658	14564	Parry Natasha	
14659	14564	Partch Harry	
14660	14564	Pascal Blaise	
14661	14564	Pascal Christine	
14662	14564	Pascin	
14663	14564	Pasolini Pier-Paolo	
14664	14564	Pasqua Charles	
14665	14564	Pasqual Luis	
14666	14564	Pasquini Pierre	
14667	14564	Passard François	
14668	14564	Passer Ivan	
14669	14564	Pasternak Boris	
14670	14564	Pasteur Louis	
14671	14564	Pastor Rosana	
14672	14564	Pastorelli Jean-Claude	conseiller général (DVD) niçois
14673	14564	Patarroyo Manuel	
14674	14564	Patassé Ange Félix	
14675	14564	Patriat François	
14676	14564	Patrice Bailly-Salins	skieur
14677	14564	Patrice Blanc-Francard	
14678	14564	Patte Jean-Marie	
14679	14564	Patten Chris	
14680	14564	Paul Christian	
14681	14564	Paulhan Jean	
14682	14564	Paume Danielle	
14683	14564	Paumier Dominique	
14684	14564	Pauvert Jean-Jacques	éditeur
14685	14564	Pavarotti Luciano	ténor
14686	14564	Pavel Gratchev	
14687	14564	Pavel Thomas	
14688	14564	Pavese Cesare	
14689	14564	Paviot Bernadette	
14690	14564	Paxton Robert	
14691	14564	Paxton Steve	
14692	14564	Paye Jean-Claude	
14693	14564	Payet Valérie	
14694	14564	Payo San	
14695	14564	Pâris Tito	
14696	14564	Pâris-Duverney	
14697	14563	ZZZZ_Personnalités PE	
14698	14697	Pearl Jam	groupe de rock
14699	14697	Peck Gregory	
14700	14697	Peck Raoul	
14701	14697	Pecker Jean-Claude	astrophysicien de l'Académie des Sciences
14702	14697	Peckinpah Sam	
14703	14697	Pedroso Ivan	
14704	14697	Peduzzi François	
14705	14697	Peduzzi Laurent	
14706	14697	Peduzzi Richard	
14707	14697	Peebles James	cosmologue spécialiste de la datation de l'Univers et du Big Bang
14708	14697	Peeters Benoît	
14709	14697	Peillon Vincent	
14710	14697	Peirce Charles Sanders	philosophe (1839-1914)
14711	14697	Pelat Roger-Patrice	
14712	14697	Pelchat Michel	
14713	14697	Pelevine Viktor	
14714	14697	Pelham Grenville Wodehouse	auteur comique britannique
14715	14697	Pelisson Gérard	
14716	14697	Pellerin Christian	
14717	14697	Pellerin Pierre	Président du SCPRI jusqu'en 1994
14718	14697	Pelletier Hervé	
14719	14697	Pelletier Jacques	Médiateur de la République
14720	14697	Pelletier Monique	
14721	14697	Pelly Laurent	
14722	14697	Pelosi Nancy	 
14723	14697	Pelosi Pino	
14724	14697	Pelous Fabien	
14725	14697	Pelt Jean-Marie	
14726	14697	Peltier Léonard	
14727	14697	Pelège Michel	
14728	14697	Pelé	joueur brésilien de football
14729	14697	Peneau Xavier	
14730	14697	Penfentenyo Marie-Christine de	élue FN
14731	14697	Penn Arthur	
14732	14697	Penn Irving	Photographe
14733	14697	Penn Sean	
14734	14697	Pennac Daniel	
14735	14697	Pennebaker Don Alan	
14736	14697	Penone Giuseppe	
14737	14697	Penrose Roger	astrophysicien spécialiste des trous noirs
14738	14697	Per Norinder	PDG de Volvo France
14739	14697	Perafan Justo Pastor	
14740	14697	Perben Dominique	
14741	14697	Perdriel Claude	patron du Nouvel Obs
14742	14697	Perec Georges	
14743	14697	Pereira Fernando	Photographe décédé dans l'explosion du "Rainbow warrior"
14744	14697	Perennou Marie	cinéaste
14745	14697	Peretti Jean-Jacques de	
14746	14697	Peretz Amir	
14747	14697	Perez Carlos Andres	
14748	14697	Perez Vincent	
14749	14697	Perez de Cuellar Javier	
14750	14697	Perez-Reverte Arturo	
14751	14697	Perfetti Patrick	
14752	14697	Perigot Francois	
14753	14697	Perisic Momcilo	
14754	14697	Pernaut Jean-Pierre	journaliste et présentateur de télévision
14755	14697	Pernell Whitaker	boxeur
14756	14697	Pernette Nathalie	danseuse
14757	14697	Pernin Jean-François	
14758	14697	Pernoo Jérome	
14759	14697	Pernoud Georges	
14760	14697	Peron Evita	
14761	14697	Peron Juan	
14762	14697	Perot Ross	
14763	14697	Perote Juan Alberto	
14764	14697	Perpère Laurent	
14765	14697	Perrault Dominique	
14766	14697	Perrault Gilles	écrivain
14767	14697	Perrein Louis	
14768	14697	Perret Pierre	
14769	14697	Perrier Laurent	
14770	14697	Perrier Olivier	Comédien, metteur en scène théâtre
14771	14697	Perrin Francis	Acteur
14772	14697	Perrin Jacques (réalisateur)	
14773	14697	Perrin Laurent	documentariste
14774	14697	Perrineau Pascal	directeur du Centre d'étude de la vie politique française
14775	14697	Perros Georges	
14776	14697	Perrot Philippe	
14777	14697	Perrot Vincent	
14778	14697	Perry Henzell	cinéaste
14779	14697	Persichetti Paolo	
14780	14697	Persson Göran	
14781	14697	Perton Christophe	metteur en scène de théâtre
14782	14697	Perugorria Jorge	
14783	14697	Peschanski Denis	
14784	14697	Pesenti François-Michel	
14785	14697	Pesenti Giampiero	
14786	14697	Pesic Vesna	
14787	14697	Peskine Nicolas	
14788	14697	Pesnic Vesna	
14789	14697	Pessis-Pasternak Guitta	
14790	14697	Pessoa Fernando	livre d'Antonio Tabucchi sur ses derniers jours
14791	14697	Pestel Dominique	
14792	14697	Pet Shop Boys	
14793	14697	Peterhansel Stéphane	champion de moto - rallye et course
14794	14697	Peters Ellis	
14795	14697	Petersen Wolfgang	
14796	14697	Petit Cécile	
14797	14697	Petit Elisabeth	
14798	14697	Petit Emmanuel	
14799	14697	Petit Jean-Claude	
14800	14697	Petit Marc	
14801	14697	Petit Roland	
14802	14697	Petkoff Teodoro	
14803	14697	Petri Kokko	patineur sur glace
14804	14697	Petrossian Levon Ter	
14805	14697	Petrovitch-Njegosh Nicolas	
14806	14697	Peuron Michel	
14807	14697	Peymann Claus	Directeur du Burgtheater de Vienne
14808	14697	Peyo	
14809	14697	Peyrat Jacques	
14810	14697	Peyrefitte Alain	député-maire de Provins
14811	14697	Peyrelevade Jean	
14812	14697	Peyret Jean-François	
14813	14697	Peyron Bruno	navigateur
14814	14697	Peyron Loïck	
14815	14697	Peyron Stéphane	
14816	14697	Peyré Serge	
14817	14697	Pezet Michel	
14818	14697	Pezzetta Roberto	Designer
14819	14697	Péan Pierre	
14820	14697	Pébereau Georges	
14821	14697	Pébereau Michel	Patron de la BNP
14822	14697	Péchon Rachel	
14823	14697	Pécresse Valérie	 
14824	14697	Péninou Jean-Louis	
14825	14697	Pépy Guillaume	
14826	14697	Pérec Marie-José	
14827	14697	Péricard Michel	maire RPR de Saint-Germain-en-Laye
14828	14697	Périssol Pierre-André	secr. nat. au logement/RPR/chiraquien
14829	14697	Pérol Georges	ancien directeur de l'OPac de Paris
14830	14697	Péry Nicole	
14831	14697	Pérès Shimon	
14832	14697	Pétain Philippe	
14833	14697	Pétetin Eric	
14834	14697	Pétin Laurent	
14835	14697	Pétriat Jean-Louis	
14836	14563	ZZZZ_Personnalités PF	
14837	14836	Pfeiffer Didier	
14838	14836	Pfeiffer Michelle	
14839	14836	Pfimlin Rémy	
14840	14836	Pflimlin Etienne	
14841	14836	Pflüger Friedbert	
14842	14563	ZZZZ_Personnalités PH	
14843	14842	Phan Van Khai	vice-Premier ministre vietnamien
14844	14842	Phil Aglang	réalisateur britannique
14845	14842	Phil Rees	
14846	14842	Philibert Cédric	
14847	14842	Philibert Jean-Pierre	
14848	14842	Philibert Nicolas	
14849	14842	Philipe Gérard	
14850	14842	Philipp Whitehead	réalisatrice de documentaire
14851	14842	Philippe Pierre	
14852	14842	Philippe Thélin	
14853	14842	Philippe de Belgique	
14854	14842	Phillipps Martin	
14855	14842	Phillips Tom	
14856	14842	Phoenix Joaquin	
14857	14842	Phoolan Devi	
14858	14842	Zimmermann Philip	mathématicien, informaticien
14859	14563	ZZZZ_Personnalités PI	
14860	14859	Coubertin Pierre de	auteur du "manifeste olympique"
14861	14859	Piaf Edith	
14862	14859	Piaget Jean	
14863	14859	Pialat Maurice	
14864	14859	Piano Renzo	
14865	14859	Piat Laetitia	fille de Yann Piat
14866	14859	Piat Yann	
14867	14859	Piazza Alberto	professeur de génétique des populations à l'université de Turin
14868	14859	Piazzolla Astor	
14869	14859	Pic Roger	
14870	14859	Picabia Francis	
14871	14859	Picard Franck	skieur
14872	14859	Picasso Pablo	
14873	14859	Piccoli Michel	
14874	14859	Pichel Irving	
14875	14859	Pichon Jean-Louis	metteur en scène d'opéra
14876	14859	Pickvance Ronald	
14877	14859	Picq Jean	
14878	14859	Picq Pascal	
14879	14859	Picquier Philippe	
14880	14859	Pie XII	
14881	14859	Pienaar françois	
14882	14859	Pierantoni Stéphane	
14883	14859	Pierce Jim	Tennis
14884	14859	Pierce Mary	
14885	14859	Pieri Charles	
14886	14859	Piero Grandi	
14887	14859	Piero della Francesca	
14888	14859	Pierrat Emmanuel	
14889	14859	Pierre Descaves	
14890	14859	Pierre Fond	
14891	14859	Pierre-Brossolette Sylvie	
14892	14859	Pierrelée Marie-Danièle	
14893	14859	Pierret Christian	
14894	14859	Pierson Frank	cinéaste us
14895	14859	Pierson Jean	
14896	14859	Pietragalla Marie-Claude	
14897	14859	Pietrangeli Carlo	
14898	14859	Pietri Jean-Fabrice	
14899	14859	Piettre Bernard	Professeur de philosophie
14900	14859	Pignon-Ernest Ernest	
14901	14859	Piketty Thomas	
14902	14859	Pilcher Rosamunde	
14903	14859	Pilhan Jacques	PDG de l'agence Temps public
14904	14859	Pinatton Jean-Pierre	
14905	14859	Pinault François	
14906	14859	Pinault François-Henri	
14907	14859	Pinay Antoine	
14908	14859	Pincemin Jean-Pierre	
14909	14859	Pineau-Valencienne Didier	
14910	14859	Pingeot Mazarine	
14911	14859	Pinget Robert	
14912	14859	Pink Floyd	
14913	14859	Pino Pagani	
14914	14859	Pinochet Augusto	
14915	14859	Pinoteau Claude	
14916	14859	Pinte Etienne	
14917	14859	Pinter Harold	
14918	14859	Pintilié Lucian	
14919	14859	Pioline Cédric	joueur de tennis
14920	14859	Piot Peter	micro-biologiste de l'OMS
14921	14859	Pipilotti Rist	jeune artiste Suisse
14922	14859	Pippo Baudo	animateur télé italien original
14923	14859	Pires Maria Joao	
14924	14859	Pires Robert	
14925	14859	Pirotte Jean-claude	
14926	14859	Pischetsrieder Bernd	
14927	14859	Pitoiset Dominique	
14928	14859	Pitoëff Georges	
14929	14859	Pitoëff Ludmilla	
14930	14859	Pitoëff Sacha	
14931	14859	Pitt Brad	
14932	14859	Pitte Jean-Robert	
14933	14859	Pivot Bernard	directeur de "Lire"
14934	14563	ZZZZ_Personnalités PL	
14935	14934	Placebo (musique)	
14936	14934	Plamondon Luc	
14937	14934	Planchon Roger	
14938	14934	Planhol Xavier de	
14939	14934	Plant Robert	
14940	14934	Plantu Jean	
14941	14934	Plassard Denis	
14942	14934	Plassat Georges	
14943	14934	Plasson Michel	
14944	14934	Plastercaster Cynthia	
14945	14934	Platel Alain	Choregraphe belge
14946	14934	Platini Michel	football
14947	14934	Platon	
14948	14934	Platonov Andreï	
14949	14934	Platzeck Matthias	 
14950	14934	Plavsic Biljana	
14951	14934	Plaziat Christian	athlète
14952	14934	Plisson Bruno	
14953	14934	Plissonnier Gaston	
14954	14934	Plog Jobst	
14955	14934	Plon Michel	
14956	14563	ZZZZ_Personnalités PO	
14957	14956	Podalydès Bruno	
14958	14956	Poe Edgar	
14959	14956	Poggioli Pierre	
14960	14956	Poher Alain	
14961	14956	Poignant Bernard	
14962	14956	Poincaré Nicolas	
14963	14956	Poindron Eric	
14964	14956	Poinssot Alain	nouveau directeur à la SNCF responsable de Socrate
14965	14956	Poirier Manuel	
14966	14956	Poiré Jean-Marie	cineaste français
14967	14956	Poitier Sydney	
14968	14956	Poivre d'Arvor Patrick	
14969	14956	Pokas Ewa	
14970	14956	Pol Pot	
14971	14956	Polac Michel	
14972	14956	Polanski Roman	
14973	14956	Polga Bruno	
14974	14956	Poliakov Léon	
14975	14956	Polke Sigmar	
14976	14956	Pollack Sydney	
14977	14956	Pollard Robert	
14978	14956	Pollet Françoise	
14979	14956	Pollet Jean-Daniel	
14980	14956	Polnareff Michel	
14981	14956	Pombo Alvaro	
14982	14956	Pommerat Joël	
14983	14956	Pommereau Xavier	psychiatre
14984	14956	Pompidou Georges	
14985	14956	Poncelet Christian	
14986	14956	Ponge Francis	
14987	14956	Poniatowski Ladislas	
14988	14956	Poniatowski Michel	sénateur du Val-D'Oise
14989	14956	Pons Bernard	
14990	14956	Pons Ventura	
14991	14956	Ponsin Jean-Claude	
14992	14956	Ponsolle Patrick	
14993	14956	Ponson Gérard	
14994	14956	Pont Jean-Pierre	
14995	14956	Pontalis Jean-Bertrand	psychanalyste, éditeur et traducteur de Freud
14996	14956	Pontecorvo Gillo	
14997	14956	Pontet Philippe	
14998	14956	Ponti Claude	
14999	14956	Pontone Antoine	
15000	14956	Poperen Claude	
15001	14956	Poperen Jean	
15002	14956	Popieluszko Jerzy	
15003	14956	Popov Alexandre	
15004	14956	Popovic Alexandre	écrivain
15005	14956	Popper Karl	
15006	14956	Porraz Jean-Luc	
15007	14956	Porte Bernard	Président du groupe Bayard presse
15008	14956	Portelli Serge	
15009	14956	Porter Cole	
15010	14956	Portillo Alfonso	
15011	14956	Portillo Michael	
15012	14956	Portishead	Rock
15013	14956	Portolan Claude	
15014	14956	Portolu Elias	
15015	14956	Portzamparc Christian de	
15016	14956	Porzner Konrad	
15017	14956	Post Ted	
15018	14956	Poster Children	groupe de pop
15019	14956	Potanine Vladimir	
15020	14956	Potard Donald	
15021	14956	Pottecher Frédéric	chroniqueur judiciaire
15022	14956	Pottecher Maurice	
15023	14956	Poujade Pierre	
15024	14956	Poulet Dachary Jean-Claude	maire-adjoint FN de Toulon
15025	14956	Poulet Fred	
15026	14956	Poulidor Raymond	cyclisme
15027	14956	Poupaud Melvil	
15028	14956	Poupon Philippe	
15029	14956	Pourre Annie	
15030	14956	Pousseur Isabelle	
15031	14956	Poussin Gérald	
15032	14956	Poussin Nicolas	
15033	14956	Poutine Vladimir	
15034	14956	Pouy Jean-Bernard	
15035	14956	Poveda Christian	
15036	14956	Powell Colin	
15037	14956	Powell Michael	réalisateur de série B
15038	14956	Powell Poker	
15039	14956	Powys John Cowper	
15040	14956	Pozza Henri	
15041	14563	ZZZZ_Personnalités PR	
15042	15041	Prada Michel	
15043	15041	Prada Miuccia	
15044	15041	Pradal Manuel	
15045	15041	Pradel Jacques	
15046	15041	Praderie Françoise	Françoise Praderie est astronome à l'Observatoire de Paris et ancienne coordinatrice du Forum Mégascience de l'OCDE.
15047	15041	Pradille Claude	
15048	15041	Prado Miguelanxo	
15049	15041	Prain Roger	pdg banque Vernes
15050	15041	Pramoedya Ananta Toer	écrivain javanais
15051	15041	Prat Louis-Antoine	
15052	15041	Pratt Hugo	BD
15053	15041	Preisner Zbigniew	
15054	15041	Preljocaj Angelin	Danse
15055	15041	Preminger Otto	
15056	15041	Prescott John	
15057	15041	Presley Elvis	
15058	15041	Presley Lisa-Marie	
15059	15041	Prestat Alain	
15060	15041	Presti Philippe	
15061	15041	Previtali Giovanni	
15062	15041	Priebke Erich	ex-nazi, responsable d'un massacre en ITALIE
15063	15041	Prieur Dominique	
15064	15041	Prieur Jérôme	
15065	15041	Prigent Christian	écrivain
15066	15041	Prigent Michel	
15067	15041	Prigogine Ilya	scientifique, Prix Nobel de Chimie
15068	15041	Primakov Evgueni	
15069	15041	Primorac Boro	affaire OM-VA
15070	15041	Prince (chanteur)	chanteur de rock
15071	15041	Princen Jan	
15072	15041	Privet Pascal	
15073	15041	Probst Jean-François	
15074	15041	Prodi Romano	
15075	15041	Proglio Henri	
15076	15041	Prokofiev Sergueï	musicien
15077	15041	Propellerheads (The)	
15078	15041	Prost Alain	
15079	15041	Prost Grégory	
15080	15041	Proulx E. Annie	
15081	15041	Proust Christian	
15082	15041	Proust Cécile	
15083	15041	Proust Marcel	écrivain
15084	15041	Prouteau Christian	commandant de gendarmerie
15085	15041	Prouvost Evelyne	
15086	15041	Provost Lucile	pseudonyme d'un haut-fonctionnaire
15087	15041	Prunenec Sylvain	
15088	15041	Prunier William	
15089	15041	Pryce Jonathan	
15090	15041	Prédali Jean-Baptiste	écrivain politique
15091	15041	Préval René	
15092	15041	Prévert Jacques	poète
15093	15041	Prévert Pierre	cinéaste
15094	15041	Prévost Daniel	
15095	15041	Prêtre Georges	
15096	14563	ZZZZ_Personnalités PU	
15097	15096	Puccini Giacomo	
15098	15096	Puech Jean	
15099	15096	Puel Caroline	
15100	15096	Puente Tito	
15101	15096	Pujadas David	
15102	15096	Pujol Jordi	
15103	15096	Pullman Bill	
15104	15096	Pulp	
15105	15096	Purcarete Silviu	metteur en scène roumain
15106	15096	Purcell Henri	
15107	15096	Purdy James	
15108	15096	Puren Coraline	
15109	15096	Putman Andrée	
15110	14563	ZZZZ_Personnalités PY	
15111	15110	Py Olivier	
15112	7428	ZZZZ_Personnalités Q	
15113	15112	Qoreï Ahmed	
15114	15112	ZZZZ_Personnalités QA	
15115	15112	ZZZZ_Personnalités QI	
15116	15115	Qiao Shi	
15117	15112	ZZZZ_Personnalités QU	
15118	15117	Quadruppani Serge	
15119	15117	Quaretta Bernard	
15120	15117	Qubilah Bahiyah Shabazz	fille de Malcolm X
15121	15117	Queiroz Rachel de	
15122	15117	Quemin Alain	
15123	15117	Queneau Raymond	
15124	15117	Quentin Didier	
15125	15117	Querry Ron	
15126	15117	Queyranne Jean-Jack	
15127	15117	Quignard Pascal	écrivain
15128	15117	Quilicus Mariotti	Maçon,inculpé pour escroquerie
15129	15117	Quilliot Roger	
15130	15117	Quilès Paul	député PS
15131	15117	Quim Monzo	Ecrivain catalan
15132	15117	Quincey Thomas de	
15133	15117	Quine Richard	
15134	15117	Quiroga Horacio	
15135	7428	ZZZZ_Personnalités R	
15136	15135	ZZZZ_Personnalités RA	
15137	15136	Rabbo Yasser Abed	
15138	15136	Rabelais François	
15139	15136	Rabette Erick	
15140	15136	Rabier Benjamin	
15141	15136	Rabin Leah	
15142	15136	Rabin Noa	
15143	15136	Rabin Yitzhak	
15144	15136	Racamier henri	
15145	15136	Rachid Baba-Ahmed	pionnier du raï tué par les islamistes
15146	15136	Rachid Chebchoub	
15147	15136	Rachid Masharawi	cinéaste palestinien
15148	15136	Rachid O.	écrivain
15149	15136	Racine Jean	
15150	15136	Raddad Omar	
15151	15136	Radford Michael	
15152	15136	Radi Lamia	cartographe
15153	15136	Radigues Patrick de	
15154	15136	Radiohead	
15155	15136	Radjavi Kazem	
15156	15136	Radjavi Maryam	
15157	15136	Radman Miroslav	chercheur scientifique
15158	15136	Rafael Caride-Simon	
15159	15136	Rafael Vera	ancien secrétaire d'Etat Espagnol à la sécurité impliqué dans le procès du GAL
15160	15136	Rafaël Aguilar	danseur et chorégraphe espagnol
15161	15136	Rafelson Bob	
15162	15136	Raffarin Jean-Pierre	
15163	15136	Raffinot François	
15164	15136	Raffour Louis-Bertrand	
15165	15136	Rafsandjani Ali Akbar Hachemi	
15166	15136	Rafter Patrick	tennis
15167	15136	Ragaru Nadège	
15168	15136	Ragnotti Jean	courreur automobile
15169	15136	Rahilou Khalid	boxeur
15170	15136	Rahim Khushnawaz	joueur de rubâb afghan
15171	15136	Rahmane Omar Abdel	chef religieux égyptien inculpé dans un attentat à New York
15172	15136	Raikin Constantin	
15173	15136	Raiman Pierre	
15174	15136	Raimi Sam	
15175	15136	Raimu	
15176	15136	Raincourt Henri de	
15177	15136	Rainer Yvonne	
15178	15136	Rainier de Monaco	
15179	15136	Rainsy Sam	
15180	15136	Rais Amien	
15181	15136	Rajfus Maurice	historien de la seconde guerre mondiale
15182	15136	Raji Sourani	Avocat palestinien
15183	15136	Rajoub Jibril	
15184	15136	Rajoy Mariano	
15185	15136	Rajsfus Maurice	écrivain
15186	15136	Ralite Jack	
15187	15136	Ralph Benatzky	
15188	15136	Ramadan Tariq	
15189	15136	Ramade Patrick	conservateur du musée des Beaux-Arts de Valence
15190	15136	Ramaphosa Cyril	
15191	15136	Rambaud Patrick	
15192	15136	Rambaud Yves	
15193	15136	Ramda Rachid	
15194	15136	Rameau Jean-Philippe	
15195	15136	Rameix Gérard	directeur depuis 1993 de la CNAM
15196	15136	Ramin Gray	
15197	15136	Ramis Harold	réalisateur
15198	15136	Ramon Haïm	
15199	15136	Ramon J. Velasquez	
15200	15136	Ramon Jose Sender	écrivain espagnol
15201	15136	Ramon Mendoza	
15202	15136	Ramond Philippe	president de technisonor
15203	15136	Ramonet Ignacio	directeur du Monde diplomatique
15204	15136	Rampling Charlotte	
15205	15136	Ramtahalsingh Roepsingh	
15206	15136	Ramuz Charles-Ferdinand	
15207	15136	Ramzi Ahmed Youssef	terroriste islamiste impliqué dans l'attentat du World trade center
15208	15136	Ranariddh Norodom	prince du Cambodge
15209	15136	Rancière Jacques	Ecrivain
15210	15136	Rand Miller	créateur de jeu multimédia
15211	15136	Rannou Jean	
15212	15136	Ranque Denis	
15213	15136	Ransmayr Christoph	
15214	15136	Rao Shanta	
15215	15136	Raoul Villain	
15216	15136	Raoult Eric	
15217	15136	Raoux Guillaume	
15218	15136	Raphaël Mechoulam	
15219	15136	Rapp Bernard	
15220	15136	Rappeneau Jean-Paul	
15221	15136	Raquel Welch	actrice
15222	15136	Raskine Michel	
15223	15136	Rassat Michèle-Laure	
15224	15136	Ratman Mani	cinéaste indien
15225	15136	Ratsirahonana Norbert	
15226	15136	Ratsiraka Didier	
15227	15136	Rattle Simon	
15228	15136	Rau Johannes	
15229	15136	Rausch Jean-Marie	
15230	15136	Rauschenberg Robert	
15231	15136	Ravalec Vincent	Romancier
15232	15136	Ravalomanana Marc	
15233	15136	Ravanelli Fabrizio	
15234	15136	Ravanne Maurice	
15235	15136	Raveau Didier	
15236	15136	Ravel Maurice	
15237	15136	Ravey Yves	écrivain
15238	15136	Ravony Francisque	
15239	15136	Rawlings Jerry	
15240	15136	Rawls John	
15241	15136	Ray Man	
15242	15136	Ray Nicholas	
15243	15136	Ray Sandip	cinéaste, fils de Satyajit Ray
15244	15136	Ray Satyajit	cinéaste indien
15245	15136	Raymond Lamontagne	Maire de Sarcelles (Val-d'Oise)
15246	15136	Raymond Loewy	designer industriel (1893-1986)
15247	15136	Raymond Moretti	sculpteur
15248	15136	Raymond Sibille	
15249	15136	Raymond W.Smith	
15250	15136	Raynal Patrick	
15251	15136	Raznatovic Zeljko	Chef d'une milice serbe
15252	15135	ZZZZ_Personnalités RE	
15253	15252	REM (musique)	groupe de rock
15254	15252	Reagan Ronald	
15255	15252	Rebaud Dominique	
15256	15252	Rebelo de Sousa Marcelo	
15257	15252	Rebillard Alain	PDG
15258	15252	Rebois Marie-Hélène	
15259	15252	Rebotier Jacques	compositeur et homme de theâtre
15260	15252	Rebsamen François	
15261	15252	Rebérioux Madeleine	
15262	15252	Recht Roland	
15263	15252	Redford Robert	
15264	15252	Redman Dewey	
15265	15252	Redman Joshua	
15266	15252	Redolfi Michel	
15267	15252	Redwood John	
15268	15252	Reed Carol	
15269	15252	Reed John	
15270	15252	Reed Lou	
15271	15252	Reeve Christopher	
15272	15252	Reeves Hubert	
15273	15252	Reeves Keanu	
15274	15252	Reggiani Patrizia	
15275	15252	Reggiani Serge	
15276	15252	Regnault François	
15277	15252	Rego Luis	
15278	15252	Rehn Elisabeth	
15279	15252	Reich Steve	
15280	15252	Reich-Ranicki marcel	
15281	15252	Reichenbach Carlos	
15282	15252	Reid Vernon	
15283	15252	Reiller Jacques	
15284	15252	Reiner Rob	
15285	15252	Reinhard Fink	Sidéen en procès pour utilisation de cannabis à fin thérapeutique
15286	15252	Reiser Jean-Marc	dessinateur décédé le 5/11/1983
15287	15252	Reisinger Marc	
15288	15252	Reisz Karel	
15289	15252	Reitz Dana	
15290	15252	Rembrandt	peintre
15291	15252	Remilleux Jean-Louis	
15292	15252	Renato Ruggiero	
15293	15252	Renaud	
15294	15252	Renaud Beffeyte	
15295	15252	Renaud Lecadre	
15296	15252	Renaud Line	
15297	15252	Renaud Madeleine	
15298	15252	Renaud Serge	
15299	15252	Rendell Ruth	
15300	15252	Reno Ginette	
15301	15252	Reno Jean	
15302	15252	Renoir Auguste	peintre
15303	15252	Renoir Axelle	
15304	15252	Renoir Jean	cinéaste français
15305	15252	Renoult Daniel	
15306	15252	Renoux Jean-Louis	
15307	15252	Renucci Robin	
15308	15252	Renzi Philippe	
15309	15252	René Desmaison	alpiniste
15310	15252	René L'Helguen	
15311	15252	René Laurentin	prêtre et théologien spécialiste des madones qui pleurent
15312	15252	René Lenoir	ancien secrétaire d'Etat à l'Action sociale
15313	15252	René Rouquet	maire PS d'Alfortville
15314	15252	Renée Poznanski	écrivain
15315	15252	Resnais Alain	
15316	15252	Restano Yndamiro	
15317	15252	Reuter Edzard	
15318	15252	Rev Martin	
15319	15252	Revault Christophe	
15320	15252	Reve Gérard	
15321	15252	Revel Jean-François	
15322	15252	Revol Jean-Luc	
15323	15252	Rexrodt Guenter	
15324	15252	Rey Florence	
15325	15252	Rey Oropeza	musicien du groupe de rap Downset
15326	15252	Rey Rosa Rodrigo	
15327	15252	Rey Thierry	
15328	15252	Reyes Alina	
15329	15252	Reynolds Kevin	
15330	15252	Reyt Michel	
15331	15252	Reza Yasmina	
15332	15252	Rezvani Serge	
15333	15252	Rébéna Frédéric	
15334	15252	Réda Jacques	
15335	15252	Régine	
15336	15252	Régis Singer	
15337	15252	Régnier Michel	
15338	15252	Régy Claude	metteur en scène/théâtre
15339	15252	Rémi Landais	
15340	15252	Rémond Alain	Juornaliste critique TV à Télérama
15341	15252	Rémond René	
15342	15252	Rémy Halbwax	
15343	15252	Rémy Muzeau	
15344	15252	Rémès Eric	journaliste libé
15345	15252	Rénier Yves	
15346	15252	Réveillon Jean	
15347	15252	Révillon Marie-Madeleine	
15348	15135	ZZZZ_Personnalités RH	
15349	15348	Rheims Bettina	photographe
15350	15348	Rheims Maurice	le + connu des commissaires-priseurs français
15351	15135	ZZZZ_Personnalités RI	
15352	15351	Riakhovski Sergueï	
15353	15351	Ribbentrop Joachim von	
15354	15351	Ribes Edouard de	
15355	15351	Ribes Jean-Michel	
15356	15351	Ribot Marc	
15357	15351	Riboud Antoine	
15358	15351	Riboud Franck	
15359	15351	Riboud Marc	
15360	15351	Ricard Jean-François	juge d'instruction chargé de l'Affaire du pasteur Doucé
15361	15351	Riccardi Andrea	
15362	15351	Riccardo Muti	chef d'orchestre
15363	15351	Ricci Nina	
15364	15351	Riccobono Maurice	
15365	15351	Rice Condoleezza	
15366	15351	Rich Charlie	
15367	15351	Richard Alain	
15368	15351	Richard Bernard	militaire à la retraite
15369	15351	Richard Fenwick	
15370	15351	Richard Goldstone	procureur sud-africain/Tribunal inter./Rwanda
15371	15351	Richard Linklater	metteur en scène américain
15372	15351	Richard Nathalie	
15373	15351	Richard Pierre	
15374	15351	Richard Zachary	
15375	15351	Richards Eugene	
15376	15351	Richards Keith	
15377	15351	Richards Michael	
15378	15351	Richards Thomas	
15379	15351	Richardson Bill	
15380	15351	Richepin Jean	
15381	15351	Richert Philippe	
15382	15351	Richet Jean-François	
15383	15351	Richier Germaine	
15384	15351	Richter Daniel	
15385	15351	Richter Gerhard	
15386	15351	Richter Sviatoslav	pianiste
15387	15351	Rickman Alan	
15388	15351	Ricoeur Paul	philosophe
15389	15351	Ricol René	président du Conseil suéprieur de l'ordre des experts-comptables
15390	15351	Ridley Philip	
15391	15351	Riefenstahl Leni	
15392	15351	Riess-Passer Suzanne	
15393	15351	Rifkin Jeremy	Economiste américain pour le partage du temps de travail
15394	15351	Rifkind Malcolm	
15395	15351	Rifkind Michael	
15396	15351	Rigaud Jacques	PDG de RTL
15397	15351	Rigout Alain	
15398	15351	Riis Bjarne	
15399	15351	Riley Terry	
15400	15351	Rilke Rainer Maria	
15401	15351	Rimareix Gaston	
15402	15351	Rimbaud Arthur	poète évanescent
15403	15351	Rios Marcelo	
15404	15351	Riou Alain	écrivain et professeur de droit à la faculté de Marseille
15405	15351	Riou Patrick	
15406	15351	Riou Vincent	
15407	15351	Rioult Pascal	Danse
15408	15351	Ripstein Arturo	
15409	15351	Risi Dino	
15410	15351	Rist Christian	
15411	15351	Rita Mitsouko	
15412	15351	Rivasi Michèle	fondatrice de la Crii-Rad en 1986
15413	15351	Rivera Diego	
15414	15351	Rivera Manuel	
15415	15351	Rivera Ordonez Francisco	
15416	15351	Rivers Dick	
15417	15351	Rivet Paul	
15418	15351	Rivette Jacques	
15419	15351	Rivière Valérie	
15420	15351	Rivière Véronique	
15421	15351	Rizzardo René	
15422	15135	ZZZZ_Personnalités RO	
15423	15422	Roach Hal	
15424	15422	Robbe Hervé	
15425	15422	Robbe Pierre	
15426	15422	Robbe-Grillet Alain	
15427	15422	Robbins Jérome	
15428	15422	Robbins Tim	
15429	15422	Robert Coffy	archevêque de Marseille
15430	15422	Robert Denis	ex-journaliste Libération
15431	15422	Robert Doboeuf	Personne agée
15432	15422	Robert Ganzo	Poète
15433	15422	Robert Guez	metteur en scène de série télé
15434	15422	Robert Herin	
15435	15422	Robert Jainin	auteur de livre scientifique pour les enfants
15436	15422	Robert Jarry	maire de la ville du Mans
15437	15422	Robert Krueger	Ambassadeur américain au Burundi
15438	15422	Robert Lafont	repreneur du Quotidien de Paris
15439	15422	Robert Yves	
15440	15422	Robert Yvon	
15441	15422	Robert de Montesquiou-Fezensac	comte anglais peintre (1855-1921)
15442	15422	Robert-André Vivien	
15443	15422	Roberts Julia	actrice américaine
15444	15422	Roberts Kenny	
15445	15422	Roberts Michèle	
15446	15422	Robertson David	musicien
15447	15422	Robertson George	
15448	15422	Robertson Pat	
15449	15422	Robertson Robbie	
15450	15422	Robial Etienne	directeur artistique de Canal plus
15451	15422	Robien Gilles de	
15452	15422	Robin Dany	
15453	15422	Robin Marie-Monique	
15454	15422	Robin Michel	
15455	15422	Robin Muriel	
15456	15422	Robinson Daron	
15457	15422	Robinson Mary	
15458	15422	Robles Rodolfo	
15459	15422	Robuchon Joël	
15460	15422	Robyn Miller	créateur de jeu multimédia
15461	15422	Rocard Michel	
15462	15422	Rocca Serra Jean-Paul de	
15463	15422	Rocca-Serra Sébastien de	Maire RPR de Zonza
15464	15422	Rocco Forte	Pdg groupe hôtellier et de restauration britannique Forte
15465	15422	Rocha Paulo	
15466	15422	Rochant Eric	
15467	15422	Roche Alain	
15468	15422	Roche Denis	
15469	15422	Rochefort Christiane	
15470	15422	Rochelle Redfield	
15471	15422	Rocheman Lionel	
15472	15422	Rochet Marc	PDG d' AOM
15473	15422	Rocheteau Dominique	
15474	15422	Roché Henri-Pierre	
15475	15422	Rockwell Alexander	
15476	15422	Rod Davis	skipper de One Australia
15477	15422	Rod Hardy	réalisateur américain de série télévisée
15478	15422	Roda-Gil Etienne	parolier situationniste
15479	15422	Rodenbach Georges	
15480	15422	Rodger George	photographe
15481	15422	Rodier Jean-Pierre	
15482	15422	Rodin Auguste	
15483	15422	Rodionov Igor	Ministre de la Défense russe
15484	15422	Rodolphe Pesce	Maire PS de Valence
15485	15422	Rodrigues Nelson	
15486	15422	Rodriguez Jesusa	dirige la compagnie "les Divas du Mexique"
15487	15422	Rodriguez Orejuela	
15488	15422	Rodriguez Oscar	
15489	15422	Rodriguez Robert	
15490	15422	Rodriguez Saa Adolfo	
15491	15422	Rogard Pascal	
15492	15422	Roger Chinaud	
15493	15422	Roger Ouvrard	PCF/Argenteuil
15494	15422	Rogers Ginger	
15495	15422	Rogge Jacques	
15496	15422	Rogge Leslie	
15497	15422	Roh Moo-hyun	
15498	15422	Roh Tae-Woo	
15499	15422	Rohan Josselin de	
15500	15422	Rohatyn Félix	
15501	15422	Rohmer Eric	cinéaste français
15502	15422	Roig Marie-Josée	
15503	15422	Roisin Thierry	
15504	15422	Rol-Tanguy Francis	
15505	15422	Roland De Pauw	
15506	15422	Roland Nungesser	député-maire de Nogent-sur-Marne et président de Carrefour du gaullisme
15507	15422	Roland Paskoff	Professeur de géographie physique
15508	15422	Roland Rowland	fondateur de Lonrho
15509	15422	Roland Thierry	
15510	15422	Roldan Luis	espagnol mis en cause dans une Affaire
15511	15422	Rolf Fehlbaum	
15512	15422	Rolin Jean	
15513	15422	Rolin Olivier	
15514	15422	Rolland Thierry	
15515	15422	Rollin Jean	
15516	15422	Rolling Stones	
15517	15422	Rollins Sonny	
15518	15422	Rollès Hélène	
15519	15422	Romain Bichara	
15520	15422	Romain Hippolyte	
15521	15422	Romain Migliorini	
15522	15422	Roman Joël	
15523	15422	Roman Petre	
15524	15422	Romand Jean-Claude	
15525	15422	Romani Roger	
15526	15422	Romanov Georges Mikhailovitch	
15527	15422	Romeo Leblanc	nouveau gouverneur général du Canada
15528	15422	Romero Jean-Luc	
15529	15422	Rominger Tony	
15530	15422	Romiti Cesare	
15531	15422	Ron Arad	pilote israélien abattu en 1986 au-dessus du Liban
15532	15422	Ron Brown	
15533	15422	Ron Sommer	directeur de Sony/Europe
15534	15422	Ronald Green	Avocat new-yorkais
15535	15422	Ronald O. Perelman	Président du conseil d'administration du musée Guggenheim de New-York
15536	15422	Ronconi Luca	
15537	15422	Rondot Philippe	
15538	15422	Ronis Willy	
15539	15422	Ronnie Kray	criminel célèbre des années 60 à Londres
15540	15422	Ronse Henri	
15541	15422	Roosevelt Franklin Delano	
15542	15422	Roots	Groupe de musique hip hop
15543	15422	Roquemaurel Gérald de	vice-PdG d'Hachette
15544	15422	Ros Hunt	prêtresse anglicane, a décidé de se revendiquer publiquement comme lesbienne
15545	15422	Rosa Alma	
15546	15422	Rosanvallon Pierre	économiste
15547	15422	Rose Ann Dimalanta	
15548	15422	Roseau Jacques	
15549	15422	Rosen Michel de	
15550	15422	Rosenberg Pierre	
15551	15422	Rosier Michèle	
15552	15422	Rosinski Grzegorz	
15553	15422	Rosnay Joël de	
15554	15422	Rosner Jacques	
15555	15422	Ross Dennis	
15556	15422	Ross Devenish	
15557	15422	Rossellini Isabella	
15558	15422	Rossellini Roberto	Réalisateur italien
15559	15422	Rosset Marc	tennisman
15560	15422	Rossi Bernard	
15561	15422	Rossi Christian	auteur de BD
15562	15422	Rossi Jean-Michel	
15563	15422	Rossi José	ministre de l'industrie
15564	15422	Rossi Paolo	
15565	15422	Rossi Valentino	
15566	15422	Rossif Frédéric	
15567	15422	Rossignol Joseph	PS/Limeil-Brévannes
15568	15422	Rossignon Christophe	
15569	15422	Rossini Gioacchino	
15570	15422	Rossinot André	Ministre de la Fonction publique
15571	15422	Rossiter Martin	starlette de la pop anglaise, leader du groupe Gene
15572	15422	Rosso Medardo	
15573	15422	Rossot Alain	conseiller général de l'Isère
15574	15422	Rostand Edmond	ecrivain
15575	15422	Rosten Leo	
15576	15422	Rostropovitch Mstislav	
15577	15422	Rotblat Joseph	
15578	15422	Rotcage Lionel	
15579	15422	Roth Henry	
15580	15422	Roth Patrick	
15581	15422	Roth Philip	
15582	15422	Roth Tim	
15583	15422	Rother Rainer	
15584	15422	Rothschild (famille)	
15585	15422	Rothé Bertrand	
15586	15422	Rotman Patrick	
15587	15422	Rouaud Jean	
15588	15422	Roubaud Jacques	
15589	15422	Rouch Jean	
15590	15422	Roudaut Jean	
15591	15422	Roudinesco Elisabeth	
15592	15422	Roudy Yvette	
15593	15422	Rouet Albert	
15594	15422	Roufs Gerry	
15595	15422	Rougelet Patrick	
15596	15422	Rouger Michel	
15597	15422	Rouland Jacques	
15598	15422	Roulet Daniel de	
15599	15422	Roulet Marcel	
15600	15422	Roumanoff Daniel	
15601	15422	Roumat Olivier	
15602	15422	Rousseau Jean-Jacques	
15603	15422	Roussel Raymond	
15604	15422	Rousselet André	
15605	15422	Roussely François	
15606	15422	Rousset Alain	
15607	15422	Roussillon Jean-Paul	
15608	15422	Roussin Michel	
15609	15422	Rousso Henry	historien
15610	15422	Roustan Didier	
15611	15422	Routskoi Alexandre	
15612	15422	Rouvillois Philippe	CEA
15613	15422	Rouvre Cyril de	
15614	15422	Roux Ambroise	
15615	15422	Roux Annette	
15616	15422	Roux François-Joseph	
15617	15422	Roux Guy	entraîneur de foot d'Auxerre
15618	15422	Roux Jean-Paul	
15619	15422	Roux Raymond	
15620	15422	Rouxel Christophe	metteur en scène de théâtre
15621	15422	Rouxel Jacques	créateur des Shadocks
15622	15422	Rowe John A.	
15623	15422	Rowland Roy	cinéaste
15624	15422	Rowlands Gena	
15625	15422	Rowling J. K.	
15626	15422	Roy Olivier	
15627	15422	Roy Thinnes	"Les Envahisseurs"
15628	15422	Royal Ségolène	
15629	15422	Royer Jean	
15630	15422	Royère Edouard (de)	ex Pdg d'Air liquide
15631	15422	Roze Pascale	
15632	15422	Rozenbaum Willy	
15633	15422	Rozier Jacques	
15634	15422	Rozès Stéphane	
15635	15422	Roüan Brigitte	
15636	15135	ZZZZ_Personnalités RU	
15637	15636	Ruben Joseph	
15638	15636	Rubens Pierre Paul	
15639	15636	Rubin Rick	
15640	15636	Rubinstein Arthur	
15641	15636	Ruby Karine	
15642	15636	Ruckert Felix	
15643	15636	Rudloff Marcel	
15644	15636	Rudolf Augstein	
15645	15636	Rudolf Noureev	danseur
15646	15636	Rudolf Wittkower	Universitaire allemand, historien de l'art.
15647	15636	Rudolf von Thadden	historien
15648	15636	Rudolph Wurlitzer	Ecrivain
15649	15636	Rudy Marcq	
15650	15636	Rueda Thierry	
15651	15636	Ruf Eric	
15652	15636	Rufenacht Antoine	
15653	15636	Rufin Jean-Christophe	
15654	15636	Rugova Ibrahim	
15655	15636	Ruiz André	
15656	15636	Ruiz Raoul	cinéaste chilien
15657	15636	Ruiz Soler Antonio	
15658	15636	Rulfo Juan	écrivain mexicain
15659	15636	Rumsfeld Donald	
15660	15636	Rupert Johan	
15661	15636	Rupert Matthews	auteur de livres pour jeunes
15662	15636	Rupert Pennant-Rea	gouverneur adjoint de la Banque d'Angleterre
15663	15636	Rupert Smith	
15664	15636	Rupnik Jacques	historien
15665	15636	Ruquier Laurent	producteur et animateur de "Rien à cirer" sur France Inter
15666	15636	Rusedski Greg	
15667	15636	Rushdie Salman	
15668	15636	Russel Bertrand	
15669	15636	Russell Ken	
15670	15636	Rutault Claude	
15671	15636	Rutelli Francesco	
15672	15636	Ruud Gullit	footballeur
15673	15636	Rué Gérard	
15674	15135	ZZZZ_Personnalités RW	
15675	15135	ZZZZ_Personnalités RY	
15676	15675	Rybkine Ivan	
15677	15675	Ryder Shaun	
15678	15675	Ryder Winona	
15679	15675	Rylance Mark	
15680	15675	Rysard Horowitz	Artiste, dessinateur.
15681	7428	ZZZZ_Personnalités S	
15682	15681	ZZZZ_Personnalités SA	
15683	15682	Saad Eddine Wahba	président de l'Union générale des artistes arabes
15684	15682	Saadi Saïd	
15685	15682	Saadé (frères)	
15686	15682	Saakachvili Mikhaïl	
15687	15682	Saal René	
15688	15682	Saatchi Charles	
15689	15682	Sabatier Patrick	
15690	15682	Sabatier Robert	
15691	15682	Sabatini Gabriela	
15692	15682	Sabeg Yazid	
15693	15682	Sabena	
15694	15682	Sablon Jean	
15695	15682	Sacco Joe	
15696	15682	Sacher Paul	
15697	15682	Sachs Jeffrey	
15698	15682	Sacirbey Muhamed	
15699	15682	Sacks Oliver	
15700	15682	Sade Donatien Alphonse François de	
15701	15682	Saderman Alejandros	
15702	15682	Sadirov Rizvon	
15703	15682	Sadoul Georges	
15704	15682	Sadr Bani	
15705	15682	Saer Juan José	
15706	15682	Saez Irene	
15707	15682	Saez Vicente	
15708	15682	Safin Marat	
15709	15682	Sagan Carl	
15710	15682	Sagan Françoise	
15711	15682	Sageloly Michel	
15712	15682	Sahnoun Ahmed	
15713	15682	Sahnoun Mohamed	
15714	15682	Sahra Wagenknecht	communiste allemande de l'ex-RDA/ultra du PDS (stalinienne)
15715	15682	Sahraoui Abdelbaki	
15716	15682	Said Edward	
15717	15682	Saincené Christian	
15718	15682	Saincené Fernand	
15719	15682	Sainjon André	responsable CGT
15720	15682	Saint-Affrique Lorrain de	
15721	15682	Saint-André Philippe	
15722	15682	Saint-Clair Malcolm	
15723	15682	Saint-Etienne Christian	
15724	15682	Saint-Exupéry Antoine de	
15725	15682	Saint-Geours Jean	président de la COB
15726	15682	Saint-Ogan Alain	
15727	15682	Saint-Paul Gérard	
15728	15682	Saint-Phalle Niki de	
15729	15682	Sainte-Marie Michel	
15730	15682	Sainz Carlos	
15731	15682	Saiz Manolo	
15732	15682	Sakharov Andreï	
15733	15682	Salad	
15734	15682	Salah Bouhsiss	franco-marocain écroué en France pour l'attentat de Marrakech
15735	15682	Salameh Hassan	
15736	15682	Salamé Ghassan	
15737	15682	Salengro Christophe	
15738	15682	Salgado Sebastiao	grand reporter
15739	15682	Salieri Antonio	
15740	15682	Salim Ahmed Salim	
15741	15682	Salinas Carlos	ancien président mexicain
15742	15682	Salinas Raul	
15743	15682	Salinger Jerome D.	
15744	15682	Salk Jonas	
15745	15682	Salle David	metteur en scène américain
15746	15682	Salles Walter	
15747	15682	Salter James	écrivain américain, ex-pilote de l'US Air Force
15748	15682	Saltykov Boris G.	ministre Russe de la Recherche
15749	15682	Salvador Henri	
15750	15682	Salvadori Pierre	
15751	15682	Salvayre Lydie	
15752	15682	Salwen Hal	
15753	15682	Samaranch Juan Antonio	
15754	15682	Sammallahti Pentti	
15755	15682	Sampaio Jorge	
15756	15682	Samper Ernesto	
15757	15682	Sampermans Françoise	PdG du Point, L'Express et de la Générale Occidentale
15758	15682	Sampras Peter	Tennis
15759	15682	Sampré Jacques	
15760	15682	Sanbar Elias	écrivain
15761	15682	Sanchez Arantxa	
15762	15682	Sanchez Thomas	
15763	15682	Sand George	
15764	15682	Sander August	
15765	15682	Sanders Allison	
15766	15682	Sandjabi Karim	
15767	15682	Sandman Mark	
15768	15682	Sandre Didier	
15769	15682	Sandrich Mark	cinéaste
15770	15682	Saner Hans	
15771	15682	Sangaré Oumou	
15772	15682	Sannier Henri	
15773	15682	Sanson Véronique	
15774	15682	Santamaria Jacques	
15775	15682	Santana Carlos	
15776	15682	Santelli Claude	réalisateur TV
15777	15682	Santer Jacques	
15778	15682	Santiago Hugo	
15779	15682	Santini André	
15780	15682	Santini Jacques	
15781	15682	Santini Pierre	
15782	15682	Santon Régis	
15783	15682	Santoni François	
15784	15682	Santoro Fabrice	joueur de tennis
15785	15682	Santu Mofokeng	
15786	15682	Sané Pierre	
15787	15682	Saoudi Nabil	
15788	15682	Saout Christian	
15789	15682	Sapho	
15790	15682	Sapin Michel	
15791	15682	Saporta Karine	
15792	15682	Saramito Christine	
15793	15682	Sarandon Susan	
15794	15682	Sarde Alain	
15795	15682	Sardou Michel	
15796	15682	Saredi Christia	
15797	15682	Sarfati Lise	
15798	15682	Sarkis	
15799	15682	Sarkouhi Faradj	
15800	15682	Sarkozy Cécilia	 
15801	15682	Sarkozy Guillaume	
15802	15682	Sarkozy Nicolas	
15803	15682	Saro-Wiwa Ken	
15804	15682	Sarraute Nathalie	
15805	15682	Sarrazin Jean-Claude	
15806	15682	Sarre Georges	
15807	15682	Sartre Jean-Paul	
15808	15682	Sary Ieng	
15809	15682	Saskia Cohen-Tanugi	conseillère pour Toubon au théâtre du 13e
15810	15682	Sassi Mohamed	
15811	15682	Sassone-Corsi Paolo	généticien biologiste du Laboratoire de Strasbourg
15812	15682	Sassou N'Guesso Denis	
15813	15682	Sastre Jean-Baptiste	
15814	15682	Sato Makoto	journaliste japonais
15815	15682	Satriani Joe	
15816	15682	Saulet Anicet	
15817	15682	Saunders Jennifer	
15818	15682	Saura Carlos	
15819	15682	Sautet Claude	
15820	15682	Sautter Christian	
15821	15682	Sautter Rémy	
15822	15682	Sauvaigo Suzanne	
15823	15682	Sauzay Brigitte	
15824	15682	Savall Jordi	
15825	15682	Savary Jérôme	metteur en scène théâtre, comédie musicale
15826	15682	Savimbi Jonas	
15827	15682	Savitzkaya Eugène	
15828	15682	Savoie Victor-Emmanuel de	
15829	15682	Savoy Guy	
15830	15682	Savy Bernard-Claude	
15831	15682	Savy Robert	
15832	15682	Sawalha Nabil	
15833	15682	Sayad Abdemalek	Ecrivain
15834	15682	Sayeeram Aruna	
15835	15682	Sayles John	
15836	15682	Saïd Mekbel	
15837	15681	ZZZZ_Personnalités SC	
15838	15837	Scaglia Charles	
15839	15837	Scalfaro Oscar Luigi	
15840	15837	Scapula Francis	
15841	15837	Scarcelli Paul	urbanist-jardiniste à Paris
15842	15837	Scardino Marjorie	
15843	15837	Scargill Arthur	
15844	15837	Schaeffer Emmanuel	
15845	15837	Schaeffer Pierre	
15846	15837	Schaffner Anne-Marie	Députée européenne
15847	15837	Schalck-Golodkowski Alexander	
15848	15837	Schapiro Meyer	historien de l'art
15849	15837	Scharping Rudolf	
15850	15837	Schattner Marius	journaliste
15851	15837	Schefer Jean-Louis	
15852	15837	Schiaretti Christian	
15853	15837	Schiele Egon	
15854	15837	Schiff Ze'ev	
15855	15837	Schiffer Claudia	
15856	15837	Schiller Friedrich	
15857	15837	Schimmel Annemarie	
15858	15837	Schleef Einar	
15859	15837	Schlegel Friedrich	
15860	15837	Schlegel Jean-Louis	
15861	15837	Schlesinger John	
15862	15837	Schlondorff Volker	
15863	15837	Schlömer Joachim	
15864	15837	Schmid Daniel	
15865	15837	Schmidt Helmut	
15866	15837	Schmidt-Rottluff Karl	
15867	15837	Schmit Philippe	Maire de Longjumeau
15868	15837	Schmitt Eric	
15869	15837	Schmitt Eric-Emmanuel	
15870	15837	Schmitt Jean-Claude	
15871	15837	Schmutzer Heinz P.	
15872	15837	Schnabel Julian	
15873	15837	Schnebelin Bruno	
15874	15837	Schneider Gilles	directeur de la rédaction de France Inter, puis à Europe 1 en Juillet 95
15875	15837	Schneider Hans	
15876	15837	Schneider Jürgen	
15877	15837	Schneider Romy	
15878	15837	Schneidermann Daniel	
15879	15837	Schnittke Alfred	
15880	15837	Schnitzler Arthur	Ecrivain
15881	15837	Schoenberg Arnold	
15882	15837	Schoenberg Claude-Michel	
15883	15837	Schoenberg Isaac	
15884	15837	Schoendoerffer Pierre	
15885	15837	Schott Pierre	chanteur
15886	15837	Schrameck Olivier	
15887	15837	Schreiber Boris	
15888	15837	Schrempp Jürgen	
15889	15837	Schroeder Barbet	
15890	15837	Schröder Gerhard	
15891	15837	Schubert Franz	
15892	15837	Schuiten François	
15893	15837	Schulberg Budd	
15894	15837	Schuller Didier	
15895	15837	Schulmann Patrick	réalisateur
15896	15837	Schultz David	
15897	15837	Schulz Bruno	
15898	15837	Schumacher Joel	
15899	15837	Schumacher Michael	
15900	15837	Schumacher Ralf	
15901	15837	Schuster Bruno	
15902	15837	Schuster Jean	
15903	15837	Schwab Werner	
15904	15837	Schwartz Bernard	
15905	15837	Schwartz Jean-Charles	
15906	15837	Schwartzenberg Léon	
15907	15837	Schwartzenberg Roger-Gérard	
15908	15837	Schwarzenegger Arnold	
15909	15837	Schwarzkopf Elisabeth	
15910	15837	Schweitzer Louis	pdg de Renault
15911	15837	Schygulla Hanna	
15912	15837	Schäfer Paul	Pédophile allemand vivant au Chili.
15913	15837	Schäuble Wolfgang	
15914	15837	Schönberg Béatrice	
15915	15837	Schönhuber Franz	
15916	15837	Schüssel Wolfgang	
15917	15837	Scitivaux Marc de	
15918	15837	Scola Ettore	
15919	15837	Scorsese Martin	
15920	15837	Scott Mike	
15921	15837	Scott Ridley	
15922	15837	Scott Tony	Frère de Ridley
15923	15837	Scott-Thomas Kristin	
15924	15837	Scriabine Alexandre	
15925	15837	Scully Sean	
15926	15681	ZZZZ_Personnalités SE	
15927	15926	Sead Hasanefendic	
15928	15926	Searle John	
15929	15926	Seatlholo Khotso	
15930	15926	Seberg Jean	
15931	15926	Seehofer Horst	
15932	15926	Seemann Monique	
15933	15926	Segal Patrick	Ecrivain
15934	15926	Segalen Victor	
15935	15926	Segovia Claudio	
15936	15926	Seguin Boris	
15937	15926	Seide Stuart	Metteur en scène de théâtre
15938	15926	Seidner David	photographe américain
15939	15926	Seigneur Eddy	
15940	15926	Seiler Lewis	
15941	15926	Seillière Ernest-Antoine	
15942	15926	Seinfeld Jerry	comédien de cabaret
15943	15926	Seio Nagao	
15944	15926	Seizinger Katja	ski alpin
15945	15926	Sekula Allan	
15946	15926	Selena Quintanilla Perez	chanteuse tex mex
15947	15926	Seles Monica	tennis
15948	15926	Seligmann Françoise	
15949	15926	Selima Guezali	directrice de l'hebdomadaire algérien "La Nation"
15950	15926	Sella Philippe	
15951	15926	Sellam Sadek	
15952	15926	Sellars Peter	
15953	15926	Sellers Catherine	
15954	15926	Sellers Peter	
15955	15926	Semdin Sakik	Chef rebelle kurde.
15956	15926	Semih Vaner	spécialiste du monde turcophone
15957	15926	Semin Didier	
15958	15926	Semoun Elie	
15959	15926	Semprun Jorge	
15960	15926	Sempé Jean-Jacques	 
15961	15926	Sendashonga Seth	
15962	15926	Senderens Alain	
15963	15926	Senghor Léopold Sédar	
15964	15926	Senna Ayrton	pilote
15965	15926	Sercia Joseph	
15966	15926	Serfaty Abraham	
15967	15926	Serge Tranvouez	metteur en scène de théâtre
15968	15926	Sergio George	chef d'orchestre de salsa
15969	15926	Sergio Trasatti	historien
15970	15926	Sergueev Igor	
15971	15926	Serguei Mavrodi	
15972	15926	Serieyx Alain	
15973	15926	Seris François	
15974	15926	Serner Walter	
15975	15926	Serra Narcis	
15976	15926	Serrault Michel	acteur
15977	15926	Serreau Coline	
15978	15926	Serres Michel	
15979	15926	Serrou Robert	
15980	15926	Servais Raoul	
15981	15926	Servan-Schreiber Jean-Jacques	maire de Bordeaux et ancien ministre
15982	15926	Servan-Schreiber Jean-Louis	directeur de "Lire"
15983	15926	Seselj Vojislav	
15984	15926	Seurat	
15985	15926	Severino Isabelle	gymnastique
15986	15926	Severo Moto	L'un des principaux opposants en Guinée équatoriale
15987	15926	Severo Sarduy	
15988	15926	Sevestre Alain	écrivain
15989	15926	Sevestre Marie-Agnès	
15990	15926	Sevran Pascal	
15991	15926	Seweryn Andrzej	
15992	15926	Sex Pistols	
15993	15926	Sexwale Tokyo	
15994	15926	Seydoux Jérôme	
15995	15926	Seydoux Nicolas	pdg de Gaumont
15996	15926	Seyfried Robert	
15997	15926	Seys Jean-Claude	président de la MAAF
15998	15926	Seznec Guillaume	
15999	15926	Sève Lucien	scientifique et membre du Comité d'éthique
16000	15926	Sébastien Flute	champion de tir à l'arc
16001	15926	Sébastien Patrick	
16002	15926	Sébastien Vankalmout	
16003	15926	Séguin Catherine	fille de Philippe
16004	15926	Séguin Philippe	
16005	15926	Séguy Georges	ancien dirigeant de la CGT
16006	15926	Séguéla Jacques	
16007	15926	Sénèque	philisophe grec
16008	15926	Séonnet Michel	
16009	15926	Sérillon Claude	
16010	15681	ZZZZ_Personnalités SF	
16011	15681	ZZZZ_Personnalités SH	
16012	16011	Shahabuddin Ahmed	Président du Bangladesh
16013	16011	Shahak Amnon	
16014	16011	Shaham Gil	
16015	16011	Shakespeare William	
16016	16011	Shakkur Hamza	
16017	16011	Shakur Tupac	
16018	16011	Shamir Yitzhak	
16019	16011	Shankar Ravi	
16020	16011	Shapiro Ken	
16021	16011	Sharon Ariel	
16022	16011	Sharp Don	
16023	16011	Sharping Rudolf	
16024	16011	Shavit Ari	Ari Shavit est écrivain et chroniqueur du journal israélien Haaretz. Il vit à Jérusalem.
16025	16011	Shaw Fiona	
16026	16011	Shaw Jeffrey	
16027	16011	Sheen Charlie	
16028	16011	Sheila	
16029	16011	Shelley Mary	
16030	16011	Shepp Archie	
16031	16011	Sheridan Jim	
16032	16011	Sherman Cindy	
16033	16011	Sherman Lowell	
16034	16011	Sherrer Victor	vice-président CNPF
16035	16011	Shields Carol	
16036	16011	Shigeaki Hazama	patron du 6e quotidien japonais
16037	16011	Shindo Kaneto	
16038	16011	Shinichiro Arakawa	jeune couturier
16039	16011	Shinozaki Makoto	
16040	16011	Shmuel Hasfari	Cinéaste israëlien
16041	16011	Shmuel Meiri	
16042	16011	Shobha De	Personnalités
16043	16011	Shootyz Groove	
16044	16011	Shubailat Laith	
16045	15681	ZZZZ_Personnalités SI	
16046	16045	Sibertin-Blanc Jean-Chrétien	
16047	16045	Sibomana André	
16048	16045	Sidibé Malick	
16049	16045	Sidney George	
16050	16045	Sidos Pierre	
16051	16045	Sieff Jean-Loup	
16052	16045	Siegel Don	réalisateur américain
16053	16045	Siegel François	
16054	16045	Siegel Jerry	
16055	16045	Siegerist Joachim	
16056	16045	Siffre Jacques	Maire socialiste d'Istres
16057	16045	Signac Paul	
16058	16045	Sihanouk Norodom	
16059	16045	Silea Francesco	
16060	16045	Silguy Yves-Thibault de	commissaire européen
16061	16045	Sillard Benoît	
16062	16045	Silveira Leonor	
16063	16045	Silverberg Robert	
16064	16045	Siman Ken	
16065	16045	Simenon Georges	
16066	16045	Simenon Marc	
16067	16045	Simeoni Xavière	
16068	16045	Simitis Costas	
16069	16045	Simmons Dan	
16070	16045	Simmons Sonny	
16071	16045	Simon Casas	
16072	16045	Simon Claire	cinéaste française
16073	16045	Simon Claude	
16074	16045	Simon Michel	
16075	16045	Simon Paul	
16076	16045	Simon Schneider	
16077	16045	Simon Simsi	
16078	16045	Simon Yves	
16079	16045	Simonds Caroline	
16080	16045	Simone Marco	foot
16081	16045	Simone Nina	Chanteuse afro-américaine
16082	16045	Simonet Claude	président de la Fédé Française de foot
16083	16045	Simonetti Jean	
16084	16045	Simonpieri Daniel	
16085	16045	Simple Minds	rock
16086	16045	Simpson Joe	alpiniste et écrivain
16087	16045	Simpson Orenthal James	
16088	16045	Siméon de Bulgarie	
16089	16045	Sinapi Jean-Pierre	
16090	16045	Sinatra Frank	
16091	16045	Sinclair Anne	
16092	16045	Sinclair Ingrid	
16093	16045	Sinet Maurice	Dessinateur
16094	16045	Singer Bryan	
16095	16045	Singer Isaac Bashevis	
16096	16045	Singh Manmohan	 
16097	16045	Singly François de	
16098	16045	Siniac Pierre	
16099	16045	Sinopoli Giuseppe	Compositeur et chef d'orchestre Italien
16100	16045	Siné	dessinateur
16101	16045	Siodmak Robert	
16102	16045	Sion Alain	réalisateur de dessin animé
16103	16045	Sionil José Francisco	
16104	16045	Sirinelli Jean-François	
16105	16045	Sirjacq Louis-Jean	
16106	16045	Sirk Douglas	cinéaste américain
16107	16045	Sirven Alfred	
16108	16045	Sis Peter	
16109	16045	Sissini Noël	
16110	16045	Sitbon Martine	
16111	16045	Sitruk Joseph	grand rabbin de France
16112	16045	Sivadier Jean-François	
16113	15681	ZZZZ_Personnalités SK	
16114	16113	Skrela Jean-Claude	entraineur équipe de France de rugby
16115	16113	Skunk Anansie	
16116	15681	ZZZZ_Personnalités SL	
16117	16116	Slitinsky Michel	
16118	15681	ZZZZ_Personnalités SM	
16119	16118	Smashing Pumpkins	
16120	16118	Smaïn	
16121	16118	Smirnoff Andreï	
16122	16118	Smirnov Boris	
16123	16118	Smith Chris	
16124	16118	Smith David	
16125	16118	Smith John (athlétisme)	
16126	16118	Smith Kendra	
16127	16118	Smith Kevin	
16128	16118	Smith Patti	
16129	16118	Smith Robert	
16130	16118	Smith Susan	
16131	16118	Smith Will	
16132	16118	Smits Thierry	
16133	15681	ZZZZ_Personnalités SN	
16134	16133	Snoop Doggy Dogg	
16135	15681	ZZZZ_Personnalités SO	
16136	16135	Soares Mario	
16137	16135	Sobel Bernard	metteur en scène de théâtre
16138	16135	Sobhraj Charles Gurmukh	criminel international célèbre de nationalité française
16139	16135	Sobtchak Anatoli	
16140	16135	Socrates Pinto de Sousa José	
16141	16135	Soderbergh Steven	
16142	16135	Soekarnoputri Megawati	
16143	16135	Sofri Adriano	
16144	16135	Soglo Nicéphore	
16145	16135	Soisson Jean-Pierre	
16146	16135	Sokal Alan	
16147	16135	Solana Javier	
16148	16135	Solano Wilebaldo	
16149	16135	Solar Race	
16150	16135	Solaro Chantal	
16151	16135	Soldini Giovanni	voile
16152	16135	Soledad Puertolas	écrivain espagnol
16153	16135	Soler Francis	
16154	16135	Soljenitsyne Alexandre	
16155	16135	Sollers Philippe	écrivain-journaliste
16156	16135	Solny Jean	
16157	16135	Solo Bruno	
16158	16135	Sologne Madeleine	actrice française
16159	16135	Solondz Todd	
16160	16135	Solti Georges	
16161	16135	Sommier Patrick	
16162	16135	Sondji Jean-Baptiste	
16163	16135	Sonic Youth	
16164	16135	Sonnenfeld Barry	
16165	16135	Sonnino Aldo	
16166	16135	Sonny Landreth	rock
16167	16135	Sonora Ponceña	
16168	16135	Sontag Susan	
16169	16135	Sony Labou Tansi	Ecrivain congolais
16170	16135	Sonya Madan	Du groupe Echobelly
16171	16135	Soo-Sung Lee	
16172	16135	Sophie Cote	fondatrice de l'AFEP
16173	16135	Sophie Curtil	pédagogue
16174	16135	Sophie L'Hélias	Avocate
16175	16135	Sophocle	
16176	16135	Sopoglian Dominique	
16177	16135	Sorescu Marin	
16178	16135	Sorin Raphaël	
16179	16135	Sorman Guy	
16180	16135	Soros George	financier international
16181	16135	Sorouch Abdol-Karim	
16182	16135	Sorvino Mira	
16183	16135	Soskovets Oleg	
16184	16135	Soto Jesus Rafael	
16185	16135	Sottsass Ettore	
16186	16135	Soubie Raymond	ancien conseiller social de Chirac et Barre
16187	16135	Soubirou André	
16188	16135	Souchon Alain	
16189	16135	Soufflet Michel	
16190	16135	Soul Coughing	groupe de rock américain
16191	16135	Soulages Pierre	
16192	16135	Soulez-Larivière Daniel	
16193	16135	Soumy Jean-Guy	
16194	16135	Soupault Philippe	
16195	16135	Souprouniouk Evgueni	
16196	16135	Souza Carl de	
16197	16135	Soyinka Wole	
16198	16135	Sôderman Jacob	
16199	16135	Sôseki Natsumé	écrivain japonais
16200	16135	Söderberg Hjalmar	
16201	15681	ZZZZ_Personnalités SP	
16202	16201	Spacey Kevin	
16203	16201	Spader James	
16204	16201	Spaeth Jean-Marie	
16205	16201	Spain	
16206	16201	Spazzola Rose-May	
16207	16201	Spencer Jon	chanteur de rock
16208	16201	Spender Stephen	
16209	16201	Spice Girls	
16210	16201	Spiegelman Art	
16211	16201	Spielberg Steven	
16212	16201	Spielmann Laurent	
16213	16201	Spies Werner	
16214	16201	Spinetta Jean-Cyril	
16215	16201	Spinoza	philosophe
16216	16201	Spinrad Norman	
16217	16201	Spira Alfred	professeur à l'université Paris-XI, Inserm U292, a coordonné les enquêtes nationales sur les comportements sexuels, Les Comportements sexuels en France, la Documentation française, 1993.
16218	16201	Spire Antoine	
16219	16201	Spitaels Guy	
16220	16201	Spitz Bernard	
16221	16201	Spring Dick	
16222	16201	Springer Michael	pdg Apple
16223	16201	Springsteen Bruce	
16224	15681	ZZZZ_Personnalités ST	
16225	16224	STE	Stéphanie, Guadeloupéenne de Vitry-sur-Seine, rappeuse gangsta.
16226	16224	Stahl John M.	
16227	16224	Staler Ilona	
16228	16224	Staline Joseph	
16229	16224	Stallone Sylvester	
16230	16224	Stamp Terence	
16231	16224	Stangerup Henrik	écrivain danois
16232	16224	Stanislas- Auguste Poniatowski	dernier roi de Pologne
16233	16224	Stanojevic Stanislas	cinéaste
16234	16224	Starck Philippe	
16235	16224	Starks John	basketteur us
16236	16224	Starr Georgina	
16237	16224	Starr Kenneth	
16238	16224	Starr Ringo	
16239	16224	Stasi Bernard	
16240	16224	Stasse François	
16241	16224	Steel Pulse	Groupe reggae Anglais
16242	16224	Steen Jan	
16243	16224	Stefanini Patrick	
16244	16224	Stehlik Vladimir	
16245	16224	Steichen René	
16246	16224	Stein Gertrude	
16247	16224	Stein Peter	
16248	16224	Steiner Georges	
16249	16224	Steiner Jeffrey	patron de la société d'investissement Rexnord Holdings
16250	16224	Steiner Michael	
16251	16224	Stella Franck	
16252	16224	Stendhal (Henri Beyle)	
16253	16224	Stenger Edmond	
16254	16224	Stepachine Sergueï	
16255	16224	Stephan Valérie	
16256	16224	Stephen Morse	chercheur de l'Université Rockefeller de NY, spécialiste des maladies nouvelles
16257	16224	Stephen Savage	auteur livre pour enfants
16258	16224	Sterbak Jana	
16259	16224	Sterin Alain	économie
16260	16224	Stern Edouard	
16261	16224	Stern Grete	
16262	16224	Stern Jacques	
16263	16224	Sternberg Josef von	
16264	16224	Stevanovic Vidosav	
16265	16224	Steve Foltyn	physicien et chercheur au labo de Los Alamos
16266	16224	Steve Parker	Ecrivain
16267	16224	Steven Philip Kramer	historien américain
16268	16224	Steven Rose	chercheur britannique spécialiste du cerveau et du comportement
16269	16224	Steven T. Katz	directeur du musée de l'Holocauste à Washington
16270	16224	Stevens George	
16271	16224	Stevenson Robert (réalisateur)	
16272	16224	Stevenson Robert Louis	
16273	16224	Stewart Dave	
16274	16224	Stewart Jacques	
16275	16224	Stewart James	
16276	16224	Stewart Rod	
16277	16224	Stich Michael	sport
16278	16224	Stifter Adalbert	
16279	16224	Sting	
16280	16224	Stirbois Marie-France	
16281	16224	Stoffaes Brigitte	
16282	16224	Stoffaës Christian	Proche conseiller d'Alain Madelin, défenseur du service d'"utilité publique".
16283	16224	Stoiber Edmund	
16284	16224	Stoica Ioan	Patron de la chaîne financière Caritas
16285	16224	Stojicic Radovan	
16286	16224	Stojko Elvis	patineur champion du monde 95
16287	16224	Stoker Bram	
16288	16224	Stoll Jean-François	
16289	16224	Stoller Irène	
16290	16224	Stolpe Manfred	
16291	16224	Stoltenberg Thorvald	
16292	16224	Stone Michael	
16293	16224	Stone Oliver	
16294	16224	Stone Roses	groupe de rock
16295	16224	Stone Sharon	
16296	16224	Stora Benjamin	
16297	16224	Stora Bernard	
16298	16224	Storey David	
16299	16224	Stoïanov Petar	
16300	16224	Stoïchkov Hristo	
16301	16224	Strakhov Alexeï	
16302	16224	Strand Paul	
16303	16224	Stratmann Veit	
16304	16224	Straub Jean-Marie	
16305	16224	Strauss Botho	
16306	16224	Strauss Richard	
16307	16224	Strauss-Kahn Dominique	
16308	16224	Stravinski Igor F.	
16309	16224	Straw Jack	
16310	16224	Streep Meryl	
16311	16224	Street Picabo	ski alpin
16312	16224	Strehler Giorgio	
16313	16224	Streibl Max	
16314	16224	Streiff Christian	 
16315	16224	Streisand Barbra	
16316	16224	Strindberg August	
16317	16224	Strobl Josef	
16318	16224	Strosberg Donny	généticien du CNRS
16319	16224	Struber Bernard	
16320	16224	Stryjkowski Julian	
16321	16224	Stuart Heisler	
16322	16224	Stuart Meg	
16323	16224	Stumpfe Werner	président de la Gesamtmetall, organisation patronale de la métallurgie allemande
16324	16224	Sturges John	
16325	16224	Sturges Preston	
16326	16224	Styron William	
16327	16224	Stéfan Jude	
16328	16224	Stéphane Beaufils	PdG de la SA Beaufils, entreprise chimique
16329	16224	Stéphane Bortzmeyer	informaticien du Cnam spécialiste du cryptage sur Internet
16330	16224	Stéphane Collaro	
16331	16224	Stéphane Delabrière	tueur en série français
16332	16224	Stéphane Lenoir	auteur de "Génération télé"
16333	16224	Stéphane Nègre	informaticien chez Intel
16334	16224	Stéphane Oberer	
16335	16224	Stéphane Rials	Ecrivain
16336	16224	Stéphane Verrue	Metteur en scène
16337	16224	Stéphanie Chévara	metteur en scène de theatre
16338	16224	Stétié Salah	essayiste et critique littéraire
16339	16224	Stévenin Jean-François	
16340	16224	Stövhase Suzanne	
16341	15681	ZZZZ_Personnalités SU	
16342	16341	Su Shaozhi	
16343	16341	Suard Pierre	
16344	16341	Suarez Gérard	
16345	16341	Suaudeau Claude	
16346	16341	Subra Valérie	
16347	16341	Suchet Mélanie	
16348	16341	Sudek Josef	
16349	16341	Sudhoff Jürgen	
16350	16341	Sudre Margie	
16351	16341	Suede (rock)	
16352	16341	Sueur Jean-Pierre	maire PS d'Orléans
16353	16341	Suharto	
16354	16341	Suleman Ramadan	
16355	16341	Sulik Martin	
16356	16341	Sulitzer Paul-Loup	
16357	16341	Sully Jeanne	
16358	16341	Summer Donna	
16359	16341	Summers Andy	
16360	16341	Sundman Per Olof	
16361	16341	Sunset Heights	
16362	16341	Supergrass	
16363	16341	Supertramp	
16364	16341	Supervielle Jules	
16365	16341	Susen Tiedtke-Greene	
16366	16341	Susie Leech Nairm	Participante de la "Coupe de l'America"
16367	16341	Sussfeld Alain	
16368	16341	Sutherland Peter	directeur de l'OMC
16369	16341	Sutton Nina	
16370	16341	Suzana Higuchi	épouse séparée du président Péruvien Alberto Fujimori
16371	16341	Suzanne Belz	nouvelle directrice de l'URSSAF de Paris
16372	16341	Süskind Patrick	
16373	15681	ZZZZ_Personnalités SV	
16374	15681	ZZZZ_Personnalités SW	
16375	16374	Sweeney John	
16376	16374	Sweets John F.	
16377	16374	Swell	
16378	16374	Swift Graham	écrivain
16379	15681	ZZZZ_Personnalités SY	
16380	16379	Sylla Fodé	Président de SOS-Racisme
16381	16379	Sylvain Boyer	
16382	16379	Sylvain Guillaume	
16383	16379	Sylvestre Anne	
16384	16379	Sylvia Bourdon	Ex-star du X
16385	16379	Sylvianne Valfiore	Assassin
16386	16379	Sylvie Deraime	Ecrivain
16387	16379	Sylvie Meloux	championne du monde de Judo 95
16388	16379	Sylvie Ramir	réalisatrice télé
16389	16379	Sylvie Vartan	
16390	16379	Synge John Millington	
16391	16379	Syrota Jean	PdG de la Cogema
16392	15681	ZZZZ_Personnalités SZ	
16393	16392	Szigeti Pierre-Alain	
16394	16392	Szpiner Francis	avocat
16395	16392	Szwarc Jeannot	
16396	16392	Szymborska Wislawa	
16397	7428	ZZZZ_Personnalités T	
16398	16397	ZZZZ_Personnalités TA	
16399	16398	Tabachnik Michel	
16400	16398	Tabard Pierre	
16401	16398	Tabarly Eric	
16402	16398	Tabary Jean	
16403	16398	Tabatha Cash	
16404	16398	Tabucchi Antonio	
16405	16398	Tadao Ando	
16406	16398	Taddei Dominique	professeur de sciences économiques
16407	16398	Tadeusz Mazowiecki	
16408	16398	Tadic Dusan	
16409	16398	Tafer Akim	Boxeur français
16410	16398	Taguieff Pierre-André	écrivain
16411	16398	Taha Rachid	
16412	16398	Taher Baha	
16413	16398	Taibo II Paco Ignacio	écrivain mexicain
16414	16398	Taittinger (famille)	
16415	16398	Tajan Jacques	
16416	16398	Take That	
16417	16398	Takemura Masayoshi	Ministre des Finances au Japon
16418	16398	Takeo Shimizu	
16419	16398	Taki Mohamed	
16420	16398	Talabani Jalal	
16421	16398	Talamoni Jean-Guy	
16422	16398	Tamet Christian	
16423	16398	Tanguy François	
16424	16398	Tanju Colak	footballeur en prison en turquie
16425	16398	Tanner Alain	metteur en scène
16426	16398	Tannouri Antony	
16427	16398	Tanvier Cathy	
16428	16398	Tapie Bernard	
16429	16398	Tapie Jean-Claude	frère de nanard et président du club de hand de Marseille, I'OM-Vitrolles
16430	16398	Tapscott Horace	pianiste de jazz texan
16431	16398	Taquet Henri	
16432	16398	Taquet Philippe	
16433	16398	Tarallo André	
16434	16398	Tarango Jeff	
16435	16398	Tarantino Quentin	Réalisateur américain
16436	16398	Tardi	auteur de BD
16437	16398	Tardieu Jean	écrivain, poète
16438	16398	Tarek Falha	
16439	16398	Targowla Olivier	
16440	16398	Tarkovski Andréï	
16441	16398	Tasca Catherine	
16442	16398	Tasma Alain	réalisateur de téléfilm
16443	16398	Tassembedo Irène	
16444	16398	Tate Jeffrey	
16445	16398	Tati Jacques	réalisateur français
16446	16398	Tatsumi Kumashiro	
16447	16398	Taubira Christiane	
16448	16398	Taurog Norman	
16449	16398	Tauziat Nathalie	
16450	16398	Tavernier Bertrand	cinéaste français
16451	16398	Tavernier Nils	journaliste
16452	16398	Taviani Paolo	
16453	16398	Taylor Alex	
16454	16398	Taylor Charles	
16455	16398	Taylor Elizabeth	
16456	16398	Taylor Lili	
16457	16398	Taïb Bentizi	ex-leader de la mosquée de Mantes
16458	16397	ZZZZ_Personnalités TC	
16459	16458	Tchalian Robert	
16460	16458	Tchaïkovski Piotr Ilitch	
16461	16458	Tchekhov Anton	
16462	16458	Tcheriebkov Viktor	
16463	16458	Tchernia Pierre	homme de cinéma et de télé
16464	16458	Tchernomyrdine Viktor	Premier ministre russe
16465	16458	Tchiguir Mikhail	
16466	16458	Tchividjian Jean	
16467	16458	Tchmil Andreï	coureur cycliste
16468	16458	Tcholakian Gérard	
16469	16458	Tchoubaïs Anatoli	
16470	16458	Tchourekov Iouri	
16471	16458	Tchuruk Serge	
16472	16397	ZZZZ_Personnalités TE	
16473	16472	Teddy Riley	producteur du groupe de rock Blackstreet
16474	16472	Tefaarere Hiro	
16475	16472	Teillard Frédéric	
16476	16472	Teller Edward	
16477	16472	Temaru Oscar	Indépendantiste de la Polynésie française
16478	16472	Temime Hervé	
16479	16472	Temine Hervé	président de l'Association des avocats pénalistes
16480	16472	Temple Julien	
16481	16472	Templon Daniel	
16482	16472	Temptations	groupe soul des années 60
16483	16472	Tenaillon Paul-Louis	
16484	16472	Tenet George	
16485	16472	Terfel Bryn	
16486	16472	Terrail Alain	
16487	16472	Terras Christian	Christian Terras est directeur de la revue Golias.
16488	16472	Terzian Alain	
16489	16472	Terzieff Laurent	
16490	16472	Terzoglou Marie-Dominique	
16491	16472	Teshigawara Saburo	
16492	16472	Tessa Brisac	institutrice ayant vécu au Mexique
16493	16472	Tesseyre Cécile	
16494	16472	Tessier Jean-Pierre	Président de l'INA
16495	16472	Tessier Marc	
16496	16472	Tesson Philippe	ex-directeur presse
16497	16472	Testa Gianmaria	
16498	16472	Testart Jacques	
16499	16472	Teulade René	
16500	16472	Texier Sébastien	
16501	16472	Teyssier Jean-Pierre	PdG de l'INA
16502	16472	Téchiné André	
16503	16472	Ténot Frank	
16504	16472	Têtes raides	
16505	16397	ZZZZ_Personnalités TH	
16506	16505	Thaksin Shinawatra	
16507	16505	Thatcher Margaret	
16508	16505	Thaçi Hashim	
16509	16505	The Replacements	groupe rock
16510	16505	The Verve	
16511	16505	Theodor Zeldin	
16512	16505	Theodore Hawkins	
16513	16505	Theresia Haidlmayr	parlementaire autrichienne
16514	16505	Thibaud Paul	
16515	16505	Thibaudeau Jean	écrivain
16516	16505	Thibaudet Albert	
16517	16505	Thibault Bernard	secrétaire général de la fédération cgt des cheminots
16518	16505	Thich Huyen Quang	boudhiste vietnam
16519	16505	Thiel Gilbert	
16520	16505	Thiercelin Marc	
16521	16505	Thierry Jean-Luc	
16522	16505	Thieû Niang Thierry	
16523	16505	Thiollière Michel	maire de Saint-Etienne
16524	16505	Thiry Bruno	pilote de rallye auto
16525	16505	This Hervé	cuisinier scientifique
16526	16505	Thivolet Pierre	
16527	16505	Thiyam Ratan	
16528	16505	Thollot Jacques	
16529	16505	Thomas David	
16530	16505	Thomas Edith	historienne et romancière
16531	16505	Thomas Evelyne	
16532	16505	Thomas Jean-Pierre	
16533	16505	Thomas Pascal	
16534	16505	Thomas Philippe	
16535	16505	Thomas Ray	biologiste informaticien qui essaie de recréer la théorie de l'évolution sur ordinateur
16536	16505	Thomass Chantal	entreprise de création de lingerie féminine
16537	16505	Thomassin Gérald	
16538	16505	Thomet Jacques	
16539	16505	Thompson Emma	
16540	16505	Thomson Anna	
16541	16505	Thorez Maurice	
16542	16505	Thornton Billy Bob	
16543	16505	Thorpe Richard	
16544	16505	Thoulouze Michel	
16545	16505	Throwing Muses	groupe de rock
16546	16505	Thurman Uma	
16547	16505	Thérond Roger	
16548	16505	Théry Gérard	
16549	16505	Thévenet Bernard	
16550	16505	Thévoz Michel	
16551	16397	ZZZZ_Personnalités TI	
16552	16551	Tiberi Dominique	
16553	16551	Tiberi Jean	
16554	16551	Tiberi Xavière	
16555	16551	Tibi Ahmed	
16556	16551	Tiepolo Giambattista	
16557	16551	Tierney Gene	
16558	16551	Tierno Monénembo	Ecrivain
16559	16551	Tietmeyer Hans	président de la Bundesbank
16560	16551	Tigana Jean	footballeur
16561	16551	Tigrett Isaac	
16562	16551	Tikhomirov Viatcheslav	
16563	16551	Tillinac Denis	écrivain/éditeur/chiraquien
16564	16551	Tilly	
16565	16551	Tim Kempton	joueur de basket-ball
16566	16551	Tim Tiny	
16567	16551	Timmer Jan	
16568	16551	Timmermans Frank	
16569	16551	Timochenko Ioulia	
16570	16551	Timon Koulmasis	réalisateur de film tv
16571	16551	Timothy Dalton	
16572	16551	Timsit Patrick	comique
16573	16551	Tin Oo	
16574	16551	Tindersticks	
16575	16551	Tinguely Jean	
16576	16551	Tiozzo Christophe	boxeur et voyou
16577	16551	Tiozzo Fabrice	
16578	16551	Tiravanija Rirkrit	
16579	16551	Tirenellayi Seshan	Homme politique indien
16580	16551	Tisserand Jérôme	
16581	16551	Tissot Claude-Annick	
16582	16551	Tito Topin	
16583	16551	Tittoni Maria Elisa	
16584	16397	ZZZZ_Personnalités TJ	
16585	16584	Tjibaou Marie-Claude	
16586	16397	ZZZZ_Personnalités TO	
16587	16586	Tobias Phillip	anthropologue
16588	16586	Tobin James	
16589	16586	Todd Eldredge	patineur
16590	16586	Todd Emmanuel	
16591	16586	Todd Olivier	
16592	16586	Todor Jivkov	dictateur bulgare
16593	16586	Todor Slavkov	petit-fils de Jivkov (Bulgarie)
16594	16586	Todorov Tzvetan	Ecrivain
16595	16586	Toesca Marc	
16596	16586	Tolkien John Ronald Reuel	
16597	16586	Tom Gogola	journaliste américain
16598	16586	Tom Higgins	restaurateur anglais de Lyon
16599	16586	Tom Shadyac	cinéaste américain
16600	16586	Tomas y Valiente Francisco	
16601	16586	Tomaszewski Marek	Maître de conférence à Lille III
16602	16586	Tomatito	chanteur de flamenco
16603	16586	Tomba Alberto	
16604	16586	Tomiichi Murayama	Premier ministre japonais
16605	16586	Tomislav Ivic	
16606	16586	Tommaso Buscetta	le plus célèbfe des repentis italiens
16607	16586	Tommy Holloway	directeur à la NASA
16608	16586	Tompkins Mark	
16609	16586	Tong Yi	dissidente chinoise, secrétaire de Wei Jingsheng
16610	16586	Tonino de Bernardi	cinéaste italien
16611	16586	Tonton David	
16612	16586	Tony Hymas	
16613	16586	Tony Secunda	
16614	16586	Topaloff Patrick	
16615	16586	Topor Roland	
16616	16586	Torr Michèle	
16617	16586	Torreton Philippe	
16618	16586	Torrès Anne	
16619	16586	Tort Patrick	spécialiste de Darwin
16620	16586	Tortell Poltrona	
16621	16586	Tortora Enzo	animateur télé
16622	16586	Toscan du Plantier Daniel	
16623	16586	Toscani Oliviero	Photographe, réalisateur des campagnes de pub de Benetton.
16624	16586	Toshes Nick	
16625	16586	Toto Riina	chef des Corleonesi (Mafia)
16626	16586	Toubiana Serge	ex-directeur de la rédaction des Cahiers du Cinéma
16627	16586	Toubon Jacques	
16628	16586	Toubon Lise	
16629	16586	Touchent Ali	
16630	16586	Touhami Ennadre	Photographe
16631	16586	Touitou Jean	
16632	16586	Toulouse-Lautrec Henri	peintre
16633	16586	Touraine Agnès	
16634	16586	Touraine Alain	
16635	16586	Tourgueniev Ivan Sergueïevitch	
16636	16586	Tourneur Jacques	
16637	16586	Tourneur Maurice	
16638	16586	Tournier Michel	
16639	16586	Touré Drissa	
16640	16586	Toussaint Jean-Philippe	
16641	16586	Touvier Paul	
16642	16586	Touyard Gilles	
16643	16586	Touzet Corinne	
16644	16586	Touzé Loïc	
16645	16397	ZZZZ_Personnalités TR	
16646	16645	Traber Matthias	Funambule allemand
16647	16645	Traboulsi Samir	
16648	16645	Traci Lords	star du porno
16649	16645	Tracy Spencer	
16650	16645	Trager René	à l'origine de l'affaire de Gérar Longuet
16651	16645	Trampoglieri Alain	voisin de l'Elysée
16652	16645	Tran Anh Hung	Réalisateur vietnamien
16653	16645	Tranchant Georges	
16654	16645	Transeau Brian	
16655	16645	Traore Alassane	
16656	16645	Traoré Lobi	
16657	16645	Traoré Mamadou	
16658	16645	Trapattoni Giovanni	
16659	16645	Trauner Alexandre	
16660	16645	Trautmann Catherine	maire PS de Strasbourg
16661	16645	Travolta John	acteur américain
16662	16645	Trenet Charles	
16663	16645	Trenet Didier	
16664	16645	Trent d'Arby Terence	
16665	16645	Trezeguet David	
16666	16645	Tribalat Michèle	
16667	16645	Trichet Jean-Claude	
16668	16645	Tricky	rock
16669	16645	Trier Lars Von	
16670	16645	Trigano Gilbert	
16671	16645	Trigano Serge	
16672	16645	Trigano Shmuel	écrivain
16673	16645	Trigon Marcel	
16674	16645	Trimble David	
16675	16645	Trinh Cong Son	
16676	16645	Trintignant Jean-Louis	
16677	16645	Trintignant Marie	
16678	16645	Trintignant Nadine	
16679	16645	Triolet Elsa	
16680	16645	Tripping Daisy	
16681	16645	Tritt Travis	
16682	16645	Trividic Pierre	
16683	16645	Troche Rose	
16684	16645	Troeltsch Ernst	
16685	16645	Trojan Carlo	
16686	16645	Trollope Joanna	
16687	16645	Tron Georges	
16688	16645	Troncy Eric	
16689	16645	Trondheim Lewis	auteur de BD
16690	16645	Trotski Léon	
16691	16645	Troyat Henri	
16692	16645	Truche Pierre	procureur/Cour de cassation
16693	16645	Trucy François	Sénateur-maire UDF-PR
16694	16645	Trueba Fernando	
16695	16645	Truffaut François	
16696	16645	Trulli Jarno	
16697	16645	Trump Donald	
16698	16397	ZZZZ_Personnalités TS	
16699	16698	Tsai Ming-Liang	
16700	16698	Tsaï Gilberte	
16701	16698	Tschumi Bernard	
16702	16698	Tsepeneag Dumitru	
16703	16698	Tshisekedi Etienne	
16704	16698	Tsvangirai Morgan	
16705	16698	Tsvetaieva Maria	
16706	16397	ZZZZ_Personnalités TU	
16707	16706	Tubiana Maurice	
16708	16706	Tudjman Franjo	président croate
16709	16706	Tuefferd François	
16710	16706	Tuel Laurent	
16711	16706	Tuffeli Monique	
16712	16706	Tullio Brigida	
16713	16706	Tung Chee-hwa	
16714	16706	Turboust Arnold	
16715	16706	Turcey Valery	secr. gal. de l'Union syndical des magistrats
16716	16706	Turgun Alimatov	
16717	16706	Turner Ike	
16718	16706	Turner Ted	
16719	16706	Turner Tina	
16720	16706	Turpin Michel	président de la commission d'enquête des scientifiques sur le stockage du centre de déchets radioactifs de la CSM à La Hague
16721	16706	Turquin Jean-Louis	
16722	16706	Turtletaub Jon	
16723	16706	Turturro John	acteur
16724	16706	Tutin Caroline	Directrice du Centre international de recherches médicales de Franceville (Cirmf) au Gabon, spécialiste des gorilles
16725	16706	Tutu Desmond	
16726	16397	ZZZZ_Personnalités TW	
16727	16726	Twagiramungu Faustin	
16728	16397	ZZZZ_Personnalités TY	
16729	16728	Tyler Liv	
16730	16728	Tyson Mike	
16731	16397	ZZZZ_Personnalités TZ	
16732	16731	Tzara Tristan	
16733	7428	ZZZZ_Personnalités U	
16734	16733	ZZZZ_Personnalités U2	
16735	16734	U2 (rock)	groupe derock irlandais
16736	16733	ZZZZ_Personnalités UB	
16737	16736	Ubrique Jesulin de	Matador
16738	16733	ZZZZ_Personnalités UD	
16739	16738	Uderzo Albert	personnalites u
16740	16733	ZZZZ_Personnalités UF	
16741	16740	Ufan Lee	
16742	16733	ZZZZ_Personnalités UK	
16743	16733	ZZZZ_Personnalités UL	
16744	16743	Ullman Georges	
16745	16743	Ullmann Liv	
16746	16743	Ullrich Jan	
16747	16743	Ulpat Anne	écrivain
16748	16743	Ulrike Meinhof	membre de la RAF
16749	16733	ZZZZ_Personnalités UM	
16750	16733	ZZZZ_Personnalités UN	
16751	16750	Unabomber	
16752	16750	Unal Kasim	
16753	16750	Ung Huot	
16754	16750	Ungauer Sylvie	
16755	16733	ZZZZ_Personnalités UP	
16756	16755	Updike John	romancier anglais
16757	16733	ZZZZ_Personnalités UR	
16758	16757	Urban Jerzy	
16759	16757	Uribe Alvaro	
16760	16757	Uribe Imanol	
16761	16757	Urquhart Jane	
16762	16757	Urska Hrovat	
16763	16757	Ursula Gauthier	journaliste
16764	16733	ZZZZ_Personnalités UT	
16765	16764	Utrillo Maurice	peintre
16766	16733	ZZZZ_Personnalités UW	
16767	16766	Uwe Barschel	
16768	7428	ZZZZ_Personnalités V	
16769	16768	ZZZZ_Personnalités VA	
16770	16769	Vacheron Raymond	
16771	16769	Vachon Christine	
16772	16769	Vacquin Henri	sociologue
16773	16769	Vadim Roger	
16774	16769	Vahakn Dadrian	
16775	16769	Vailland Roger	
16776	16769	Vaillant Daniel	
16777	16769	Vairelles Tony	
16778	16769	Vajpayee Atal Behari	
16779	16769	Val Philippe	
16780	16769	Valade Jacques	sénateur RPR et président du Conseil régional d'Aquitaine
16781	16769	Valantin Emilie	marionnettiste
16782	16769	Valat Jean-Paul	juge d'instruction chargé de l'affaire des écoutes du PS
16783	16769	Valderrama Carlos	
16784	16769	Valdez Hugo Avellaneda	
16785	16769	Valdès Zoé	Ecrivain cubain.
16786	16769	Valenti Jack	
16787	16769	Valentini Michel	
16788	16769	Valentino Foti	
16789	16769	Valeri Poliakov	cosmonaute/440 j dans l'espace
16790	16769	Valery Kayumba	boxeur
16791	16769	Valery Piankov	gal. russe
16792	16769	Valery Polyakov	astronaute soviétique
16793	16769	Valleix Jean	
16794	16769	Valletti Serge	
16795	16769	Valli Alarmel	
16796	16769	Valls Manuel	
16797	16769	Vallès Francis	
16798	16769	Valo Laurent	
16799	16769	Valérie Tracqui	écrivain
16800	16769	Van Allsburg Chris	
16801	16769	Van Beirendonck Walter	
16802	16769	Van Cauwelaert Didier	écrivain, prix Goncourt 1994
16803	16769	Van Dam José	Baryton belge
16804	16769	Van Damme Jean-Claude	
16805	16769	Van Den Heede Jean-Luc	voile
16806	16769	Van Dormael Jaco	
16807	16769	Van Gogh Vincent	
16808	16769	Van Hamme Jean	
16809	16769	Van Miert Karel	
16810	16769	Van Noten Dries	
16811	16769	Van Passel Frank	
16812	16769	Van Peebles Melvin	
16813	16769	Van Ruymbeke Renaud	juge d'instruction
16814	16769	Van Sant Gus	photographe et producteur
16815	16769	Van Velde Bram	
16816	16769	Van Warmerdam Alex	
16817	16769	Van Zandt Townes	
16818	16769	Van de Steene Benoît	
16819	16769	Van der Biest Alain	
16820	16769	Van der Keuken Johan	
16821	16769	Vance William	
16822	16769	Vanden Eeckhoudt Michel	
16823	16769	Vandenbroucke Frank	
16824	16769	Vandepoorte Serge	
16825	16769	Vanderlove Anne	
16826	16769	Vanderschmitt Georges	
16827	16769	Vandier Jacques	
16828	16769	Vandingenen Philippe	
16829	16769	Vaneigem Raoul	
16830	16769	Vanessa Rubin	
16831	16769	Vannier Jean-Claude	
16832	16769	Vanoni Patrice	
16833	16769	Vanot Silvain	
16834	16769	Vanunu Mordekhai	
16835	16769	Vanverberghe Francis	
16836	16769	Vaquin Henri	sociologue
16837	16769	Varaut Jean-Marc	
16838	16769	Varda Agnès	
16839	16769	Vareille Alain	
16840	16769	Vargas Fred	
16841	16769	Vargas Julian Garcia	
16842	16769	Vargas Llosa Mario	écrivain péruvien
16843	16769	Varin Jean-Philippe	photographe animalier
16844	16769	Varèse Edgar	
16845	16769	Vasarely Victor	peintre sénile
16846	16769	Vasquez Joey	
16847	16769	Vasquez Montalban Manuel	
16848	16769	Vasseur Philippe	vice-président du PR et chiraquien
16849	16769	Vassili Pitchoul	cinéaste russe
16850	16769	Vassiliev Vladimir	nouveau directeur du Bolchoï de Moscou
16851	16769	Vassilikos Vassilis	
16852	16769	Vatine Paul	navigateur
16853	16769	Vaturi Clément	
16854	16769	Vaude Nicolas	
16855	16769	Vaugelade Anaïs	
16856	16769	Vaujour Michel	
16857	16769	Vautrin Jean	
16858	16769	Vauzelle Michel	
16859	16768	ZZZZ_Personnalités VE	
16860	16859	Veber Francis	
16861	16859	Vecchi Philippe	
16862	16859	Vecchiali Paul	cinéaste français
16863	16859	Vega Alan	
16864	16859	Vega Suzanne	
16865	16859	Vegard Ulvang	champion olympique de ski de fond et alpiniste
16866	16859	Veil Simone	
16867	16859	Veillon Dominique	
16868	16859	Veinstein Alain	
16869	16859	Veinstein Gilles	
16870	16859	Velayati	
16871	16859	Veloso Caetano	
16872	16859	Velter André	
16873	16859	Veltroni Walter	
16874	16859	Velvet Underground	
16875	16859	Ventura Claude	réalisateur de documentaire
16876	16859	Ventura Lino	
16877	16859	Ventura Perez Marino	juge espagnol rebelle à Felipe Gonzalez dans le procès du GAL
16878	16859	Verdi Giuseppe	
16879	16859	Verdi Jean-Martin	
16880	16859	Vergne Philippe	
16881	16859	Vergès Jacques	
16882	16859	Vergès Pierre	
16883	16859	Verhaeghe Jean-Daniel	
16884	16859	Verhoeven Paul	
16885	16859	Verhofstadt Guy	
16886	16859	Verlaine Paul	
16887	16859	Vermeer Johannes	
16888	16859	Vermillard Marie	
16889	16859	Vernant Jean-Pierre	
16890	16859	Vernaudon Emile	
16891	16859	Verne Jules	
16892	16859	Vernes Jean-Marc	
16893	16859	Verneuil Henri	
16894	16859	Vernier Jacques	
16895	16859	Vernoux Marion	
16896	16859	Verny Dina	
16897	16859	Verny Françoise	
16898	16859	Verret François	
16899	16859	Verret Thierry	
16900	16859	Versace Gianni	
16901	16859	Verstappen Jos	
16902	16859	Veruca Salt	Groupe de rock
16903	16859	Vervoort Jean-Marc	
16904	16859	Verwoerd Betsie	
16905	16859	Vesna Misanovic	
16906	16859	Veyrat Marc	grand chef cuistot, spécialiste des herbes sauvages
16907	16859	Veyrenche Jean-Pierre	
16908	16859	Veyrinas Françoise de	
16909	16859	Veyron Martin	
16910	16859	Veysset Sandrine	
16911	16859	Védrine Hubert	
16912	16859	Véricel Christiane	
16913	16859	Véricourt Emmanuel de	
16914	16859	Véronique Colucci	
16915	16768	ZZZZ_Personnalités VI	
16916	16915	Vial Patrick	
16917	16915	Viala Jean	
16918	16915	Vialatte Michel	
16919	16915	Viallat Claude	
16920	16915	Vialle Tatiana	
16921	16915	Viallet Jacky	
16922	16915	Vian Boris	
16923	16915	Viannet Louis	Secrétaire général de la CGT
16924	16915	Viard Karin	
16925	16915	Viatte Germain	
16926	16915	Vicari Andrew	
16927	16915	Vicentico Valdès	
16928	16915	Vichnievsky Laurence	
16929	16915	Vick Graham	metteur en scène de théâtre
16930	16915	Vickers Martha	
16931	16915	Victor Jackovitch	Ambassadeur sortant des Etats-Unis à Sarajevo
16932	16915	Victor Merlhès	critique d'art
16933	16915	Victor Paul-Emile	
16934	16915	Victor Pelson	vice-pdt d'ATT (groupe de télécom)
16935	16915	Victor Zigelman	
16936	16915	Victor Zvunka	football
16937	16915	Vidal Philippe	
16938	16915	Vidor Charles	
16939	16915	Vidor King	cinéaste
16940	16915	Vieira Patrick	
16941	16915	Viens Gaston	
16942	16915	Vigner Eric	
16943	16915	Vignon Dominique	
16944	16915	Vigny Alfred de	
16945	16915	Vigo Jean	
16946	16915	Vigouroux Robert	
16947	16915	Viguier Cyril	
16948	16915	Vikram Seth	écrivain anglais d'origine Indoue
16949	16915	Viktor Erine	
16950	16915	Viktor Kund	
16951	16915	Viktor Slavkine	Auteur russe de théâtre
16952	16915	Viktor Ullmann	
16953	16915	Vila-Matas Enrique	écrivain espagnol
16954	16915	Vilar Jean	
16955	16915	Vilbenoit Marc	
16956	16915	Vilela Guillermo	
16957	16915	Villeneuve Charles	homme de télévision
16958	16915	Villeneuve Jacques	
16959	16915	Villeneuve Jeanne	
16960	16915	Villepin Dominique de	
16961	16915	Villepreux Pierre	
16962	16915	Villeroy de Galhau François	
16963	16915	Villers Claude	
16964	16915	Villiers Philippe de	
16965	16915	Villin Philippe	homme de presse et gérant d'une banque financière
16966	16915	Villégier Jean-Marie	Metteur en scène théâtre
16967	16915	Vincensini Noëlle	
16968	16915	Vincent Christian	
16969	16915	Vincent Gérard	
16970	16915	Vincent Jean-Pierre	
16971	16915	Vincent Scheffels	curé de nanterre
16972	16915	Vincent de Gaulejac	sociologue
16973	16915	Vincenti Denis	
16974	16915	Vincenti Jean-Charles de	
16975	16915	Vinci Léonard de	
16976	16915	Vindras Isabelle	Isabelle Vindras est présidente de la section française de l'Observatoire international des prisons.
16977	16915	Vini Reilly	
16978	16915	Vinik Jeffrey	
16979	16915	Vinnie Pazienza	
16980	16915	Viola Bill	
16981	16915	Violet Bernard	journaliste
16982	16915	Violeta Chamorro	pdte. du Nicaragua
16983	16915	Vion Michel	
16984	16915	Virenque Richard	Cycliste
16985	16915	Virgilio Martini	écrivain
16986	16915	Virginie Thévenet	réalisatrice française
16987	16915	Virieu François-Henri de	journaliste-présentateur
16988	16915	Virilio Paul	
16989	16915	Visage Bertrand	
16990	16915	Visconti Luchino	
16991	16915	Vita Sackville-West	écrivain
16992	16915	Vitali Massol	Premier ministre conservateur ukrainien
16993	16915	Vitali Tretiakov	directeur du quotidien moscovite Nezavissimaïa Gazeta
16994	16915	Vitez Antoine	
16995	16915	Vitor Pavao dos Santos	responsable du centre d'archivage du théâtre de Lisbonne
16996	16915	Vittorio Giardino	BD italienne
16997	16915	Vivette Samuel	ex-résistante qui sauva les enfants juifs de Vichy
16998	16915	Viviant Arnaud	
16999	16915	Vivien Alain	
17000	16915	Viénot Marc	pdg de la Société Générale
17001	16768	ZZZZ_Personnalités VL	
17002	17001	Vladimir Kokonine	
17003	17001	Vladimir Maximov	
17004	17001	Vladimir Smirnov	
17005	17001	Vladimir Tikhonov	
17006	17001	Vladislav Listiev	directeur de la télé russe
17007	17001	Vladislav Starkov	Rédacteur en chef du plus grand hebdomadaire russe "Argoumenti i fakti'
17008	16768	ZZZZ_Personnalités VO	
17009	17008	Vo Van Kiet	Premier ministre du Viêt-nam
17010	17008	Voeller Rudi	
17011	17008	Vogelweith Alain	juge
17012	17008	Voinnet Richard	
17013	17008	Voinquel Raymond	
17014	17008	Voirin Jean	
17015	17008	Voisin Jacques	
17016	17008	Volcker Paul	
17017	17008	Volker Bernard	
17018	17008	Volodine Antoine	
17019	17008	Volodos Arcadi	
17020	17008	Volski Arkadi	
17021	17008	Voltaire	
17022	17008	Voss Gert	
17023	17008	Vostell wolf	
17024	17008	Vouet Simon	
17025	17008	Vovelle Michel	
17026	17008	Voynet Dominique	
17027	16768	ZZZZ_Personnalités VR	
17028	17027	Vranitzky Franz	
17029	17027	Vreni Schneider	skieuse
17030	16768	ZZZZ_Personnalités VU	
17031	17030	Vu An Eric	
17032	17030	Vuillemin Philippe	
17033	7428	ZZZZ_Personnalités W	
17034	17033	ZZZZ_Personnalités WA	
17035	17034	Wachowski Larry et Andy	
17036	17034	Wachowski Mieczyslaw	Chef de cabinet et ami de Lech Walesa, le président de la Pologne.
17037	17034	Wachter Anita	skieuse autrichienne
17038	17034	Waddington Steven	
17039	17034	Wade Abdoulaye	
17040	17034	Wadia Riyad Vinci	
17041	17034	Waechter Antoine	
17042	17034	Waechter Bruno	
17043	17034	Wagner Bruce	
17044	17034	Wagner Paul	
17045	17034	Wagner Richard	musicien
17046	17034	Waigel Theo	
17047	17034	Waite Terry	
17048	17034	Wajda Andrzej	
17049	17034	Wajed Hasina	
17050	17034	Wajsbrot Cécile	
17051	17034	Walcott Derek	
17052	17034	Waldeck-Rousseau	président du Conseil
17053	17034	Waldemar Pawlak	1er ministre polonais
17054	17034	Waldheim Kurt	
17055	17034	Walesa Lech	
17056	17034	Walken Christopher	
17057	17034	Walker Scott	
17058	17034	Wall Jeff	
17059	17034	Wallace David Foster	
17060	17034	Wallace Henry	Henry Wallace
17061	17034	Wallenberg Raoul	
17062	17034	Wallon Dominique	
17063	17034	Walser Robert	
17064	17034	Walsh Raoul	
17065	17034	Walter Bonatti	
17066	17034	Walters Minette	
17067	17034	Walther Joachim	
17068	17034	Waltrip Robert	
17069	17034	Wamytan Roch	
17070	17034	Wanda Jakubowska	
17071	17034	Wang Dan	Dissident chinois, ancien leader étudiant
17072	17034	Wang Wayne	
17073	17034	Ward Connerly	Noir américain qui défend les quotas raciaux Noirs/Blancs
17074	17034	Ward Peter	
17075	17034	Ware Chris	
17076	17034	Ware David S.	
17077	17034	Wareing Bob	
17078	17034	Wargnier Régis	
17079	17034	Warhol Andy	
17080	17034	Warin Odile	
17081	17034	Warner Deborah	
17082	17034	Warren Christopher	
17083	17034	Warren G	
17084	17034	Warren Zimmerman	Ambassadeur des Etats-Unis à Belgrade de 1989 à 1992
17085	17034	Warrilow David	théâtre
17086	17034	Wassmo Herbjorg	
17087	17034	Wastiaux François	
17088	17034	Watkins Gérard	
17089	17034	Watkins Peter	
17090	17034	Watson Emily	
17091	17034	Watt Ben	
17092	17034	Watterson Bill	
17093	17034	Watts Charlie	
17094	17034	Waugh Evelyn	
17095	17034	Wauthier Claude	
17096	17034	Wavelet Christophe	
17097	17034	Waylon Jennings	ancien bassiste de Buddy Holly et cofondateur du Mouvement Outlaw
17098	17034	waldner jan-Owe	
17099	17033	ZZZZ_Personnalités WE	
17100	17099	Weah George	
17101	17099	Wearing Gillian	
17102	17099	Weaver Sigourney	
17103	17099	Weber Eugen	
17104	17099	Weber Florence	
17105	17099	Weber Henri	
17106	17099	Weber Jacques (comédien)	
17107	17099	Weber Jean-Jacques	pdt. conseil gal./Haut-Rhin
17108	17099	Weber Max	
17109	17099	Wedekind Franz	
17110	17099	Weeks Kent	égyptologue et découvreur des tombes des fils de Ramsès II
17111	17099	Weezer	groupe de rock
17112	17099	Wegman William	
17113	17099	Wehrling Yann	
17114	17099	Wei Jingsheng	
17115	17099	Weil Patrick	
17116	17099	Weill Kurt	
17117	17099	Weinberg Serge	
17118	17099	Weinrich Johannes	
17119	17099	Weir Peter	
17120	17099	Weisbuch Paul	
17121	17099	Weiss Julien	
17122	17099	Weissflog Jens	champion de ski
17123	17099	Weitzmann Marc	
17124	17099	Weizmann Ezer	
17125	17099	Wellek René	
17126	17099	Weller Frederick	
17127	17099	Welles Orson	
17128	17099	Wells Herbert George	
17129	17099	Wells Patricia	critique cuisine
17130	17099	Welsh Irvine	
17131	17099	Wen Jiabao	
17132	17099	Wendelin Wiedeking	président du consistoire de Porsche
17133	17099	Wenders Wim	cinéaste
17134	17099	Wenger Arsène	
17135	17099	Wenzel Jean-Paul	
17136	17099	Werfel Franz	
17137	17099	Werner Helmut	
17138	17099	Wernicke Herbert	
17139	17099	Wescott Glenway	
17140	17099	Wesselmann Tom	
17141	17099	West Dudley	
17142	17099	West Frederick	tueur en série
17143	17099	West Mae	
17144	17099	West Paul	écrivain britannique vivant aux USA
17145	17099	West Richard	astronome
17146	17099	West Rosemary	femme de F.West
17147	17099	Westlake Donald	
17148	17099	Weston Edward	
17149	17099	Westwood Vivienne	
17150	17099	Weyergans François	
17151	17099	Weygand Lucien	
17152	17033	ZZZZ_Personnalités WH	
17153	17152	Whelan Tim	
17154	17152	Whistler James Abbott McNeil	peintre américain
17155	17152	Whit Stillman	cinéaste
17156	17152	Whitaker Forest	
17157	17152	White Anthony	
17158	17152	White Marco Pierre	
17159	17152	White Tony Joe	
17160	17152	Whitley Chris	
17161	17033	ZZZZ_Personnalités WI	
17162	17161	Wiazemsky Anne	
17163	17161	Wiberg Pernilla	ski/championne olympique
17164	17161	Wideman John Edgar	
17165	17161	Widmer Jean	
17166	17161	Wiecha Edouard A.	professeur de civilisation française à Munich
17167	17161	Wiehn Pierre	
17168	17161	Wienand Karl	
17169	17161	Wieschaus Eric	Prox Nobel de médecine 1995
17170	17161	Wiesel Elie	
17171	17161	Wiesenthal Simon	Directeur du centre de documentation juif de Vienne
17172	17161	Wieviorka Annette	
17173	17161	Wieviorka Michel	
17174	17161	Wiktor Sidorenko	vice-ministre russe de l'énergie atomique
17175	17161	Wilde Oscar	
17176	17161	Wilder Billy	
17177	17161	Wilen Barney	
17178	17161	Wilfried Nelissen	vainqueur de Paris-Nice
17179	17161	Wilkie Collins	romancier victorien
17180	17161	Will Carling	Capitaine de l'équipe de rugby d'Angleterre.
17181	17161	Willem	BD
17182	17161	William Durand	
17183	17161	William K. Howard	cinéaste américain
17184	17161	William Perry	secrétaire américain à la Défense
17185	17161	William T. Hurtz	auteur de BD américano-nippon
17186	17161	Williams Cunnie	
17187	17161	Williams Peter	
17188	17161	Williams Robin	
17189	17161	Williams Serena	
17190	17161	Williams Stephen	
17191	17161	Williams Venus	
17192	17161	Willis Bruce	
17193	17161	Willy Stricker	
17194	17161	Willy Van Coppernolle	
17195	17161	Wilmotte Joël	
17196	17161	Wilms André	
17197	17161	Wilson Brian	Compositeur des Beach boys
17198	17161	Wilson Lambert	Acteur-chanteur
17199	17161	Wilson Robert	
17200	17161	Wiltrud Hendriks	théologienne protestante
17201	17161	Wim Mertens	pianiste new-wave belge
17202	17161	Wincer Simon	
17203	17161	Windhorst Lars	
17204	17161	Winfrey Oprah	
17205	17161	Wingrove Nigel	
17206	17161	Winkler Angela	
17207	17161	Winner Michael	
17208	17161	Winningham Mare	
17209	17161	Winock Michel	
17210	17161	Winston Zulu	
17211	17161	Winter Ophélie	
17212	17161	Winterbottom Michael	
17213	17161	Winterson Jeanette	écrivain
17214	17161	Wise Robert	
17215	17161	Wiseman Frederick	
17216	17161	Witkin Joel-Peter	
17217	17161	Witt Karsten	
17218	17161	Wittgenstein Ludwig	
17219	17161	Wittkop Gabrielle	
17220	17033	ZZZZ_Personnalités WO	
17221	17220	Woerth Eric	 
17222	17220	Wolf Christa	
17223	17220	Wolf Markus	
17224	17220	Wolfensohn James	président de la Banque mondiale
17225	17220	Wolfgang Sawallisch	
17226	17220	Wolfgang Sofsky	sociologue allemand
17227	17220	Wolfowitz Paul	
17228	17220	Wolman Gil	
17229	17220	Wolton Dominique	
17230	17220	Wolton Thierry	
17231	17220	Wonder Stevie	musicien soul
17232	17220	Woo Choong Kim	
17233	17220	Woo John	
17234	17220	Wood Ed	
17235	17220	Wood Frances	
17236	17220	Wood Ron	
17237	17220	Woods Tiger	
17238	17220	Woolf Virginia	romancière féministe américaine
17239	17220	Worms Gérard	Président du groupe Suez
17240	17220	Wouts Bernard	PdG du Point
17241	17033	ZZZZ_Personnalités WU	
17242	17241	Wu Harry	
17243	17241	Wu Tang Clan	
17244	17241	Wuer Kaixi	
17245	17241	Wumba Nzaki	
17246	17241	Wuttke Martin	
17247	17241	Wuttle Martin	
17248	17033	ZZZZ_Personnalités WY	
17249	17248	Wyler Bea	
17250	17248	Wyler William	
17251	17248	Wyman Bill	
17252	17248	Wyspianski Stanislas	
17253	7428	ZZZZ_Personnalités X	
17254	17253	ZZZZ_Personnalités XA	
17255	17254	Xatard Jean	
17256	17254	Xavier Bodin-Hullin	
17257	17254	Xavier Chinaud	balladurien
17258	17254	Xavier Ellie	directeur de la publication du Progrès
17259	17254	Xavier Roy	organisateur du MIP-Asia
17260	17253	ZZZZ_Personnalités XE	
17261	17260	Xenakis Iannis	
17262	17253	ZZZZ_Personnalités XI	
17263	17262	Xianyong Bai	
17264	17262	Xiao-Yen Wang	
17265	17262	Xiaowen Zou	
17266	17262	Xie Jin	
17267	17262	Xingjian Gao	
17268	17253	ZZZZ_Personnalités XU	
17269	17268	Xu Wenli	dissident chinois
17270	7428	ZZZZ_Personnalités Y	
17271	17270	ZZZZ_Personnalités YA	
17272	17271	Yakovlev Vladimir	
17273	17271	Yamamoto Yohji	
17274	17271	Yamgnane Kofi	
17275	17271	Yang Edward	
17276	17271	Yanis Hisham	
17277	17271	Yann Delaigue	rugbyman
17278	17271	Yann-Ber Tillenon	
17279	17271	Yanne Jean	acteur
17280	17271	Yannick Beugnet	victime attentat
17281	17271	Yannick Bodin	président du groupe socialiste au conseil régional et 1er secrétaire du PS en Seine-et-Marne
17282	17271	Yared Basile	
17283	17271	Yashar Kemar	
17284	17271	Yassine Abdessalam	
17285	17271	Yassine Ahmed	
17286	17271	Yasushi Akashi	
17287	17271	Yates Peter	
17288	17271	Yavlinski Grigori	
17289	17270	ZZZZ_Personnalités YE	
17290	17289	Yeats William Butler	
17291	17289	Yehoshua Avraham B.	écrivain israélien
17292	17289	Yersin Claude	
17293	17270	ZZZZ_Personnalités YI	
17294	17293	Yilmaz Mesut	
17295	17293	Yimou Zhang	
17296	17293	Ying Ning	
17297	17270	ZZZZ_Personnalités YO	
17298	17297	Yo La Tengo	
17299	17297	Yoncourt Bernard	
17300	17297	Yorke Thom	
17301	17297	Yoshida Kijû	
17302	17297	Yoshida Yoshishige	
17303	17297	Yoshimoto Banana	
17304	17297	Youcef	
17305	17297	Young Andrew	
17306	17297	Young Faron	
17307	17297	Young Neil	musicien
17308	17297	Yourcenar Marguerite	
17309	17297	Youssef Qaradhawi	Théologien égyptien
17310	17270	ZZZZ_Personnalités YU	
17311	17310	Yuan Shang Lin	
17312	17310	Yukio Aoshima	gouverneur de Tokyo
17313	17310	Yurtçu Isik	
17314	17310	Yusuf Vrioni	
17315	17270	ZZZZ_Personnalités YV	
17316	7428	ZZZZ_Personnalités Z	
17317	17316	ZZZZ_Personnalités ZA	
17318	17317	Zabel Erik	
17319	17317	Zacharopoulos Denys	
17320	17317	Zachmann Patrick	Photographe.
17321	17317	Zadek Annie	
17322	17317	Zadek Peter	
17323	17317	Zaepffel Gilles	
17324	17317	Zafy Albert	
17325	17317	Zagdanski Stéphane	écrivain
17326	17317	Zagury Daniel	
17327	17317	Zahar Mahmoud	
17328	17317	Zahonero Coraly	
17329	17317	Zahouania	
17330	17317	Zahouania Chaba	
17331	17317	Zakaïev Akhmed	
17332	17317	Zakel Ludek	
17333	17317	Zambello Francesca	
17334	17317	Zangwill Israël	
17335	17317	Zanuck Darryl Francis	
17336	17317	Zaoui Ahmed	
17337	17317	Zapata Emiliano	
17338	17317	Zapatero José Luis Rodriguez	
17339	17317	Zappa Frank	
17340	17317	Zarifian Edouard	
17341	17317	Zarka Pierre	
17342	17317	Zarnitsky Laurent	
17343	17317	Zavaro Maurice	
17344	17317	Zawinul Joe	
17345	17317	Zaïdi Rachid	
17346	17316	ZZZZ_Personnalités ZE	
17347	17346	Zedillo Ernesto	
17348	17346	Zeffirelli Franco	cinéaste italien
17349	17346	Zeller Adrien	
17350	17346	Zelnik Patrick	
17351	17346	Zemaïch Mohamed	
17352	17346	Zemeckis Robert	Réalisateur
17353	17346	Zenawi Meles	
17354	17346	Zender Hans	
17355	17346	Zerbi Gérard	
17356	17346	Zeroual Liamine	
17357	17346	Zervudacki Cécile	anthropologue et linguiste
17358	17316	ZZZZ_Personnalités ZH	
17359	17358	Zhang Yuan	
17360	17358	Zhenxiang Yao	
17361	17358	Zhu Rongji	
17362	17316	ZZZZ_Personnalités ZI	
17363	17362	Ziant Georges	
17364	17362	Zidane Zinedine	Joueur de football.
17365	17362	Zidi Claude	
17366	17362	Ziegler Jean	
17367	17362	Ziming Chen	
17368	17362	Zimmerman Bernard	
17369	17362	Zine El Abidine Ben Ali	
17370	17362	Zinoviev Alexandre	
17371	17362	Ziouganov Guennadi	
17372	17362	Zisyadis Joseph	
17373	17362	Zito	réfugié mozambicain
17374	17362	Zitouni Djamel	
17375	17362	Zitrone Léon	
17376	17362	Zizola Giancarlo	
17377	17316	ZZZZ_Personnalités ZL	
17378	17316	ZZZZ_Personnalités ZO	
17379	17378	Zola Emile	
17380	17378	Zonca Erick	
17381	17378	Zouabri Antar	
17382	17378	Zourabichvili François	
17383	17316	ZZZZ_Personnalités ZU	
17384	17383	Zubak Kresimir	
17385	17383	Zubin Mehta	
17386	17383	Zucca Pierre	
17387	17383	Zuccarelli Emile	
17388	17383	Zucco Roberto	criminel italien
17389	17383	Zucker Jerry	
17390	17383	Zulawski Andrezj	
17391	17383	Zumthor Paul	historien, philologue
17392	17383	Zurlini Valerio	
17393	17383	Zülle Alex	
17394	17316	ZZZZ_Personnalités ZW	
17395	17394	Zweig Stefan	
17396	17394	Zwickel Klaus	
17397	17394	Zwierzchlewski Benoît	
17398	17394	Zwigoff Terry	Réalisateur
17399	\N	Altran	 
17400	\N	Free	 
17401	\N	Ryanair	 
17402	\N	Confédération syndicale internationale	 
17403	\N	société des lecteurs	 
17404	\N	MySpace	 
17405	\N	Gusenbauer Alfred	 
17406	\N	Correa Rafael	 
17407	\N	Pöttering Hans-Gert	 
17408	\N	Racine Bruno	 
17409	\N	Phelps Michael	 
17410	\N	Thorpe Ian	 
17411	\N	de Pouzilhac Alain	 
17412	\N	C. Noonan	 
17413	\N	M. Richard-Serrano	 
17414	\N	Piton de la Fournaise	 
17415	\N	inactif	 
17416	\N	Smoby	 
17417	\N	Phil Spector	 
17418	\N	Final Fantasy	 
17419	\N	Raymond Marcillac	 
17420	\N	Obama Barack	 
17421	\N	Enel	 
17422	\N	Endesa	 
17423	\N	Wal-Mart	 
17424	\N	slam	 
17425	\N	Dils Patrick	 
17426	\N	Gallo Max	 
17427	\N	Police Justice	
17428	\N	Désastres et Accidents	
17429	\N	Economie, et Finances	
17430	\N	Education	
17431	\N	Gens, animaux, insolite	
17432	\N	Social	
17433	\N	Vie quotidienne et Loisirs	
17434	\N	Religion et croyance	
17435	\N	Science et Technologie	
17436	\N	Société	
17437	\N	Guerres et conflits	
17438	\N	Météo	
17439	\N	Hippique	
17440	\N	Cours de Bourse	
17441	\N	Notes de service	
17442	\N	Général	
17443	\N	Magazine	
17444	\N	Arts, Culture et Spectacles	
17445	\N	International	
17446	\N	contestation	\N
17447	\N	quiz	\N
17448	\N	Johnny Hallyday	\N
17449	\N	the Kills	\N
17450	\N	révolte	\N
17451	\N	islam	\N
17452	\N	système politique	\N
17453	\N	Mode	\N
17454	\N	Prêt-à-porter	\N
17455	\N	2011	\N
17456	\N	Mouammar Kadhafi	\N
17457	\N	Livre	\N
17458	\N	Roberto Bolaño	\N
17459	\N	Musique	\N
17460	\N	François Baroin	\N
17461	\N	Alain Juppé	\N
17462	\N	Cinéma	\N
17463	\N	précarité	\N
17464	\N	Procès	\N
17465	\N	Partis politiques	\N
17466	\N	Patrick Devedjian	\N
17467	\N	Pete Doherty	\N
17468	\N	spectateur	\N
17469	\N	Fabien Engelmann	\N
17470	\N	Front national	\N
17471	\N	internet	\N
17472	\N	consommateur	\N
17473	\N	établissement d'enseignement supérieur	\N
17474	\N	G20	\N
17475	\N	parti socialiste	\N
17476	\N	matière première	\N
17477	\N	pays en voie de développement	\N
17478	\N	travail	\N
17479	\N	condition de travail	\N
17480	\N	Vincent Lindon	\N
17481	\N	Jean-Pierre Bacri	\N
17482	\N	Ali Abdullah Saleh	\N
17483	\N	Sahel	\N
17484	\N	français à l'étranger	\N
17485	\N	Famille	\N
17486	\N	Danse	\N
17487	\N	bourse	\N
17488	\N	Jean-Pierre Jouyet	\N
17491	\N	Boulogne-sur-Mer	\N
17494	\N	adolescent	\N
17495	\N	Comédie française	\N
17496	\N	Georges Feydeau	\N
17497	\N	gel	\N
17498	\N	Etats-unis	\N
17676	\N	gastronomie	\N
17678	\N	Didier Lombard	\N
17679	\N	conseil	\N
17681	\N	Silvio Berlusconi	\N
17682	\N	Presse écrite	\N
17683	\N	Curzio Malaparte	\N
17685	\N	Henri Bergson	\N
17686	\N	drogue	\N
17687	\N	amphétamine	\N
17688	\N	François Nourissier	\N
17690	\N	blasphème	\N
17693	\N	Hervé Novelli	\N
17694	\N	Eric Zemmour	\N
17695	\N	Le Monde	\N
17696	\N	David Foenkinos	\N
17698	\N	Bertrand Delanoë	\N
17699	\N	supermarché	\N
17700	\N	Michel Mercier	\N
17702	\N	caténaire	\N
17703	\N	Elvis Presley	\N
17707	\N	Iyad Allaoui	\N
17708	\N	insulte	\N
17710	\N	Anne Lauvergeon	\N
17712	\N	Mairie	\N
17716	\N	Sexion d'assaut	\N
17717	\N	Sandrine Bonnaire	\N
17718	\N	Ministère des affaires étrangères	\N
17723	\N	Archos	\N
17725	\N	Gérard Longuet	\N
17726	\N	Xavier Musca	\N
17727	\N	Julien Prévieux	\N
17728	\N	installation	\N
17729	\N	Maghreb islamique (Aqmi)	\N
17731	\N	voyage (déplacement)	\N
17732	\N	réseau ferroviaire	\N
17733	\N	Paris VI	\N
17735	\N	conjoncture\néconomique	\N
17736	\N	coup d'état	\N
17737	\N	Joseph Kabila	\N
17739	\N	Bernard-Henry Lévy	\N
17744	\N	droits de l'Homme	\N
17747	\N	Pays-de-Galles	\N
17753	\N	Luc Chatel	\N
17754	\N	Médiator	\N
17755	\N	droit du malade	\N
17756	\N	Fédération française de cyclisme	\N
17760	\N	Francis Scott Fitzgerald	\N
17767	\N	ruine	\N
17771	\N	sans-domicile fixe	\N
17772	\N	SDF	\N
17776	\N	Ségolène Royal	\N
17779	\N	Nicolas Hulot	\N
17780	\N	Géorgie	\N
17783	\N	Transport aérien	\N
17784	\N	2013	\N
17786	\N	WikiLeaks	\N
17789	\N	Salon (foire)	\N
17790	\N	Éducation nationale	\N
17791	\N	Histoire	\N
17792	\N	Alan Vega	\N
17793	\N	homme politique	\N
17794	\N	Consommation	\N
17795	\N	Christian Karembeu	\N
17796	\N	culture	\N
17799	\N	revendication sociale	\N
17805	\N	élection Présidentielle	\N
17806	\N	travailleur étranger	\N
17810	\N	ministère de la Défense	\N
17811	\N	appel d'offres	\N
17812	\N	Immigration	\N
17817	\N	religion	\N
17819	\N	Barack Obama	\N
17822	\N	trésor public	\N
17826	\N	Sivio Berlusconi	\N
17830	\N	émission  radiophonique	\N
17831	\N	sans papier	\N
17832	\N	Grand Paris	\N
17833	\N	Jean-Paul Huchon	\N
17834	\N	kurdistan	\N
17836	\N	journaliste	\N
17837	\N	Twitter	\N
17841	\N	accident	\N
17842	\N	Danny Boyle	\N
17843	\N	Républicain Lorrain (Le)	\N
17846	\N	Serge Doubrovsky	\N
17849	\N	environnement	\N
17850	\N	Yann-Arthus Bertrand	\N
17852	\N	service secret	\N
17853	\N	Box office	\N
17855	\N	presse sp^écialisée	\N
17856	\N	presse mensuel	\N
17857	\N	Mondadori France	\N
17859	\N	Charles Trenet	\N
17860	\N	testament	\N
17861	\N	droits d'auteur	\N
17863	\N	Skype	\N
17867	\N	Joel Coen	\N
17868	\N	Ethan Coen	\N
17870	\N	CDU	\N
17872	\N	Jonathan Nossiter	\N
17875	\N	Election  cantonale	\N
17876	\N	Mouammar  Kadhafi	\N
17878	\N	Jacques Chirac	\N
17879	\N	DCRI	\N
17880	\N	relation internationale	\N
17881	\N	Energie	\N
17882	\N	institut de sondage	\N
17883	\N	appeld'offre	\N
17884	\N	Patrick Buisson	\N
17885	\N	conflit d'intérêt	\N
17886	\N	syndicalisme	\N
17889	\N	British petroleum	\N
17891	\N	chiffre d'affaire	\N
17892	\N	innovation technique	\N
17893	\N	éducation nationale	\N
17894	\N	capital	\N
17895	\N	La Voix du Nord	\N
17896	\N	retour Toulouse	\N
17897	\N	stage	\N
17898	\N	Jeux olympiques	\N
17899	\N	ministère	\N
17900	\N	Frédéric Mitterrand	\N
17903	\N	Positif (presse)	\N
17904	\N	médecin spécialiste hôpital	\N
17905	\N	encadrement	\N
17906	\N	Politique de l'environnement	\N
17912	\N	année	\N
17914	\N	économie	\N
17915	\N	fondation	\N
17916	\N	écologisme	\N
17917	\N	Vie quotidienne	\N
17918	\N	Affaires étrangères	\N
17919	\N	élection  cantonale	\N
17920	\N	programme électorale	\N
17937	\N	Laurent Delahousse	\N
17947	\N	Jean-Baptiste Grange	\N
17952	\N	Vladimir Poutine	\N
17953	\N	British Museum	\N
17489	\N	Daniel Leconte	\N
17490	\N	Dominique de Villepin	\N
17492	\N	ministre (gouvernement)	\N
17493	\N	Nicolas Sarkozy	\N
17499	\N	Carrefour	\N
17500	\N	Claude Guéant	\N
17501	\N	Henri de Raincourt	\N
17502	\N	Terrorisme	\N
17503	\N	sport	\N
17504	\N	pari	\N
17505	\N	Chantal Jouanno	\N
17506	\N	Jacques Rogge	\N
17507	\N	Alfred Hitchcock	\N
17508	\N	luxe	\N
17509	\N	Chef de l'Etat	\N
17510	\N	objet	\N
17511	\N	Gouvernement	\N
17512	\N	Michèle Alliot-Marie	\N
17513	\N	PS	\N
17514	\N	marché du logement	\N
17515	\N	Télecommunication	\N
17516	\N	Christian Dior	\N
17517	\N	John Galliano	\N
17518	\N	Arlette Chabot	\N
17519	\N	entreprise	\N
17520	\N	Emploi	\N
17521	\N	Bobigny (Hauts-de-Seine)	\N
17522	\N	aide à l'emploi	\N
17523	\N	Benoist Apparu	\N
17524	\N	logement	\N
17525	\N	logo	\N
17526	\N	couple	\N
17527	\N	Insee	\N
17528	\N	basket	\N
17529	\N	Industrie automobile	\N
17530	\N	voiture	\N
17531	\N	groupe politique	\N
17532	\N	Jean-Pierre Raffarin	\N
17533	\N	Jean-Claude Gaudin	\N
17534	\N	Roberto Rossellini	\N
17535	\N	restauration	\N
17536	\N	Jérôme Delormas	\N
17537	\N	payes	\N
17538	\N	François Hollande	\N
17539	\N	Grand prix	\N
17540	\N	formule 1	\N
17541	\N	Bernie Ecclestone	\N
17542	\N	constitution	\N
17543	\N	Laurent Gbagbo	\N
17544	\N	Alassane Ouattara	\N
17545	\N	réfugiés	\N
17546	\N	énergie électrique	\N
17547	\N	pot-de-vin	\N
17548	\N	Politique économique	\N
17549	\N	main-d'œuvre	\N
17550	\N	industrie	\N
17551	\N	Hosni Moubarak	\N
17552	\N	résidence surveillée	\N
17553	\N	Laurent Joffrin	\N
17554	\N	Nouvel Observateur	\N
17555	\N	Photographie	\N
17556	\N	Georges Buschini	\N
17557	\N	ministère des Affaires étrangères Affaires étrangères	\N
17558	\N	Diplomatie	\N
17559	\N	alcool	\N
17560	\N	Henri Guaino	\N
17561	\N	préfecture de police	\N
17562	\N	Jean-François Copé	\N
17563	\N	Marc-Olivier Fogiel	\N
17564	\N	Muammar Kadhafi	\N
17565	\N	Fédération française de football	\N
17566	\N	Arts plastiques	\N
17567	\N	mobilier	\N
17568	\N	Ronan Bouroullec	\N
17569	\N	Erwan Bouroullec	\N
17570	\N	Laurence Parisot	\N
17571	\N	profit	\N
17572	\N	Théâtre	\N
17573	\N	Jérôme Deschamps	\N
17574	\N	Alain Françon	\N
17575	\N	François Fillon	\N
17576	\N	Mediator	\N
17577	\N	actionnariat	\N
17578	\N	Financial Times	\N
17579	\N	Tony Joe White	\N
17580	\N	Bernadette Chirac	\N
17581	\N	performance	\N
17582	\N	Annie Girardot	\N
17583	\N	Bob Dylan	\N
17584	\N	Physique	\N
17585	\N	Mathématiques	\N
17586	\N	Chimie	\N
17587	\N	Elizabeth Taylor	\N
17588	\N	Jason Lamy-Chappuis	\N
17589	\N	Brice Hortefeux	\N
17590	\N	ministère de l'intérieur	\N
17591	\N	Muammar al-Kadhafi	\N
17592	\N	ministère des affaires étrangères	\N
17593	\N	Patrick Ollier	\N
17594	\N	texte intégrale	\N
17595	\N	Pétition	\N
17596	\N	obligation	\N
17597	\N	Royaume-Uni	\N
17598	\N	Serge Gainsbourg	\N
17599	\N	Nord	\N
17600	\N	Manuel Valls	\N
17601	\N	législation	\N
17602	\N	santé	\N
17603	\N	Football	\N
17604	\N	vie quotidienne	\N
17605	\N	bois	\N
17606	\N	voiture électrique	\N
17607	\N	Jacques Dutronc	\N
17608	\N	Michèle  Alliot-Marie	\N
17609	\N	Nicolas sarkozy	\N
17610	\N	Roman Polanski	\N
17611	\N	Sofia Coppola	\N
17612	\N	Airbus	\N
17613	\N	Marine Le Pen	\N
17614	\N	FN	\N
17615	\N	f	\N
17616	\N	Prada Italie	\N
17617	\N	Milan	\N
17618	\N	Jean-Claude Brialy	\N
17619	\N	Laurent Terzieff	\N
17620	\N	Mohamed el-Baradei	\N
17621	\N	Martine Aubry	\N
17622	\N	Transport de voyageur	\N
17623	\N	Karl Lagerfeld	\N
17624	\N	Baptiste Giabiconi	\N
17625	\N	Dior	\N
17626	\N	Christian Lacroix	\N
17627	\N	Al Qaeda	\N
17628	\N	abattoir	\N
17629	\N	Isabella Rossellini	\N
17630	\N	États-Unis	\N
17631	\N	Haut-de-Seine	\N
17632	\N	Organisation des Nations Unies	\N
17633	\N	Florence Cassez	\N
17634	\N	relation diplomatique	\N
17635	\N	agriculture	\N
17636	\N	subvention	\N
17637	\N	médecine	\N
17638	\N	limogeage	\N
17639	\N	kidnapping	\N
17640	\N	Alexandra Lamy	\N
17641	\N	Musiques	\N
17642	\N	Equipement culturel	\N
17643	\N	communication	\N
17644	\N	Energie nucléaire	\N
17645	\N	radioactif	\N
17646	\N	Salon (exposition)	\N
17647	\N	Rabah Ameur-Zaïmeche	\N
17648	\N	Patrick Dupond	\N
17649	\N	ligue des champions	\N
17650	\N	Marylise Lebranchu	\N
17651	\N	Christian Jacob	\N
17652	\N	Dominique Strauss-Kahn	\N
17653	\N	Abdelaziz Bouteflika	\N
17654	\N	Jeanne Moreau	\N
17655	\N	Jean Dujardin	\N
17656	\N	République solidaire	\N
17657	\N	André Glucksman	\N
17658	\N	Hippodrome	\N
17659	\N	Eric Woerth	\N
17660	\N	conflit d'intêrets	\N
17661	\N	taliban	\N
17662	\N	Facebook	\N
17663	\N	cma-cgm	\N
17664	\N	prise de participation	\N
17665	\N	Christine Lagarde	\N
17666	\N	Laurent Wauquiez	\N
17667	\N	coopération économique	\N
17668	\N	Micheèle Alliot-Marie	\N
17669	\N	déficit public	\N
17670	\N	finance publique	\N
17671	\N	disque	\N
17672	\N	Union syndicale des magistrats	\N
17673	\N	Nelson Monfort	\N
17674	\N	opéra Bastille	\N
17675	\N	Museum d'histoire naturelle	\N
17677	\N	Bernard Lavilliers	\N
17680	\N	insurrection	\N
17684	\N	france	\N
17689	\N	enseignement	\N
17691	\N	Prix Nobel	\N
17692	\N	Muhammad Yunus	\N
17697	\N	sexe	\N
17701	\N	Gaëtan Roussel	\N
17704	\N	Marine Le Pen présidence	\N
17705	\N	sénat	\N
17706	\N	parc immobilier privé cartographie	\N
17709	\N	comédie	\N
17711	\N	Sida	\N
17713	\N	Eric Besson	\N
17714	\N	Philippe Val	\N
17715	\N	musique électronique	\N
17719	\N	aide humanitaire	\N
17720	\N	politique de développement	\N
17721	\N	dette	\N
17722	\N	Bob Geldof	\N
17724	\N	matin	\N
17730	\N	Psychiatrie	\N
17734	\N	Autorité européenne de sécurité des aliments	\N
17738	\N	Égypte	\N
17740	\N	Cécile Duflot	\N
17741	\N	les Verts	\N
17742	\N	Journalisme	\N
17743	\N	Chelsea	\N
17745	\N	Mohamed Ghannouchi	\N
17746	\N	Irlande	\N
17748	\N	Parti politique	\N
17749	\N	Géraldine Muhlmann	\N
17750	\N	Nicolas Demorand	\N
17751	\N	défense	\N
17752	\N	Antony	\N
17757	\N	court-métrage	\N
17758	\N	centre Beaubourg	\N
17759	\N	Michel Gondry	\N
17761	\N	cour d'appel	\N
17762	\N	Charles Pasqua	\N
17763	\N	Jean-Pierre Mocky	\N
17764	\N	Quick	\N
17765	\N	Otan	\N
17766	\N	oppération militaire	\N
17768	\N	Warren Buffet	\N
17769	\N	achat d'entreprise	\N
17770	\N	état d'urgence	\N
17773	\N	Nouveau Centre	\N
17774	\N	Jean-Louis Borloo	\N
17775	\N	Hervé Morin	\N
17777	\N	magazine	\N
17778	\N	pays	\N
17781	\N	printemps	\N
17782	\N	tendance	\N
17785	\N	éducation supérieure	\N
17787	\N	Axel Poniatowski	\N
17788	\N	Alain Richard	\N
17797	\N	Valérie Pécresse	\N
17798	\N	Julian Assange	\N
17800	\N	Front de gauche	\N
17801	\N	Parti de gauche (PG)	\N
17802	\N	Parti communiste Français	\N
17803	\N	Vivendi	\N
17804	\N	Jean-Marie Messier	\N
17807	\N	danger	\N
17808	\N	voie ferrée	\N
17809	\N	Droits de l'homme	\N
17813	\N	Jean-Paul Alduy	\N
17814	\N	Xavier Bertrand	\N
17815	\N	extrême droite	\N
17816	\N	Europe Ecologie	\N
17818	\N	Jean-Claude Milner	\N
17820	\N	Guy Debord	\N
17821	\N	Bibliothèque nationale de France	\N
17823	\N	naissance	\N
17824	\N	Institut national d'études démographiques	\N
17825	\N	Martin Malvy	\N
17827	\N	Jane Birkin	\N
17828	\N	Angela Merkel	\N
17829	\N	Daimler Benz	\N
17835	\N	Tauromachie	\N
17838	\N	Cohn-Bendit	\N
17839	\N	Les verts	\N
17840	\N	Europe-Ecologie	\N
17844	\N	Irène Jacob	\N
17845	\N	Mariah Carey	\N
17847	\N	vente d'arme	\N
17848	\N	Bulgare	\N
17851	\N	pacs	\N
17854	\N	Lafarge Copée	\N
17858	\N	presse	\N
17862	\N	Jean Lartéguy	\N
17864	\N	Arabie saoudite	\N
17865	\N	marine nationale	\N
17866	\N	canal de Suez	\N
17869	\N	transport	\N
17871	\N	Behgjet Pacolli	\N
17873	\N	Tony Blair	\N
17874	\N	David cameron	\N
17877	\N	archive	\N
17887	\N	société	\N
17888	\N	Michael Jackson	\N
17890	\N	Marion Cotillard	\N
17901	\N	Nouvelle-zélande	\N
17902	\N	énergie renouivelable	\N
17907	\N	Karim Benzema	\N
17908	\N	Livret A	\N
17909	\N	produit financier	\N
17910	\N	Tennis	\N
17911	\N	Mario Ancic	\N
17913	\N	Union Européenne	\N
17921	\N	Bernard Accoyer	\N
17922	\N	Justice	\N
17923	\N	palais de justice	\N
17924	\N	parti conservateur	\N
17925	\N	Shimon Pérès	\N
17926	\N	Moyen-Orient	\N
17927	\N	dictateur	\N
17928	\N	Tennessee Williams	\N
17929	\N	ministère des  Affaires étrangères	\N
17930	\N	Jean-David Levitte	\N
17931	\N	relation économique	\N
17932	\N	libre-service	\N
17933	\N	Ramzy Bedia	\N
17934	\N	Bernard Tapie	\N
17935	\N	Crédit lyonnais	\N
17936	\N	Économie	\N
17938	\N	réalité	\N
17939	\N	Christine Angot	\N
17940	\N	Camille Laurens	\N
17941	\N	Discrimination	\N
17942	\N	pénalité financiière	\N
17943	\N	Thierry Mariani	\N
17944	\N	Climat	\N
17945	\N	prévision	\N
17946	\N	Union  européenne	\N
17948	\N	Marine Le Pen? Front national	\N
17949	\N	Grand Prix	\N
17950	\N	Mikhaïl Gorbatchev	\N
17951	\N	Dmitri Medvedev	\N
17954	\N	collection d'oeuvres d'art	\N
17960	\N	Radio Bleu	\N
17964	\N	Jean-Luc Bennahmias	\N
17965	\N	Modem	\N
17967	\N	Anne Sinclair	\N
17969	\N	François Bayrou	\N
17983	\N	François Morin	\N
17989	\N	ministère de la défense	\N
17990	\N	François Mitterrand	\N
17991	\N	année 80	\N
17992	\N	Patrimoine	\N
18008	\N	techno (music)	\N
18009	\N	défilé	\N
18021	\N	Dailymotion	\N
18024	\N	parlement	\N
18032	\N	Sécurité	\N
18036	\N	Biographie	\N
18049	\N	Dashiell Hammett	\N
18057	\N	1973	\N
18082	\N	L'Express	\N
18141	\N	Jean-Paul Dollé	\N
18152	\N	Pierre Lellouche	\N
18169	\N	Femme	\N
18171	\N	Côte d'Ivoire	\N
18172	\N	bar	\N
18176	\N	Nokia	\N
18177	\N	téléphonie mobile	\N
18192	\N	Enseignement supérieur	\N
18205	\N	suppression de postes	\N
18206	\N	suppressions de postes	\N
18235	\N	fable	\N
18236	\N	Viktor Ianoukovitch	\N
18237	\N	Eric Ciotti	\N
18238	\N	Magistrature	\N
18258	\N	Parti radical	\N
18260	\N	Riccardo Ricco	\N
18265	\N	animateur  de télévision	\N
18267	\N	Nouvel observateur	\N
18272	\N	Jean-Louis Bianco	\N
18294	\N	Anthropologie	\N
18296	\N	prise de participation française	\N
18298	\N	Rachida Dati	\N
18303	\N	David Marton	\N
18309	\N	Helene Hegemann	\N
18332	\N	Sergio Marchionne	\N
18333	\N	Eric de Montgolfier	\N
18345	\N	Exposition	\N
18347	\N	collection d'œuvre d'art	\N
18351	\N	Yoann Gourcuff	\N
18357	\N	Ville	\N
18369	\N	tablette	\N
18370	\N	Ipad	\N
18377	\N	News Corp	\N
18378	\N	iPad	\N
18379	\N	Rupert Murdoch	\N
18385	\N	Tournoi des Six nations	\N
18399	\N	Bernard Thibault	\N
18416	\N	Côte-d'ivoire	\N
18417	\N	gouvernement élection présidentielle	\N
18425	\N	Detroit	\N
18435	\N	Lola Doillon	\N
18436	\N	Kristin Scott Thomas	\N
18437	\N	Georges Lavaudant	\N
18438	\N	William Shakespeare	\N
18443	\N	Fritz Lang	\N
18446	\N	roi	\N
18463	\N	Gérald Hustache-Mathieu	\N
18465	\N	Jean-Pierre Améri	\N
18492	\N	John Berry	\N
18499	\N	Ringo Starr	\N
18508	\N	Martin Hirsch	\N
18509	\N	engagement	\N
18537	\N	CD	\N
18538	\N	Molex	\N
18550	\N	Vichy	\N
18553	\N	Renne	\N
18562	\N	homme d'affaires	\N
18582	\N	Philippe Marini	\N
18593	\N	Lou	\N
18599	\N	Miss Ming	\N
18605	\N	solde	\N
18613	\N	Vanessa Paradis	\N
18614	\N	René Préval	\N
18622	\N	Dominique Hervieu	\N
18623	\N	José Montalvo	\N
18666	\N	Italien	\N
18667	\N	Pietro Marcello	\N
18671	\N	forces spéciales	\N
18678	\N	Annie Leibovitz	\N
18680	\N	échec	\N
18693	\N	Laurence Bloch	\N
18695	\N	coupe du Monde	\N
18698	\N	Taïwan	\N
18699	\N	réunification	\N
18707	\N	PCF	\N
18710	\N	corse	\N
18711	\N	Yvan colonna	\N
18740	\N	Election régionale	\N
18741	\N	Hélène Mandroux	\N
18742	\N	Georges Frêche	\N
18743	\N	affrontements	\N
18744	\N	Droits de l'Homme	\N
18745	\N	Martin Margiela	\N
18746	\N	Lucinda Childs	\N
18752	\N	John Scofield	\N
18753	\N	Gérard Collomb	\N
18754	\N	Washington	\N
18755	\N	Niki de Saint Phalle	\N
18756	\N	femme; exposition	\N
20036	\N	Référendum	\N
20037	\N	idenité nationale	\N
20038	\N	pollution marine	\N
20042	\N	alliance électorale	\N
20046	\N	troupe d'occupation	\N
20047	\N	rerait	\N
20048	\N	musque	\N
20050	\N	Ratko Mladic	\N
20051	\N	La Martinière	\N
20052	\N	Alain Rousset	\N
20056	\N	Hitler	\N
20065	\N	levée	\N
20076	\N	Paix	\N
20081	\N	Emily Jane White	\N
20082	\N	Jean Ingres	\N
20083	\N	site internet	\N
20084	\N	Sonia Wieder-Atherton	\N
20085	\N	Fanny Ardant	\N
20089	\N	Claude Vasconi	\N
20092	\N	Mosanto	\N
20101	\N	Bernard Pivot	\N
20102	\N	Périco Légasse	\N
20103	\N	Cirque	\N
20108	\N	Springer	\N
20110	\N	télévision privée	\N
20116	\N	géographique	\N
20117	\N	Marissa Mayer	\N
20118	\N	Rosa Luxemburg	\N
20119	\N	Pierre Pradervand	\N
20120	\N	aide (soutien)	\N
20121	\N	Claudie Haigneré	\N
20122	\N	direction administration	\N
20123	\N	Jean-Michel Carré	\N
20124	\N	Commerce ou Artisanat	\N
20125	\N	François-Marie Banier	\N
20127	\N	Frédéric Mitterand	\N
20129	\N	Jean-Marie Besset	\N
20131	\N	hervé Morin	\N
20132	\N	sigle	\N
20133	\N	François  Bayrou	\N
20138	\N	Annise Parker	\N
20143	\N	Castres profanation	\N
20144	\N	Ayman al-Zawahiri	\N
20145	\N	Etat-Unis	\N
20147	\N	Chef de l' Etat	\N
20150	\N	maladie d' Alzheimer	\N
20151	\N	diagnostique	\N
20152	\N	CO	\N
20154	\N	Formation	\N
20159	\N	Technologia	\N
20162	\N	Planète	\N
20164	\N	lettre (courrier)	\N
20165	\N	soukouk	\N
20170	\N	John Huston	\N
17955	\N	Giec	\N
17958	\N	inaugureration	\N
17963	\N	flolk	\N
17978	\N	Carla Bruni	\N
18034	\N	Marc Ravalomanana	\N
18038	\N	Industrie pharmaceutique	\N
18039	\N	Sanofi Aventis	\N
18040	\N	recherche	\N
18067	\N	Fabrice Luchini	\N
18068	\N	Sandrine Kiberlain	\N
18080	\N	Bruno Le Maire	\N
18085	\N	OGM	\N
18091	\N	Sebastian Vettel	\N
18096	\N	Jean Renoir	\N
18108	\N	Pierre Moscovici	\N
18109	\N	Christian Estrosi	\N
18115	\N	Roubaix (Nord)	\N
18130	\N	Ronaldo	\N
18135	\N	dissolution	\N
18138	\N	patrimoine mondial	\N
18147	\N	Foot	\N
18151	\N	euro (monnaie)	\N
18154	\N	Bacary Sagna	\N
18158	\N	Côte- d'Ivoire	\N
18175	\N	Erik Izraelewicz	\N
18182	\N	Sud-Soudan	\N
18183	\N	sécession	\N
18194	\N	Mohammed el-Baradei	\N
18203	\N	privilèges	\N
18212	\N	Flandres	\N
18219	\N	place boursière	\N
18220	\N	New York (ville)	\N
18244	\N	joueur	\N
18261	\N	Élection présidentielle	\N
18262	\N	Europe Ecologie-les Verts (EELV)	\N
18277	\N	box office	\N
18278	\N	Dany Boon	\N
18285	\N	Slim Amamou	\N
18286	\N	Zine el-Abidine Ben Ali	\N
18314	\N	(salle de jeux)	\N
18315	\N	best-seller	\N
18316	\N	islam intégrisme	\N
18323	\N	loire-Atlantique	\N
18337	\N	La Rumeur	\N
18338	\N	Ronald Reagan	\N
18340	\N	Patrick de Carolis	\N
18398	\N	mai 1968	\N
18400	\N	Chaillot	\N
18401	\N	Centre national de la danse	\N
20039	\N	Adeline Grattard	\N
20040	\N	politique européenne	\N
20041	\N	drone	\N
20043	\N	Richard Descoings	\N
20044	\N	Hippolyte Girardot	\N
20045	\N	Nobuhiro Suwa	\N
20049	\N	Isabelle Adjani	\N
20053	\N	Mont Valérien	\N
20054	\N	exécution	\N
20057	\N	suisse	\N
20058	\N	minaret	\N
20059	\N	Politique du sport	\N
20060	\N	Economie du sport	\N
20062	\N	zone-euro	\N
20063	\N	'Arles	\N
20064	\N	Hommage	\N
20066	\N	Canal +	\N
20067	\N	Ex-RDA	\N
20068	\N	Stasi	\N
20071	\N	prélèvement	\N
20072	\N	Philosophie	\N
20073	\N	Jean-Chrétien Bach	\N
20074	\N	Philippe Jaroussky	\N
20075	\N	castrat	\N
20078	\N	Modest Petrovitch Moussorgski	\N
20080	\N	Vigneron Luc	\N
20086	\N	jeu en ligne	\N
20088	\N	Le Maire Bruno	\N
20090	\N	Ségolène Royal déclaration	\N
20093	\N	Olivier besancenot	\N
20094	\N	kurde	\N
20095	\N	PKK	\N
20097	\N	la City	\N
20098	\N	Comédie-Française	\N
20099	\N	Catherine Hiegel	\N
20112	\N	René Zahnd	\N
20113	\N	Matthew Eric Wrinkles	\N
20130	\N	fugue	\N
20139	\N	Sri-Lanka	\N
20140	\N	Tamoul	\N
20155	\N	Tour Eiffel	\N
20156	\N	escalier	\N
20157	\N	hadopi	\N
20168	\N	arts décoratifs	\N
20171	\N	James Joyce	\N
20175	\N	Fidel Castro	\N
20179	\N	Charmes	\N
20180	\N	ascenseur	\N
20181	\N	indemnité financière	\N
20184	\N	succession	\N
20190	\N	RTE	\N
20192	\N	Liste	\N
20195	\N	centre de rétention	\N
20199	\N	Barbara Dalibard	\N
20201	\N	laicité	\N
20205	\N	Paul Jorion	\N
20206	\N	acarien	\N
20207	\N	burqa	\N
20208	\N	André Gerin	\N
20209	\N	Guy Carcasonne	\N
20210	\N	Etienne Pinte	\N
20211	\N	souffrance au travail	\N
20216	\N	Secret bancaire	\N
20223	\N	Sahara Occidental	\N
20224	\N	Gérard Larcher	\N
20226	\N	Tribunal arbitral du sport	\N
20234	\N	Niel Xavier	\N
20237	\N	enjeu	\N
20238	\N	Jean-Marie Gourio	\N
20241	\N	jeu vidéo football	\N
20247	\N	Douglas Sirk	\N
20249	\N	CNC	\N
20250	\N	Natation	\N
20251	\N	record du	\N
20254	\N	chef d'Etat	\N
20258	\N	dessin animé	\N
20259	\N	Asif Zardari	\N
20262	\N	Championnat du Monde	\N
20263	\N	Thierry Tilly	\N
20267	\N	Droit d'auteur	\N
20268	\N	jugement	\N
20269	\N	Syndicat national de l'édition (SNE)	\N
20270	\N	Société des gens de lettres (SGDL)	\N
20271	\N	dommages et intérêts	\N
20274	\N	course automobile	\N
20279	\N	cinema	\N
20284	\N	citoyen	\N
20285	\N	Jacques Chriac	\N
20286	\N	Nanterre (Hautes-de-Seine)	\N
20287	\N	prise illégale d'intérêt	\N
20294	\N	fédération sportive	\N
20306	\N	vente en ligne	\N
20309	\N	Michael Phelps	\N
20311	\N	minorité	\N
20312	\N	dentité nationale	\N
20318	\N	Rama Yade	\N
20320	\N	Eric Hazan	\N
20324	\N	Mahmoud  Ahmadinejad	\N
20325	\N	Claudia Cardinale	\N
20329	\N	langue	\N
20330	\N	Rage Against the Machine	\N
20342	\N	changement	\N
20348	\N	Goran Paskaljevic	\N
20351	\N	Père Noël	\N
20352	\N	Achille Zavatta	\N
20354	\N	Michel Charasse	\N
20360	\N	Cocaïne	\N
20366	\N	paris	\N
20380	\N	domicile	\N
20381	\N	citoyennté	\N
20384	\N	Chiffre d'affaires	\N
20385	\N	Rap	\N
20387	\N	Pétillon	\N
20388	\N	ecole	\N
20389	\N	Mercedes Benz	\N
20399	\N	faune	\N
17956	\N	magistrat	\N
17957	\N	Giancarlo de Cataldo	\N
17968	\N	gendarme	\N
17977	\N	Mahmoud Ahmadinejad	\N
17999	\N	Laïcité	\N
18001	\N	Jean-Pierre Chevènement	\N
18002	\N	Territoire de Belfort	\N
18017	\N	Jean-Claude Mailly	\N
18018	\N	congrès	\N
18022	\N	Transport ferroviaire	\N
18025	\N	Catherine Ashton	\N
18033	\N	cour d'assises	\N
18041	\N	Viticulture	\N
18042	\N	bordeaux	\N
18043	\N	stratégie de l'entreprie	\N
18079	\N	corps	\N
18086	\N	David Beckham	\N
18090	\N	Mickey Rourke	\N
18093	\N	Espace (cosmos)	\N
18102	\N	secret	\N
18110	\N	Mikhaïl Khodorkovski	\N
18111	\N	procédure pénale	\N
18116	\N	Police	\N
18120	\N	copte	\N
18123	\N	Thalès	\N
18125	\N	Michel Folco	\N
18126	\N	Jean-Pierre Jeunet	\N
18137	\N	Fédération française de tennis	\N
18139	\N	Centre	\N
18144	\N	Michel Ocelot	\N
18168	\N	Axel Weber	\N
18170	\N	report	\N
18174	\N	Winnie Mandela	\N
18185	\N	Auteuil	\N
18186	\N	Fédération française de tennis (FFT)	\N
18187	\N	Marne-la-Vallée (Seine-et-Marne)	\N
18188	\N	Gonesse (Val-d'Oise)	\N
18189	\N	Versailles (Yvelines)	\N
18208	\N	plateforme pétrolière	\N
18210	\N	Cour de cassation annulation	\N
18211	\N	Denis Robert	\N
18229	\N	Yannick Haenel	\N
18263	\N	casino	\N
18264	\N	braquage	\N
18287	\N	crie politique	\N
18293	\N	fait divers	\N
18313	\N	Andrée Chedid	\N
18322	\N	Polynésie	\N
18328	\N	Peter Jackson	\N
18339	\N	Robert Kubica	\N
18341	\N	réseau	\N
18342	\N	Bande dessinée	\N
18343	\N	Muzo	\N
18352	\N	Wall street	\N
18353	\N	direction d'entreprise	\N
18360	\N	mis en examen	\N
18361	\N	commissaire-priseur	\N
18375	\N	Littérature	\N
18376	\N	Edouard Glissant	\N
18388	\N	BPCE	\N
18389	\N	François Pérol	\N
18390	\N	Sud	\N
18391	\N	conflit d'intérêts	\N
18395	\N	vente d'entreprise	\N
18428	\N	compagnie d'assurance	\N
18433	\N	Guy Walter	\N
18447	\N	Denis Villeneuve	\N
18448	\N	Wajdi Mouawad	\N
18461	\N	Patrick Poivre d'Arvor	\N
18466	\N	Robert De Niro	\N
18476	\N	Valeria Bruni Tedeschi	\N
18495	\N	Stéphane Rozès	\N
18500	\N	Sondage	\N
18505	\N	art urbain	\N
18506	\N	Bristol	\N
18526	\N	Grand Palais	\N
18527	\N	Claude Monet	\N
18528	\N	bibilographie	\N
18533	\N	Liliane Bettencourt	\N
18534	\N	Michael Bloomberg	\N
18535	\N	nouvelles technologie	\N
18543	\N	Union soviétique	\N
18548	\N	Régime de Vichy	\N
18569	\N	chercheur	\N
18576	\N	raid	\N
18577	\N	Arnaud Lagardère	\N
18578	\N	Trophée Jules-Verne	\N
18579	\N	Franck Cammas	\N
18581	\N	Observatoire français des drogues et des toxicomanies (OFDT)	\N
18583	\N	Nicolas Dupont-Aignan	\N
18589	\N	Dupont-Aignan	\N
18594	\N	enseignement supérieure	\N
18600	\N	bourgeoisie	\N
18606	\N	Parti Radical	\N
18607	\N	Nouveau parti anticapitaliste (NPA)	\N
18608	\N	Lutte ouvrière (LO)	\N
18609	\N	Marie-George Buffet	\N
18610	\N	rallye-raid	\N
18624	\N	Alain Joyandet	\N
18625	\N	Christian Blanc	\N
18626	\N	secrétaire d'état	\N
18640	\N	W9	\N
18641	\N	Alexia Laroche-Joubert	\N
18642	\N	Dilemme	\N
18654	\N	Philippe Séguin	\N
18655	\N	conseil constitutionnel	\N
18658	\N	Fret maritime	\N
18659	\N	CMA CGM	\N
18664	\N	Art	\N
18674	\N	terre	\N
18685	\N	collectivité territoriale	\N
18692	\N	politique de la culture	\N
18720	\N	produit alimentaire	\N
18725	\N	dermatologie	\N
18731	\N	dépense publique	\N
18734	\N	Galiléo	\N
18735	\N	satellite	\N
20055	\N	Xie Zhenhua	\N
20061	\N	Marco Enriquez-Ominami	\N
20077	\N	code procédure pénale	\N
20100	\N	Charles Darwin	\N
20104	\N	Raymond Roussel	\N
20106	\N	Laurent Garnier	\N
20107	\N	Lindsay Anderson	\N
20111	\N	Guillaume Bachelay	\N
20115	\N	Christina Romer	\N
20126	\N	Ridley Scott	\N
20128	\N	représailles	\N
20149	\N	Richard Rodgers	\N
20158	\N	Diesel	\N
20166	\N	Radio France International	\N
20167	\N	départ volontaire	\N
20176	\N	parc d'attraction	\N
20182	\N	cantine	\N
20186	\N	Dylan Walsh	\N
20193	\N	Pacifique	\N
20194	\N	Tamiflu	\N
20200	\N	club de foot	\N
20202	\N	Jean-Marc Mormeck	\N
20204	\N	Eugène Delacroix	\N
20212	\N	Conseil supérieur de l'audiovisuel	\N
20213	\N	Etienne Mougeotte	\N
20214	\N	Will Self	\N
20217	\N	Jean-Marie Le Guen	\N
20218	\N	Assistance publique de Paris (AP-HP)	\N
20221	\N	Boris Cyrulnik	\N
20222	\N	élections régionales	\N
20229	\N	sosie	\N
20230	\N	Agence France presse	\N
20232	\N	Susan Boyle	\N
20233	\N	suppressions de poste	\N
20235	\N	Eric Raoult	\N
20236	\N	occupation	\N
20243	\N	Information	\N
20252	\N	règlement de comptes	\N
20253	\N	Luynes	\N
20257	\N	équipe	\N
17959	\N	Stéphane Hessel	\N
17961	\N	détection	\N
17962	\N	odorat	\N
17975	\N	Mamadou Niang	\N
17998	\N	produit chimique	\N
18000	\N	Vanessa Winship	\N
18006	\N	Sexualité	\N
18016	\N	Tessa Worley	\N
18020	\N	Clermont-ferrand	\N
18030	\N	Philippe Rondot	\N
18046	\N	Bernard Madoff	\N
18048	\N	Michel Bouquet	\N
18050	\N	droit de l'homme	\N
18059	\N	Kim Jong-il	\N
18064	\N	NPA (ex LCR)	\N
18065	\N	Parti de gauche	\N
18066	\N	Jean-Luc Mélenchon	\N
18071	\N	Antoine Waechter	\N
18083	\N	livre numérique	\N
18100	\N	théâtre du Bolchoï	\N
18119	\N	trêve	\N
18122	\N	Christophe de Margerie	\N
18143	\N	Charles Schulz	\N
18148	\N	matière	\N
18150	\N	vice-présidence	\N
18153	\N	prise d'otage	\N
18164	\N	Canard enchaîné	\N
18165	\N	enquête judicaire	\N
18193	\N	Michel Foucault	\N
18209	\N	Caisse des dépôts	\N
18215	\N	spéculation	\N
18216	\N	spécialiste	\N
18217	\N	Wikileaks	\N
18218	\N	pouvoir politique	\N
18224	\N	temps	\N
18230	\N	Gilles Jobin	\N
18233	\N	Edouard Balladur	\N
18234	\N	Georges Pompidou	\N
18249	\N	politique internationale	\N
18255	\N	greffe	\N
18280	\N	Saint-Valentin	\N
18283	\N	Jean-François Kahn	\N
18284	\N	vie scolaire	\N
18289	\N	Jonathan Safran Foer	\N
18299	\N	David Cameron	\N
18302	\N	Jean Sarkozy	\N
18304	\N	Lindsay Owen-Jones	\N
18305	\N	Jean-Paul Agon	\N
18312	\N	élections législatives	\N
18346	\N	repression	\N
18359	\N	Coupe du Monde	\N
18362	\N	Laurent Boyer	\N
18368	\N	beauté	\N
18373	\N	Maria Schneider	\N
18402	\N	Jude Célestin	\N
18410	\N	John Irving	\N
18454	\N	peine de mort exécution capitale	\N
18455	\N	ressortissant	\N
18457	\N	Kim Jong-un	\N
18460	\N	grève générale	\N
18462	\N	Stanley Kubrick	\N
18479	\N	Peter Doherty	\N
18481	\N	Haute autorité de lutte contre la discrimination et pour l'égalité	\N
18482	\N	Prison	\N
18493	\N	Brandon Welchez	\N
18507	\N	Catégorie d'âge	\N
18514	\N	Andrée Putman	\N
18515	\N	homophobie	\N
18516	\N	Aniston Jennifer	\N
18525	\N	démolition	\N
18549	\N	Lady Gaga	\N
18551	\N	Olivier Assayas	\N
18552	\N	Edagar Ramirez	\N
18554	\N	Jean-Pierre Meyers	\N
18556	\N	Jean-Luc Hees	\N
18557	\N	Stéphane Guillon	\N
18558	\N	Didier Porte	\N
18561	\N	arts plastique	\N
18565	\N	DCN	\N
18571	\N	graphique	\N
18575	\N	collaboration (coopération )	\N
18584	\N	Proche-orient	\N
18585	\N	Autorité Palestinienne	\N
18604	\N	océan	\N
18627	\N	agenda	\N
18631	\N	Superbowl	\N
18632	\N	télé-réalité	\N
18633	\N	quartier défavorisé	\N
18636	\N	fonctionnaire	\N
18651	\N	partié hommes-femmes	\N
18652	\N	Elisabeth Badinter	\N
18653	\N	maternité	\N
18663	\N	Valérie Mréjen	\N
18665	\N	Marc Recha	\N
20069	\N	James Thierrée	\N
20087	\N	reconversion	\N
20134	\N	Ségolène  Royal	\N
20135	\N	Martine  Aubry	\N
20136	\N	combinaison	\N
20137	\N	maillot de bain	\N
20141	\N	Emilio Calcagno	\N
20142	\N	Emmaüs	\N
20153	\N	science-fiction	\N
20163	\N	Paul Kagame	\N
20173	\N	Walter Benjamin	\N
20174	\N	oeuvre complète	\N
20183	\N	Oscar Niemeyer	\N
20185	\N	régie publicitaire	\N
20187	\N	contructeur automobile	\N
20188	\N	heuliez	\N
20189	\N	Fonds d'investissement stratégique	\N
20191	\N	Nucléaire	\N
20197	\N	maire d'arrondissement	\N
20198	\N	conseiller de paris	\N
20203	\N	Démographie	\N
20220	\N	Francis Ford Coppola	\N
20225	\N	Ligue des Champions	\N
20227	\N	Grand palais	\N
20231	\N	Florent Amodio	\N
20239	\N	première guerre mondiale	\N
20242	\N	prisonnier	\N
20246	\N	OrLéans	\N
20255	\N	titre de séjour	\N
20261	\N	participation	\N
20264	\N	techno	\N
20282	\N	cinéma Robert Bresson	\N
20283	\N	Murray Head	\N
20292	\N	Babra Streisand	\N
20293	\N	Ryan O'Neal	\N
20298	\N	restructuration	\N
20300	\N	sportif	\N
20301	\N	club de sport	\N
20305	\N	spoliation	\N
20307	\N	négociationimage	\N
20313	\N	Ulster	\N
20316	\N	cow-boys	\N
20317	\N	inculpation	\N
20322	\N	favela	\N
20323	\N	dévelopement économique	\N
20326	\N	Yves Lion	\N
20331	\N	Afrique-du-Sud	\N
20332	\N	ensignement	\N
20333	\N	centre de formation	\N
20334	\N	Brittany Murphy	\N
20337	\N	exonération	\N
20338	\N	artise	\N
20339	\N	anniversiare	\N
20343	\N	Bahman Ghobadi	\N
20346	\N	Frédéric Mistral	\N
20347	\N	Gustave Fayet	\N
20353	\N	Bruce Willis	\N
20355	\N	maladie psychiatrique	\N
20367	\N	Louvre	\N
20368	\N	peinture murale	\N
20370	\N	adoption (vote)	\N
20395	\N	Sport de glisse	\N
20401	\N	peronne agée	\N
20402	\N	plantation	\N
20404	\N	club plitique	\N
20433	\N	pêche	\N
17966	\N	campement	\N
17981	\N	Chef de l'etat	\N
17982	\N	Akbar Hachémi Rafsandjani	\N
17984	\N	encyclopédie	\N
17985	\N	Wikipédia	\N
17988	\N	Dassault	\N
17993	\N	Nolwenn Leroy	\N
17997	\N	Axel Kahn	\N
18003	\N	Mogwai	\N
18010	\N	Mosquée	\N
18011	\N	formation	\N
18014	\N	comptabilité	\N
18027	\N	Gustave Courbet	\N
18047	\N	Arcep	\N
18055	\N	Eva Joly	\N
18056	\N	Amérique latine	\N
18063	\N	Eric Duyckaerts	\N
18074	\N	Union cycliste internationale	\N
18084	\N	bronze	\N
18088	\N	élection	\N
18089	\N	Disney	\N
18097	\N	convention	\N
18098	\N	trafic	\N
18099	\N	RFF sécurité	\N
18103	\N	Radio	\N
18105	\N	fiscalité du patrimoine	\N
18112	\N	Sébastien Loeb	\N
18117	\N	Développement durable	\N
18118	\N	Dakar	\N
18124	\N	agression sexuelle	\N
18129	\N	Pau (Pyrénées-Atlantiques)	\N
18131	\N	Manchester United	\N
18132	\N	Wayne Rooney	\N
18184	\N	dicrimination	\N
18199	\N	industrie agro-alimentaire	\N
18225	\N	Web	\N
18226	\N	art plastique	\N
18227	\N	château de Versailles	\N
18243	\N	Charles Edelstenne	\N
18246	\N	infrastructure	\N
18252	\N	Centre national des arts du cirque	\N
18256	\N	Luz Casal	\N
18259	\N	Lech Kaczynski	\N
18268	\N	Henning Mankell	\N
18273	\N	Chambre de commerce	\N
18275	\N	Astronomie	\N
18276	\N	Nasa	\N
18281	\N	pharmacie	\N
18282	\N	Lilly	\N
18300	\N	Marie Darrieussecq	\N
18301	\N	Arthur Nauzyciel	\N
18324	\N	Riccardo Tisci	\N
18334	\N	Pierre Mauroy	\N
18335	\N	Lyne Cohen-Solal	\N
18336	\N	Communauté urbaine	\N
18355	\N	Politique culturelle	\N
18374	\N	Recep Tayyip Erdogan	\N
18382	\N	Robert Hue	\N
18383	\N	Ioulia Timochenko	\N
18384	\N	aspartame	\N
18392	\N	café	\N
18404	\N	séparatisme	\N
18407	\N	clônage	\N
18408	\N	sécurité alimentaire	\N
18413	\N	Edgar Morin	\N
18422	\N	Yves Cochet	\N
18426	\N	Louis-Ferdinand Céline	\N
18427	\N	Serge Klarsfeld	\N
18439	\N	agroalimentaire	\N
18440	\N	vignoble	\N
18442	\N	politique	\N
18456	\N	Cité des sciences	\N
18458	\N	Joanna Newsom	\N
18464	\N	Diego Luna	\N
18470	\N	Jean-Philippe Nataf	\N
18471	\N	JP Nataf	\N
18485	\N	The National	\N
18488	\N	acteur	\N
18494	\N	République	\N
18501	\N	Grande Bretagne	\N
18502	\N	graffiti	\N
18503	\N	art mural	\N
18504	\N	art urbain	\N
18510	\N	Michel Drucker	\N
18511	\N	CSA	\N
18513	\N	commission	\N
18522	\N	Logement étudiant	\N
18523	\N	secrétaire d'Etat	\N
18524	\N	immobilier	\N
18529	\N	raul Castro	\N
18536	\N	suppression	\N
18541	\N	union	\N
18544	\N	action hmanitaire	\N
18545	\N	Frère musulman	\N
18546	\N	islamisme	\N
18564	\N	Ken Loach	\N
18567	\N	mémorial	\N
18570	\N	sauvetage	\N
18587	\N	Ile-de-Drance	\N
18588	\N	Julien Dray	\N
18590	\N	général	\N
18602	\N	Koweït	\N
18603	\N	canicule	\N
18616	\N	justice internationale	\N
18628	\N	Jean-Luc Godard	\N
18650	\N	chef de l'état	\N
18660	\N	Jean-Philippe Derenne	\N
18672	\N	Sens	\N
18675	\N	Identité nationale	\N
18686	\N	Joseph Stiglitz	\N
18687	\N	PIB	\N
18688	\N	projet économique	\N
18690	\N	Jean-Vincent Placé	\N
18694	\N	John Dos Passos	\N
18696	\N	Yves Leterme\nfrancophonie	\N
18700	\N	pétrome	\N
18714	\N	enquête judiciaire	\N
18715	\N	seconde guerre modiale	\N
18726	\N	Marcel Proust	\N
20070	\N	Congrès (réunion)	\N
20079	\N	José Lenzini	\N
20091	\N	extradiction	\N
20096	\N	budget de l'état	\N
20105	\N	Jean-Claude Dassier	\N
20109	\N	Union pour la Méditerranée	\N
20114	\N	Nakheel	\N
20146	\N	Sciences-PO	\N
20148	\N	Arsène Wenger	\N
20160	\N	Jean-Paul Morat	\N
20161	\N	Gaullisme	\N
20169	\N	Omar el-Béchir	\N
20172	\N	France télévision	\N
20177	\N	Tzipi Livni	\N
20178	\N	crimes de guerre	\N
20196	\N	soupe	\N
20215	\N	Politique de la Santé	\N
20219	\N	Joseph Staline	\N
20228	\N	fête de fin d'année	\N
20240	\N	préméditation	\N
20244	\N	Catherine Breillat	\N
20245	\N	Christophe Rocancourt	\N
20248	\N	Robert Bresson	\N
20256	\N	Sacha Baron Cohen	\N
20260	\N	Transport en commun	\N
20265	\N	diam's	\N
20273	\N	chiite	\N
20275	\N	Fédération Française de Foot	\N
20276	\N	fanzine	\N
20277	\N	foire (salon)	\N
20281	\N	richesse	\N
20299	\N	Onu	\N
20302	\N	Ali Montazeri	\N
20314	\N	RDC	\N
20315	\N	Jean-Guy Wallemme	\N
20321	\N	Hervé de la Martinière	\N
20340	\N	Anna Mougladis	\N
20341	\N	Lewis Caroll	\N
20344	\N	Isabelle Autissier	\N
20345	\N	WWF	\N
20349	\N	centre de détention	\N
20356	\N	secteur privée	\N
20357	\N	aide (solidarité)	\N
20358	\N	hébergement	\N
17970	\N	personnel naviguant	\N
17973	\N	Alberto Contador	\N
17987	\N	écologie	\N
17994	\N	Renata Lesnik	\N
17996	\N	Christophe Donner	\N
18026	\N	Elisabeth Guigou	\N
18035	\N	championnat du Monde	\N
18044	\N	politique intérieure	\N
18045	\N	Walonnie	\N
18072	\N	professeur	\N
18073	\N	discipline	\N
18081	\N	Benoît Magimel	\N
18092	\N	Haut Commissariat de l'ONU pour les réfugiés	\N
18101	\N	Ally Coulibaly	\N
18128	\N	Raynal Pellicer	\N
18145	\N	Montreuil	\N
18146	\N	Olivier Besancenot	\N
18156	\N	Lindsay Lohan	\N
18159	\N	fusion d'entreprise	\N
18163	\N	Vacances	\N
18166	\N	mise en scène	\N
18167	\N	Samuel Finzi	\N
18173	\N	éthique	\N
18180	\N	relation bi latérale	\N
18181	\N	État	\N
18198	\N	Pierre Falcone	\N
18204	\N	Philippe Delerm	\N
18213	\N	Michael Moore	\N
18231	\N	portrait(genre artistique)	\N
18232	\N	évasion fiscale	\N
18248	\N	Jean-François Mancel	\N
18271	\N	François Cavanna	\N
18279	\N	pris (valeur)	\N
18292	\N	Alain Finkielkraut	\N
18306	\N	Françoise Cachin	\N
18307	\N	Paul Signac	\N
18317	\N	Teddy Riner	\N
18319	\N	suite	\N
18363	\N	exploitation	\N
18364	\N	gaz à effet de serre	\N
18386	\N	Jean-Pierre Vincent	\N
18396	\N	harmonisation	\N
18406	\N	Pierre Lescure	\N
18420	\N	campagne	\N
18421	\N	d'information	\N
18424	\N	Loire- Atlantique	\N
18441	\N	AKP	\N
18451	\N	cencure	\N
18452	\N	DVD	\N
18459	\N	exclusion	\N
18472	\N	Isild Le Besco	\N
18480	\N	zoo	\N
18483	\N	JR	\N
18489	\N	Delano Orchestra (the)	\N
18491	\N	Jean-Marie Straub	\N
18512	\N	Bruxelle	\N
18519	\N	Pierre Salvadori	\N
18520	\N	Nathalie Baye	\N
18521	\N	Audrey Tautou	\N
18539	\N	Charles De Gaulle	\N
18540	\N	Winston Churchill	\N
18597	\N	Jean-Luc Lagardère	\N
18601	\N	Géraldine Nakache	\N
18612	\N	détention emprisonnement)	\N
18617	\N	Epad	\N
18618	\N	taxe carbone	\N
18619	\N	Henri Proglio	\N
18634	\N	Charlotte Gainsbourg	\N
18635	\N	Pollution	\N
18646	\N	Abbas Kiarostami	\N
18647	\N	Juliette Binoche	\N
18656	\N	Joaquin Phoenix	\N
18661	\N	voyage	\N
18662	\N	maroc	\N
18669	\N	Stevie Wonder	\N
18670	\N	Gothenburg	\N
18673	\N	Bernard Kouchner	\N
18677	\N	L 'Oréal	\N
18684	\N	Gregg Araki	\N
18697	\N	Marguerite Duras	\N
18708	\N	prolongation	\N
18709	\N	Crise politique	\N
18712	\N	Martine Aubry PS	\N
18713	\N	Cristina Garmendia	\N
18718	\N	Lorenzo Bini Smaghi	\N
18719	\N	Pacte de stabilité monétaire	\N
18747	\N	Gordon Brown	\N
18748	\N	parti travailliste	\N
20266	\N	pays industrialisé	\N
20272	\N	stock-options	\N
20278	\N	Zingaro	\N
20280	\N	Jean-Pierre Escalettes	\N
20288	\N	Them Crooked Vultures	\N
20289	\N	The Independent	\N
20290	\N	Gerry Adams	\N
20291	\N	abus sexuel	\N
20295	\N	relations diplomatiaues	\N
20296	\N	Bachar al-Assad	\N
20297	\N	SOS Racisme	\N
20303	\N	guerilla	\N
20304	\N	parti communiste	\N
20308	\N	Eygalières (Bouches-du-Rhône)	\N
20310	\N	Provence-Alpes-Côte-d'Azur (PACA)	\N
20319	\N	Allan Dwan	\N
20327	\N	Le Caravage	\N
20328	\N	Louis Althusser	\N
20335	\N	Malie	\N
20336	\N	albinos	\N
20350	\N	maladie psychologique	\N
20359	\N	Léa Seydoux	\N
20361	\N	chant chorale	\N
20362	\N	Clairvaux	\N
20369	\N	Pascal Canfin	\N
20371	\N	mal lpgé	\N
20372	\N	promotion immobilière	\N
20373	\N	Eglise Catholique	\N
20375	\N	insription	\N
20376	\N	citoyenté	\N
20377	\N	inscription	\N
20382	\N	Guy Verhofstadt	\N
20383	\N	rachat d'entreprise	\N
20391	\N	localisation	\N
20392	\N	établissement	\N
20393	\N	centre de soin	\N
20398	\N	Melody Gardot	\N
20407	\N	Yannick Noah	\N
20412	\N	ministère de la Culture	\N
20413	\N	haut fonctionnaire	\N
20416	\N	drotis de l'homme	\N
20418	\N	Michel Debré	\N
20420	\N	Judaïsme	\N
20435	\N	Antarctique	\N
20439	\N	Avigdor Lieberman	\N
20447	\N	Que Choisir	\N
20449	\N	.	\N
20450	\N	pétole	\N
20455	\N	Ile de France	\N
20457	\N	Paul Volcker	\N
20458	\N	Benon Sevan	\N
20459	\N	portrait	\N
20460	\N	Nato	\N
20461	\N	Huissier	\N
20472	\N	Jean Claude Marin	\N
20482	\N	Jean Giono	\N
20483	\N	Michel Onfray	\N
20485	\N	lady Diana	\N
20489	\N	Midlake	\N
20490	\N	François Rebsamen	\N
20498	\N	Steve Jacobs	\N
20499	\N	John Malkovich	\N
20508	\N	Marseille (Bouches-du-Rhône)	\N
20509	\N	Marce Rufo	\N
20513	\N	Arpad Schilling	\N
20518	\N	Etats-du-Golfe	\N
20519	\N	coopération militiare	\N
20524	\N	Hédi Kaddour	\N
20533	\N	dalaï-lama	\N
20534	\N	Olivier Metzner	\N
20535	\N	Élection régionale	\N
20537	\N	Stéphane Courbit	\N
20539	\N	ameublement	\N
20569	\N	intérim	\N
17971	\N	Bansky	\N
17972	\N	fichage	\N
17976	\N	Frères musulmans	\N
17986	\N	xénophobie	\N
17995	\N	polar	\N
18007	\N	Fernando Alonso	\N
18013	\N	ambassadeur	\N
18015	\N	Didier Migaud	\N
18023	\N	Alexandre Pugachev	\N
18051	\N	Carla Bruni-Sarkozy	\N
18052	\N	Midi Libre	\N
18053	\N	Eric Judor	\N
18061	\N	Ikea	\N
18062	\N	Ingvar Kamprad	\N
18069	\N	Afrique du Nord	\N
18077	\N	Réunion	\N
18078	\N	Jérôme Chartier	\N
18087	\N	Sébastien Ogier	\N
18095	\N	produit intérieur brut	\N
18106	\N	Cyclisme	\N
18107	\N	tour de France	\N
18136	\N	Hauts de Seine	\N
18149	\N	Liliane  Bettencourt	\N
18160	\N	Fédération internationale de ski	\N
18161	\N	Jean-Pierre Pernaut	\N
18162	\N	dépendance	\N
18190	\N	Cevipof	\N
18191	\N	Présidence	\N
18195	\N	Michel Houellebecq	\N
18214	\N	polimique	\N
18221	\N	Continental	\N
18228	\N	Philippe Varin	\N
18239	\N	Krzysztof Warlikowski	\N
18240	\N	Franz Kafka	\N
18241	\N	Bernard-Marie Koltès	\N
18242	\N	John Maxwell Coetzee	\N
18245	\N	The Guardian	\N
18254	\N	laboratoire pharmaceutique	\N
18266	\N	AOL	\N
18274	\N	biodiversité	\N
18295	\N	Jacques Attali	\N
18318	\N	Jimi Hendrix	\N
18320	\N	Benyamin Nétanyahou	\N
18321	\N	chef d'état-major	\N
18329	\N	José Bové	\N
18330	\N	Gaz de schiste	\N
18331	\N	Alain Béhar	\N
18349	\N	Laure Adler	\N
18350	\N	Françoise Giroud	\N
18356	\N	Michel Wieviorka	\N
18358	\N	Cartographie	\N
18367	\N	Élisabeth Guigou	\N
18380	\N	Festival	\N
18381	\N	relation bi-latérale	\N
18387	\N	Laurent Blanc	\N
18394	\N	Robert Boulin	\N
18397	\N	Arnaud Montebourg	\N
18405	\N	Ifop	\N
18409	\N	Dino Egger	\N
18412	\N	Jerome David Salinger	\N
18418	\N	Mahmoud Hussein	\N
18419	\N	sociologie\npolitique	\N
18431	\N	Albert Camus	\N
18434	\N	Tom Hooper	\N
18444	\N	Pétrole	\N
18445	\N	record	\N
18449	\N	chôùage	\N
18450	\N	Michal Batory	\N
18467	\N	Rafic Hariri	\N
18468	\N	ministre démission	\N
18469	\N	Premier ministre déplacement (voyage)	\N
18477	\N	sortie	\N
18478	\N	Philippe Guillard	\N
18486	\N	Louise Bourgeois	\N
18487	\N	Honoré de Balzac	\N
18490	\N	Ernest Hemingway	\N
18497	\N	Patrimoine culturel	\N
18498	\N	civilisation	\N
18555	\N	dépense	\N
18560	\N	Patrice De Maistre	\N
18563	\N	New York	\N
18566	\N	Nouveau centre	\N
18572	\N	Finance	\N
18573	\N	monnaie (euro)	\N
18574	\N	Frédéric Oudéa	\N
18586	\N	DCN (Direction des constructions navales)	\N
18595	\N	Jacques Tardi	\N
18596	\N	Luc Besson	\N
18611	\N	Emmanuelle Seigner	\N
18629	\N	Finances publiques	\N
18630	\N	Alain Minc	\N
18637	\N	New-York	\N
18638	\N	World Trade Center	\N
18644	\N	Karl lagerfeld	\N
18645	\N	Médiapart	\N
18679	\N	Ouïghour	\N
18691	\N	Maurice Lévy	\N
18716	\N	Jeux Olympique	\N
18717	\N	écosytéme	\N
18721	\N	radiation	\N
18722	\N	Fécamp (Seine-Maritime)	\N
18724	\N	écolologie	\N
20363	\N	Aubervilliers (Seine-Saint-Denis)	\N
20364	\N	atlier d'écriture	\N
20365	\N	analphabétisme	\N
20374	\N	Secours populaire	\N
20378	\N	chine	\N
20379	\N	Liu Xiaobo	\N
20386	\N	Hara-Kiri	\N
20390	\N	Michaël Schumacher	\N
20396	\N	Ryan Gosling	\N
20397	\N	Zach Shields	\N
20400	\N	Timisoara	\N
20403	\N	soins intensifs	\N
20405	\N	Jean-Louis Murat	\N
20414	\N	Boxe	\N
20415	\N	philippine	\N
20419	\N	courrier (correspondance)	\N
20429	\N	RSA	\N
20432	\N	compilation	\N
20434	\N	Geneviève de Fontenay	\N
20436	\N	Herman Van Rompuy	\N
20437	\N	conseil de l'Europe	\N
20443	\N	Tatsuya Ichihashi	\N
20453	\N	Lhasa	\N
20454	\N	chanteuse	\N
20456	\N	cité de la musique	\N
20465	\N	Christian Boltanski	\N
20466	\N	Tarrus Riley	\N
20468	\N	Karine Saporta	\N
20469	\N	ponctuation	\N
20471	\N	Stéphane Bern	\N
20474	\N	livre électronique	\N
20479	\N	union européenne	\N
20486	\N	Gaby Bonnand	\N
20492	\N	Marc Weitzmann	\N
20493	\N	Claude Lanzmann	\N
20495	\N	Pierre Botton	\N
20496	\N	expérience (hors science)	\N
20497	\N	plaint judiciaire	\N
20500	\N	Luiz Inácio Lula da Silva	\N
20501	\N	sanction pénale	\N
20505	\N	Crous	\N
20517	\N	Sport mécanique	\N
20522	\N	Ile-de-France.	\N
20526	\N	Robert Doisneau	\N
20538	\N	Fiscalité	\N
20541	\N	Jean-Louis Roumégas	\N
20543	\N	Cergy-Pontoise	\N
20545	\N	John Banville	\N
20552	\N	Ressources naturelles	\N
20556	\N	Killoffer	\N
20568	\N	Pierre Joxe	\N
20576	\N	ustice	\N
20577	\N	juif	\N
20578	\N	Charles Wyplosz	\N
20599	\N	Courtney Love	\N
20607	\N	Natalie Dessay	\N
20608	\N	Vincenzo Bellini	\N
20609	\N	Marco Arturo Marelli	\N
20610	\N	Grenoble  (Isère)	\N
17974	\N	Banlieue	\N
17979	\N	André Senik	\N
17980	\N	Karl Marx	\N
18004	\N	Nathalie Kosciusko-Morizet	\N
18005	\N	Ecologie	\N
18012	\N	République tchèque	\N
18019	\N	Raymond Domenech	\N
18028	\N	(Haute-Garonne)	\N
18029	\N	recherche(hors sciences)	\N
18031	\N	Fédération internationale de football	\N
18037	\N	Jean-Louis Guigou	\N
18054	\N	Michel Boujut	\N
18058	\N	Loisirs	\N
18060	\N	Hugo Chávez	\N
18070	\N	Pablo Picasso	\N
18075	\N	Lindsey Vonn	\N
18076	\N	forfait	\N
18094	\N	instument de musique	\N
18104	\N	crique	\N
18113	\N	régulation financière	\N
18114	\N	Parti républicain	\N
18121	\N	Grammy Awards	\N
18127	\N	Philippe Pétain	\N
18133	\N	Télévision	\N
18134	\N	Yves Calvi	\N
18140	\N	Ski alpin	\N
18142	\N	2018	\N
18155	\N	Fifa	\N
18157	\N	Robert Badinter	\N
18178	\N	libération (journal)	\N
18179	\N	Carlos Ghosn	\N
18196	\N	Antoine Gallimard	\N
18197	\N	Michel Audiard	\N
18200	\N	Etienne Daho	\N
18201	\N	Natalie Portman	\N
18202	\N	Darren Aronofsky	\N
18207	\N	Jafar Panahi	\N
18222	\N	Liberia	\N
18223	\N	Charles Taylor	\N
18247	\N	Marc Trévidic	\N
18250	\N	hausse	\N
18251	\N	régulation	\N
18253	\N	Bâtiment et travaux publics	\N
18257	\N	Julian  Assange	\N
18269	\N	Terra Nova	\N
18270	\N	politique de l'envirronement	\N
18288	\N	Peter Esterhazy	\N
18290	\N	NPA	\N
18291	\N	(ex LCR)	\N
18297	\N	Gary Moore	\N
18308	\N	Wim Wenders	\N
18310	\N	opéra; metteur en scène	\N
18311	\N	opère	\N
18325	\N	Rugby	\N
18326	\N	Tournoi des six nations	\N
18327	\N	Écosse	\N
18344	\N	LVHM	\N
18348	\N	Paris.	\N
18354	\N	Bruno Bayen	\N
18365	\N	Transport maritime	\N
18366	\N	retraite anticipée	\N
18371	\N	Clémence Massart	\N
18372	\N	Philippe Caubère	\N
18393	\N	Dilma Rousseff	\N
18403	\N	Mahmoud Abbas	\N
18411	\N	cour de cassation	\N
18414	\N	Virgile	\N
18415	\N	mythologie	\N
18423	\N	ours	\N
18429	\N	Patrice Chéreau	\N
18430	\N	Romain Duris	\N
18432	\N	parti démocrate	\N
18453	\N	monde arabe	\N
18473	\N	The Kills	\N
18474	\N	Charles de Meaux	\N
18475	\N	David Carradine	\N
18484	\N	Jean-Christophe Cambadélis	\N
18496	\N	Architecture	\N
18517	\N	résistance	\N
18518	\N	seconde guerre mondiale	\N
18530	\N	audiovisuel extérieur	\N
18531	\N	Christine Ockrent	\N
18532	\N	Alain de Pouzilhac	\N
18542	\N	urgence	\N
18547	\N	Marc Trévédic	\N
18559	\N	Sarkozy	\N
18568	\N	Jean Moulin	\N
18580	\N	collectivités locales	\N
18591	\N	lettre	\N
18592	\N	Henri Martre	\N
18598	\N	Vanessa paradis	\N
18615	\N	Conseil représentatif des institutions juives de France (Crif)	\N
18620	\N	Politique de la santé	\N
18621	\N	Roselyne Bachelot	\N
18639	\N	Jean-François copé	\N
18643	\N	TNT	\N
18648	\N	Emilie Dequenne	\N
18649	\N	Samuel Le Bihan	\N
18657	\N	carbone	\N
18668	\N	Sylvio Berlusconi	\N
18676	\N	Jim Carrey	\N
18681	\N	Alexandre Dumas	\N
18682	\N	Gérard Depardieu	\N
18683	\N	Benoît Poelvoorde	\N
18689	\N	statistiques	\N
18701	\N	Opéra-Comique	\N
18702	\N	Henri Purcell	\N
18703	\N	William Christie	\N
18704	\N	Fairy Queen	\N
18705	\N	Arts Florissants	\N
18706	\N	Jonathan Kent	\N
18723	\N	funérailles	\N
18727	\N	mitsubishi	\N
18728	\N	Mistral	\N
18729	\N	Villiers-le-Bel (Val-d'Oise)	\N
18730	\N	accident de la circulation	\N
18732	\N	camp de réfugié	\N
18733	\N	raude fiscale	\N
18736	\N	Bernard-Henri Lévy	\N
18737	\N	erreur	\N
18738	\N	Le Canard enchaîné	\N
18739	\N	Frédéric Pagès	\N
18749	\N	Jacques Julliard	\N
18750	\N	art numérique	\N
18751	\N	Transmediale	\N
18757	\N	Mathieu Bastareaud	\N
18758	\N	Tournoi des Six Nations	\N
18759	\N	délaration	\N
18760	\N	Emmanuel Kant	\N
18761	\N	hip hop	\N
18762	\N	Yves Duteil	\N
18763	\N	Dominique Wolton	\N
18764	\N	météorolgie	\N
18765	\N	Saad Hariri	\N
18766	\N	Dominique Bussereau	\N
18767	\N	euro	\N
18768	\N	marché monnétaire	\N
18769	\N	Coupe de l'América	\N
18770	\N	Valence	\N
18771	\N	interpellation	\N
18772	\N	Troyes (Aube)	\N
18773	\N	sponsor	\N
18774	\N	Alex Rigola	\N
18775	\N	Finance publique	\N
18776	\N	Dominique Voynet	\N
18777	\N	tribunal spécial	\N
18778	\N	André Malraux	\N
18779	\N	Eric besson	\N
18780	\N	XXIeme siécle	\N
18781	\N	PS Parti socialiste	\N
18782	\N	Didier Codorniou	\N
18783	\N	exil; retour	\N
18784	\N	Nelson Mandela	\N
18785	\N	ANC (Congrès national africain)	\N
18786	\N	service publique	\N
18787	\N	Baltasar Garzón	\N
18788	\N	Safy Nebbou	\N
18789	\N	Sarah Palin	\N
18790	\N	Pierre Bergé	\N
18791	\N	Internat	\N
18792	\N	multinationale	\N
18801	\N	mécénat culturel	\N
18812	\N	holocauste	\N
18834	\N	cour suprême	\N
18837	\N	Voile (nautisme)	\N
18839	\N	mer baltique	\N
18842	\N	parti républicain (USA)	\N
18850	\N	Jean-Luc Nancy	\N
18893	\N	prix	\N
18894	\N	tarif	\N
18899	\N	nouvelle-orléans	\N
18902	\N	intégration	\N
18926	\N	armée française	\N
18928	\N	niformatique	\N
18932	\N	NPA (ex-LCR)	\N
18934	\N	Caisse des dépôts et consignations (CDC)	\N
18935	\N	CO2	\N
18938	\N	Paul Alliès	\N
18939	\N	récession économique	\N
18944	\N	Loire -Atlantique	\N
18945	\N	yuan	\N
18947	\N	expulion	\N
18953	\N	catalogue	\N
18954	\N	Jean-Paul Cluzel	\N
18959	\N	plan de relance	\N
18961	\N	Dominique Fabre	\N
18962	\N	Vincent Peillon	\N
18964	\N	dalaï lama	\N
18965	\N	République dominicaine	\N
18966	\N	église évangélique	\N
18970	\N	Olia Lialina	\N
18971	\N	Dragan Espenschied	\N
18974	\N	John McTiernan	\N
18977	\N	Samuel Maoz	\N
18978	\N	Fipa	\N
18979	\N	Franck Riester	\N
18980	\N	électorale	\N
20394	\N	Juliette Gréco	\N
20406	\N	métal (musique)	\N
20408	\N	Salif Keita	\N
20409	\N	Mikhaïl  Khodorkovski	\N
20411	\N	multimedia	\N
20417	\N	Parti social-démocrate	\N
20421	\N	Hmong	\N
20422	\N	émirat	\N
20423	\N	Real Madrid	\N
20424	\N	club sportif Football	\N
20425	\N	journal officiel	\N
20428	\N	Philippe Bélaval	\N
20430	\N	Alberto Fujimori	\N
20431	\N	Pathé	\N
20438	\N	Jacob Zuma	\N
20440	\N	deutsche mark	\N
20441	\N	implant	\N
20442	\N	sprint	\N
20444	\N	télé-chargement	\N
20445	\N	local	\N
20470	\N	Gianmaria Testa	\N
20475	\N	Jean-Michel Jarre	\N
20480	\N	Bret Eaton Ellis	\N
20481	\N	Jérôme David Salinger	\N
20487	\N	réinsertion sociale	\N
20488	\N	salon de beauté	\N
20491	\N	chef d'établissement	\N
20502	\N	Capa	\N
20503	\N	Fabrice Larue	\N
20504	\N	Hervé Chabalier	\N
20510	\N	Vanves	\N
20520	\N	compétiton	\N
20521	\N	mixité	\N
20523	\N	Hervé Lemoine	\N
20525	\N	José Socrates	\N
20527	\N	Azouz Begag	\N
20536	\N	acord électoral	\N
20547	\N	Alberto Giacometti	\N
20548	\N	note de frais	\N
20551	\N	prix(valeur)	\N
20563	\N	plan d'austérité	\N
20589	\N	Probo-Koala	\N
20592	\N	évêque	\N
20597	\N	Ko Siu-Lan	\N
20601	\N	constructeur	\N
20613	\N	Jacques Tajan	\N
20618	\N	Marc Ona Essangui	\N
20623	\N	Police municipale	\N
20624	\N	socilogue	\N
20625	\N	Metz (Moselle)	\N
20626	\N	François Grosdidier	\N
20634	\N	Toutankhamon	\N
20635	\N	découverte scientifique	\N
20638	\N	La réunion	\N
20649	\N	militant	\N
20653	\N	personnage	\N
20654	\N	rôle	\N
20655	\N	maquillage	\N
20656	\N	trasformation	\N
20664	\N	Alexandre Bilodeau	\N
20665	\N	Wes Anderson	\N
20666	\N	Roald Dahl	\N
20670	\N	Pascal Bruckner	\N
20674	\N	résultat élection	\N
20675	\N	Horoscope	\N
20680	\N	vaudou	\N
20681	\N	journal intime	\N
20683	\N	météo	\N
20686	\N	Alain Ehrenberg	\N
20687	\N	allocation	\N
20688	\N	Eglise	\N
20689	\N	abus sexuels	\N
20690	\N	vatican	\N
20691	\N	Cambio	\N
20692	\N	luge	\N
20693	\N	poids	\N
20694	\N	Florence Aubenas	\N
20696	\N	google	\N
20710	\N	lobbys	\N
20713	\N	circonscripton électorale	\N
20716	\N	Micky Green	\N
20722	\N	coup d'etat	\N
20726	\N	frigidité	\N
20727	\N	décoration	\N
20728	\N	égalité hommes-femmes	\N
20729	\N	majorité gouvernementale	\N
20732	\N	saturation	\N
20751	\N	The White Stripes	\N
20753	\N	Archéologie	\N
20754	\N	art rupestre	\N
20755	\N	Luc-Henri Fage	\N
20756	\N	Jean-Michel Chazine	\N
20757	\N	Mohamed El-Baradei	\N
20758	\N	AIEA	\N
20760	\N	Afghanista	\N
20761	\N	Hemland	\N
20762	\N	scanner	\N
20770	\N	The Observer	\N
20773	\N	Démocratie	\N
20775	\N	Front de gauche et Europe Ecologie	\N
20776	\N	prosélytisme	\N
20789	\N	lection régionale	\N
20794	\N	Stephen Hester	\N
20797	\N	John Travolta	\N
20798	\N	José Garcia	\N
20804	\N	papeterie	\N
20810	\N	Tony Gatlif	\N
20819	\N	XXème arrondissement	\N
20823	\N	conseil d'Etat	\N
20824	\N	abolition	\N
20830	\N	japon	\N
20846	\N	tribunal international	\N
20858	\N	mariage forcé	\N
20859	\N	insecticide	\N
20860	\N	La Sorbonne	\N
20863	\N	bracelet électronique	\N
20864	\N	duel	\N
20871	\N	Polémique	\N
20872	\N	Salon	\N
20873	\N	politique agricole commune	\N
20874	\N	Le conseil régional 2004	\N
20877	\N	Grande bretagne	\N
20878	\N	René Descartes	\N
20880	\N	accident de travail	\N
20881	\N	tribunal	\N
20883	\N	Alvaro Uribe	\N
18793	\N	crise économique déficit budgétaire	\N
18794	\N	Jean-Claude Juncker	\N
18804	\N	institution	\N
18817	\N	Marie Claire	\N
18819	\N	Sport automobile	\N
18820	\N	Kimi Räikkönen	\N
18821	\N	rallye	\N
18824	\N	État-Unis	\N
18832	\N	ex-URSS	\N
18835	\N	littérature enfantine	\N
18838	\N	Bernard Accoyer président	\N
18849	\N	Institut de veille sanitaire (INVS)	\N
18856	\N	Vera Farmiga	\N
18866	\N	Sarath Fonseka	\N
18869	\N	Virginia Woolf	\N
18875	\N	Henri Weber	\N
18879	\N	États-unis	\N
18880	\N	Pascal Perrineau	\N
18895	\N	Timothy Geithner	\N
18898	\N	Loïck Peyron	\N
18903	\N	expérience	\N
18904	\N	huis clos	\N
18910	\N	Guy Bedos	\N
18911	\N	Nicolas Bedos	\N
18917	\N	Johnny Depp	\N
18918	\N	Keith Richards	\N
18921	\N	Nouvelle-Orléans	\N
18923	\N	raffinerie	\N
18925	\N	Irlande du Nord	\N
18927	\N	bioéthioque	\N
20410	\N	Assassinat	\N
20426	\N	Hugo Chavez	\N
20427	\N	HCR	\N
20451	\N	Transmusicales	\N
20452	\N	Eric Fottorino	\N
20463	\N	super Mario	\N
20464	\N	Lemi Ponifasio	\N
20467	\N	arbitrage	\N
20478	\N	dommage et intérêt	\N
20506	\N	John Terry	\N
20511	\N	Michael Schumacher	\N
20514	\N	Arthur Conan Doyle	\N
20515	\N	Guy Ritchie	\N
20516	\N	Jude Law	\N
20530	\N	courier	\N
20531	\N	Verts	\N
20532	\N	désarmement nucléaire	\N
20540	\N	Jean-Luc Marion	\N
20544	\N	Yves-Patrick Delachaux	\N
20549	\N	Éducation sexuelle	\N
20553	\N	Association	\N
20555	\N	chronolohgie	\N
20557	\N	graphisme	\N
20558	\N	Omar Sy	\N
20559	\N	Fred Testot	\N
20565	\N	André Cicolella	\N
20566	\N	toxicologie	\N
20567	\N	biberon	\N
20573	\N	Philippe Djian	\N
20637	\N	gouvernance européenne	\N
20639	\N	Conseil régional	\N
20640	\N	Noël Mamère	\N
20652	\N	Gil Scott-Heron	\N
20658	\N	New york Times	\N
20659	\N	Wall street journal	\N
20671	\N	insustrie	\N
20672	\N	Fabrice Guy	\N
20673	\N	Jason Lamy- Chappuis	\N
20682	\N	Abbey Road	\N
20684	\N	enfnat	\N
20685	\N	Fontenay-sous-Bois (Val-de-Marne)	\N
20698	\N	jumelle	\N
20708	\N	Marie-Luce Penchard	\N
20712	\N	club privé	\N
20723	\N	Parti socilaiste	\N
20724	\N	election	\N
20731	\N	David Lafore	\N
20733	\N	Jean Boulègue	\N
20735	\N	destitution	\N
20736	\N	Mamadou Tandja	\N
20739	\N	Pot-de-vin	\N
20750	\N	Oxelaëre	\N
20769	\N	prud'hommes	\N
20788	\N	Max Göldi	\N
20796	\N	Lone Scherfig	\N
20814	\N	Val d'Oise	\N
20820	\N	Hubert Haenel	\N
20829	\N	Debout la République	\N
20831	\N	Emmanuelle Pagano	\N
20847	\N	art (peinture)	\N
20848	\N	mort	\N
20850	\N	technologie électronique	\N
20855	\N	Martine Aubry ²	\N
20862	\N	Simone Harari	\N
20886	\N	Thomas Ngijol	\N
20888	\N	comédienne	\N
20889	\N	race noire	\N
20906	\N	GIEC (Groupe d'experts intergouvernemental sur l'évolution du climat	\N
20907	\N	Claude Allègre	\N
20916	\N	Dominique Rousseau	\N
20923	\N	Ifri	\N
20929	\N	Azouz Begag Modem	\N
20935	\N	Matteo Pasquinelli	\N
20937	\N	césar	\N
20947	\N	Naomi Klein	\N
20954	\N	Mahomet	\N
20963	\N	libértés publiques	\N
20967	\N	Etienne Balibar	\N
20971	\N	BNF	\N
20984	\N	Alain Resnais	\N
20985	\N	Delphine Seyrig	\N
20998	\N	Restos du Cœur	\N
21004	\N	Georges Soros	\N
21017	\N	Audrey Hepburn	\N
21030	\N	haÏti	\N
21034	\N	Georges Papandréou	\N
21046	\N	George Bush Jr	\N
21047	\N	new York times	\N
21060	\N	ouveerture	\N
21061	\N	victoires de la musique	\N
21062	\N	Délinquance	\N
21063	\N	dialyse	\N
21064	\N	mossad	\N
21065	\N	Autorité de sûreté nucléaire	\N
21066	\N	rallye (automobile)	\N
21068	\N	Yves Jégo	\N
21069	\N	Takeshi Kitano	\N
21070	\N	Damien Saez	\N
21071	\N	Jean-Baptiste Mondino	\N
21072	\N	chariot	\N
21073	\N	Jean-Marie Delarue	\N
21074	\N	hôpital psychiatriques	\N
21075	\N	scuplture	\N
21076	\N	Guy Marchand	\N
21077	\N	Dimitri Medvedev	\N
21078	\N	peinture (arts)	\N
21079	\N	arme	\N
21080	\N	bus de bien social	\N
21081	\N	Fonds monétaire européen	\N
21082	\N	Roger Gicquel	\N
21083	\N	Clapping Music	\N
21084	\N	libération( journal)	\N
21085	\N	Casino	\N
21086	\N	David Petraeus	\N
21087	\N	Geneviève Brisac	\N
21088	\N	Louis Gallois	\N
21089	\N	Daniel Soulez-Larivière	\N
21090	\N	David Miliband	\N
21091	\N	Enrique Vila-Matas	\N
21092	\N	Alain Prost	\N
21093	\N	atttentat	\N
21094	\N	Boris Berezovski	\N
21095	\N	commission électorale	\N
21096	\N	Bruno Peyron	\N
21097	\N	Michelle Obama	\N
21098	\N	Etats généraux	\N
21099	\N	Ban Ki-Moon	\N
21100	\N	François Patriat	\N
21101	\N	Northern Rock	\N
21102	\N	cour d'assises de Saint-Omer	\N
21103	\N	secret-défense	\N
18795	\N	Adrien Zeller	\N
18806	\N	Olympisme	\N
18807	\N	Arnold Schwarzenegger	\N
18818	\N	dépense de santé	\N
18823	\N	premier ministre	\N
18836	\N	Jean-Jacques Aillagon	\N
18860	\N	Alain Chamfort	\N
18861	\N	Yves Saint-Laurent	\N
18874	\N	Parti socialiste (PS)	\N
18876	\N	G7	\N
18881	\N	addiction	\N
18882	\N	DS	\N
18892	\N	Nouveau Parti anticapitaliste (NPA)	\N
18907	\N	FSU	\N
18908	\N	Fonction publique	\N
18909	\N	conseiller municipal	\N
18913	\N	Nashville	\N
20446	\N	Aubagne (Bouches-du-Rhône)	\N
20448	\N	Iata	\N
20462	\N	Edward Moore Kennedy	\N
20473	\N	mmigration clandestine	\N
20476	\N	RMC	\N
20477	\N	Europe1	\N
20484	\N	Miramax	\N
20494	\N	droit au logement opposable	\N
20507	\N	Davos	\N
20512	\N	King Midas Sound	\N
20528	\N	Charles de Gaulle	\N
20529	\N	Pierre Mendès France	\N
20550	\N	poil	\N
20554	\N	Commerce	\N
20561	\N	balance commerciale	\N
20562	\N	Elia Kazan	\N
20564	\N	BTP	\N
20570	\N	monsanto	\N
20571	\N	José Manuel Barroso	\N
20572	\N	commision européenne	\N
20575	\N	paradis fiscal	\N
20587	\N	Bobigny (Seine-Saint-Denis)	\N
20590	\N	Pédophilie	\N
20594	\N	commissaire	\N
20598	\N	LIgue 1	\N
20602	\N	Michel Vauzelle	\N
20603	\N	Laurence Vichnievsky	\N
20614	\N	Elliott Erwitt	\N
20615	\N	surpopulation carcérale	\N
20643	\N	transition	\N
20648	\N	paratge	\N
20650	\N	Nords-Pas-de-Calais	\N
20651	\N	Daniel Percheron	\N
20667	\N	Bernard Krief Consulting	\N
20668	\N	trésorerie	\N
20678	\N	These New Puritans	\N
20695	\N	élevage caprin	\N
20700	\N	mére porteuse	\N
20704	\N	crie financière	\N
20705	\N	trader	\N
20719	\N	campagne éléctorale	\N
20720	\N	Christophe Béchu	\N
20725	\N	Cité des Sciences	\N
20730	\N	François-Henri Pinault	\N
20743	\N	politique social	\N
20759	\N	Quentin Tarantino	\N
20774	\N	prpéaration	\N
20777	\N	Orlan	\N
20802	\N	Emmanuel Blanchard	\N
20803	\N	Karim Miské	\N
20825	\N	délégué  syndical	\N
20828	\N	.entraîneur	\N
20838	\N	Chopin	\N
20839	\N	Pleyel	\N
20840	\N	Herman Melville	\N
20842	\N	enchères	\N
20853	\N	Résultat	\N
20854	\N	hubert  Haenel	\N
20861	\N	Réserve fédérale (FED)	\N
20868	\N	Psychiatre	\N
20892	\N	fortune	\N
20893	\N	abus	\N
20900	\N	Scam	\N
20919	\N	Marco Decorpeliada	\N
20920	\N	thérapie	\N
20921	\N	art conceptuel	\N
20948	\N	Île de Ré	\N
20951	\N	Pierce Brosnan	\N
20975	\N	totalitarisme	\N
20976	\N	Myriam Revault d'Allonnes	\N
20983	\N	réfugié politique	\N
20992	\N	Naomi Campbell	\N
20993	\N	Jean-Pierre Coffe	\N
21008	\N	John Paulson	\N
21015	\N	violence conjugale	\N
21024	\N	foot	\N
21035	\N	Paul Vergès	\N
21036	\N	président	\N
21037	\N	La Réunion	\N
21104	\N	Malek Boutih	\N
21113	\N	Ayrton Senna	\N
21117	\N	diversion	\N
21133	\N	Peter Sloterdijk	\N
21135	\N	Youssou N'Dour	\N
21136	\N	sénégal	\N
21137	\N	Bob Marley	\N
21140	\N	Front de Gauche	\N
21141	\N	Partic comuniste Français PCF	\N
22959	\N	Pierre Etaix	\N
22960	\N	réédition	\N
22961	\N	André de Toth	\N
22962	\N	gardien	\N
22963	\N	surveillant	\N
22964	\N	Mauro Bolognini	\N
22965	\N	Boris Charmatz	\N
22968	\N	Assistance publique/ Hôpitaux de Paris (APHP)	\N
22969	\N	fonds d'investissement	\N
22970	\N	Saint Nazaire	\N
22971	\N	opposition\npolitique	\N
22972	\N	Cynthia Fleury	\N
22973	\N	Hissène Habré	\N
22974	\N	Patrice de Maistre	\N
22975	\N	dette publique\nFrançois Baroin	\N
22977	\N	William Dieterle	\N
22978	\N	Margaret Laurence	\N
22980	\N	Bébé	\N
22982	\N	politique cultuelle	\N
22984	\N	George Michael	\N
22985	\N	Guillaume Pépy	\N
22987	\N	vidéo surveillance	\N
22988	\N	mére	\N
22989	\N	Marcos Andandia	\N
22990	\N	Comact Disc	\N
22991	\N	Stéphane Lagoutte	\N
22992	\N	Régime alimentaire	\N
22994	\N	Avion	\N
22995	\N	autruche	\N
22996	\N	sucrerie	\N
22997	\N	Flavigny	\N
22999	\N	Mark Cavendish	\N
23000	\N	SACD (Société des auteurs et compositeurs dramatiques)	\N
23002	\N	rédaction	\N
23003	\N	Air France-KLM	\N
23004	\N	Jean-Cyril Spinetta	\N
23005	\N	Mikhaïl Pletnev	\N
23007	\N	Ridley Scot	\N
23010	\N	Jean-Patrick Manchette	\N
23012	\N	transaction financière	\N
23015	\N	Capitalisme	\N
23016	\N	Stephen Smith	\N
23017	\N	Usain Bolt	\N
23018	\N	Alimentation	\N
23019	\N	Jean Todt	\N
23020	\N	Claude Gassian	\N
23022	\N	Robert Musil	\N
23024	\N	Célébrité	\N
23025	\N	Charlie Capelle	\N
23026	\N	Nicolas Machiavel	\N
23027	\N	Herbie Hancock	\N
23028	\N	Gisèle Vienne	\N
23030	\N	Goût	\N
23031	\N	fichier informatique	\N
23034	\N	abbaye	\N
18796	\N	Jacques Bompard	\N
18797	\N	Jean-Marie Le Pen	\N
18798	\N	offensive militaire	\N
20542	\N	Alberto Moravia	\N
20546	\N	Georges Wilson	\N
20560	\N	Commissariat à l'Egalité des chances	\N
20579	\N	Massimo Ranieri	\N
20580	\N	ligue des droits de l'homme	\N
20584	\N	laboratoire	\N
20585	\N	PACA	\N
20588	\N	examen médical	\N
20591	\N	Olivier Jay	\N
20593	\N	fatah	\N
20595	\N	real de Madrid	\N
20600	\N	Paradis fiscal	\N
20604	\N	Mel Gibson	\N
20605	\N	Conseil représentatif des institutions juives de France Crif	\N
20611	\N	autorité	\N
20612	\N	politesse	\N
20619	\N	Guillaume Apollinaire	\N
20620	\N	non lieu	\N
20627	\N	camapgne électorale	\N
20628	\N	absention	\N
20701	\N	euthansie	\N
20703	\N	haut-commissariat	\N
20709	\N	Ariane Mnouchkine	\N
20711	\N	Robert Pandraud	\N
20717	\N	Kenneth Branagh	\N
20747	\N	densité	\N
20752	\N	Salman Rushdie	\N
20765	\N	pots-de-vin	\N
20771	\N	Nonce Paolini	\N
20784	\N	Pouvoir d'achat	\N
20790	\N	Musée mécanique	\N
20806	\N	espèce protégée	\N
20807	\N	lynx	\N
20812	\N	propriétaire	\N
20816	\N	grand palais	\N
20817	\N	William Turner	\N
20835	\N	Pierre Louette	\N
20837	\N	banque centrale européenne	\N
20857	\N	Guy Hascoët	\N
20867	\N	imaginaire	\N
20875	\N	Mikhaïl Saakachvili	\N
20884	\N	Alain Madelin	\N
20885	\N	codamnation	\N
20904	\N	ostréiculture	\N
20914	\N	Jean-Jack Queyranne	\N
20915	\N	Philippe Meirieu	\N
20924	\N	Enzo Cormann	\N
20931	\N	controverse	\N
20945	\N	relation commerciale	\N
20958	\N	mouton	\N
20973	\N	Richard Morgiève	\N
20979	\N	détention	\N
20986	\N	Mahinda Rajapakse	\N
20987	\N	etat d'urgence	\N
20994	\N	Jean-Luc Warsmann	\N
20995	\N	Daniel Cohn-Bendit  appel (sollicitation)	\N
21005	\N	Mylène Farmer	\N
21006	\N	Alain Le Vern	\N
21007	\N	Bruno Le Maire.	\N
21023	\N	Steven Cohen	\N
21028	\N	Carolyn Carlson	\N
21038	\N	A400M	\N
21044	\N	Corinne Lepage	\N
21048	\N	Chris Birkett	\N
21051	\N	sociologie politique	\N
21052	\N	résidence	\N
21055	\N	Waris Dirie	\N
21105	\N	cour d'assises de Saint-Ome	\N
21106	\N	famille royale	\N
21107	\N	Nora Berra	\N
21108	\N	innovation technologie	\N
21109	\N	mandragore	\N
21110	\N	instruction	\N
21111	\N	judiciaire	\N
21112	\N	Inetrnet	\N
21114	\N	règlement	\N
21115	\N	grand prix (sport)	\N
21116	\N	Parti communiste français	\N
21118	\N	Marihne Le Pen	\N
21119	\N	conseiller régional	\N
21120	\N	Hassan Chalgoumi	\N
21121	\N	harmonica	\N
21122	\N	compétion sportive	\N
21123	\N	Art contemporain	\N
21124	\N	création artistique	\N
21125	\N	Groupe Lagardère	\N
21126	\N	commission d'enquête parlementaire	\N
21127	\N	Mike Tyson	\N
21128	\N	Va--de-Marne	\N
21129	\N	direction 'dentrprise	\N
21130	\N	catégorie sociale	\N
21131	\N	électeur	\N
21132	\N	conférence internationale	\N
21134	\N	remplacement	\N
21138	\N	Europe Ecologie (EE)	\N
21139	\N	Nicoals sarkozy	\N
21142	\N	NPA Nouveau Pari anticapitaliste	\N
21143	\N	Miguel Delibes	\N
21144	\N	Mercedes	\N
21145	\N	mode de scrution	\N
21146	\N	absence	\N
21147	\N	parent d'élèves	\N
21148	\N	musqiue	\N
21149	\N	Gastronomie	\N
21150	\N	Pays basque	\N
21151	\N	locataire	\N
21152	\N	politique économie	\N
21153	\N	Philippe de Villiers	\N
21154	\N	Paris XIV	\N
21155	\N	dividende	\N
21156	\N	Elie Cohen	\N
21157	\N	exode urbain	\N
21158	\N	vierge Marie	\N
21159	\N	Walid Joumblatt	\N
21160	\N	achat d'armes	\N
21161	\N	organisme international	\N
21162	\N	Jean Ferrat	\N
21163	\N	processus de Paix	\N
21164	\N	Hugues Aufray	\N
21165	\N	banque privée	\N
21166	\N	garde du corps	\N
21167	\N	fraise	\N
21168	\N	saison	\N
21169	\N	Job Cohen	\N
21170	\N	Nièvres	\N
21171	\N	taille	\N
21172	\N	Gilles Simon	\N
21173	\N	syndicaliste	\N
21174	\N	racsime	\N
21175	\N	Nick McDonell	\N
21176	\N	Voyage	\N
21177	\N	Federico García Lorca	\N
21178	\N	années 1960	\N
21179	\N	Christian Rizzo	\N
21180	\N	Thomas Cadène	\N
21181	\N	orphelinat	\N
21182	\N	Francis Graille	\N
21183	\N	Pierre Frelot	\N
21184	\N	Laurent Perpère	\N
21185	\N	métrologie	\N
21186	\N	Christian Fevret	\N
21187	\N	CMA-CGM	\N
21188	\N	Seine-saint-Denis	\N
21189	\N	Anne-Marie Idrac	\N
21190	\N	Get Well Soon	\N
21191	\N	Konstantin Gropper	\N
21192	\N	Grand-Bretagne	\N
21193	\N	grand-Bretagne	\N
21194	\N	Peter Graves	\N
21195	\N	boisson	\N
21196	\N	mobilité	\N
21197	\N	Pays-Basque	\N
21198	\N	Andrés Wood	\N
21199	\N	Pascal Chaumeil	\N
21200	\N	Joy Sorman	\N
21201	\N	François Bégaudeau	\N
21202	\N	Bernard Plossu	\N
18799	\N	audiovisuel publique	\N
18802	\N	Alain Platel	\N
18805	\N	Guido Bertolaso	\N
18810	\N	Théorie économique	\N
18815	\N	Brigitte Bardot	\N
18816	\N	Patrick Balkany	\N
18826	\N	François Veillerette	\N
18827	\N	raisin	\N
18829	\N	loisir	\N
18851	\N	Dominique Paillé	\N
18852	\N	André Valentin	\N
18853	\N	Nadine Morano	\N
18854	\N	Pascal Clément	\N
18859	\N	politique de l'Industrie	\N
18865	\N	Vitry-sur-Seine (Val-de-Marne)	\N
18867	\N	Première ministre	\N
18885	\N	Hamid Baghai	\N
18886	\N	patrimoine	\N
18887	\N	plainte	\N
18888	\N	British museum	\N
18906	\N	évolution	\N
18912	\N	Christianisme	\N
18919	\N	Cristina Scabbia	\N
20574	\N	mer du Nord	\N
20581	\N	Lyon (Rhône-Alpes)	\N
20582	\N	presse quotidienne nationale	\N
20583	\N	Marisol Touraine	\N
20586	\N	ambition	\N
20596	\N	réalisation	\N
20606	\N	richesse (fortune)	\N
20616	\N	Dario Fo	\N
20617	\N	Muriel Mayette	\N
20629	\N	médaille	\N
20630	\N	réchauffement  climatique	\N
20631	\N	Jacques Higelin	\N
20633	\N	Brigitte Fontaine	\N
20702	\N	sqalaire	\N
20738	\N	Pantin (Seine-Saint-Denis)	\N
20744	\N	Presstalis	\N
20745	\N	commerce en ligne	\N
20764	\N	Puma	\N
20766	\N	David Cage	\N
20767	\N	thriller	\N
20778	\N	Parti des travailleurs	\N
20779	\N	Dilma Roussef	\N
20782	\N	carburant	\N
20783	\N	Alain Marleix	\N
20795	\N	îles Malouines	\N
20799	\N	Oscar	\N
20800	\N	Kathryn Bigelow	\N
20801	\N	station-service	\N
20809	\N	Martin Scorsese	\N
20815	\N	navigateur	\N
20821	\N	faculté	\N
20822	\N	CHU	\N
20827	\N	oignon	\N
20836	\N	Paul Kagamé	\N
20843	\N	Vincent Rottiers	\N
20844	\N	Césars	\N
20865	\N	Peter Lindbergh	\N
20866	\N	retouche	\N
20879	\N	Ile-de-france	\N
20910	\N	Bruno Gollnisch	\N
20918	\N	utilisation	\N
20922	\N	colère	\N
20946	\N	Christian Picquet	\N
20949	\N	Michaël Youn	\N
20950	\N	Colin Firth	\N
20952	\N	Jean-Pierre Masseret	\N
20953	\N	Laurent Hénart	\N
20959	\N	reportage	\N
20960	\N	Jean-Patrick Gilles	\N
20974	\N	requête	\N
20997	\N	Patrimoine culturelle	\N
21016	\N	Pôle Emploi	\N
21021	\N	Louis Bacon	\N
21027	\N	animaux	\N
21031	\N	Prud'hommes	\N
21041	\N	Yann Barthès	\N
21045	\N	célébration	\N
21203	\N	Eric Lacascade	\N
21204	\N	Maxime Gorki	\N
21205	\N	Sceaux	\N
21210	\N	Mikhaïl  Saakachvili	\N
21220	\N	récession	\N
21234	\N	Frédéric Chignac	\N
21235	\N	Aïssa Maïga	\N
21236	\N	cour martiale	\N
21241	\N	annonce	\N
21252	\N	crie économique	\N
21283	\N	Spike Jonze	\N
21287	\N	trimaran	\N
21305	\N	Provence-Côte-d'Azur (PACA)	\N
21316	\N	Taxe	\N
21341	\N	Hong Kong	\N
21343	\N	Coupe de la Ligue	\N
21351	\N	George Steiner	\N
21352	\N	Adolf Hitler	\N
21354	\N	Patrick Sébastien	\N
21355	\N	Chronologie	\N
21359	\N	Journal télévisé	\N
21366	\N	Dominique Bucchini	\N
21367	\N	Clara Bruni	\N
21371	\N	Akhenaton	\N
21376	\N	Charlie Haden	\N
21390	\N	Cerc	\N
21391	\N	rapporteur	\N
21412	\N	Calogero	\N
21429	\N	rédio	\N
21431	\N	déduction fiscale modification	\N
21440	\N	Pascal Elbé	\N
21470	\N	Jean-Pierre Papin	\N
21477	\N	marché de l'immobilier	\N
21484	\N	Roger-Pol Droit	\N
21485	\N	François Henrot	\N
21495	\N	La Maison Tellier	\N
21504	\N	Salam Fayyad	\N
21516	\N	mal-logés	\N
21526	\N	président de la République	\N
21567	\N	npes (Institut national de prévention et d'éducation à la santé)	\N
21570	\N	déficit commercial	\N
21573	\N	renseignement intérieur	\N
21579	\N	Alexandre Romanès	\N
21580	\N	cort-métrage	\N
21589	\N	Jaguar	\N
21595	\N	Solidarnosc	\N
21600	\N	Mip tv	\N
21603	\N	Nouvelle Calédonie	\N
21604	\N	Alexandre Bompard	\N
21605	\N	Béatrice Dalle	\N
21609	\N	Werner Schroeter	\N
21611	\N	code de la famille	\N
21615	\N	(Val-de-Marne)	\N
21616	\N	UE	\N
21618	\N	William Boyd	\N
21628	\N	Nick Clegg	\N
21638	\N	service cil	\N
21653	\N	Zoé Valdés	\N
21670	\N	GDF-Suez	\N
21671	\N	barrage	\N
21672	\N	Inacio Lula da Silva Luis	\N
21684	\N	Arthur Rimbaud	\N
21705	\N	malte	\N
21706	\N	construction automobile	\N
21707	\N	low cost	\N
21709	\N	Nikita Mikhalkov	\N
21718	\N	Thierry Lefebvre	\N
21721	\N	reprise	\N
21723	\N	séïsme	\N
21725	\N	Jacques Doillon	\N
21726	\N	Julie Depardieu	\N
21729	\N	Julie Delpy	\N
21756	\N	musée Carnavalet	\N
21758	\N	parti libéral	\N
21761	\N	Michèle Alliot-marie	\N
21762	\N	outrage	\N
21764	\N	hôtelerie	\N
21765	\N	Viavoice	\N
21775	\N	Antoine Schneck	\N
21778	\N	rafic d'influence	\N
21784	\N	Laurent Vacher	\N
18800	\N	Jean-Marie Bockel	\N
18803	\N	Veolia	\N
18808	\N	Fadela Amara	\N
18809	\N	Diam's	\N
18813	\N	laboratoires pharmaceutique	\N
18814	\N	stratégie économique	\N
18822	\N	Conseil général	\N
18831	\N	Sebastian Piñera	\N
18841	\N	milieu raral	\N
18846	\N	lieu de culte	\N
18848	\N	Andrius kubilius	\N
18862	\N	Nouveau Parti anticapitaliste	\N
18863	\N	LCR	\N
18864	\N	Camille de Casabianca	\N
18872	\N	réchauffement climatique	\N
18873	\N	Rajendra Pachauri	\N
18878	\N	Laura Chinchilla	\N
18883	\N	cordon ombilical	\N
18884	\N	conservation	\N
18890	\N	Richard Hawley	\N
18897	\N	politique de l'enseignement	\N
18900	\N	permis de séjour	\N
18914	\N	campagne de prévention	\N
18915	\N	fin	\N
18924	\N	Bernard-Henri Levy	\N
18929	\N	Dubaï	\N
18930	\N	années quatre vingt	\N
18940	\N	relation bilatérale	\N
18941	\N	Canal plus	\N
18942	\N	propositon	\N
18946	\N	Suez	\N
18955	\N	John Lennon	\N
20621	\N	sculpteur	\N
20622	\N	Raymond Mason	\N
20632	\N	résultat électorale	\N
20641	\N	Didier Defago	\N
20644	\N	vie ruralePays Basque Espagnol	\N
20646	\N	mode vie	\N
20647	\N	relation	\N
20661	\N	Crédit municipal de Paris	\N
20662	\N	organisation internationale	\N
20663	\N	jeux olympique	\N
20699	\N	crimes contre l'humanité	\N
20707	\N	Direction de la surveillance du territoire (DST)	\N
20718	\N	Nouveau Pari anticapitaliste (NPA)	\N
20734	\N	pharaon	\N
20737	\N	Philippe Mayaux	\N
20740	\N	Ian Hamel	\N
20741	\N	touareg	\N
20746	\N	Kevin Costner	\N
20763	\N	banque d'affaire	\N
20780	\N	archevêque	\N
20786	\N	Laurent Cantet	\N
20787	\N	Pascale Ferran	\N
20791	\N	Ophélie David	\N
20792	\N	télévision locale	\N
20793	\N	Valérie Donzelli	\N
20811	\N	Jacques Barrot	\N
20826	\N	Florina Ilis	\N
20845	\N	groupe parlemenaire	\N
20851	\N	Sécurité routière	\N
20852	\N	Claude Got	\N
20869	\N	ENA	\N
20876	\N	Lubéron	\N
20882	\N	Whitney Houston	\N
20887	\N	Zone euro	\N
20890	\N	Audrey Pulvar	\N
20897	\N	Patrick Pélata	\N
20932	\N	Réforme	\N
20933	\N	Peter Mandelson	\N
20969	\N	console	\N
20991	\N	centre-ville	\N
20996	\N	Patrick Modiano	\N
20999	\N	adulte	\N
21011	\N	centre de recherche	\N
21026	\N	Jean-Louis Debré	\N
21206	\N	Jésus-Christe	\N
21207	\N	Géraldine Danon	\N
21208	\N	Philippe Poupon	\N
21211	\N	Jean-Luc Delarue	\N
21212	\N	Bonheur	\N
21213	\N	Parvin Ardalan	\N
21214	\N	juge	\N
21215	\N	Calvin Klein	\N
21216	\N	Tommy Hilfiger	\N
21217	\N	Christophe Nick	\N
21218	\N	Sorbonne	\N
21219	\N	Fatih Akin	\N
21221	\N	Albert Maysles	\N
21222	\N	David Maysles	\N
21223	\N	campagne élecrorale	\N
21224	\N	Hans-Christian Schmid	\N
21225	\N	Fond monétaire européen	\N
21226	\N	Renzo Piano	\N
21227	\N	Amanda Seyfried	\N
21228	\N	Richard Wagner	\N
21229	\N	condition de travai	\N
21230	\N	TF	\N
21231	\N	gestion local	\N
21232	\N	Christophe Hondelatte	\N
21233	\N	Benyamin  Nétanyahou	\N
21239	\N	Tomas Alfredson	\N
21240	\N	fiscalité  local	\N
21242	\N	Raul Castro	\N
21243	\N	entrepreneur	\N
21244	\N	psychanalyste	\N
21245	\N	expérience scientifique	\N
21246	\N	Laurent Bègue	\N
21247	\N	Joe Biden	\N
21248	\N	Tawni O'Dell	\N
21249	\N	mine	\N
21251	\N	polèmique	\N
21253	\N	France-soir	\N
21254	\N	jeu d'argent	\N
21255	\N	promotion	\N
21256	\N	canada	\N
21257	\N	quizz	\N
21258	\N	question	\N
21259	\N	années quatre vingt-dix	\N
21260	\N	Carlos Nunez	\N
21261	\N	cornemuse	\N
21262	\N	campus	\N
21263	\N	Jean-Claude Carrière	\N
21264	\N	Lucian Freud	\N
21265	\N	Manche	\N
21266	\N	Pierre Guyotat	\N
21267	\N	Thomas Bernhard	\N
21268	\N	Paul Audi	\N
21269	\N	CSA (Audiovisuel)	\N
21270	\N	gastronomie (cuisine)	\N
21272	\N	élevage ovin	\N
21273	\N	reforme	\N
21274	\N	abstention	\N
21275	\N	Lagardère	\N
21277	\N	Côte d'Azur	\N
21278	\N	Jeu vidéo	\N
21279	\N	Congrès	\N
21280	\N	Bred	\N
21281	\N	biocarburant	\N
21282	\N	Stephen Harper	\N
21284	\N	Doha (Qatar)	\N
21285	\N	Languedoc Roussillon	\N
21286	\N	BCG	\N
21288	\N	Jean-Michel di Falco	\N
21289	\N	Hameed Nasser	\N
21290	\N	musée de France	\N
21291	\N	Christiane Naffah	\N
21292	\N	Michel André	\N
21293	\N	Académie française	\N
21294	\N	Gilbert Houngbo	\N
21295	\N	Patrick Gaubert	\N
21296	\N	scoop	\N
21297	\N	François Falletti	\N
21298	\N	Jean-Pierre Luminet	\N
21299	\N	Isaac Newton	\N
21300	\N	Budget de l'état	\N
21301	\N	travesti	\N
21302	\N	Philippe Plisson	\N
21303	\N	Lewis Carroll	\N
21304	\N	Jean-Yves Le Drian	\N
18811	\N	Afrique du sud	\N
18825	\N	Garde à vue	\N
18828	\N	parti de gauche	\N
18830	\N	moratoire	\N
18833	\N	papier	\N
18840	\N	temps de travail	\N
18843	\N	Mariann Fischer Boel	\N
18844	\N	Vénézuela	\N
18845	\N	émission de radio	\N
18847	\N	elu local	\N
18855	\N	Criirad	\N
18857	\N	région CentreHervé Novelli	\N
18858	\N	Bernard Cathelat	\N
18868	\N	Nouveau Parti Anticapitaliste	\N
18870	\N	Nouveau Parti Anticapitaliste (NPA)	\N
18871	\N	Île-de-France	\N
18877	\N	PSG	\N
18889	\N	horloge	\N
18891	\N	Buffy Sainte-Marie	\N
18896	\N	Benjamin Biolay	\N
18901	\N	Isabelle Huppert	\N
18905	\N	conditionnement	\N
18916	\N	Espace	\N
18920	\N	illéttrisme	\N
18922	\N	Elections ou Référendum	\N
18931	\N	Yazid Sabeg	\N
18933	\N	James Cameron	\N
18936	\N	musée du Louvre	\N
18937	\N	Léonard de Vinci	\N
18943	\N	frais	\N
18948	\N	compact-disc	\N
18949	\N	Vincent Bolloré	\N
18950	\N	Livre CGT	\N
18951	\N	Roland Barthes	\N
18952	\N	séminaire	\N
18956	\N	Per Olov Enquist	\N
18957	\N	pneumologie	\N
18958	\N	poumon	\N
18960	\N	presse hebdomadaire extrême droite	\N
18963	\N	Augustin Legrand	\N
18967	\N	Vincent Van Gogh	\N
18968	\N	égalité des chances	\N
18969	\N	Arnaud Fleurent-Didier	\N
18972	\N	France télécom	\N
18973	\N	Stéphane Richard	\N
18975	\N	Claude Le Roy	\N
18976	\N	Claude Bartolone	\N
18981	\N	cotisation	\N
18982	\N	Jean Leonetti	\N
18983	\N	gestation pour autrui	\N
18984	\N	Christophe Caresche	\N
18985	\N	réaction  proposition	\N
18986	\N	Profanation	\N
18987	\N	Roland Ries	\N
18988	\N	Laurent Fabius	\N
18989	\N	Europe Ecologie.	\N
18990	\N	Aéronautique	\N
18991	\N	A400 M	\N
18992	\N	particule	\N
18993	\N	juré	\N
18994	\N	Lycée	\N
18995	\N	Jo-Wilfried Tsonga	\N
18996	\N	Roger Federer	\N
18997	\N	Clio	\N
18998	\N	Jean-Louis Gergorin	\N
18999	\N	Imad Lahoud	\N
19000	\N	Florian Bourges	\N
19001	\N	Moïse	\N
19002	\N	Hamid Karzaï	\N
19003	\N	AIG	\N
19004	\N	Vincent Lagaf	\N
19005	\N	nourrice	\N
19006	\N	allaitement	\N
19007	\N	NMPP	\N
19008	\N	erreur (faute )	\N
19009	\N	Justine Hénin	\N
19010	\N	Andy Murray	\N
19011	\N	plante	\N
19012	\N	Muséum national d'histoire naturelle	\N
19013	\N	jardin	\N
19014	\N	débat politique	\N
19015	\N	Congrès (USA)	\N
19016	\N	Porto Alegre	\N
19017	\N	Lilian Thuram	\N
19018	\N	Marina Hands	\N
19019	\N	Problémes de société	\N
19020	\N	Claude Alphandéry	\N
19021	\N	Augustin de Romanet	\N
19022	\N	assurance-vie	\N
19023	\N	innovation	\N
19024	\N	IPad	\N
19025	\N	Steve Jobs	\N
19026	\N	édition scolaire	\N
19027	\N	recette	\N
19028	\N	Evo Morales	\N
19029	\N	heures supplémentaires	\N
19030	\N	Emmanuelle Devos	\N
19031	\N	McDonald's	\N
19032	\N	recherche et développement	\N
19033	\N	ministère de l'Intérieur.	\N
19034	\N	établissement de santé	\N
19035	\N	ministre de l'Intérieur	\N
19036	\N	Interdiction	\N
19037	\N	Europe écologie	\N
19038	\N	salarié	\N
19039	\N	Etat-major	\N
19040	\N	haute-couture	\N
19041	\N	Givenchy	\N
19042	\N	Coupe d'Afrique des nations	\N
19043	\N	Don Cherry	\N
19044	\N	Michel Le Bris	\N
19045	\N	Art plastique	\N
19046	\N	Pier Paolo Pasolini	\N
19047	\N	Daniel Cohn-Bendit	\N
19048	\N	les verts	\N
19049	\N	produit toxique	\N
19050	\N	Manu Larcenet	\N
19051	\N	Paul Quilès	\N
19052	\N	George Clooney	\N
19053	\N	Jason Reitman	\N
19054	\N	Emmanuelle Haïm	\N
19055	\N	Corée du sud	\N
19056	\N	Résolution	\N
19057	\N	chef de l'etat	\N
19058	\N	prix (coût)	\N
19059	\N	nouvelle tendance	\N
19060	\N	taïwan	\N
19061	\N	Vincent Geisser	\N
19062	\N	TFretraite	\N
19063	\N	Claude Chabrol	\N
19064	\N	Rafael Nadal	\N
19065	\N	Bureau international du travail (BIT)	\N
19066	\N	actionnaire majoritaire	\N
19067	\N	chien	\N
19068	\N	impôt	\N
19069	\N	Josephus Thimister	\N
19070	\N	André Gérin	\N
19071	\N	Pierre Goldman	\N
19072	\N	extrême gauche	\N
19073	\N	Andy Garcia	\N
19074	\N	scientologie	\N
19075	\N	Pierre Laurent	\N
19076	\N	liquidation judiciaire	\N
19077	\N	équipementier	\N
19078	\N	Masahiro Kobayashi	\N
19079	\N	Conseil français du culte musulman (CFCM)	\N
19080	\N	Heiner Müller	\N
19081	\N	élimination	\N
19082	\N	championnat national	\N
19083	\N	Technologie	\N
19084	\N	Nanotechnologie	\N
19085	\N	Frédéric Chopin	\N
19086	\N	pasteur	\N
19087	\N	diacre orthodoxe	\N
19088	\N	malade	\N
19089	\N	Géraldine Pailhas	\N
19090	\N	Le Havre (Seine-Maritime)	\N
19091	\N	Liberté de l'information	\N
19092	\N	code du travail	\N
19094	\N	TMC	\N
19093	\N	Bong Joon-ho	\N
19099	\N	Tim Burton	\N
19106	\N	entretien	\N
19107	\N	Laurence Ferrari	\N
19116	\N	affaires étrangères	\N
19135	\N	Stieg Larsson	\N
19136	\N	Eva Gabrielsson	\N
19151	\N	Didier Cuche	\N
19153	\N	Le Parisien	\N
19184	\N	enseignat	\N
19198	\N	course de fonds	\N
19199	\N	Andreï Kourkov	\N
19244	\N	salon	\N
19248	\N	Michel-Edouard Leclerc	\N
19250	\N	Loïk Le Floch-Prigent	\N
19251	\N	Elf	\N
19256	\N	Philippe Starck	\N
19270	\N	Martin Szekely	\N
19271	\N	Tour du Monde	\N
19278	\N	Mathilde Brétillot	\N
19283	\N	Sanseverino	\N
19293	\N	Edgar Allan Poe	\N
19296	\N	media	\N
19307	\N	Slavoj Zizek	\N
19311	\N	Susan Sontag	\N
19330	\N	compromis	\N
19339	\N	commissaire européen	\N
19340	\N	parlement européen	\N
19343	\N	Richard Gasquet	\N
19345	\N	Oxmo Puccino	\N
19347	\N	Frédéric Mermoud	\N
19348	\N	Ipsos	\N
19351	\N	Jean-Paul Belmondo	\N
19352	\N	enfance	\N
19355	\N	ournalisme	\N
19359	\N	Daniel Karlin	\N
19360	\N	site ne ligne	\N
19366	\N	ligue 1	\N
19369	\N	Canal+	\N
19372	\N	Bobby Charles	\N
19373	\N	rock'n'roll	\N
19381	\N	eau alimentation	\N
19384	\N	Ministère de l'Economie et des Finances	\N
19386	\N	Hervé Samb	\N
19388	\N	clip vidéo	\N
19389	\N	Roger Ballen	\N
19401	\N	Parti de Gauche	\N
19408	\N	solidarité	\N
19419	\N	Patrick Sommier	\N
19422	\N	Soul	\N
19423	\N	F1	\N
19424	\N	ukraine	\N
19425	\N	jean-Marie Besset	\N
19430	\N	Michel Barnier	\N
19431	\N	photo	\N
19466	\N	vœux	\N
19475	\N	Ann Bidermann	\N
19478	\N	Luc Moullet	\N
19481	\N	Eric Rohmer	\N
19485	\N	Ivo Josipovic	\N
19489	\N	vaccin	\N
20636	\N	grade à vue	\N
20642	\N	rétention	\N
20645	\N	Paradis fiscaux	\N
20657	\N	rétrospetcive	\N
20660	\N	Isabelle Clair	\N
20669	\N	Conseil supérieur de l'audiovisuel (CSA)	\N
20676	\N	Violaine Vanoyeke	\N
20677	\N	curling	\N
20679	\N	réseau social	\N
20697	\N	Robert Ford	\N
20706	\N	collaboration (coopération)	\N
20714	\N	campagne publicitaire	\N
20715	\N	lutte contre	\N
20721	\N	Amérindien	\N
20742	\N	imposture	\N
20748	\N	semaine	\N
20749	\N	Nicolas Rey	\N
20768	\N	Paul Lederman	\N
20772	\N	Giacomo Casanova	\N
20781	\N	incinérateur	\N
20785	\N	Mohammed Reza Heydari	\N
20805	\N	François Cervantes	\N
20808	\N	Carl Lewis	\N
20813	\N	Leonardo DiCaprio	\N
20818	\N	amiral	\N
20832	\N	Métro	\N
20833	\N	du médiateur de la République	\N
20834	\N	Jean-Paul Delevoye	\N
20841	\N	Renaud Camus	\N
20849	\N	Colloque	\N
20856	\N	néo-nazisme	\N
20870	\N	Eurovision	\N
20891	\N	Claude Lelouch	\N
20896	\N	Jan Dibbets	\N
20899	\N	catholiscisme	\N
20902	\N	processus de pais	\N
20903	\N	Haaretz	\N
20908	\N	milan	\N
20909	\N	prescription judiciaire	\N
20925	\N	pays émergents	\N
20926	\N	organisation mondiale de la santé (OMS)	\N
20927	\N	injure intégrisme	\N
20928	\N	parution	\N
20930	\N	arrêt de travail	\N
20934	\N	Géorgie (ex-URSS)	\N
20936	\N	ingérence extérieure	\N
20938	\N	Rhône (fleuve)	\N
20939	\N	protection	\N
20940	\N	John Furlong	\N
20941	\N	Etat-unis	\N
20942	\N	bunker	\N
20943	\N	Radovan Karadzic	\N
20944	\N	tribunal pénal international	\N
20956	\N	masque	\N
20957	\N	MF Doom	\N
20965	\N	Djibril Cissé	\N
20966	\N	Diego Maradona	\N
20970	\N	Chasse	\N
20977	\N	coalition gouvernementale	\N
20978	\N	éviction	\N
20980	\N	Karima Delli	\N
20982	\N	Hassen Chalghoumi	\N
20988	\N	Régis Jauffret	\N
20989	\N	Edouard Stern	\N
20990	\N	Cécile Brossard	\N
21000	\N	Helmut Fritz	\N
21003	\N	salon de l'agriculture	\N
21009	\N	déplacement	\N
21010	\N	Bouches-d-Rhône	\N
21014	\N	tutsi	\N
21018	\N	Yvette Roudy	\N
21019	\N	condition de la femme	\N
21022	\N	Olivier Temime	\N
21039	\N	Paul Mccartney	\N
21040	\N	Nouri al-Maliki	\N
21042	\N	Ryszard Kapuscinski	\N
21043	\N	soution	\N
21049	\N	coupe Davis	\N
21050	\N	déploiement militaire	\N
21053	\N	Faure Gnassingbé	\N
21057	\N	Claude François	\N
21058	\N	France dimanche	\N
21059	\N	interview	\N
21209	\N	Agence française de lutte contre le dopage	\N
21237	\N	élection régional	\N
21238	\N	Marine Aubry	\N
21250	\N	fusion	\N
21271	\N	Matthieu Boogaerts	\N
21276	\N	gouvrnement	\N
21306	\N	France inter	\N
21311	\N	Christine Boutin	\N
21315	\N	Carles Balagué	\N
21318	\N	écrivian	\N
21319	\N	solidartié	\N
21323	\N	Demi Moore	\N
21324	\N	André Santini	\N
21328	\N	années vingt	\N
21335	\N	Marco Bellocchio	\N
21342	\N	Jeannette Bougrab	\N
21345	\N	David Vann	\N
21349	\N	villes	\N
19096	\N	Logement social	\N
19105	\N	patinage artistique	\N
19111	\N	Lucilla Galeazzi	\N
19119	\N	Hillary Clinton	\N
19121	\N	Immigration clandestine	\N
19122	\N	Pierre Henry	\N
19125	\N	liberté de la presse	\N
19126	\N	RSF	\N
19127	\N	Jacques Audiard	\N
19147	\N	Antiquité	\N
19161	\N	Jean-Paul Gaultier	\N
19163	\N	YouTube	\N
19167	\N	Design	\N
19168	\N	Patrick Jouin	\N
19170	\N	Jerszy Seymour	\N
19171	\N	Philippe Nigro	\N
19172	\N	Laurent Massaloux	\N
19175	\N	Fernando Campana	\N
19188	\N	semi-conducteur	\N
19192	\N	quartier difficile	\N
19193	\N	contrôle de police	\N
19201	\N	Politique de l'immigration	\N
19213	\N	Jack Ralite	\N
19216	\N	Les Halles	\N
19231	\N	Monténégro	\N
19233	\N	ex-Yougoslavie	\N
19237	\N	œuvre d'art	\N
19253	\N	Enquête	\N
19257	\N	GDF Suez	\N
19258	\N	Gérard Mestrallet	\N
19259	\N	stock option	\N
19284	\N	identification	\N
19287	\N	Sylvie Kauffmann	\N
19288	\N	Monde (le)	\N
19331	\N	producteur	\N
19332	\N	Teitur	\N
19336	\N	élèvede enseignement primaire	\N
19353	\N	Clémentine Autain	\N
19362	\N	Victor Ianoukovitch	\N
19371	\N	griipe	\N
19376	\N	contrôle aéroport	\N
19387	\N	Débat	\N
19403	\N	Madeleine Vionnet	\N
19435	\N	cédès	\N
19436	\N	James Dean	\N
19438	\N	taxation	\N
19456	\N	immigration  clandestine	\N
19458	\N	équipement	\N
19461	\N	IGN	\N
19462	\N	Inrap	\N
19471	\N	littérature policière	\N
19472	\N	James Ellroy	\N
19483	\N	Sarah palin	\N
19492	\N	pastiche	\N
19493	\N	années soixante dix	\N
20894	\N	marée	\N
20895	\N	Niccolas Sarkozy	\N
20898	\N	navire	\N
20901	\N	Françoise Grossetête	\N
20905	\N	Infographie	\N
20911	\N	code	\N
20912	\N	internaute	\N
20913	\N	utilisateur	\N
20917	\N	défaut	\N
20955	\N	halal	\N
20961	\N	Franck Appréderis	\N
20962	\N	Saint-Germain	\N
20964	\N	ange	\N
20968	\N	Juvénal Habyarimana	\N
20972	\N	belgique	\N
20981	\N	travaux	\N
21001	\N	lyceen	\N
21002	\N	expusion	\N
21012	\N	bus	\N
21013	\N	Pierre Fonlupt	\N
21020	\N	vente île	\N
21025	\N	Luchino Visconti	\N
21029	\N	Gordon brown	\N
21032	\N	STMicroelectronics	\N
21033	\N	Pyrénées -Atlantiques	\N
21054	\N	Mons	\N
21056	\N	textile	\N
21307	\N	Nelson Freire	\N
21308	\N	Nicolas Cage	\N
21309	\N	François Cluzet	\N
21310	\N	Benoït XVI	\N
21312	\N	ségolène Royal	\N
21313	\N	handicapé moteur	\N
21314	\N	Jeux paralympiques	\N
21317	\N	Metz (Lorraine)	\N
21320	\N	Hachette	\N
21321	\N	Pays Bas	\N
21322	\N	révolution industrielle\nexode rurale	\N
21325	\N	Outre-Mer	\N
21326	\N	Emmanuelle Béart	\N
21327	\N	Georges Tron	\N
21329	\N	Marc-Philippe Daubresse	\N
21330	\N	élevage bovin	\N
21331	\N	Claire Denis	\N
21332	\N	Marie NDiaye	\N
21333	\N	Manuel Noriega	\N
21334	\N	John Lipsky	\N
21336	\N	marchés financiers	\N
21337	\N	Nina Bouraoui	\N
21338	\N	Richard Berry	\N
21339	\N	Franz-Olivier Giesbert	\N
21340	\N	Jean Reno	\N
21344	\N	John Cage	\N
21346	\N	île-de-france	\N
21347	\N	remaniement ministérielle	\N
21348	\N	Akira Kurosawa	\N
21350	\N	Nick Hornby	\N
21353	\N	Olivier Cadiot	\N
21356	\N	Brian Joubert	\N
21357	\N	Restos du cœur	\N
21358	\N	Jean-Pierre Bel	\N
21360	\N	compétition	\N
21361	\N	vie privé	\N
21362	\N	pays de l'Est	\N
21363	\N	Patrick Braouezec	\N
21364	\N	Nogent-sur-Oise	\N
21365	\N	Bianca Li	\N
21368	\N	Bruno Racine	\N
21372	\N	Hank Skinner	\N
21373	\N	Raymond Depardon	\N
21374	\N	utopie	\N
21375	\N	Françoise Hardy	\N
21377	\N	Antoine Zacharias	\N
21378	\N	Vinci	\N
21379	\N	abus de biens sociaux	\N
21380	\N	piratage informatique	\N
21381	\N	Pascal Lamy	\N
21383	\N	exposition universelle	\N
21384	\N	Gaspard Proust	\N
21386	\N	Snesup	\N
21387	\N	Georg Büchner	\N
21388	\N	Bernard Sobel	\N
21389	\N	magistature	\N
21392	\N	famine	\N
21393	\N	Tony Curtis	\N
21394	\N	Marilyn Monroe	\N
21395	\N	Etas-Unis	\N
21396	\N	Camélia Jordana	\N
21397	\N	Lune	\N
21398	\N	Marie-Noëlle Lienemann	\N
21399	\N	françois Fillon	\N
21400	\N	Antoine Bernheim	\N
21401	\N	RAI	\N
21403	\N	Iyad Allawi	\N
21404	\N	parti	\N
21408	\N	rire	\N
21409	\N	Shanghaï	\N
21413	\N	sécurité sanitaire	\N
21414	\N	nanotechnologie	\N
21415	\N	Jean-Paul Jean	\N
21417	\N	Gilles Jacob	\N
21418	\N	syndicat d'enseignant	\N
21419	\N	ANC	\N
21420	\N	äge	\N
21421	\N	orang-outang	\N
21422	\N	Jardin des plantes	\N
21423	\N	Joseph Tual	\N
21424	\N	témoin	\N
21425	\N	Jenson Button	\N
19097	\N	cinémathèque française	\N
19098	\N	Philippe Garrel	\N
19100	\N	Jeanne Balibar	\N
19130	\N	Décines	\N
19131	\N	Union des organisations islamiques de France (UOIF)	\N
19141	\N	Stade français	\N
19148	\N	Bruno Soulier	\N
19149	\N	Eva Vallejo	\N
19152	\N	Roger Pierre	\N
19178	\N	protection des espèces	\N
19180	\N	Aerosmith	\N
19181	\N	Steven Tyler	\N
19195	\N	Tour du monde	\N
19202	\N	nicolas Sarkozy	\N
19218	\N	israël	\N
19223	\N	Unicef	\N
19224	\N	procédure	\N
19238	\N	Joachim Jirou-Najou	\N
19239	\N	Marie-Aurore Stiker	\N
19240	\N	Claudio Colucci	\N
19241	\N	Humberto Campana	\N
19243	\N	Juan Martin Del Potro	\N
19245	\N	Kraft	\N
19246	\N	Cadbury	\N
19247	\N	Warren Buffett	\N
19249	\N	budget de l'Eta	\N
19262	\N	cuisine	\N
19268	\N	Christian Gailly	\N
19276	\N	judaÏsme	\N
19277	\N	conseil d'état	\N
19292	\N	- Netanyahou Benyamin	\N
19295	\N	David Attoub	\N
19301	\N	Jérôme Bonaparte	\N
19302	\N	frère	\N
19303	\N	Napoléon Ier	\N
19304	\N	vol	\N
19333	\N	Ali Agca	\N
19334	\N	Jean Paul II	\N
19335	\N	tigre	\N
19337	\N	vache	\N
19338	\N	Télécommunication	\N
19365	\N	jour	\N
19383	\N	satellite de communication	\N
19395	\N	Comité olympique	\N
19396	\N	jeu olympique	\N
19399	\N	Tintin	\N
19404	\N	Joseph Nadj	\N
19405	\N	Guerre	\N
19406	\N	George Bush père	\N
19407	\N	Saddam Hussein	\N
19420	\N	copie	\N
19439	\N	turquie	\N
19459	\N	François Roussely	\N
19482	\N	Murray Schafer	\N
19497	\N	Sinn Féin	\N
21369	\N	médiation	\N
21370	\N	Maurice Papon	\N
21382	\N	Judith Godrèche	\N
21385	\N	statistique mode de vie	\N
21402	\N	force	\N
21405	\N	Pal Sarkozy	\N
21406	\N	Jean-Michel Aulas	\N
21407	\N	Jean-Louis Triaud	\N
21410	\N	avis	\N
21411	\N	Youssef Chahine	\N
21416	\N	Univers	\N
21426	\N	Ricky Martin	\N
21427	\N	Pablo Emilio Moncayo	\N
21432	\N	Jean Arthuis	\N
21437	\N	Erika	\N
21442	\N	Faune	\N
21443	\N	girafe	\N
21449	\N	CGC	\N
21458	\N	Tchétchènie	\N
21460	\N	Andreï Nekrassov	\N
21466	\N	Hayao Miyazaki	\N
21471	\N	éditeur	\N
21472	\N	Claude Tchou	\N
21476	\N	Florent Malouda	\N
21478	\N	système financier	\N
21487	\N	parole	\N
21490	\N	dénonciation	\N
21492	\N	The Stooges	\N
21500	\N	Lotus	\N
21501	\N	Valérie Létard	\N
21505	\N	Marée noire	\N
21507	\N	haute technologie	\N
21508	\N	mal logé	\N
21511	\N	James Bond	\N
21514	\N	politique sociale\ndéveloppement économique	\N
21520	\N	cinéma d'art et essai	\N
21522	\N	Ioukos	\N
21524	\N	monople	\N
21531	\N	Katyn	\N
21554	\N	superbowl	\N
21556	\N	jeu de hazard	\N
21557	\N	Pour une République solidaire	\N
21558	\N	la Réunion	\N
21564	\N	parti national	\N
21566	\N	Agence de l'environnement et de la maîtrise de l'énergie	\N
21572	\N	Haute Autorité de lutte contre les discriminations et pour l'égalité (Halde)	\N
21574	\N	Brice Lalonde	\N
21582	\N	Gerhard Richter	\N
21583	\N	Gwen Aduh	\N
21586	\N	Jacques Weber	\N
21596	\N	Afssa	\N
21606	\N	Nilda Fernandez	\N
21607	\N	candidatureélection présidentielle	\N
21608	\N	201	\N
21614	\N	charge sociale	\N
21622	\N	comité central d'entreprise	\N
21624	\N	Bruno Gollnish	\N
21625	\N	présidnce	\N
21635	\N	Yvan Attal	\N
21639	\N	politique fiscale\nfinancement	\N
21643	\N	Samuel L.Jackson	\N
21647	\N	Popularité	\N
21648	\N	Roger-Gérard Schwartzenberg	\N
21649	\N	Parti radical de gauche	\N
21650	\N	corrida	\N
21651	\N	Juan Carlos	\N
21656	\N	Matt Damon	\N
21662	\N	mutinerie	\N
21663	\N	1917	\N
21664	\N	Prince	\N
21673	\N	comapratif	\N
21680	\N	lSégolène Royal	\N
21690	\N	Marc Simoncini	\N
21691	\N	royauté	\N
21694	\N	Joestarr	\N
21696	\N	Conseil d'orientation des retraites (COR)	\N
21701	\N	Henry Moore	\N
21728	\N	Mrap	\N
21733	\N	Grève	\N
21736	\N	insalubrité	\N
21740	\N	deuil	\N
21742	\N	institutrice	\N
21743	\N	David Lynch	\N
21752	\N	Richard Nixon	\N
21759	\N	Juan Antonio Samaranch	\N
21763	\N	Luxe	\N
21772	\N	message électonique	\N
21774	\N	nouveau	\N
21779	\N	Patrick Marest	\N
21781	\N	Terre	\N
21783	\N	Marc-Edouard Nabe	\N
21788	\N	naeisme	\N
21798	\N	Georges Lucas	\N
21799	\N	Olympique lyonnais	\N
21800	\N	Bayern Munich	\N
21802	\N	traumatisme	\N
21803	\N	soldat\nassociation	\N
21810	\N	oubli	\N
21811	\N	Grégory Thil	\N
21813	\N	invalidation	\N
21815	\N	Conseil représentatif des institutions juives de France	\N
21816	\N	Olympique Lyonnais	\N
21817	\N	Hugo Lloris	\N
21818	\N	Bayern (Munich)	\N
21822	\N	Ben Stiller	\N
19101	\N	DOM TOM	\N
19114	\N	Vaux-en-Velin	\N
19115	\N	Villefranche	\N
19150	\N	Paul Smith	\N
19156	\N	Justine Henin	\N
19169	\N	onu? enfant	\N
19173	\N	Thierry Omeyer	\N
19186	\N	Science de la terre	\N
19187	\N	voix	\N
19191	\N	Ferran Savall	\N
19203	\N	Louis Petiet	\N
19204	\N	introduction en Bourse	\N
19205	\N	Krief Group	\N
19208	\N	Agence européenne des médicaments	\N
19210	\N	Willy Rozenbaum	\N
19214	\N	travailleur saisonnier	\N
19215	\N	MSF	\N
19242	\N	Django Reinhardt	\N
19252	\N	Jasper Morrison	\N
19254	\N	Constance Guisset	\N
19255	\N	Andrea Branzi	\N
19266	\N	fond souverain	\N
19267	\N	politique de la défense	\N
19269	\N	Election présidentielle	\N
19275	\N	statut déclaration	\N
19281	\N	expérimentation	\N
19282	\N	site d'information	\N
19286	\N	émission télévisée	\N
19289	\N	Philippe Courroye	\N
19300	\N	colloque	\N
19314	\N	adoption (procédure	\N
19315	\N	élection  législative	\N
19325	\N	casque bleu	\N
19342	\N	Denzel Washington	\N
19350	\N	escale	\N
19357	\N	entourage Saddam Hussein	\N
19361	\N	Claude Onesta	\N
19393	\N	Cinémathèque de la danse	\N
19410	\N	Charlotte Perriand	\N
19411	\N	Napoléon	\N
19412	\N	Victor Hugo	\N
19413	\N	Jean-Marc Hovasse	\N
19428	\N	Luis Sepulveda	\N
19429	\N	label	\N
19433	\N	mer Méditerrannée	\N
19451	\N	arnaque	\N
19463	\N	Tiger Woods	\N
19464	\N	TNS	\N
19476	\N	Associated Press	\N
19490	\N	Martin VEYRON	\N
21428	\N	Erykah Badu	\N
21430	\N	cheminée	\N
21433	\N	Antoine Vitez	\N
21434	\N	Coopération	\N
21435	\N	Francophonie	\N
21436	\N	équivalence	\N
21438	\N	Emmanuel Chain	\N
21439	\N	Rio Tinto	\N
21441	\N	opposition	\N
21444	\N	Dennis Quaid	\N
21445	\N	Paul Bettany	\N
21446	\N	Parlementaire	\N
21447	\N	jeux	\N
21448	\N	jeux en ligne	\N
21450	\N	bilan accord	\N
21451	\N	plainte judicière	\N
21452	\N	europe	\N
21453	\N	poduction	\N
21454	\N	trafic franduleux	\N
21455	\N	Carcassonne (Aude)	\N
21456	\N	garde  à vue	\N
21457	\N	Lou Reed	\N
21459	\N	Antoine de Baecque	\N
21461	\N	Michel Aumont	\N
21462	\N	Jean-Michel Lemétayer	\N
21463	\N	Nouvelle technologie	\N
21464	\N	téléphonie	\N
21465	\N	Olivier Balez	\N
21467	\N	machine	\N
21468	\N	dvd	\N
21469	\N	Max Ophüls	\N
21473	\N	Boogers	\N
21474	\N	vie	\N
21475	\N	voyage (tourisme)	\N
21479	\N	Dagestan	\N
21480	\N	condamnation à perpétuité	\N
21481	\N	démantèlement	\N
21482	\N	occupation des locaux	\N
21483	\N	Alain Lambert	\N
21486	\N	bagerre	\N
21488	\N	Christian Ward	\N
21489	\N	Vincent Cespedes	\N
21491	\N	Pôle emploi	\N
21493	\N	Bruno Le Roux	\N
21494	\N	politique de la Ville	\N
21496	\N	doublure	\N
21497	\N	Sékouba Konaté	\N
21498	\N	calendier	\N
21499	\N	hier Bernard Tapie	\N
21502	\N	ouvrier agricole	\N
21503	\N	Red Bull	\N
21506	\N	Damien Hirst	\N
21509	\N	Olivier Dahan	\N
21510	\N	Serge Dassault	\N
21512	\N	Pierre Charon	\N
21513	\N	Jean-Michel Basquiat	\N
21515	\N	Alain Gautré	\N
21517	\N	enquête policière	\N
21518	\N	accueil	\N
21519	\N	Serge de Diaghilev	\N
21521	\N	Daimler	\N
21523	\N	Pascal Thomas	\N
21525	\N	aide finacière	\N
21527	\N	ordure ménagère	\N
21528	\N	René Belletto	\N
21529	\N	Vienne	\N
21530	\N	pari en ligne	\N
21532	\N	Convention collective	\N
21533	\N	Andy Roddick	\N
21534	\N	Recep Erdogan	\N
21535	\N	abrogation	\N
21536	\N	ex-NMPP	\N
21537	\N	Richard Malka	\N
21538	\N	Germaine Tillion	\N
21539	\N	Clyde Chabot	\N
21540	\N	Renée Zellweger	\N
21541	\N	autorité palestinienne	\N
21542	\N	Guido Westerwelle	\N
21543	\N	ministère des Affaires étrangères \nhomme d'affaire	\N
21544	\N	UMP Christian Jacob	\N
21545	\N	Georges Fenec	\N
21546	\N	general motors	\N
21547	\N	frein	\N
21548	\N	Coline Serreau	\N
21549	\N	-	\N
21550	\N	campagne électorale\nparti politique	\N
21551	\N	traité de non-prolifération	\N
21552	\N	Taslima Nasreen	\N
21553	\N	Tempête	\N
21555	\N	le chef de l'Etat	\N
21559	\N	Rachida dati	\N
21560	\N	népotisme	\N
21561	\N	commission des finances	\N
21562	\N	fonds souverains	\N
21563	\N	Jacques Perrin	\N
21565	\N	consensus	\N
21568	\N	nicolas sarkozy	\N
21569	\N	Jérôme Cahuzac	\N
21571	\N	Grigny (Essonne)	\N
21575	\N	Jean-Claude Trichet	\N
21576	\N	Michael Douglas	\N
21577	\N	Kirk Douglas	\N
21578	\N	trafic de stupéfiant	\N
21581	\N	El Greco	\N
21584	\N	cycle	\N
21585	\N	immigration illégale	\N
21587	\N	pays du sud	\N
21588	\N	Najat Belkacem	\N
21590	\N	hitoire	\N
21591	\N	São Paulo	\N
19102	\N	Thierry Lhermitte	\N
19103	\N	Hadopi	\N
19104	\N	mmigration	\N
19112	\N	Oussama Ben Laden	\N
19113	\N	cassette audio	\N
19118	\N	Oskar Lafontaine	\N
19128	\N	souvenir	\N
19132	\N	education sexuelle	\N
19133	\N	économique	\N
19142	\N	nucléaire	\N
19158	\N	Archive	\N
19159	\N	Eric Cantona	\N
19160	\N	Rachida Brakni	\N
19164	\N	Georges Simenon	\N
19165	\N	Pierre Simenon	\N
19197	\N	présidence de la République	\N
19219	\N	article	\N
19221	\N	Bruno le Maire	\N
19226	\N	Michele De Lucchi	\N
19227	\N	Naoto Fukasawa	\N
19229	\N	Nestor Perkal	\N
19232	\N	Jean-Marie Massaud	\N
19235	\N	Sam Baron	\N
19265	\N	José Saramago	\N
19291	\N	jean-Louis Borloo	\N
19310	\N	cumul	\N
19312	\N	Jérôme Valcke	\N
19313	\N	coupe du monde	\N
19341	\N	i-phone	\N
19344	\N	Christophe Beaux	\N
19346	\N	supporteur	\N
19349	\N	Marcos Baghdatis	\N
19354	\N	Benoit XVI	\N
19377	\N	habitation	\N
19378	\N	carton	\N
19402	\N	prévention agriculteur	\N
19416	\N	Benoît Jacquot	\N
19417	\N	Jules Massenet	\N
19418	\N	Jonas Kaufman	\N
19426	\N	destruction école	\N
19437	\N	voeux  presse écrite	\N
19447	\N	Banque centrale européenne (BCE)	\N
19452	\N	Palais de la découverte	\N
19453	\N	Science	\N
19491	\N	Robert Zemeckis	\N
21592	\N	strasbourg	\N
21612	\N	Charente-maritime	\N
21613	\N	maison	\N
21623	\N	Viktor Orbán	\N
21626	\N	île de Wight	\N
21631	\N	Philippe Borrel	\N
21642	\N	David Servan-Schreiber	\N
21654	\N	logistique	\N
21655	\N	Bono	\N
21685	\N	2014	\N
21688	\N	INA	\N
21689	\N	Agence France-Presse	\N
21698	\N	immigré	\N
21699	\N	océan atlantique	\N
21720	\N	acciden	\N
21727	\N	Agence France Presse	\N
21730	\N	Valéry Giscard d'Estaing.	\N
21738	\N	Sam Mendes	\N
21739	\N	Agathe Bonitzer	\N
21741	\N	Franck Dubosc	\N
21746	\N	Paula Fox	\N
21776	\N	Radovic Vukovic	\N
21777	\N	Zoran Tomic	\N
21797	\N	hyperréalisme	\N
21801	\N	circulation automobile	\N
21807	\N	digital versatile disc	\N
21823	\N	Robert Zoellick	\N
21837	\N	Günter Walraff	\N
21851	\N	Emile Zola	\N
21852	\N	Paul Bocuse	\N
21853	\N	Paul Reubens	\N
21858	\N	Stephen Hawking	\N
21860	\N	Amnesty international	\N
21867	\N	Jean-Christophe Rufin	\N
21886	\N	Athène	\N
21916	\N	taliban Pakistan	\N
21924	\N	atlhétisme	\N
21936	\N	Jean-Claude Kaufmann	\N
23032	\N	Commission nationale de l'informatique et des libertés	\N
23554	\N	Alexis Mabille	\N
23558	\N	ornithologie	\N
23559	\N	iidéologie politique	\N
23560	\N	Abdul Ruzibiza	\N
23562	\N	Dries Van Noten	\N
23566	\N	John Rawls	\N
23568	\N	crise économie	\N
23569	\N	Denis Diderot	\N
23570	\N	Xavier Veilhan	\N
23571	\N	Droite	\N
23574	\N	batterie	\N
23578	\N	Romain Gary	\N
23579	\N	Rafael Correa	\N
23840	\N	traitement médicale	\N
23849	\N	Antoine De Caunes	\N
23854	\N	Pays bas	\N
23858	\N	Secours catholique	\N
23864	\N	fédération française de football	\N
23893	\N	Clotilde Hesme	\N
23895	\N	Anderson Luis de Carvalho	\N
23897	\N	Bernard Stiegler	\N
23903	\N	Judit Reigl	\N
23904	\N	Beaux-Arts	\N
23915	\N	garde d'enfant	\N
23924	\N	Catherine Maunoury	\N
23927	\N	Hervé Bourges	\N
23928	\N	Alfred de Musset	\N
23934	\N	Direction des constructions navales (DCN)	\N
23935	\N	Alain Juillet	\N
23936	\N	Commerce en ligne	\N
23937	\N	économie locale	\N
23952	\N	Île de La Réunion	\N
23955	\N	Eric Fassin	\N
23956	\N	Roberto Garzelli	\N
23957	\N	Hugh Hefner	\N
23958	\N	ministre de la Défense	\N
23959	\N	Simonetta Greggio	\N
23965	\N	régime	\N
23966	\N	parti politque	\N
23967	\N	Europe écologie- Les Verts	\N
23976	\N	Sharon Stone	\N
23977	\N	Penelope Cruz	\N
23978	\N	J.D. Salinger	\N
23979	\N	Julia Roberts	\N
23988	\N	fiscalité de l'entreprise	\N
23996	\N	Ernest-Antoine Seillère	\N
24000	\N	Alexandre Jardin	\N
24001	\N	agent	\N
24002	\N	Proche Orient	\N
24024	\N	Italien décès	\N
24025	\N	Haute Autorité de santé	\N
24026	\N	Philippe Druillet	\N
24027	\N	démobilisation	\N
24028	\N	Omar el-Bechir	\N
24029	\N	Omar El-Béchir	\N
24030	\N	Syndicat des eaux d'Ile-de-France (Sedif)	\N
24032	\N	Ayub Macharia	\N
24033	\N	Viktor Orban	\N
24034	\N	rentrée parlementaire	\N
24035	\N	Chambre des représentants	\N
24036	\N	Jérémie Bélingard	\N
24037	\N	Havas	\N
24038	\N	Ariel Sharon	\N
24039	\N	décoration intérieur	\N
24040	\N	Banque centrale des Etats d'Afrique de l'Ouest (BCEAO)	\N
24041	\N	Pascale Clark	\N
24042	\N	Offre publique d'achat	\N
24043	\N	scripte	\N
24044	\N	Hugues Micol	\N
24045	\N	William Daley	\N
24046	\N	Barbie	\N
24047	\N	Hervé Kempf	\N
19108	\N	iran	\N
19120	\N	politiqie de l'immigration	\N
19134	\N	coupe d'Europe	\N
19139	\N	Laura Smet	\N
19145	\N	Banque centrale	\N
19146	\N	Ben Bernanke	\N
19157	\N	habitant	\N
19162	\N	Gaston Chaissac	\N
19174	\N	Julien Cendre	\N
19196	\N	visite	\N
19200	\N	Frédéric Lefebvre	\N
19206	\N	abeille	\N
19207	\N	étude scientifique	\N
19209	\N	Québec	\N
19217	\N	Pierre Charpin	\N
19222	\N	Inga Sempe	\N
19225	\N	Ingo Maurer	\N
19228	\N	Matali Crasset	\N
19234	\N	Gilles Belley	\N
19236	\N	Handball	\N
19260	\N	Serge Blisko	\N
19261	\N	Patrick Bloche	\N
19279	\N	créancier	\N
19280	\N	Sara Palin	\N
19285	\N	Geert Wilders	\N
19290	\N	Racing club	\N
19294	\N	chaînes de télévision	\N
19297	\N	Cervantès	\N
19298	\N	Don Quichotte	\N
19299	\N	statue	\N
19305	\N	Matt Dillon	\N
19306	\N	Michel Blanc	\N
19308	\N	Joann Sfar	\N
19326	\N	social	\N
19327	\N	CCAS	\N
19328	\N	direction générale	\N
19329	\N	junte militaire	\N
19356	\N	fignitaire religieux	\N
19370	\N	téléthon	\N
19382	\N	Hindi Zahra	\N
19390	\N	Humanitaire	\N
19391	\N	industrie aéronautique	\N
19392	\N	avion (modèle)	\N
19414	\N	Miquel Dewever-Plana	\N
19415	\N	indien	\N
19432	\N	propsition	\N
19445	\N	Israél	\N
19446	\N	service militaire	\N
19449	\N	chef d'état	\N
19450	\N	Moussa Dadis Camara	\N
19460	\N	Patrick Rotman	\N
19465	\N	Les Echos	\N
19467	\N	meubles	\N
19498	\N	location	\N
21593	\N	or	\N
21594	\N	réchauffement climatique  bateau	\N
21597	\N	Liz Taylor	\N
21598	\N	Gaetano Pesce	\N
21599	\N	table	\N
21601	\N	stratégiede l'entreprise	\N
21602	\N	information judiciaire	\N
21610	\N	Slobodan Milosevic	\N
21617	\N	procès-verbal	\N
21619	\N	aérien	\N
21620	\N	Easyjet	\N
21621	\N	droit du travail Pôle emploi	\N
21627	\N	MIP TV	\N
21629	\N	Kourmanbek Bakiev	\N
21630	\N	Didier Le Reste	\N
21632	\N	Nicolas Anelka	\N
21633	\N	Jean-Louis Malys	\N
21634	\N	Lou Ye	\N
21636	\N	Xabi Molia	\N
21637	\N	Julie Gayet	\N
21640	\N	Daniel Bilalian	\N
21641	\N	SNF	\N
21644	\N	promesse électrorale	\N
21645	\N	vendée	\N
21646	\N	Paris Match	\N
21652	\N	sondage Reuters	\N
21657	\N	Cité nationale de l'histoire de l'immigration	\N
21658	\N	Luc Gruson	\N
21659	\N	Cécile de France	\N
21660	\N	Sam Worthington	\N
21661	\N	Woody Allen	\N
21665	\N	IVG	\N
21666	\N	Patrice Bessac	\N
21667	\N	agence	\N
21668	\N	Emmanuel Hoog	\N
21669	\N	Pierre Kosciusko-Morizet	\N
21674	\N	Vidéo à la demande	\N
21675	\N	vente électronique	\N
21676	\N	Starbucks	\N
21677	\N	Henry Fonda	\N
21678	\N	John Ford	\N
21679	\N	Nick Cave	\N
21681	\N	Saint-Raphaël	\N
21682	\N	Paris-Dakar	\N
21683	\N	camion	\N
21686	\N	Gianni Agnelli	\N
21687	\N	Guillaume Musso	\N
21692	\N	tri	\N
21693	\N	TTempête	\N
21695	\N	Xavier Niel	\N
21697	\N	Police de proximité	\N
21700	\N	Jean-Paul Sartre	\N
21702	\N	librté de circulation	\N
21703	\N	Le Point	\N
21704	\N	Publicité	\N
21708	\N	Eric Nataf	\N
21710	\N	profession médicale	\N
21711	\N	Benazir Bhutto	\N
21712	\N	avantage fiscal	\N
21713	\N	Archives	\N
21714	\N	bibliothèque national	\N
21715	\N	Joey Starr	\N
21716	\N	Jean-Michel Aphatie	\N
21717	\N	Le monde	\N
21719	\N	Mimmo Jodice	\N
21722	\N	Ehud Olmert	\N
21724	\N	Elisabeth Roudinesco	\N
21731	\N	Hawaï	\N
21732	\N	brice Hortefeux	\N
21734	\N	sociologue	\N
21735	\N	montage	\N
21737	\N	code de procédure pénal	\N
21744	\N	Nyons (Drôme)	\N
21745	\N	procédure pénal	\N
21747	\N	questions sociales	\N
21748	\N	Faurecia	\N
21749	\N	Christian Lambert	\N
21750	\N	MArtine Aubry	\N
21751	\N	Hervé Mariton	\N
21753	\N	Benoît Delépine	\N
21754	\N	Gustave Kervern	\N
21755	\N	André Manoukian	\N
21757	\N	lettre (correspondance)	\N
21760	\N	politique du transport	\N
21766	\N	Juge d'instruction	\N
21767	\N	Elie Wiesel	\N
21768	\N	judaîsme	\N
21769	\N	Quinzaine des réalisateurs	\N
21770	\N	Frédéric Boyer	\N
21771	\N	Brive (Corrèze)	\N
21773	\N	menace de mort	\N
21780	\N	Jorge Luis Borges	\N
21782	\N	Indianapolis	\N
21785	\N	Saint-Barthélémy	\N
21786	\N	Robert Mugabe	\N
21787	\N	Napoléon Bonaparte	\N
21789	\N	Rachid Bakhalq	\N
21790	\N	Bruges	\N
21791	\N	Gap	\N
21792	\N	Endemol	\N
21793	\N	Claire Chazal	\N
21794	\N	cinéma pornographique	\N
21795	\N	François Chérèque	\N
21796	\N	Championnat de France	\N
21804	\N	viagra	\N
21805	\N	Daniel Toscan du Plantier	\N
21806	\N	Racing Métro 92	\N
21808	\N	transport aérienne	\N
21809	\N	manœuvre militaire	\N
19109	\N	master	\N
19110	\N	sciences humaines et sociales	\N
19117	\N	oscars	\N
19123	\N	Juan Carlos Lecompte	\N
19124	\N	Ingrid Betancourt	\N
19129	\N	Patrice Duhamel	\N
19137	\N	Patrick Vieira	\N
19138	\N	hôtel	\N
19140	\N	ArcelorMittal	\N
19143	\N	patrimoine culturelle	\N
19144	\N	Guy de Maupassant	\N
19154	\N	Carlos Cruz-Diez	\N
19155	\N	Véolia	\N
19166	\N	Biodiversité	\N
19176	\N	Anthony Dunne	\N
19177	\N	Fiona Raby	\N
19179	\N	Christophe Pillet	\N
19182	\N	Konstantin Grcic	\N
19183	\N	Marti Guixé	\N
19185	\N	salon (foire)	\N
19189	\N	Sebastián Piñera	\N
19190	\N	Edication nationale	\N
19194	\N	Chef de l'état	\N
19211	\N	Daniel Bensaïd	\N
19212	\N	philosophe	\N
19220	\N	proposition de loi	\N
19230	\N	Fox News	\N
19263	\N	guadeloupe	\N
19264	\N	David Guetta	\N
19272	\N	UGC	\N
19273	\N	technique	\N
19274	\N	3d	\N
19309	\N	Michelle Pierre-Louis	\N
19316	\N	Nicholas Stern	\N
19317	\N	collège de France	\N
19318	\N	développement durable	\N
19319	\N	Catastrophe naturelle	\N
19320	\N	la Seine	\N
19321	\N	Statistique	\N
19322	\N	but	\N
19323	\N	Lionel Messi	\N
19324	\N	commmunauté internationale	\N
19358	\N	Lionel Jospin	\N
19363	\N	Julien Lizeroux	\N
19364	\N	Sandrine Aubert	\N
19367	\N	Polaroid	\N
19368	\N	exile	\N
19374	\N	Alexandre Vvedenski	\N
19375	\N	Agnès Bourgeois	\N
19379	\N	Edwy Plenel	\N
19380	\N	vérité	\N
19385	\N	attaque	\N
19394	\N	Viktor Iouchtchenko	\N
19397	\N	Bode Miller	\N
19398	\N	dialogue	\N
19400	\N	Marie Bové	\N
19409	\N	Jaco Van Dormael	\N
19421	\N	Manuel Aeschlimann	\N
19427	\N	Antiquités (civilisation)	\N
19434	\N	relation sociale	\N
19440	\N	Ilich Ramírez Sánchez	\N
19441	\N	procédure judicaire	\N
19442	\N	rédaction en chef	\N
19443	\N	Antonio Gramsci	\N
19444	\N	théorie politique	\N
19448	\N	ouvrier	\N
19454	\N	catch	\N
19455	\N	INPI	\N
19457	\N	V.S. Naipaul	\N
19468	\N	production électrique	\N
19469	\N	Alain Krivine	\N
19470	\N	Ligue communiste révolutionnaire (LCR )	\N
19473	\N	Richard Stallman	\N
19474	\N	Sam Williams	\N
19477	\N	télévisoin	\N
19479	\N	Malik Zidi	\N
19480	\N	Hiver	\N
19484	\N	Serge Renko	\N
19486	\N	visiteur	\N
19487	\N	Marc Tessier	\N
19488	\N	Gallica	\N
19494	\N	Arielle Dombasle	\N
19495	\N	Marie Rivière	\N
19496	\N	Melvil Poupaud	\N
19499	\N	ministrère des Affaires étrangères	\N
19500	\N	alarme	\N
19501	\N	bonus	\N
19502	\N	Pedro Costa	\N
19503	\N	tour	\N
19504	\N	outre-mer	\N
19505	\N	Antilles	\N
19506	\N	Clint Eastwood	\N
19507	\N	épidémiologie	\N
19508	\N	élection  régionale	\N
19509	\N	Montreuil (Seine-Saint- Denis)	\N
19510	\N	Nationalité	\N
19511	\N	Raymond Murray Schafer	\N
19512	\N	établissement public	\N
19513	\N	André Brink	\N
19514	\N	Haute technologie	\N
19515	\N	François de Rugy	\N
19516	\N	Benoît Hamon	\N
19517	\N	Nikolay Davydenko	\N
19518	\N	Doha	\N
19519	\N	témoignange	\N
19520	\N	intempérie	\N
19521	\N	Orchestre national de Lyon	\N
19522	\N	Laurent Langlois	\N
19523	\N	Hongkong	\N
19524	\N	Justice internationale	\N
19525	\N	Apartheid	\N
19526	\N	éleve	\N
19527	\N	Yves Michaud	\N
19528	\N	Sébastien Clerc	\N
19529	\N	Louis Nicollin	\N
19530	\N	Beyoncé	\N
19531	\N	Hannibal Khadafi	\N
19532	\N	argent (monnaie)	\N
19533	\N	Stipe Mesic	\N
19534	\N	Jérôme Bonnell	\N
19535	\N	Barbet Schroeder	\N
19536	\N	Pascal Greggory	\N
19537	\N	Anne Hidalgo	\N
19538	\N	Le Figaro	\N
19539	\N	Denis Podalydès	\N
19540	\N	Robert Louis Stevenson	\N
19541	\N	urbanisation	\N
19542	\N	Sandro da Cruz	\N
19543	\N	jury	\N
19544	\N	délibération	\N
19545	\N	Tesco	\N
19546	\N	hypermarché	\N
19547	\N	casinos	\N
19548	\N	Université	\N
19549	\N	grandes écoles	\N
19550	\N	Mano Solo	\N
19551	\N	écologimte	\N
19552	\N	Thon	\N
19553	\N	Yukio Hatoyama	\N
19554	\N	Précarité	\N
19555	\N	programme	\N
19556	\N	Kristina Rady	\N
19557	\N	Bertrand Cantat	\N
19558	\N	Noir désir	\N
19559	\N	Les Bodin's	\N
19560	\N	voile voile islamique	\N
19561	\N	fondamentalisme	\N
19562	\N	HongKong	\N
19563	\N	occupation des lieux	\N
19564	\N	Air	\N
19565	\N	Barak Obama	\N
19566	\N	série	\N
19567	\N	Lost	\N
19568	\N	égalité homme-femme	\N
19569	\N	confidentialité	\N
19570	\N	wi-fi	\N
19571	\N	Stade	\N
19572	\N	partie  civile	\N
19573	\N	supportzer	\N
19574	\N	Automobile	\N
19575	\N	Fraude	\N
19576	\N	Michael Brand	\N
19577	\N	Nuala O'Faolain	\N
19578	\N	Flavius Josèphe	\N
19579	\N	Amos Gitai	\N
19582	\N	Michèle Manceaux	\N
19594	\N	cour des comptes	\N
19614	\N	hard discount	\N
19628	\N	Michel Rocard	\N
19671	\N	Stéphane Freiss	\N
19672	\N	Laurent Jaoui	\N
19676	\N	Erika Steinbach	\N
21812	\N	Parti socialiste européen	\N
21814	\N	Odile Duboc	\N
21820	\N	Poitou-Charente	\N
21821	\N	lycéen	\N
21824	\N	déchet nucléaire	\N
21872	\N	parti écologiste	\N
21875	\N	Benyamin Netanyahou	\N
21879	\N	Bouygues Telecom	\N
21880	\N	France Telecom	\N
21881	\N	Albert Londres	\N
21887	\N	éconmie	\N
21888	\N	Didier Adès	\N
21889	\N	Dominique Dambert	\N
21891	\N	écosystéme	\N
21898	\N	Marcel Hanoun	\N
21899	\N	éléction législative	\N
21901	\N	eexploitation des matières premières	\N
23037	\N	Mode de vie	\N
23038	\N	Fred Bernard	\N
23042	\N	Biologie	\N
23051	\N	golfe du Mexique	\N
23055	\N	anatomie	\N
23056	\N	échographie	\N
23586	\N	Umberto Eco	\N
23587	\N	piratage infomratique	\N
23588	\N	Marianne	\N
23589	\N	météologie	\N
23590	\N	Ben Affleck	\N
23591	\N	Commission électorale	\N
23592	\N	Yann Moix	\N
23593	\N	Gayssot Jean-Claude Gayssot	\N
23594	\N	Énergie solaire	\N
23595	\N	Sans-domicile-fixe	\N
23596	\N	Jean-Noël Guérini	\N
23597	\N	Lagardère groupe	\N
23598	\N	vigneron	\N
23599	\N	Charm-el-Cheikh	\N
23600	\N	foyerd'hébergement	\N
23601	\N	électricicité	\N
23602	\N	L'Unità	\N
23603	\N	Meetic	\N
23604	\N	cochon	\N
23605	\N	David Blunkett	\N
23606	\N	Saint-Louis (Missouri)	\N
23607	\N	années deux-mille	\N
23608	\N	silicone	\N
23609	\N	handisport	\N
23610	\N	2022	\N
23611	\N	William Sheller	\N
23612	\N	recel d'abus de confiance	\N
23613	\N	Miss France	\N
23614	\N	panda	\N
23615	\N	Charles Aznavour	\N
23616	\N	fracture	\N
23617	\N	cocotier	\N
23618	\N	l'Unità	\N
23619	\N	Haute autorité de lutte contre les discriminations et pour l'égalité (Halde)	\N
23620	\N	Louis Schweitzer	\N
23621	\N	candidadure	\N
23622	\N	poursuite judicaire	\N
23623	\N	Françoise Sagan	\N
23624	\N	Denis Westhoff	\N
23625	\N	nouveaté	\N
23626	\N	fiscalité ce l'entreprise	\N
23627	\N	Aqmi	\N
23628	\N	Pays-de-la-Loire	\N
23629	\N	aide-soignant	\N
23630	\N	Heinrich Kühn	\N
23631	\N	Virginia Fienga	\N
23632	\N	Jon Hanssen-Bauer	\N
23633	\N	Jacques Lafleur	\N
23634	\N	Edgar Degas	\N
23635	\N	Mario Ceroli	\N
23636	\N	Arlette Laguiller	\N
23637	\N	Jean-Pierre Fourcade	\N
23638	\N	Fonds stratégique d'investissement (FSI)	\N
23639	\N	Edward Yang	\N
23640	\N	Ibsen	\N
23641	\N	Thierry Roisin	\N
23642	\N	Josip Broz Tito	\N
23643	\N	Pascale Guédot	\N
23644	\N	politique fiscalité	\N
23645	\N	Jean François Copé	\N
23646	\N	projet de loi de finances	\N
23647	\N	Cancun	\N
23648	\N	gospel	\N
23649	\N	David Burnett	\N
23650	\N	France et en Allemagne	\N
23651	\N	investissements à l'étranger	\N
23652	\N	Commerce extérieur	\N
23653	\N	Radu Muntean	\N
23654	\N	William Bourdon	\N
23655	\N	plainte judiciaire torture	\N
23656	\N	Dario Argento	\N
23657	\N	Guillaume Nicloux	\N
23658	\N	Jean-Bernard Pouy	\N
23659	\N	Lobby	\N
23660	\N	Chris Morris	\N
23661	\N	Marcel cohen	\N
23662	\N	Sharunas Bartas	\N
23663	\N	Partii socialiste	\N
23664	\N	Didier Blonde	\N
23665	\N	Sam Taylor-Wood	\N
23666	\N	Union Fédérale des Consommateurs (UFC)	\N
23667	\N	politiquer sociale	\N
23668	\N	ministre du Travail	\N
23669	\N	réfomre	\N
23670	\N	VIe République	\N
23671	\N	obsésité	\N
23672	\N	harcèlement moral	\N
23673	\N	Jean-Paul Besset	\N
23674	\N	Henry James	\N
23675	\N	Sophia Domancich	\N
23676	\N	Hayden Christensen	\N
23677	\N	Affaire politico financière	\N
23678	\N	Bernard Arnault	\N
23679	\N	M.I.A.	\N
23680	\N	Hérmès	\N
23681	\N	Cro-Magnon	\N
23682	\N	Peter Watkins	\N
23683	\N	exposotion	\N
23684	\N	Percy Kemp	\N
23685	\N	Les  Verts	\N
23686	\N	James Graham Ballard	\N
23687	\N	Céline Dion	\N
23688	\N	Elise Lucet	\N
23689	\N	norme européenne	\N
23690	\N	Vendée Globe	\N
23691	\N	le Monde	\N
23692	\N	Pierre Ducrozet	\N
23693	\N	Rémy Pernelet	\N
23694	\N	magazine spécialisée	\N
23695	\N	Aretha Franklin	\N
23696	\N	dîner	\N
23697	\N	Muhammar Kadhafi	\N
23698	\N	aventure	\N
23699	\N	Lautréamont	\N
23700	\N	Yves Coppens	\N
23701	\N	George Harrison	\N
23702	\N	Cour européenne des droits de l'homme (CEDH)	\N
23703	\N	enchère	\N
23704	\N	Guy Loudmer	\N
23705	\N	Martine Le Gall	\N
23706	\N	années quatre-vingt dix	\N
23707	\N	autoroutier	\N
23708	\N	Camille Morineau	\N
23709	\N	John Leahy	\N
23710	\N	services secret	\N
23711	\N	Convention internationale	\N
19580	\N	Thierry Lancino	\N
19584	\N	Fos-sur-Mer (Bouches-du-Rhône)	\N
19589	\N	Franck Ribéry	\N
19602	\N	syndicat du Livre	\N
19618	\N	Guantánamo	\N
19630	\N	La Courneuve (Seine-Saint-Denis)	\N
19634	\N	stupidité	\N
19637	\N	Jane Campion	\N
19664	\N	Ounie Lecomte	\N
19675	\N	Marsan (Landes)	\N
21819	\N	Christophe Alévêque	\N
21825	\N	Todd Solondz	\N
21826	\N	mathématique	\N
21836	\N	emprisonnement	\N
21838	\N	Ben Ali	\N
21839	\N	Marianne Thyssen	\N
21842	\N	Claude Michel Cluny	\N
21849	\N	Nicolas Sarkozy \nHu Jintao	\N
21855	\N	concurrence commerciale	\N
21859	\N	Pierre Rosanvallon	\N
21866	\N	postcast	\N
21868	\N	allocation sociale	\N
21871	\N	H Cup	\N
21878	\N	étude supérieure	\N
21885	\N	campagne électorale\ncandidature	\N
21890	\N	Retraite	\N
21893	\N	Pierre Encrevé	\N
21896	\N	Brillante Mendoza	\N
21900	\N	Mickaël Landreau	\N
21903	\N	Kirghizistan	\N
21904	\N	antiquité (civilisation)	\N
21905	\N	rchéologie	\N
21906	\N	nion européenne	\N
21908	\N	Gaspar Noé	\N
21910	\N	déficit budgétaire\ndette publique	\N
21914	\N	Martine Aubry.	\N
21917	\N	Tbilissi	\N
21920	\N	Alli	\N
21922	\N	Transbordeur	\N
21923	\N	Gare du Nord	\N
21928	\N	Murdoch	\N
21929	\N	femmes	\N
21930	\N	The Sun	\N
21932	\N	Cinéhappy	\N
21935	\N	Ségolène Royal \nFrançois Hollande	\N
21939	\N	François Kersaudy	\N
21940	\N	Rue89	\N
21941	\N	magasine	\N
21942	\N	Numéricable	\N
21943	\N	BetClic	\N
21944	\N	Aberdeen	\N
21945	\N	Ben Jones	\N
21946	\N	Lisa De Bruine	\N
23043	\N	Martin Kannegiesser	\N
23045	\N	14 juillet	\N
23047	\N	contrôle fiscale	\N
23048	\N	Mémoire	\N
23049	\N	Catherine Deneuve	\N
23061	\N	Lilianne Bettencourt	\N
23062	\N	David Pujadas	\N
23063	\N	embauche	\N
23064	\N	inspection des impôts	\N
23065	\N	ministre du budget	\N
23066	\N	Fonds stratégique d'investissement	\N
23067	\N	Neuilly sur Seine	\N
23068	\N	les Noailles	\N
23069	\N	Marie-George buffet	\N
23070	\N	Industrie aéronautique	\N
23071	\N	repos	\N
23072	\N	Yann Potin	\N
23073	\N	France Galop	\N
23074	\N	Karim Aga Khan	\N
23075	\N	Soldat	\N
23076	\N	blanchiment	\N
23077	\N	Pixar	\N
23078	\N	Andy Schleck	\N
23079	\N	guide partique	\N
23080	\N	Syndicat national des entreprises artistiques et culturelles (Syndeac)	\N
23081	\N	ministre du Budget	\N
23082	\N	bavure	\N
23083	\N	Richard Dadd	\N
23084	\N	Florence Woerth	\N
23085	\N	Compact Disc	\N
23086	\N	Animals	\N
23087	\N	Handicapé	\N
23088	\N	Alain Crombecque	\N
23089	\N	Olivier Saillard	\N
23090	\N	Ernest Pignon-Ernest	\N
23091	\N	Autralie	\N
23092	\N	Marjane Satrapi	\N
23093	\N	Carlos Santana	\N
23094	\N	olivier Cadiot	\N
23095	\N	Ludovic Lagarde	\N
23096	\N	Cindy Van Acker	\N
23097	\N	iPhone	\N
23098	\N	Joe Meek	\N
23099	\N	banquier	\N
23100	\N	album (musique)	\N
23101	\N	Pierre Schott	\N
23102	\N	Boccace	\N
23103	\N	Thierry Saussez	\N
23104	\N	Inspection générale	\N
23105	\N	onctionnement	\N
23106	\N	Alicante	\N
23107	\N	Conseiller	\N
23108	\N	la Joconde	\N
23109	\N	Justice international	\N
23110	\N	armée de Terre	\N
23111	\N	Zaz	\N
23112	\N	L	\N
23113	\N	brigade financière	\N
23114	\N	Joshua Bilton	\N
23115	\N	football.	\N
23116	\N	Cencic	\N
23117	\N	Julie Bertucelli	\N
23118	\N	Jeanne Cherhal	\N
23119	\N	Ile	\N
23120	\N	remerciement	\N
23121	\N	barack Obama	\N
23122	\N	Monde	\N
23123	\N	Cascadeur	\N
23124	\N	crédit suisse	\N
23125	\N	déclaration\nvoyage officiel	\N
23126	\N	Jason Goodwin	\N
23127	\N	Bixente Lizarazu	\N
23128	\N	vacances scoalires	\N
23129	\N	Raja Shehadeh	\N
23130	\N	lauréat	\N
23131	\N	MRC	\N
23132	\N	Isabella Blow	\N
23133	\N	Stéphane Delajoux	\N
23134	\N	opération chirugicale	\N
23135	\N	clavecin	\N
23136	\N	Perche	\N
23137	\N	Frantz Kafka	\N
23138	\N	Edition	\N
23139	\N	légalité	\N
23140	\N	Mirko Cvetkovic	\N
23141	\N	Charles Dickens	\N
23142	\N	Intellectuel	\N
23143	\N	Eric Da Silva	\N
23144	\N	Christopher Buckley	\N
23145	\N	Bill Gates	\N
23146	\N	Saisie	\N
23147	\N	Gloria Allred	\N
23148	\N	Valentino Rossi	\N
23149	\N	science de la terre	\N
23150	\N	Nietzsche	\N
23151	\N	Laura Flessel	\N
23152	\N	Sheila Jackson Lee	\N
23153	\N	Gabriel Cohn-Bendit	\N
23154	\N	Aurélie Filippetti	\N
23155	\N	Marie-Odile Bertella-Geffroy	\N
23156	\N	Christian Bourgeois	\N
23157	\N	Ax	\N
23158	\N	site enligne	\N
23159	\N	Christophe Riblon	\N
23160	\N	Pythagore	\N
23161	\N	Kant	\N
23162	\N	Mark Webber	\N
23163	\N	Montesquiou	\N
19581	\N	DOM-TOM	\N
19585	\N	Nigéria	\N
19596	\N	Pascal Rambert	\N
19599	\N	Simone Veil	\N
19621	\N	Patrick Colleony	\N
19622	\N	Christopher Lee	\N
19623	\N	Charlemagne	\N
19631	\N	chiffre	\N
19632	\N	Axel Springer	\N
19648	\N	Juan Gabriel Vasquez	\N
19649	\N	Joseph Conrad	\N
21827	\N	João Pedro Rodrigues	\N
21830	\N	bande dessiné	\N
21832	\N	Joni Mitchell	\N
21833	\N	Arnaud Largardère	\N
21834	\N	Guy Wyser-Pratte	\N
21843	\N	exploration	\N
21863	\N	Mario Levi	\N
21870	\N	Gérad Larcher	\N
21876	\N	personnalité	\N
21877	\N	Time Magazine	\N
21882	\N	Jérôme Kerviel	\N
21894	\N	palace	\N
21907	\N	Christophe Fiat	\N
21911	\N	Naturama	\N
21921	\N	Dominique Perben	\N
21925	\N	Grenelle de l'environnement	\N
23044	\N	homoparentalité	\N
23046	\N	Ed Wood	\N
23050	\N	Frédéric Bonnaud	\N
23054	\N	Recette de cuisine	\N
23059	\N	Bernard Herrmann	\N
23060	\N	René Teulade	\N
23164	\N	Hanoch Levin	\N
23170	\N	Claude Dilain	\N
23184	\N	dissolution  parlementaire	\N
23194	\N	pistes cyclables	\N
23197	\N	Chuan Lu	\N
23199	\N	tour de france	\N
23203	\N	Christian Poveda	\N
23206	\N	Blackberry	\N
23207	\N	sécurité nationale	\N
23712	\N	Vice-président	\N
23720	\N	Jean-Pierre Bechter	\N
23723	\N	Will Ferrell	\N
23731	\N	allègement fiscale	\N
23841	\N	Beauregard	\N
23842	\N	Jean-Paul Bailly	\N
23843	\N	Collectivités territoriales	\N
23844	\N	world Music	\N
23845	\N	Alain Ducasse	\N
23847	\N	hors-la-loi	\N
23848	\N	Billy the Kid	\N
23851	\N	investissements étrangers	\N
23852	\N	Ludovic Giuly	\N
23853	\N	anorexie	\N
23855	\N	Raymond Aron	\N
23859	\N	Assenblée nationale	\N
23860	\N	Conciergerie	\N
23861	\N	Politique de la famille	\N
23865	\N	Conseil de la Concurrence	\N
23866	\N	sanction financière	\N
23867	\N	signalisation	\N
23868	\N	élection Législative	\N
23869	\N	excommunication	\N
23875	\N	rentrée littéraire	\N
23876	\N	Crédit Coopératif	\N
23877	\N	prêt bancaire	\N
23878	\N	proximité	\N
23879	\N	commerce sociale	\N
23880	\N	Autorié palestinienne	\N
23881	\N	Zimbabwée	\N
23882	\N	permis de travail	\N
23883	\N	Guillaume Canet	\N
23884	\N	Banque Postale	\N
23885	\N	Virginie occidentale	\N
23886	\N	lobbying	\N
23887	\N	gréve de la faim	\N
23888	\N	Reporters d'espoirs	\N
23889	\N	cardinal André Vingt-Trois	\N
23890	\N	poid lourd	\N
23892	\N	Brive	\N
23894	\N	Ville de Paris	\N
23899	\N	Stefano Accorsi	\N
23900	\N	Laetitia Casta	\N
23901	\N	politique de la Défense	\N
23902	\N	centre d'hébergement	\N
23906	\N	Christophe Lemaitre	\N
23907	\N	automonile	\N
23908	\N	Nano	\N
23909	\N	Autorité paklestinienne	\N
23910	\N	Yannick Bertrand	\N
23911	\N	Libération(journal)	\N
23912	\N	Michel Castermans	\N
23913	\N	Maurice Leroy	\N
23914	\N	Pierre Reverdy	\N
23916	\N	Vladimir Jankélévitch	\N
23917	\N	Olivier De Schutter	\N
23918	\N	Sali Berisha	\N
23919	\N	trafic d'arme	\N
23921	\N	Airy Darbon	\N
23922	\N	poids lourds	\N
23923	\N	Avidgor Lieberman	\N
23926	\N	rite religieux	\N
23930	\N	Michelangelo Frammartino	\N
23931	\N	Michel Polnareff	\N
23932	\N	Loi	\N
23933	\N	SRU	\N
23938	\N	ski Alpin	\N
23939	\N	Michael Walchhofer	\N
23940	\N	Pierre Manent	\N
23942	\N	Seymour Hoffman	\N
23945	\N	Servier	\N
23946	\N	Bibliothèque	\N
23947	\N	nouvel	\N
23949	\N	Cedeao	\N
23950	\N	Jean-Charles Szurek	\N
23951	\N	Philip Seymour Hoffmann	\N
23953	\N	Ralph Eugene Meatyard	\N
23954	\N	Centre national du cinéma (CNC)	\N
23960	\N	Camélia-Jordana	\N
23961	\N	L'Orél	\N
23962	\N	Fortune (richesse)	\N
23963	\N	Maylis de Kerangal	\N
23964	\N	Israel	\N
23968	\N	lanque française	\N
23969	\N	éléctricité	\N
23971	\N	procureur général	\N
23973	\N	Cesare Battisti	\N
23974	\N	mère Teresa	\N
23975	\N	aid financière	\N
23982	\N	lapidation	\N
23983	\N	Sakineh Mohammadi Ashtiani	\N
23984	\N	Boris Nemtsov	\N
23987	\N	Hassan Nasrallah	\N
23989	\N	Hervé Ghesquière	\N
23990	\N	Stéphane Taponier	\N
23991	\N	modèle d'avion	\N
23992	\N	bande-dessinée	\N
23997	\N	Jacques Vergès	\N
23998	\N	Roland Dumas	\N
24003	\N	Firefox	\N
24004	\N	Véronique Cayla	\N
24005	\N	Vladimire Poutine	\N
24006	\N	CEDAO	\N
24007	\N	Salva Kiir	\N
24008	\N	André Gide	\N
24011	\N	Nouvel an	\N
24013	\N	Chuck Berry	\N
24014	\N	Mathieu Lindon	\N
24015	\N	outil	\N
24016	\N	Maliphant Russell	\N
24017	\N	La Seyne-sur-Mer	\N
24018	\N	Marcus Malte	\N
24019	\N	ventes	\N
24020	\N	Henry Kissinger	\N
24021	\N	URSS	\N
24022	\N	Pierre Graff	\N
24023	\N	Aéroports de Paris	\N
19583	\N	Kader Attou	\N
19595	\N	impayé	\N
19597	\N	Tutsi	\N
19598	\N	hutu	\N
19600	\N	Anne-Laure Liégeois	\N
19601	\N	Rémi de Vos	\N
19608	\N	gratuit	\N
19609	\N	Jacques Toubon	\N
19610	\N	Patrick Zelnik	\N
19627	\N	Presse Emblème Campagne (PEC)	\N
19633	\N	Flavio Briatore	\N
19636	\N	richesse(fortune)	\N
19647	\N	monument	\N
19650	\N	Bryan Stanley Johnson	\N
19651	\N	Jonathan Coe	\N
19673	\N	facture	\N
19678	\N	Israël ; incident	\N
21828	\N	Agence européenne de sécurité alimentaire (Aesa)	\N
21829	\N	Agence française de sécurité sanitaire des aliments (Afssa)	\N
21831	\N	Xavier Beauvois	\N
21835	\N	Jean-François Lamour	\N
21840	\N	Christian Godin	\N
21841	\N	essai(genre littéraire)	\N
21844	\N	Edmund White	\N
21845	\N	Peter Adam	\N
21846	\N	devoir de réserve	\N
21847	\N	statégie politique	\N
21848	\N	Hubert Védrine	\N
21850	\N	Robert Adams	\N
21854	\N	UBS	\N
21856	\N	rmanifestation	\N
21857	\N	Tim Roth	\N
21861	\N	Paul McCartney	\N
21862	\N	Vincent Cassel	\N
21864	\N	New Delhi	\N
21865	\N	Gymnastique	\N
21869	\N	chronolgie	\N
21873	\N	Anna Politkovskaïa	\N
21874	\N	Mireille Perrier	\N
21883	\N	Français	\N
21884	\N	Corruption	\N
21892	\N	Harry Roselmack	\N
21895	\N	stylisme	\N
21897	\N	terrrosime	\N
21902	\N	Connie Hedegaard	\N
21909	\N	Yousry Nasrallah	\N
21912	\N	Santé environnement France	\N
21913	\N	Bbvert	\N
21915	\N	Doux	\N
21918	\N	Photo	\N
21919	\N	année soixante-dix	\N
21926	\N	Raphaël Saurin	\N
21927	\N	Shangaï	\N
21931	\N	William Lubtchansky	\N
21933	\N	Picasso	\N
21934	\N	Hermann Goring	\N
21937	\N	Christophe Alevêque	\N
21938	\N	Fouquet	\N
21947	\N	Michèle Laroque	\N
21948	\N	Lokua Lanza	\N
21949	\N	Pavement	\N
21950	\N	Zénith	\N
21951	\N	légalisation  (stupéfiant)	\N
21952	\N	Stéphane Gatignon	\N
21953	\N	Pierre Skira	\N
21954	\N	politique locale	\N
21955	\N	Pinacothèque	\N
21956	\N	infogrqaphie	\N
21957	\N	Préhistoire	\N
21958	\N	Paléontologie	\N
21959	\N	Ademe	\N
21960	\N	Coblence	\N
21961	\N	Nuits Botanique	\N
21962	\N	grande-Bretagne	\N
21963	\N	Dennis Hopper	\N
21964	\N	Easy Rider	\N
21965	\N	pollution climatique	\N
21966	\N	Coutances	\N
21967	\N	Newsweek	\N
21968	\N	espace-vert	\N
21969	\N	Desmond Tutu	\N
21970	\N	Deu-Sèvres	\N
21971	\N	Via Kathelong	\N
21972	\N	Lindigo	\N
21973	\N	Saïf al-Islam Kadhafi	\N
21974	\N	Michel Sardou	\N
21975	\N	José Van Dam	\N
21976	\N	Laurent Pelly	\N
21977	\N	Yves Klein	\N
21978	\N	Notube Contest	\N
21979	\N	Bifo	\N
21980	\N	Vallauris	\N
21981	\N	Zineb Sedira	\N
21982	\N	Frédéric Rouvillois	\N
21983	\N	Johnny Cash Project	\N
21984	\N	Johnny Cash	\N
21985	\N	Roberto Saviano	\N
21986	\N	Dominique Blanc	\N
21987	\N	recherche (hors science)	\N
21988	\N	parti polirtique	\N
21989	\N	Raúl Castro	\N
21990	\N	Nacera Belaza	\N
21991	\N	rencontres chorégraphiques de Seine-Saint-Denis	\N
21992	\N	Anita Mathieu	\N
21993	\N	inventaire	\N
21994	\N	Palstikman	\N
21995	\N	Richie Hawtin	\N
21996	\N	Villette Sonique	\N
21997	\N	Iphone	\N
21998	\N	Grenelle	\N
21999	\N	André Orléan	\N
22000	\N	Science et technologie	\N
22001	\N	Robert Pires	\N
22002	\N	Hannelore Kraft	\N
22003	\N	David Douillet	\N
22004	\N	Emmanuelle seigner	\N
22005	\N	Véolia Environnement	\N
22006	\N	ministre des Affaires étrangères	\N
22007	\N	Frédéric Pietruszka	\N
22008	\N	pigiste	\N
22009	\N	Bouygues	\N
22010	\N	Frédéric Thiriez	\N
22011	\N	transport ferrovière	\N
22012	\N	Éducation	\N
22013	\N	Claire Nebout	\N
22014	\N	oupe du monde	\N
22015	\N	Bernard Giraudeau	\N
22016	\N	licence	\N
22017	\N	vean-Marie Le Guen	\N
22018	\N	René Ricol	\N
22019	\N	comptabilité de l'entreprise	\N
22020	\N	disquette	\N
22021	\N	Christophe Honoré	\N
22022	\N	Volley-Ball	\N
22023	\N	DAL	\N
22024	\N	Écologie	\N
22025	\N	Problèmes sociaux	\N
22026	\N	Hervé Maurey	\N
22027	\N	Elena Kagan	\N
22028	\N	Djamel Klouche	\N
22029	\N	libéralisation	\N
22030	\N	Jerusalem	\N
22031	\N	Éric Besson	\N
22032	\N	Intégration sociale	\N
22033	\N	Mahamat-SalehHaroun	\N
22034	\N	foire de Paris	\N
22035	\N	Centre Pompidou de Metz	\N
22036	\N	Alizé Cornet	\N
22037	\N	Benoît Delépin	\N
22038	\N	Mathieu Amalric	\N
22039	\N	Littérature policière	\N
22040	\N	Michael Connelly	\N
22041	\N	Jean-Pierre Dardenne	\N
22042	\N	Luc Dardenne	\N
22043	\N	Prada	\N
22044	\N	gtraitement des déchets	\N
22045	\N	Daniele Luchetti	\N
22046	\N	Stéphane Brizé	\N
22047	\N	Jean-Marie Cavada	\N
19586	\N	Yves Simon	\N
19587	\N	Jack London	\N
19588	\N	IPhone	\N
19592	\N	Christophe Cagnolari	\N
19593	\N	improvisation	\N
19624	\N	Jean-laurent Lastelle	\N
19629	\N	Nathalie Arthaud	\N
19638	\N	i-pillule	\N
19643	\N	RFI	\N
19644	\N	bug	\N
19656	\N	Andre Agassi	\N
19665	\N	travail manuel	\N
19684	\N	Bertrand Lavier	\N
19685	\N	cave	\N
19687	\N	Pierre Haski	\N
22048	\N	Société des rédacteurs du monde	\N
22060	\N	secrétaire général	\N
22070	\N	parti libéral-démocrate	\N
22076	\N	José Manuel  Durão Barroso	\N
22083	\N	Politique sociale	\N
22090	\N	Paris-Saint-Geramin	\N
22095	\N	Sabina Guzzanti	\N
22101	\N	Daniel Buren	\N
22102	\N	alphabet	\N
22107	\N	touriste	\N
22113	\N	Toscan du Plantier	\N
22124	\N	etats-Unis	\N
22129	\N	anonyme	\N
22136	\N	Rebecca Zlotowski	\N
22139	\N	Quentin Dupieux	\N
22147	\N	renseignement	\N
22148	\N	donnée	\N
22149	\N	Saint-Augustin	\N
22157	\N	droit de la femme	\N
22162	\N	Chapour Bakhtiar	\N
22163	\N	Clotilde Reiss	\N
22196	\N	Olivier Messiaen	\N
22236	\N	Médecine	\N
22242	\N	Ligue nationale de rugby	\N
22246	\N	Thierry Desmarest	\N
22275	\N	intellctuel	\N
22279	\N	Apitchapong Weerasathakul	\N
22282	\N	moral	\N
22283	\N	parti républicain	\N
22292	\N	Société Générale	\N
22301	\N	"flash-trading"	\N
22317	\N	défense anti-missile	\N
22318	\N	exercice	\N
22325	\N	Luc Chatel politique de l'éducation	\N
22344	\N	Louis Calaferte	\N
22347	\N	Informatique	\N
22348	\N	Tungstène	\N
22352	\N	croissance	\N
22367	\N	Villefranche-sur-mer	\N
22370	\N	Institut de veille sanitaire	\N
22375	\N	festival affiche	\N
22383	\N	faits divers	\N
22385	\N	Marion Bartoli	\N
22388	\N	Noam Chomsky	\N
22417	\N	Ernest-Antoine Seillière	\N
22421	\N	Assemblée générale	\N
22426	\N	Christiane Lagarde	\N
22447	\N	Agence internationale pour l'énergie atomique (AIEA)	\N
22457	\N	Pierre Creton	\N
22458	\N	Maniquerville	\N
22466	\N	Tribunal pénal international	\N
22468	\N	ancienneté professionnelle	\N
22469	\N	calcul	\N
22496	\N	Guy Montagné	\N
22499	\N	invesstissement étranger	\N
22527	\N	license	\N
22535	\N	Natacha Atlas	\N
22537	\N	décroissance	\N
22546	\N	Eglise catholique	\N
22570	\N	Robin Soderling	\N
22571	\N	Jean-Claude Duvalier	\N
22595	\N	Jean-Claude Volot	\N
22604	\N	Emile Hesquey	\N
22621	\N	Chaumont	\N
22630	\N	Claude Perdriel	\N
22635	\N	Oxu	\N
22636	\N	Super Mario	\N
22641	\N	Philippe Genty	\N
22642	\N	Kremlin	\N
22645	\N	British Petroleum; communication	\N
22646	\N	organe sexuel	\N
22648	\N	Fondation (organisme)	\N
22670	\N	Staline	\N
23165	\N	Rigoberto Pérezcano	\N
23166	\N	Roselyne bachelot	\N
23167	\N	Hamid KarzaÏ	\N
23168	\N	célibataire	\N
23169	\N	sexologie	\N
23171	\N	Direction générale de l'aviation civile	\N
23172	\N	salle de cinéma	\N
23173	\N	commission des affaires sociales	\N
23174	\N	Christopher Nolan	\N
23175	\N	Conseil d'État	\N
23176	\N	Louis Oosthuizen	\N
23177	\N	Golf	\N
23178	\N	Sergey Brin	\N
23179	\N	Joseph Gordon-Levitt	\N
23180	\N	Documentaire	\N
23181	\N	Jean-Michel Bertrand	\N
23182	\N	Partis socialiste	\N
23183	\N	Mario Vargas Llosa	\N
23185	\N	ministère de l'Agriculture	\N
23186	\N	occupation des sols	\N
23187	\N	Jacques Rousselot	\N
23188	\N	Fédération française de foot	\N
23189	\N	moscou	\N
23190	\N	US Open	\N
23191	\N	Château-Thierry	\N
23192	\N	reprise financière	\N
23193	\N	Ferdinand Lop	\N
23195	\N	Vincent Ravalec	\N
23196	\N	Philippe Faure	\N
23198	\N	conseiller général	\N
23200	\N	pentathlon moderne	\N
23201	\N	Benyamin Nétanhayou	\N
23202	\N	système éducatif	\N
23204	\N	Bruno Gaccio	\N
23205	\N	Jean-Claude Camus	\N
23208	\N	Alvaro Gil-Roblès	\N
23209	\N	François Fillion	\N
23210	\N	Jocelyn Benoist	\N
23211	\N	Daniel Wildenstein	\N
23212	\N	Basile Boli	\N
23213	\N	politique de la Santé	\N
23214	\N	centre médical	\N
23215	\N	Médecins du Monde	\N
23216	\N	David Prudhomme	\N
23217	\N	Louis XV	\N
23218	\N	Alvaro Pastor	\N
23219	\N	Antonio Naharro	\N
23220	\N	voyage (exploration)	\N
23221	\N	poison	\N
23222	\N	intrnet	\N
23223	\N	Goodyear	\N
23224	\N	Hewlett Packard	\N
23225	\N	Jean-Michel Baylet	\N
23226	\N	Don DeLillo	\N
23227	\N	William Hague	\N
23228	\N	Jean-Louis Servan-Schreiber	\N
23229	\N	Didier Deschamps	\N
23230	\N	William Klein	\N
23231	\N	travail recrutement	\N
23232	\N	demande	\N
23233	\N	Institut national de recherche pédagogique	\N
23234	\N	Arcueil (Val-de-Marne)	\N
23235	\N	formation continue	\N
23236	\N	Energie renouvelable	\N
23237	\N	Inspection générale des finances (IGF)	\N
23238	\N	Zürich	\N
19590	\N	Blackwater	\N
19591	\N	Caméra café	\N
19606	\N	hokey	\N
19611	\N	The Last Poets	\N
19612	\N	Amérique	\N
19613	\N	Claude Santiago	\N
19615	\N	reine	\N
19616	\N	Elizabeth II	\N
19626	\N	Isadora Duncan	\N
19635	\N	pays basque espagnol	\N
19640	\N	porte-parole	\N
19641	\N	sécurité aérienne	\N
19646	\N	Jean-Louis Bruguière	\N
19657	\N	Shoah	\N
19680	\N	OM	\N
19681	\N	Hatem Ben Arfa	\N
19683	\N	Jean-Jacques Lebel	\N
19688	\N	Jean-Jacques Schuhl	\N
19689	\N	Sherlock Holmes	\N
19690	\N	Radu Mihaileanu	\N
22049	\N	Carlos Diegues	\N
22050	\N	Daniel Cohen	\N
22051	\N	Android	\N
22052	\N	Nuit sonores	\N
22053	\N	The Residents	\N
22054	\N	Nuits sonores	\N
22055	\N	erreur(faute)	\N
22056	\N	Rithy Panh	\N
22057	\N	Gilles Marchand	\N
22058	\N	Nicoas Winding Refn	\N
22059	\N	Robert Guédiguian	\N
22061	\N	Dominique	\N
22062	\N	Strauss-Kahn	\N
22063	\N	journalsime	\N
22064	\N	Russel Crowe	\N
22065	\N	Riad Sattouf	\N
22066	\N	Césaria Evora	\N
22067	\N	Destin de Lisa	\N
22068	\N	Armel Le Cléac'h	\N
22069	\N	Fabien Delahaye	\N
22071	\N	Sidney Govou	\N
22072	\N	sexuallité	\N
22073	\N	Agnès Varda	\N
22074	\N	jean-Luc Mélenchon	\N
22075	\N	Manoel De Oliveira	\N
22077	\N	Daniel Morel	\N
22078	\N	texte	\N
22079	\N	Jean-Claude Carle	\N
22080	\N	Fiscalité locale	\N
22081	\N	Rideley Scott	\N
22082	\N	Benigno Aquino	\N
22084	\N	Baltasar Garzon	\N
22085	\N	cour pénale internationale	\N
22086	\N	Brigitte Roüan	\N
22087	\N	Coupe du monde 2010	\N
22088	\N	Lionnel Luca	\N
22089	\N	Rachid Bouchareb	\N
22091	\N	Thierry Frémaux	\N
22092	\N	pirate	\N
22093	\N	libération(mise en liberté)	\N
22094	\N	Jaafar Panahi	\N
22096	\N	conseil de l'ordre	\N
22097	\N	droit des femmes	\N
22098	\N	Michael Haneke	\N
22099	\N	Martin Suter	\N
22100	\N	Immacolata Vassallo de Lopes	\N
22103	\N	Russell Crowe	\N
22104	\N	Cate Blanchett	\N
22105	\N	Andry Rajoelina	\N
22106	\N	René Clément	\N
22108	\N	Gaël Monfils	\N
22109	\N	Richard Galliano	\N
22110	\N	Michel Leclerc	\N
22111	\N	interdicyion	\N
22112	\N	Nuits botanique	\N
22114	\N	Luc Vigneron	\N
22115	\N	Marco Cristino	\N
22116	\N	Calcio	\N
22117	\N	Conto TV	\N
22118	\N	droit de retransmission	\N
22119	\N	Latium	\N
22120	\N	Mike Leight	\N
22121	\N	Isabelle Poireaudeau	\N
22122	\N	Ela Calvo	\N
22123	\N	Victor Lemoine	\N
22125	\N	Paris-XII	\N
22126	\N	TV Globo	\N
22127	\N	Jean Daniel	\N
22128	\N	Wang Xiaoshuai	\N
22130	\N	Abou dhabi	\N
22131	\N	Emilie-Romagne	\N
22132	\N	Raphaël	\N
22133	\N	Olivier Coussemacq	\N
22134	\N	Géopolitique	\N
22135	\N	Yves Lacoste	\N
22137	\N	Tony Parker	\N
22138	\N	Katell Quillévéré	\N
22140	\N	Oliver Stone	\N
22141	\N	Manoel de Oliveira	\N
22142	\N	Kirgihizistan	\N
22143	\N	Michel Galabru	\N
22144	\N	Kad Merad	\N
22145	\N	Xavier Dolan	\N
22146	\N	Jean- Louis Borloo	\N
22150	\N	Médecins sans frontières	\N
22151	\N	peinture(art)	\N
22152	\N	Guy Matchoro	\N
22153	\N	british Petroléum	\N
22154	\N	réparation	\N
22155	\N	Jean-François Colosimo	\N
22156	\N	Centre national du livre (CNL)	\N
22158	\N	Lolita Chammah	\N
22159	\N	monarchie armée	\N
22160	\N	Georges Courteline	\N
22161	\N	Georges Aperghis	\N
22164	\N	Guy Drut	\N
22165	\N	Luis Inacio Lula da Silva	\N
22166	\N	Robert Linhart	\N
22167	\N	Contrefaçon	\N
22168	\N	Catherine Viot	\N
22169	\N	libération (journal) appel (sollicitation)	\N
22170	\N	Observatoire international des prisons (OIP)	\N
22171	\N	tombe	\N
22172	\N	antiquité	\N
22173	\N	Claire Diterzi	\N
22174	\N	Marcial Di Fonzo Bo	\N
22175	\N	Bertrand Tavernier	\N
22176	\N	Christoph Hochhäussler	\N
22177	\N	New-Hampshire	\N
22178	\N	Sophie Fiennes	\N
22179	\N	Ouest-France	\N
22180	\N	zone	\N
22181	\N	Euro	\N
22182	\N	Pierre Bel	\N
22183	\N	Emission de télévision	\N
22184	\N	Infiltrés	\N
22185	\N	Aulnay-sous-bois	\N
22186	\N	Louis-Georges Tin	\N
22187	\N	Venus Williams	\N
22188	\N	Aravane Rezaï	\N
22189	\N	Jean-Noël Darde	\N
22190	\N	Ramiro Guerra	\N
22191	\N	Véronique Courjault	\N
22192	\N	homicide	\N
22193	\N	Elvis Costello	\N
22194	\N	Peter de Wit	\N
22195	\N	commission de la sécurité des consommateurs	\N
22197	\N	Marc Fitoussi	\N
22198	\N	William Gallas	\N
22199	\N	Paul Verhaegen	\N
22200	\N	Défenseur des droits	\N
22201	\N	Jack Kerouac	\N
22202	\N	fonds spéculatif	\N
22203	\N	Pierre-Henri Gourgeon	\N
22204	\N	Yvan Colonna	\N
22205	\N	centre urbain	\N
22206	\N	Pierre Larrouturou	\N
19603	\N	Chris Anderson	\N
19604	\N	magazine spécialisé	\N
19607	\N	voile islamisque	\N
19617	\N	coupure	\N
19619	\N	medef	\N
19620	\N	Cirque et spectacle de rue	\N
19645	\N	Série télévisée	\N
19661	\N	Outre-mer	\N
19663	\N	Dom-Tom	\N
19667	\N	La poste	\N
22207	\N	Lilly Wood and the Prick	\N
22208	\N	Nili Hadida	\N
22219	\N	Thomas Piketty	\N
22222	\N	Chez Camillou\n10	\N
22223	\N	route du Languedoc	\N
22224	\N	48130 Aumont-Aubrac	\N
22225	\N	tél. : 04 66 42 86 14.\nwww.hotel-camillou.com	\N
22237	\N	service civique	\N
22240	\N	Michel Sapin	\N
22249	\N	Guéret (Creuse)	\N
22255	\N	Sean Penn	\N
22256	\N	Naomi Watts	\N
22284	\N	Bernard THIBAULT	\N
22287	\N	vVadimir Poutine	\N
22290	\N	José-Manuel Barroso	\N
22291	\N	Jean-Louis Masson	\N
22300	\N	François de Grossouvre	\N
22324	\N	dogdating	\N
22326	\N	Pierre Boulez	\N
22335	\N	plan de rigeur	\N
22336	\N	Elena Salgado	\N
22350	\N	Daniel Mermet	\N
22354	\N	François Lamy	\N
22359	\N	volcan Islande	\N
22368	\N	criminologie	\N
22387	\N	Keiichi Tanaami	\N
22391	\N	Benito Mussolini	\N
22409	\N	surdité	\N
22427	\N	notation	\N
22428	\N	Easy rider	\N
22429	\N	Etat- Unis	\N
22439	\N	Rineke Dijkstra	\N
22448	\N	Plan B	\N
22449	\N	Ben Drew	\N
22450	\N	Mayer Hawthorne	\N
22451	\N	Merriweather	\N
22473	\N	Radio Réunion	\N
22474	\N	Télé Réunion	\N
22485	\N	théorie	\N
22492	\N	politique pénitentière	\N
22493	\N	Bernard Marie Koltès	\N
22494	\N	Combat de nègre et de chiens	\N
22495	\N	Malcolm Lowry	\N
22497	\N	Robert Zollitsch	\N
22498	\N	Ilan Greilsammer	\N
22500	\N	vêtements	\N
22504	\N	Thabo Mbeki	\N
22509	\N	mode d'emploi	\N
22514	\N	Pierre-André de Chalendar	\N
22515	\N	Jean-Louis Beffa	\N
22517	\N	Jacques Davila	\N
22540	\N	semaine de quatre jours	\N
22550	\N	Michael Jackson (chanteur)	\N
22557	\N	AC/DC	\N
22565	\N	René Féret	\N
22568	\N	Etats Généraux	\N
22580	\N	Harvard	\N
22582	\N	lyon	\N
22586	\N	îles Canaries	\N
22592	\N	Robert Fico	\N
22596	\N	le Parisien	\N
22597	\N	la Tribune	\N
22606	\N	Luc Ferry	\N
22643	\N	24 heures du Mans	\N
22657	\N	le Progrès	\N
22671	\N	Brigitte Sy	\N
23239	\N	aménagement urbain	\N
23244	\N	Tom Hanks	\N
23248	\N	Education Nationale	\N
23267	\N	Chucho Valdés	\N
23279	\N	Benjamin Nétanyahou	\N
23282	\N	jogging	\N
23289	\N	Warren Ellis	\N
23296	\N	Politique fiscale	\N
23337	\N	Jean-Baptiste Harang	\N
23344	\N	spéculation boursière	\N
23353	\N	océan arctique	\N
23360	\N	Cnuced	\N
23364	\N	Alexeï Guerman	\N
23382	\N	Walter Veltroni	\N
23397	\N	Commission Européenne	\N
23404	\N	José Mourinho	\N
23407	\N	Vieux-Boucau (Landes)	\N
23415	\N	Freddie Mercury	\N
23418	\N	tribunal de grande Instance	\N
23419	\N	son et lumière	\N
23442	\N	Cecilia Bartoli	\N
23461	\N	Jean-Marcel Jeanneney	\N
23462	\N	Jean-Marc Ayrault	\N
23464	\N	primaire élctorale	\N
23473	\N	politique des tranports	\N
23481	\N	Sam Rainsy	\N
23482	\N	Travail emploi chômage	\N
23713	\N	Lehman Brothers	\N
23714	\N	Syndicat du Livre CGT	\N
23715	\N	parité	\N
23716	\N	Stains (Seine-Saint-Denis)	\N
23717	\N	Neige	\N
23718	\N	collectivité locales	\N
23719	\N	qualité de l'eau	\N
23721	\N	Ideye Brown	\N
23722	\N	longévité	\N
23724	\N	Miriam Makeba	\N
23725	\N	futur	\N
23727	\N	Massoud Barzani	\N
23728	\N	Les Etats-Unis	\N
23729	\N	Parti démocratique	\N
23730	\N	Pristina	\N
23732	\N	Rnaud Lagardère	\N
23734	\N	Christine Okrent	\N
23735	\N	arresstation	\N
23736	\N	tours	\N
23737	\N	convention nationale	\N
23738	\N	Michael Powell	\N
23739	\N	Camilla Parker Bowles	\N
23740	\N	cour d'assises spéciale	\N
23742	\N	Francis Veber	\N
23743	\N	Erwin Olaf	\N
23744	\N	kiosque	\N
23745	\N	Art graphique	\N
23746	\N	pontoise	\N
23747	\N	candidature élection présidentielle	\N
23748	\N	Nada Strancar	\N
23749	\N	Hashim Thaçi	\N
23750	\N	Ligue de football professionnel (LFP)	\N
23751	\N	Christiane Taubira	\N
23752	\N	Marie-Anne Montchamp	\N
23753	\N	Dominique Bagouet	\N
23754	\N	Claude Régy	\N
23755	\N	Otto Dix	\N
23757	\N	Enrique Morente	\N
23758	\N	Augusto Pinochet	\N
23759	\N	haut-fonctionnaire	\N
23760	\N	Nicole Garcia	\N
23761	\N	Moriarty	\N
23762	\N	vie lprivée	\N
23763	\N	validation (adoption)	\N
23764	\N	Eran Riklis	\N
23765	\N	Alain Afflelou	\N
23766	\N	la Défense	\N
23767	\N	Prisma	\N
23768	\N	sociologie \npolitique	\N
23769	\N	Michel Denisot	\N
23770	\N	Jacques Tati	\N
23771	\N	Paul Veyne	\N
23772	\N	Jacques Demy	\N
23773	\N	Larry King	\N
23774	\N	Kénya	\N
19605	\N	cité internationale	\N
19625	\N	Jean Lassalle	\N
19639	\N	mercure	\N
19642	\N	Claude Puel	\N
19652	\N	Tata	\N
19653	\N	prêt	\N
19654	\N	centrale hydroélectrique	\N
19655	\N	Pimkie	\N
19658	\N	Christoph Waltz	\N
19659	\N	David Cronenberg	\N
19660	\N	The Talking Cure	\N
19662	\N	Sigmund Freud	\N
19666	\N	Lucy Gayheart	\N
19668	\N	lancement stratégie de l'entreprise	\N
19669	\N	rafale	\N
19670	\N	aviation militiare	\N
19674	\N	Xavier Darcos	\N
19677	\N	Marie Muller	\N
19679	\N	Warren Beatty	\N
19682	\N	José Luis Zapatero	\N
19686	\N	Jean-Charles Fitoussi	\N
19691	\N	Caterpillar	\N
19692	\N	parking	\N
19693	\N	réglement	\N
19694	\N	revue spécialisée	\N
19695	\N	voeu 2010	\N
19696	\N	voeu	\N
19697	\N	medecin	\N
19698	\N	Elton John	\N
19699	\N	comparaison	\N
19700	\N	peinture	\N
19701	\N	Al-qaeda	\N
19702	\N	Raphaël Poirée	\N
19703	\N	Oussama ben Laden	\N
19704	\N	Abdoulaye Wade	\N
19705	\N	jour de l'an	\N
19706	\N	Nouveau parti anticapitaliste	\N
19707	\N	musée d'Orsay	\N
19708	\N	Degas	\N
19709	\N	avocat général	\N
19710	\N	Laurent Le Mesle	\N
19711	\N	jnouvel an	\N
19712	\N	SUD	\N
19713	\N	monoxyde de carbone	\N
19714	\N	travail au noir	\N
19715	\N	Robin Söderling	\N
19716	\N	Tiger Wood	\N
19717	\N	Cristiano Ronaldo	\N
19718	\N	Portsmouth	\N
19719	\N	Jean Laplanche	\N
19720	\N	pays en développement	\N
19721	\N	Gilles Peterson	\N
19722	\N	Robert Wise	\N
19723	\N	Antoine de Saint-Exupéry	\N
19724	\N	Jacques Henri Lartigue	\N
19725	\N	XVe siècle	\N
19726	\N	Miles Davis	\N
19727	\N	République Centrafricaine	\N
19728	\N	coopération	\N
19729	\N	Valéry Giscard d'Estaing	\N
19730	\N	François Bourgeon	\N
19731	\N	Ump	\N
19732	\N	Libération (mise en liberté)	\N
19733	\N	diminution	\N
19734	\N	acessoire	\N
19735	\N	Compact disc	\N
19736	\N	monnaire	\N
19737	\N	téléphone portable	\N
19738	\N	innovation téchnologie	\N
19739	\N	crise fonancière	\N
19740	\N	bousre	\N
19741	\N	escroqueire	\N
19742	\N	Zinedine Zidane	\N
19743	\N	Britney Spears	\N
19744	\N	Kate Moss	\N
19745	\N	téléréalité	\N
19746	\N	pérsonnalité politique	\N
19747	\N	date	\N
19748	\N	adaptation	\N
19749	\N	J.K. Rowling	\N
19750	\N	résultat électoral	\N
19751	\N	diversité	\N
19752	\N	rétropsective	\N
19753	\N	RTT	\N
19754	\N	collectif	\N
19755	\N	mal	\N
19756	\N	logé	\N
19757	\N	mot	\N
19758	\N	Chistian Estrosi	\N
19759	\N	Paul Giacobbi	\N
19760	\N	PRG	\N
19761	\N	Charlotte de Turckheim	\N
19762	\N	lutte antiterrorisme Brice Hortefeux	\N
19763	\N	Création	\N
19764	\N	Bilan	\N
19765	\N	mur	\N
19766	\N	assignation à résidence  Mauritanie	\N
19767	\N	politique fiscal	\N
19768	\N	Belleville	\N
19769	\N	lieu (site)	\N
19770	\N	Nicolae Ceausescu	\N
19771	\N	Finance et fiscalité	\N
19772	\N	Jan Kounen	\N
19773	\N	Igor Stravinsky	\N
19774	\N	Sébastien Lifshitz	\N
19775	\N	moine	\N
19776	\N	Elias Canetti	\N
19777	\N	Yan Lianke	\N
19778	\N	Saint Jean	\N
19779	\N	Ali Khamenei	\N
19780	\N	sans domicile fixe	\N
19781	\N	jérusalem	\N
19782	\N	Barack obama	\N
19783	\N	stratégie poliltique	\N
19784	\N	facebook	\N
19785	\N	Gentilly (Hauts-de-Seine)	\N
19786	\N	immatriculation	\N
19787	\N	approvisionnement	\N
19788	\N	livraison	\N
19789	\N	Europe de l'Est	\N
19790	\N	Roland Emmerich	\N
19791	\N	espace	\N
19792	\N	Emirats Arabes Unis	\N
19793	\N	EPR	\N
19794	\N	faux-témoignage	\N
19795	\N	Youtube	\N
19796	\N	James Ensor	\N
19797	\N	Bernard Lacombe	\N
19798	\N	Marc Guillemot	\N
19799	\N	Roissy	\N
19800	\N	Yemen	\N
19801	\N	Etienne Tête	\N
19802	\N	mahmoud Ahmadinejad	\N
19803	\N	égalité professionnelle	\N
19804	\N	Jim Jarmusch	\N
19805	\N	Viggo Mortensen	\N
23242	\N	VTT	\N
19807	\N	William Burroughs	\N
19808	\N	Jeffrey Lee Pierce	\N
19809	\N	Samuel Fuller	\N
19810	\N	Joe Stummer	\N
19811	\N	Nicholas Ray	\N
19812	\N	Neil Young	\N
19813	\N	Pascale Ogier	\N
19814	\N	Jean-Jacques Zilbermann	\N
19815	\N	Antoine de Caunes	\N
19816	\N	John Hillcoat	\N
19817	\N	bilan carbone	\N
19818	\N	Marc Scialom	\N
19819	\N	Robert Kenner	\N
19820	\N	Flavie Flament	\N
19821	\N	Eric Bana	\N
19822	\N	Tim Robbins	\N
19823	\N	film fantastique	\N
19824	\N	Oren Peli	\N
19825	\N	renfort	\N
19826	\N	messagerie	\N
19827	\N	Yannick Jadot	\N
19828	\N	Anwar Ibrahim	\N
19829	\N	Axelle Ropert	\N
19830	\N	Jonathan Littell	\N
19831	\N	rachat	\N
19832	\N	propriété	\N
19839	\N	Eric Faye	\N
19833	\N	confiscation	\N
19838	\N	FIPN	\N
19849	\N	déforestation	\N
19858	\N	Ined	\N
19878	\N	Gauche	\N
19883	\N	Caraïbes	\N
19901	\N	droit humanitaire	\N
19913	\N	symbole	\N
19914	\N	Rio	\N
19916	\N	Robert Gates	\N
19918	\N	Samuel Maréchal	\N
19928	\N	actualité	\N
19930	\N	Merce Cunningham	\N
19935	\N	Conférence	\N
19936	\N	Gilad Shalit	\N
19937	\N	visite médicale	\N
19942	\N	Yves Bigot	\N
19947	\N	Nicoals Sarkozy	\N
19948	\N	Bruce Springsteen	\N
19949	\N	Traian Basescu	\N
19950	\N	présient	\N
19955	\N	phrase	\N
19956	\N	corrèze	\N
19957	\N	sncf	\N
19958	\N	luute (action contre)	\N
19964	\N	Loïc Le Meur	\N
22209	\N	Otar Iosseliani	\N
22210	\N	Human Rights Watch	\N
22211	\N	Bagram	\N
22212	\N	Détroit	\N
22213	\N	initiative	\N
22214	\N	dcélébrité	\N
22215	\N	Grégoire Leprince-Ringuet	\N
22216	\N	Michelle Williams	\N
22217	\N	Alain Goldman	\N
22218	\N	Cynthia?Fleury	\N
22220	\N	Hervé Gaymard	\N
22221	\N	jean-pierre Raffarin	\N
22226	\N	Apichatpong Weerasethakul	\N
22227	\N	alimentation pauvreté	\N
22228	\N	Ivan Sierra Montoya	\N
22229	\N	invention	\N
22230	\N	Audiovisuel	\N
22231	\N	Philippe Santini	\N
22232	\N	gestion des ressources humaine	\N
22233	\N	gestion de l'entreprise	\N
22234	\N	festival de Cannes	\N
22235	\N	Rachid Bouchared	\N
22238	\N	Alberta	\N
22239	\N	Eriel Deranger	\N
22241	\N	coutier	\N
22243	\N	pédiatre	\N
22244	\N	Sébastien Grosjean	\N
22245	\N	musée d'Art moderne	\N
22247	\N	Fabrice Gobert	\N
22248	\N	Carte Musique jeunes	\N
22250	\N	Simon Hantaï	\N
22251	\N	Paul Dubrule	\N
22252	\N	Duval	\N
22253	\N	Romain Zaleski	\N
22254	\N	conflit d'interêts	\N
22257	\N	pays basque	\N
22258	\N	réduction de poste	\N
22259	\N	Bayonne (Pyrénées-Atlantiques)	\N
22260	\N	Mick Jagger	\N
22261	\N	Jean-Frédéric Poisson	\N
22262	\N	comptage	\N
22263	\N	Pervez Musharraf	\N
22264	\N	Salvador Dali	\N
22265	\N	Marcel Duchamp	\N
22266	\N	La Tribune	\N
22267	\N	Alain Weil	\N
22268	\N	Valérie Décamp	\N
22269	\N	microbe	\N
22270	\N	Claude Durand	\N
22271	\N	visite (déplacement)	\N
22272	\N	Marcela Iacub	\N
22273	\N	Yann Queffélec	\N
22274	\N	Tramway	\N
22276	\N	centrele nucléaire	\N
22277	\N	François Dubet	\N
22278	\N	BP	\N
22280	\N	europdéputé	\N
22281	\N	Parlement français	\N
22285	\N	Nathalie Artaud	\N
22286	\N	Guy Dessut	\N
22288	\N	Fabienne Berthaud	\N
22289	\N	Villiers-sur-Marne	\N
22293	\N	Bien de consommation	\N
22294	\N	Christiona Lacroix	\N
22295	\N	tauraumachie	\N
22296	\N	Museum national d'histoire naturelle	\N
22297	\N	États Généraux	\N
22298	\N	British Pétroleum	\N
22299	\N	Jean Aurel Maurice	\N
22302	\N	Black et Decker	\N
22303	\N	"24 heures chrono"	\N
22304	\N	Tignes	\N
22305	\N	régions	\N
22306	\N	Verone	\N
22307	\N	Gérard Touati	\N
22308	\N	allocations familiales	\N
22309	\N	Paul-Henri Mathieu	\N
22310	\N	Pierre Nora	\N
22311	\N	Jean Tigana	\N
22312	\N	Etats	\N
22313	\N	-unis	\N
22314	\N	Minoo Moallem	\N
22315	\N	parité homme-femme	\N
22316	\N	utte (action contre)	\N
22319	\N	s du Bureau international du travail (BIT)	\N
22320	\N	Marie-Pierre Martinet	\N
22321	\N	André Vallin	\N
22322	\N	Emmanuelle Bayamack-Tam	\N
22323	\N	Etats- Unis	\N
22327	\N	Vuitton	\N
22328	\N	Paul Virillo	\N
22329	\N	flash trading	\N
22330	\N	Médiateur de la République	\N
22331	\N	Commission (organisme)	\N
22332	\N	défenseur des droits	\N
22333	\N	Radio numérique	\N
22334	\N	syndicat national des radios libres	\N
22337	\N	finances	\N
22338	\N	Edvard Munch	\N
22339	\N	fonds	\N
22340	\N	commun	\N
22341	\N	arsenal	\N
22342	\N	discours	\N
22343	\N	métaphysique	\N
22345	\N	Monica Bellucci	\N
22346	\N	Pierre Dukan	\N
22349	\N	Rio-Paris	\N
22351	\N	George Osborne	\N
22353	\N	Disney compagnie	\N
22355	\N	Henri Emmanuelli	\N
22356	\N	Jean Peyrelevade	\N
22357	\N	Matthias Fekl	\N
22358	\N	Michel Husson	\N
22360	\N	émission	\N
22361	\N	Vert-le- Petit	\N
22362	\N	prêt à porter	\N
22363	\N	mode sur mesure	\N
22364	\N	Anne Golon	\N
22365	\N	Tito	\N
22366	\N	fève	\N
22369	\N	Everest	\N
22371	\N	Mathieu Gallet	\N
22372	\N	Eric Worth	\N
22373	\N	droit des salariés	\N
22374	\N	Foxconn Technology	\N
22376	\N	Giulio Tremonti	\N
22377	\N	Inge Morath	\N
22378	\N	José Luis Rodríguez Zapatero	\N
22379	\N	Mortlach	\N
22380	\N	distillerie	\N
22381	\N	catégorie socio-professionnelle	\N
22382	\N	Marie-Dominique Arrighi	\N
22384	\N	chEf de l'état	\N
22386	\N	Esther Benbassa	\N
19834	\N	centre des monuments nationaux	\N
19845	\N	Baudouin Prot	\N
19846	\N	Nicolas Grimaldi	\N
19851	\N	La Marseillaise	\N
19852	\N	sanction	\N
19871	\N	Charles Baudelaire	\N
19881	\N	Tariq Ramadan	\N
19885	\N	parti Socialiste	\N
19902	\N	Montauban (Tarn-et-Garonne)	\N
19932	\N	Gabriel Garcia Marquez	\N
19933	\N	Gérald Martin	\N
19946	\N	handicap	\N
22389	\N	estimation	\N
22416	\N	Ernest-Antoine Seillière	\N
22422	\N	Assemblée générale	\N
22433	\N	vieillesse	\N
22454	\N	gaza	\N
22464	\N	Disparition	\N
22465	\N	Andreï Voznessenski	\N
22501	\N	African Broadcasting Corporation	\N
22508	\N	colocation	\N
22511	\N	écrivains	\N
22512	\N	Andrée Brink	\N
22513	\N	J.M. Coetzee	\N
22516	\N	la Poste	\N
22520	\N	équipe de sport	\N
22522	\N	ségrégation	\N
22524	\N	Nikolaï Maslov	\N
22534	\N	Dov Zerah	\N
22536	\N	Paul Anka	\N
22538	\N	brice hortefeux	\N
22547	\N	formation professionnel	\N
22563	\N	Tayyip Erdogan	\N
22584	\N	majorité présidentielle	\N
22591	\N	The Doors	\N
22610	\N	identité	\N
22612	\N	Crise économique	\N
22619	\N	Cherbourg (Manche)	\N
22638	\N	génome humain	\N
22640	\N	Charenton	\N
22651	\N	Sigmar Polke	\N
22654	\N	Bart de Wever	\N
22656	\N	Baby-boomers	\N
22658	\N	Ulysse	\N
22666	\N	Electronic Entertainment Expo	\N
22667	\N	évènement	\N
22672	\N	Geoffrey Chaucer	\N
23240	\N	Stéphanie Hochet	\N
23241	\N	Jean-Marie  Le Pen	\N
23243	\N	mouvement social	\N
23245	\N	Julia Fischer	\N
23246	\N	Charlie Bauer	\N
23247	\N	Jacques Mesrine	\N
23249	\N	carte d'identité	\N
23250	\N	Flushing Meadows	\N
23251	\N	lutte	\N
23252	\N	légion d'honneur	\N
23253	\N	Patrick de Maistre	\N
23254	\N	Liliane Bettencourt.	\N
23255	\N	Mouvement républicain et citoyen (MRC)	\N
23256	\N	Nicolalas sarkozy	\N
23257	\N	nomade tzigane	\N
23258	\N	amende	\N
23259	\N	Michael Lonsdale	\N
23260	\N	Terry Gilliam	\N
23261	\N	nomadee	\N
23262	\N	maladie cardiaque	\N
23263	\N	Minitel	\N
23265	\N	Satyajit Ray	\N
23266	\N	Alexandre Aja	\N
23268	\N	espoir	\N
23269	\N	François Pinault	\N
23270	\N	Bucrest	\N
23271	\N	Kanye West	\N
23272	\N	Taylor Swift	\N
23273	\N	Dexia	\N
23274	\N	cotation boursière	\N
23275	\N	Gianfranco Fini	\N
23276	\N	Gilles Brücker	\N
23277	\N	les Echos	\N
23278	\N	Val de Marne	\N
23280	\N	Saint-Germain-des-Prés	\N
23281	\N	Vincent Gallo	\N
23283	\N	Ivan Illich	\N
23284	\N	assistance juridique	\N
23285	\N	Antoine Volodine	\N
23286	\N	Raymond Carver	\N
23287	\N	sécurité sociale	\N
23288	\N	Mireille Mathieu	\N
23290	\N	Teddy Rider	\N
23291	\N	Nicolas Beytout	\N
23292	\N	Laurent Wauquiez déclaration	\N
23293	\N	Tziganes	\N
23294	\N	Gilles Brucker	\N
23295	\N	Parti communiste chinois	\N
23297	\N	Rafael de Paula	\N
23299	\N	Centre d'affaires	\N
23300	\N	Afghanistan otage	\N
23301	\N	Tweeter	\N
23302	\N	André Chassaigne	\N
23303	\N	André Vingt-Trois	\N
23304	\N	L'humanité	\N
23305	\N	Tatiana de Rosnay	\N
23306	\N	alternace politique	\N
23307	\N	desaccord	\N
23308	\N	réfome	\N
23310	\N	Nicoale Ceaucescu	\N
23311	\N	Clément Poitrenaud	\N
23312	\N	Nina Simone	\N
23313	\N	Abdellatif Kechiche	\N
23316	\N	hold-up	\N
23317	\N	Mururoa	\N
23318	\N	Frédérique Jossinet	\N
23319	\N	the New York Times	\N
23320	\N	Etats Unis	\N
23321	\N	chargé de mission	\N
23323	\N	Black Panthers	\N
23324	\N	Paul Morrissey	\N
23325	\N	Frida Kahlo	\N
23326	\N	Rodrigo Garcia	\N
23327	\N	François Chéreque	\N
23328	\N	Olivier Maurel	\N
23331	\N	puberté	\N
23333	\N	Kim Clijsters	\N
23334	\N	Cahiers du cinéma	\N
23335	\N	gymnase	\N
23336	\N	Pierre laurent	\N
23338	\N	Camille Lacourt	\N
23339	\N	matières premières	\N
23340	\N	grahique	\N
23341	\N	parc d'attractions	\N
23342	\N	déficit publique	\N
23343	\N	randonnée	\N
23345	\N	alternative politique	\N
23346	\N	Philippe Collin	\N
23347	\N	Pierre Boulat	\N
23348	\N	Alain Della Negra	\N
23349	\N	Romain Gavras	\N
23350	\N	Floria Sigismondi	\N
23351	\N	réedition	\N
23352	\N	Paolo Sorrentino	\N
23354	\N	Blaise Pascal	\N
23355	\N	efficacité	\N
23356	\N	contagion	\N
23358	\N	politique de l'Immigration	\N
23359	\N	classe d'âge	\N
23361	\N	intérêt d'emprunt	\N
23362	\N	front de gauche	\N
23363	\N	carrière	\N
23365	\N	Cour de justice européenne	\N
23366	\N	le Canard enchaîné	\N
23367	\N	presse magazine	\N
23368	\N	Bernard Zekri	\N
23369	\N	les Inrockuptibles	\N
23370	\N	Patrick Lapeyre	\N
23371	\N	Jean Baudrillard	\N
23372	\N	Jean d'Ormesson	\N
23373	\N	Julian Schnabel	\N
23374	\N	Pierre Vimont	\N
24031	\N	PAF	\N
19835	\N	transmusicales	\N
19836	\N	Slow Joe	\N
19837	\N	Cédric de la Chapelle	\N
19843	\N	offre d'achat	\N
19853	\N	Guerres	\N
19854	\N	Farc	\N
19865	\N	Christine Albanel	\N
19867	\N	île de Sercq	\N
19868	\N	conjoncture	\N
19869	\N	indemnité	\N
19873	\N	Gendarmerie	\N
19874	\N	suspect vol (cambriolage)	\N
19879	\N	Peshawar	\N
19880	\N	ministère (gouvernement )	\N
19892	\N	prix (récompense)	\N
19893	\N	journalmisme	\N
19894	\N	Amira Hass	\N
19897	\N	Amélie Mauresmo	\N
19900	\N	Etats -Unis	\N
19905	\N	Julien Clerc	\N
19920	\N	Jean-Luc Lagarce	\N
19921	\N	François Berreur	\N
19938	\N	Election Régionale	\N
19952	\N	Kyoto	\N
19963	\N	magnifestation	\N
22390	\N	éspèrance de vie	\N
22392	\N	Primavera Sound	\N
22393	\N	Ganglians	\N
22394	\N	pop music	\N
22395	\N	appareil	\N
22396	\N	Ministre	\N
22397	\N	Eats-Unis	\N
22398	\N	Daniel Johnston	\N
22399	\N	transports ferroviaire	\N
22400	\N	la Bible	\N
22401	\N	Lech  Kaczynski	\N
22402	\N	capitalisation financière	\N
22403	\N	Crédit municipal de Paris (CMP)	\N
22404	\N	fra	\N
22405	\N	çais à l'étranger	\N
22406	\N	Jean-Yves Thibaudet	\N
22407	\N	festival cannes	\N
22408	\N	René Dosière	\N
22410	\N	Régis Debray	\N
22411	\N	Alain Weill	\N
22412	\N	journalistes	\N
22413	\N	Ernest-Antoine Seillière	\N
22414	\N	Ernest-Antoine Seillière	\N
22415	\N	Ernest-Antoine Seillière	\N
22418	\N	Assemblée générale	\N
22419	\N	Sophie Boegner	\N
22420	\N	Assemblée générale	\N
22423	\N	opération militaire	\N
22424	\N	Seconde Guerre mondiale	\N
22425	\N	Cap 21	\N
22430	\N	Bel-Air	\N
22431	\N	Al-Jezira	\N
22432	\N	Anton Tchekhov	\N
22434	\N	traversée	\N
22435	\N	liberté publique	\N
22436	\N	Droits de l'enfant	\N
22437	\N	Vincent Elbaz	\N
22438	\N	opération	\N
22440	\N	tourisme (voyage)	\N
22441	\N	Juan Manuel Santos	\N
22442	\N	Dimitri Dimitriadis	\N
22443	\N	Odéon	\N
22444	\N	Alexander Calder	\N
22445	\N	Arts plastique	\N
22446	\N	UFC-Que choisir	\N
22452	\N	Walt Disney	\N
22453	\N	Nicolas Demorrand	\N
22455	\N	Sebastian Cordero	\N
22456	\N	Rabia	\N
22459	\N	ouverture politique	\N
22460	\N	Frédérick Bousquet	\N
22461	\N	champion	\N
22462	\N	indice économique	\N
22463	\N	Trianon de Romainville	\N
22467	\N	Erasmus	\N
22470	\N	Pierre Méhaignerie	\N
22471	\N	Aix-en-provence	\N
22472	\N	numérique	\N
22475	\N	Ile de La Réunion	\N
22476	\N	Bernard Venet	\N
22477	\N	Téléphone mobile	\N
22478	\N	France télévisions	\N
22479	\N	Média	\N
22480	\N	Martine	\N
22481	\N	Aubry	\N
22482	\N	Benoni	\N
22483	\N	Nibs van der Spuy	\N
22484	\N	modification (changement)	\N
22486	\N	Stellenbosch	\N
22487	\N	Ntsiki Biyela	\N
22488	\N	Maurice Barrès	\N
22489	\N	impressionisme	\N
22490	\N	festival Normandie impressioniste	\N
22491	\N	qi gong	\N
22502	\N	trafic de droque	\N
22503	\N	reccord	\N
22505	\N	Jean-Marie-Messier	\N
22506	\N	Francesca Schiavone	\N
22507	\N	câble électrique	\N
22510	\N	Tumi and the volume	\N
22518	\N	Bagnols-sur-Cèze	\N
22519	\N	Johan Greef	\N
22521	\N	bouteille	\N
22523	\N	pénibilité	\N
22525	\N	Dominique Versini	\N
22526	\N	Stéphane Cohen	\N
22528	\N	Fed	\N
22529	\N	Didier Drogba	\N
22530	\N	Melun (Seine-et-Marne)	\N
22531	\N	collége	\N
22532	\N	incendie volontaire	\N
22533	\N	Bosch	\N
22539	\N	Pollution marine	\N
22541	\N	Jacques  Dupuydauby	\N
22542	\N	Ali Bongo	\N
22543	\N	Omar Bongo	\N
22544	\N	chapelle	\N
22545	\N	conjoncture internationale	\N
22548	\N	Brad Pitt	\N
22549	\N	programme télévisé	\N
22551	\N	société des rédacteurs	\N
22552	\N	champoin	\N
22553	\N	Abu Dhabi	\N
22554	\N	Joujouka	\N
22555	\N	Les Eurockéennes	\N
22556	\N	droit du  malade	\N
22558	\N	handicapé physique	\N
22559	\N	France Télévision	\N
22560	\N	Guillermo del Toro	\N
22561	\N	Samantha Stosur	\N
22562	\N	conditions de travail droit du travail	\N
22564	\N	Jean-Marc Sylvestre	\N
22566	\N	guérison	\N
22567	\N	réponse	\N
22569	\N	Dennis Cooper	\N
22572	\N	Libération	\N
22573	\N	Niko de La Faye	\N
22574	\N	Romain Goupil	\N
22575	\N	Valeria Bruni-Tedeschi	\N
22576	\N	Avantage	\N
22577	\N	Gena Rowlands	\N
22578	\N	John Cassavetes	\N
22579	\N	Mamoru Hosoda	\N
22581	\N	patient	\N
22583	\N	Zaha Hadid	\N
22585	\N	coupe du monde 2010	\N
22587	\N	Vincent Ostria	\N
22588	\N	Shenzen	\N
22589	\N	Foxconn	\N
22590	\N	Erik Orsenna	\N
22593	\N	Georges Fotinos	\N
22594	\N	société générale	\N
22598	\N	Oskar Schindler	\N
22599	\N	Jean-François Peyret	\N
22600	\N	ballon	\N
22601	\N	Jabulani	\N
19840	\N	Dusan Batakovic	\N
19841	\N	Manifestation	\N
19842	\N	Act Up	\N
19844	\N	Affaires	\N
19855	\N	singe	\N
19860	\N	mine antipersonnelle	\N
19861	\N	Jean Tinguely	\N
19862	\N	Robert Rauschenberg	\N
19866	\N	abonnemenet	\N
19888	\N	Jairam Ramesh	\N
19889	\N	réduction	\N
19903	\N	Bernard de la Villardière	\N
19906	\N	Martin Bouygues	\N
19907	\N	opérateur	\N
19908	\N	Orange	\N
19909	\N	Bouygues télécom	\N
19910	\N	free	\N
19911	\N	BD	\N
19912	\N	Placid	\N
19917	\N	décor	\N
19919	\N	chat	\N
19929	\N	raz de marée	\N
19934	\N	Le Louvre	\N
19943	\N	NPA (exLCR)	\N
22602	\N	retaite	\N
22603	\N	cour d' assises	\N
22614	\N	gingembre	\N
22639	\N	comprtement	\N
22647	\N	Henri Cuq	\N
22663	\N	principe de précaution	\N
23264	\N	élection parlementaire	\N
23298	\N	Louis Giscard d'Estaing	\N
23309	\N	Amérique centrale	\N
23314	\N	Côte-d'Azur	\N
23315	\N	David Bowie	\N
23322	\N	Mohamed Sifaoui	\N
23329	\N	Haute Cour de justice	\N
23330	\N	controle	\N
23332	\N	Takashi Murakami	\N
23357	\N	Claude Arnaud	\N
23375	\N	Albert Jacquard	\N
23380	\N	Frédéric Péchenard	\N
23384	\N	Recep Tayyip Eerdogan	\N
23386	\N	Patrick Weil	\N
23389	\N	surpression de poste	\N
23390	\N	vidéo-clip	\N
23393	\N	sous-traitante	\N
23395	\N	Krystian Lupa	\N
23396	\N	Andy Warhol	\N
23398	\N	Renaud Van Ruymbeke	\N
23401	\N	Larry Clark	\N
23402	\N	Cher	\N
23405	\N	volley	\N
23412	\N	Jean-Pierre Mignard	\N
23423	\N	Nation	\N
23424	\N	Guy Forget	\N
23429	\N	Serge Daney	\N
23430	\N	crtique	\N
23431	\N	Nicolas Bouchaud	\N
23432	\N	eau potable	\N
23433	\N	esclavagisme	\N
23434	\N	Yoplait	\N
23435	\N	Häagen-Dazs	\N
23436	\N	Alexander McQueen	\N
23444	\N	Khaled	\N
23446	\N	Sophie Davant	\N
23450	\N	remaniement ministeriel	\N
23451	\N	Jon Hamm	\N
23452	\N	Chace Crawford	\N
23454	\N	Mathias Enard	\N
23457	\N	Hôpital	\N
23459	\N	satire	\N
23465	\N	organe	\N
23467	\N	Conseil d'état	\N
23468	\N	Serge Dasault	\N
23469	\N	erreur( faute)	\N
23470	\N	Dalil Boubakeur	\N
23471	\N	poltique économique	\N
23472	\N	Léonard Cohen	\N
23477	\N	entraîneur sportif	\N
23480	\N	politique extérieure	\N
23485	\N	penture (art)	\N
23488	\N	Tiken Jah Fakoly	\N
23491	\N	Crédit d'impôt	\N
23493	\N	Jimmy Carter	\N
23502	\N	Astaffort	\N
23503	\N	Francis Cabrel	\N
23506	\N	David Assoulin	\N
23508	\N	Coco Sumner	\N
23510	\N	Samy Naceri	\N
23511	\N	Roschdy Zem	\N
23523	\N	Umberto Bossi	\N
23524	\N	Joesley Batista	\N
23526	\N	Rahm Emanuel	\N
23530	\N	Sophia Aram	\N
23539	\N	extrême droite en Suède	\N
23546	\N	Union europenne	\N
23551	\N	projet de  loi	\N
23555	\N	Lacoste	\N
23556	\N	RAF	\N
23561	\N	Amadou Toumani Touré	\N
23563	\N	Valérie Plame	\N
23564	\N	George Bush	\N
23567	\N	Conflit d'intérêts	\N
23572	\N	Ludivine Sagnier	\N
23573	\N	Georges Charpak	\N
23575	\N	réservation	\N
23577	\N	Cancún	\N
23580	\N	politique de l'Education	\N
23726	\N	petite et moyenne entreprise	\N
23733	\N	Mouvement démocrate (Modem)	\N
23741	\N	Préfet	\N
23756	\N	Maria Callas	\N
23775	\N	poupée	\N
23776	\N	Guillaume Soro	\N
23780	\N	prière	\N
23781	\N	Syndicat général du livre et de la communication (SGLCE)	\N
23794	\N	ciel	\N
23795	\N	Direction centrale du renseignement intérieur	\N
23806	\N	la Pléiade	\N
23807	\N	Jacques Schiffrin	\N
23821	\N	modernité	\N
23832	\N	manège	\N
23837	\N	super-G	\N
23846	\N	Mike Leigh	\N
23850	\N	Angelina Jolie	\N
23856	\N	Christopher Browning	\N
23857	\N	Charlie Chaplin	\N
23862	\N	Jean-Claude  Gayssot	\N
23863	\N	PParti Communiste Français	\N
23870	\N	Alain Bashung	\N
23871	\N	conseil des ministre	\N
23872	\N	ministrère (gouvernement)	\N
23873	\N	mobylette	\N
23874	\N	deux-roues	\N
23891	\N	Val-de-Marne; jeunesse	\N
23896	\N	Nikos Papatakis	\N
23898	\N	désobéissance civique	\N
23905	\N	Vladimir poutine	\N
23920	\N	caisse nationale d'assurance maladie	\N
23925	\N	Roissy-Charles de Gaulle	\N
23929	\N	repas	\N
23941	\N	Luis Ignacio Lula Da Silva	\N
23943	\N	Fabrice Gabriel	\N
23944	\N	Tony parker	\N
23948	\N	homo sapiens	\N
23970	\N	k chef de l'Etat	\N
23972	\N	Libération (Journal)	\N
23980	\N	Moshe Katzav	\N
23981	\N	Alassane Outtara	\N
23985	\N	Jacques Rancière	\N
23986	\N	AnnaCcalvi	\N
23993	\N	Jacques Servier	\N
23994	\N	Tina Brown	\N
23995	\N	Aurélie Boullet	\N
23999	\N	Ludwig van Beethoven	\N
24009	\N	Philippe Sollers	\N
24010	\N	Stendhal	\N
24012	\N	Banque centrale des Etats de l'Afrique de l'Ouest	\N
19847	\N	André Trigano	\N
19848	\N	prise de contrôle	\N
19850	\N	Conseil de l 'Europe	\N
19886	\N	Institut national de l'audiovisuel	\N
19887	\N	Thierry Ardisson	\N
19890	\N	Ray Bradbury	\N
19891	\N	Mars	\N
19922	\N	Dominique Méda	\N
19931	\N	scepticisme	\N
19961	\N	Didier Eribon	\N
22605	\N	Parti républicain.	\N
22607	\N	les verta	\N
22608	\N	Vaclav Havel	\N
22609	\N	Eduard Chuvashov	\N
22611	\N	fonds souverain	\N
22613	\N	bureau	\N
22615	\N	eBay	\N
22616	\N	séries télévisées	\N
22617	\N	fonds de réserve	\N
22618	\N	José Luis Rodriguez Zapatero	\N
22620	\N	François Morel	\N
22622	\N	Politique audivisuelle	\N
22623	\N	Patrice Evra	\N
22624	\N	François Asensi	\N
22625	\N	Stéphane	\N
22626	\N	Gatignon	\N
22627	\N	Patrick Jarry	\N
22628	\N	poule	\N
22629	\N	François bayrou	\N
22631	\N	formation artistique	\N
22632	\N	Savion Glover	\N
22633	\N	Theâtre de le Ville	\N
22634	\N	claquette	\N
22637	\N	François Léotard	\N
22644	\N	bataille	\N
22649	\N	Durban	\N
22650	\N	ghetto	\N
22652	\N	Ouzbekistan	\N
22653	\N	Cartlos Ghosn	\N
22655	\N	Uzès	\N
22659	\N	Royaume Uni	\N
22660	\N	Henric Svenberg	\N
22661	\N	Tony Hayward	\N
22662	\N	Frix	\N
22664	\N	CSG	\N
22665	\N	niveaux de vie	\N
22668	\N	Marielle de Sarnez	\N
22669	\N	Modigliani	\N
22673	\N	Bouches du Rhône	\N
22674	\N	agrégation	\N
22675	\N	ravail	\N
22676	\N	Taoufik Zizi	\N
22677	\N	Nouvelle Star	\N
22678	\N	sanitaire	\N
22679	\N	Charle De Gaulle	\N
22680	\N	Radio France internationale (RFI)	\N
22681	\N	Théatre	\N
22682	\N	doctrine politique	\N
22683	\N	Frédéric Michalak	\N
22684	\N	Contenus Numériques	\N
22685	\N	suspension allocation familiale	\N
22686	\N	Jean Hornain	\N
22687	\N	Anni Podimata	\N
22688	\N	"festivalandco"	\N
22689	\N	Alain Lamassoure	\N
22690	\N	Côte d'ivoire	\N
22691	\N	Médiascopie	\N
22692	\N	état	\N
22693	\N	Frédéric Lopez	\N
22694	\N	(collaboration)	\N
22695	\N	union européene	\N
22696	\N	Jean-Paul Delevoy	\N
22697	\N	Claude Debussy	\N
22698	\N	Outox	\N
22699	\N	Catherine Millet	\N
22700	\N	matériau	\N
22701	\N	British pétroleum	\N
22702	\N	Philippe Manoeuvre	\N
22703	\N	PriceMinister	\N
22704	\N	Rakuten	\N
22705	\N	François Taillandier	\N
22706	\N	Jean Lacouture	\N
22707	\N	loyer impayé	\N
22708	\N	Irving Penn	\N
22709	\N	Mary Anne Hobbs	\N
22710	\N	nuisance sonore	\N
22711	\N	Marcel Bigeard	\N
22712	\N	Journal (genre littéraire)	\N
22713	\N	Ludo Pin	\N
22714	\N	Thierry Beccaro	\N
22715	\N	Gérard Chaliand	\N
22716	\N	éopolitique	\N
22717	\N	Stéphane Lhomme	\N
22718	\N	Stéphane Hallegatte	\N
22719	\N	Peter Erlinder	\N
22720	\N	Agence internationale de l'énergie	\N
22721	\N	Gérard Moisselin	\N
22722	\N	Clearstream	\N
22723	\N	Ronnie Lee Gardner	\N
22724	\N	Jean-François Pradeau	\N
22725	\N	Arno Bertina	\N
22726	\N	Jaroslaw Kaczynski	\N
22727	\N	animateur de radio	\N
22728	\N	twitter	\N
22729	\N	Pontarlier (Doubs)	\N
22730	\N	Bronislaw Komorowski	\N
22731	\N	Bloc Party	\N
22732	\N	Kele	\N
22733	\N	télésurveillance	\N
22734	\N	Trappes (Yvelines)	\N
22735	\N	Wim Delvoye	\N
22736	\N	Zinédine Zidane	\N
22737	\N	presse satirique	\N
22738	\N	Steven Pienaar	\N
22739	\N	Marcel Campion	\N
22740	\N	secrétaire national	\N
22741	\N	L'Equipe	\N
22742	\N	coupe de monde	\N
22743	\N	Philippe Muray	\N
22744	\N	Kim Chapiron	\N
22745	\N	Luc Multigner	\N
22746	\N	chloredécone	\N
22747	\N	Dessin	\N
22748	\N	Karl Lagelfeld	\N
22749	\N	finacement	\N
22750	\N	Première Guerre mondiale	\N
22751	\N	metal	\N
22752	\N	Rostam Ghassemi	\N
22753	\N	Fernando Arrabal	\N
22754	\N	Jean Cocteau	\N
22755	\N	Milly-la-Forêt	\N
22756	\N	Corée du nord	\N
22757	\N	Mark Rutte	\N
22758	\N	Trafigura	\N
22759	\N	lithium	\N
22760	\N	Javier Aguirre	\N
22761	\N	Daniel Bouton	\N
22762	\N	Karl Lagarfeld	\N
22763	\N	Karl lagelfeld	\N
22764	\N	var	\N
22765	\N	refus déménagement	\N
22766	\N	Alan Clarke	\N
22767	\N	El Pais	\N
22768	\N	Jeff Koons	\N
22769	\N	Claude Lévêque	\N
22770	\N	réanimation	\N
22771	\N	Georg Wilhelm Pabst	\N
22772	\N	Natalia Smirnoff	\N
22773	\N	Patrice Lumumba	\N
22774	\N	Tourisme	\N
22775	\N	comportements	\N
22776	\N	bisphénol A	\N
22777	\N	sous- traitance	\N
22778	\N	France Musique	\N
22779	\N	Alex Taylor	\N
22780	\N	Lionel Duroy	\N
22781	\N	délégué	\N
22782	\N	François Copé	\N
22783	\N	"Jerk-off"	\N
22784	\N	"gay pride"	\N
22785	\N	Christophe Haleb	\N
19856	\N	agence de presse internationale	\N
19872	\N	Thierry Henry	\N
19895	\N	condamnation à mort	\N
19896	\N	SIDA	\N
19923	\N	viodéosurveillance	\N
19926	\N	ccondamnation avec sursis	\N
19944	\N	NBC Universal	\N
19945	\N	Sixto Rodriguez	\N
19951	\N	Ali Akbar Hachémi Rafsandjani	\N
19959	\N	animal de compagnie	\N
19960	\N	Daniel Mille	\N
22786	\N	Natascha Kampusch	\N
22787	\N	Jack Johnson	\N
22791	\N	Batman	\N
22799	\N	libraire	\N
22812	\N	Belvédère	\N
22814	\N	déplacement (voyage) cité	\N
22839	\N	Anne Consigny	\N
22843	\N	rougeole	\N
22857	\N	Koji Wakamatsu	\N
22876	\N	ministère de l'Equipement	\N
22877	\N	Bâtiment et Travaux publics	\N
22882	\N	personnalité politiques	\N
22901	\N	Frédéric Rébéna	\N
22909	\N	Fédération française de foot (FFF)	\N
22910	\N	Conseil fédéral	\N
22919	\N	origine	\N
22926	\N	gare d'Australie	\N
22928	\N	Lance Armstrong	\N
22938	\N	Angélica Liddell	\N
22943	\N	ministre de la santé	\N
22949	\N	Omar Souleyman	\N
22950	\N	Affaire politico-judiciaire	\N
22953	\N	Union européen	\N
22954	\N	Sylvie Goulard	\N
22979	\N	année soixante	\N
22983	\N	parents	\N
22993	\N	Traités et accords	\N
22998	\N	Syndeac (Syndicat national des entreprises artistiques et culturelles)	\N
23001	\N	marche	\N
23006	\N	revue	\N
23011	\N	Isabelle Prévost-Déprez	\N
23021	\N	Breyten Breytenbach	\N
23036	\N	trafic d'influence conjoint	\N
23039	\N	Cour européenne	\N
23040	\N	garde des Sceaux	\N
23041	\N	mensonge	\N
23052	\N	Jeu	\N
23053	\N	Émile Zola	\N
23057	\N	Anne Teresa De Keersmaeker	\N
23058	\N	acytion humanitaire	\N
23376	\N	Britsh petroleum	\N
23377	\N	Louisianne	\N
23378	\N	enfant; étude	\N
23379	\N	réussite scolaire	\N
23381	\N	Viviane Reding	\N
23383	\N	Antony Cordier	\N
23385	\N	Mohame El-Baradei	\N
23387	\N	New York (état)	\N
23388	\N	ïle de La réunion	\N
23391	\N	réforme Constitution	\N
23392	\N	Nicole Kidman	\N
23394	\N	Georges Bataille	\N
23399	\N	élection municipal	\N
23400	\N	Amboise (Indre-et-Loire)	\N
23403	\N	Jack Lang	\N
23406	\N	representativité	\N
23408	\N	assocoaition	\N
23409	\N	Pandémie	\N
23410	\N	Epidémie	\N
23411	\N	parti communiste français	\N
23413	\N	Raphaël Mezrahi	\N
23414	\N	Kassav	\N
23416	\N	voile ( nautisme)	\N
23417	\N	Christine O'Donnell	\N
23420	\N	raï	\N
23421	\N	organisme génétiquement modifié	\N
23422	\N	Sophie Fontanel	\N
23425	\N	Euro Disney	\N
23426	\N	équipe nationale	\N
23427	\N	Bahrein	\N
23428	\N	juge des enfants	\N
23437	\N	i Dominique Strauss-Kahn	\N
23438	\N	politique du Logement	\N
23439	\N	philopsophie	\N
23440	\N	Fernando Savater	\N
23441	\N	Marina Abramovi	\N
23443	\N	Ruwen Ogien	\N
23445	\N	Esther Duflo	\N
23447	\N	Gérard Rabinovitch	\N
23448	\N	urbaisme	\N
23449	\N	assurance-maladie	\N
23453	\N	Académie des sciences	\N
23455	\N	Tzigane	\N
23456	\N	Raphaël (chanteur)	\N
23458	\N	frais bancaire	\N
23460	\N	Mélanie Laurent	\N
23463	\N	Lejaby	\N
23466	\N	téchnologie	\N
23474	\N	terroisme	\N
23475	\N	Chris Marker	\N
23476	\N	Cité universitaire	\N
23478	\N	enregistrement	\N
23479	\N	colis postal	\N
23483	\N	Jacques Bonnaffé	\N
23484	\N	Handicap International	\N
23486	\N	jean-François Copé	\N
23487	\N	Villeneuve d'Ascq	\N
23489	\N	salon de l'automobile	\N
23490	\N	plan de reprise	\N
23492	\N	Alain Souchon	\N
23494	\N	Iouri Loujkov	\N
23495	\N	classe	\N
23496	\N	Mahamat Saleh Haroun	\N
23497	\N	Natixis	\N
23498	\N	Colette Neuville	\N
23499	\N	New-york	\N
23500	\N	Thiais (Val-de-Marne)	\N
23501	\N	mannequinat	\N
23504	\N	castrisme	\N
23505	\N	Olof Arnalds	\N
23507	\N	Villejuif (Val-de-Marne)	\N
23509	\N	mouvement	\N
23512	\N	ministère de la culture	\N
23513	\N	exonération fiscal	\N
23514	\N	unité	\N
23515	\N	Takehisa Yaegashi	\N
23516	\N	Vallauris (Alpes-Maritimes)	\N
23517	\N	Euro RSCG	\N
23518	\N	Oded Grajew	\N
23519	\N	Marc Sussi	\N
23520	\N	Jean-Pierre Elkabbach	\N
23521	\N	loi de finances	\N
23522	\N	Jean-Louis Nadal	\N
23525	\N	ouragan	\N
23527	\N	gers	\N
23528	\N	Bernard accoyer	\N
23529	\N	Angelin Preljocaj	\N
23531	\N	Philip Roth	\N
23532	\N	Tilda Swinton	\N
23533	\N	transport urbain	\N
23534	\N	Jean Echenoz	\N
23535	\N	trilogie	\N
23536	\N	Paul Ariès	\N
23537	\N	politologue	\N
23538	\N	Jeanne Labrune	\N
23540	\N	Rose Bosch	\N
23541	\N	Anne Deleporte	\N
23542	\N	Deyrolle	\N
23543	\N	Pharmacie	\N
23544	\N	Stupéfiant	\N
23545	\N	reculement	\N
23547	\N	accident de la route	\N
23548	\N	Bertrand Mosca	\N
23549	\N	Arthur Penn	\N
23550	\N	Indie	\N
23552	\N	Guy Carcassonne	\N
23565	\N	boudhisme	\N
19857	\N	Camilla Läckberg	\N
19863	\N	assemblée nationale	\N
19864	\N	OMC	\N
19876	\N	referendum	\N
19877	\N	démocratie directe	\N
19884	\N	Château de Versailles	\N
19915	\N	new yorker	\N
19924	\N	Steven Spielberg	\N
19941	\N	commissariat	\N
19953	\N	loi martiale	\N
19954	\N	Etat d'urgence	\N
19962	\N	infographies	\N
22788	\N	campagne présidentielle	\N
22789	\N	Suicide	\N
22790	\N	Faustin Kayumba Nyamwasa	\N
22792	\N	Bertrand Russell	\N
22793	\N	Aquila	\N
22794	\N	manifestation culturelle	\N
22795	\N	Jean-Paul Salomé	\N
22796	\N	Vaclav Klaus	\N
22797	\N	News Corporation	\N
22798	\N	The Times	\N
22800	\N	Organisation mondiale du commerce (OMC)	\N
22801	\N	Aurélie Trouvé	\N
22802	\N	succession(suite)	\N
22803	\N	Longchamp	\N
22804	\N	Stanley McChrystal	\N
22805	\N	réquisitoire	\N
22806	\N	Andrew Crumey	\N
22807	\N	Dider Porte	\N
22808	\N	France Soir	\N
22809	\N	déplacement (voyage) Seine-Saint-Denis	\N
22810	\N	Grégoire Chamayou	\N
22811	\N	Assemblée Nationale	\N
22813	\N	téléviseur	\N
22815	\N	Hérouville Saint Clair	\N
22816	\N	Alex Maclean	\N
22817	\N	Maurice Thorez	\N
22818	\N	Pascal Boniface	\N
22819	\N	délégué syndicat	\N
22820	\N	Banlieues	\N
22821	\N	Damian Marley	\N
22822	\N	recherche médicale	\N
22823	\N	force internationale	\N
22824	\N	Kylie Minogue	\N
22825	\N	musique électro	\N
22826	\N	digital	\N
22827	\N	collection	\N
22828	\N	Khmer rouge	\N
22829	\N	politique énergétique	\N
22830	\N	David Peace	\N
22831	\N	Frontignan	\N
22832	\N	Réunion des musées nationaux	\N
22833	\N	lutte  action contre)	\N
22834	\N	Pharrell Williams	\N
22835	\N	Louis Vuitton	\N
22836	\N	Tétu	\N
22837	\N	poney	\N
22838	\N	Karma Samdrup	\N
22840	\N	capitalisation	\N
22841	\N	Matthieu Pigasse	\N
22842	\N	austérité	\N
22844	\N	lutte( action contre)	\N
22845	\N	Nicolas Hayek	\N
22846	\N	Marie-Françoise Marais	\N
22847	\N	Patrick Eveno	\N
22848	\N	Shrek	\N
22849	\N	Charles Chaplin	\N
22850	\N	André Glucksmann	\N
22851	\N	Joachim Gauck	\N
22852	\N	genre	\N
22853	\N	Mia Engberg	\N
22854	\N	Argenteuil (Val-d'Oise)	\N
22855	\N	juistice	\N
22856	\N	Foofwa	\N
22858	\N	ministère de l'Economie et des finances	\N
22859	\N	Daniel Canepa	\N
22860	\N	Les Bronzés font du ski	\N
22861	\N	Jean-Denis Perez	\N
22862	\N	Gilles Pélisson	\N
22863	\N	prêt immobilier	\N
22864	\N	Bill Clinton	\N
22865	\N	Paul Girot de Langlade	\N
22866	\N	tribunal correctionne	\N
22867	\N	Créteil (Val-de-Marne)	\N
22868	\N	Affaire politico-financière	\N
22869	\N	affaire politico-judiciaire	\N
22870	\N	marine	\N
22871	\N	dioplomatie	\N
22872	\N	art premier	\N
22873	\N	musée du Quai-Branly	\N
22874	\N	Marcello Dell'Utri	\N
22875	\N	enregistrement politique	\N
22878	\N	Sergio Vega	\N
22879	\N	prise illégale d'intérêts	\N
22880	\N	Mark Jenkins	\N
22881	\N	hamas	\N
22883	\N	Miquel Barceló	\N
22884	\N	spiritueux	\N
22885	\N	viodéo	\N
22886	\N	Sepp Blatter	\N
22887	\N	Peter Brook	\N
22888	\N	Michel Pébereau	\N
22889	\N	Remy Pflimlin	\N
22890	\N	mer Méditérranée	\N
22891	\N	vacance	\N
22892	\N	F.Scott Fitzgerald	\N
22893	\N	Mediapart	\N
22894	\N	Paul Virilio	\N
22895	\N	Téléram	\N
22896	\N	Fabienne Pascaud	\N
22897	\N	Emmanuel Levinas	\N
22898	\N	André Vallini	\N
22899	\N	U2	\N
22900	\N	Marlon Brando	\N
22902	\N	faute fiscale	\N
22903	\N	administration fiscale	\N
22904	\N	Jorge Rafael Videla	\N
22905	\N	Executive life	\N
22906	\N	François Gilles	\N
22907	\N	pétanque	\N
22908	\N	Election législative	\N
22911	\N	demandeur d'asile	\N
22912	\N	chimisme	\N
22913	\N	Golfe du mexique	\N
22914	\N	British pétroléum	\N
22915	\N	pari politique	\N
22916	\N	Valérie Decamp	\N
22917	\N	Time	\N
22918	\N	Sunday Time	\N
22920	\N	vavance	\N
22921	\N	Philippe Ménard	\N
22922	\N	insolite	\N
22923	\N	Christoph Marthaler	\N
22924	\N	Oprah Winfrey	\N
22925	\N	Martine AUbry	\N
22927	\N	Yamaha	\N
22929	\N	coiffeur	\N
22930	\N	Haute couture	\N
22931	\N	Jean-Baptiste Sastre	\N
22932	\N	Shakespeare	\N
22933	\N	Aix en Provence	\N
22934	\N	art lyrique	\N
22935	\N	Robert Lepage	\N
22936	\N	tissu	\N
22937	\N	Rémy Pflimlin	\N
22939	\N	Jean-Charles Naouri	\N
22940	\N	Laurent Poitrenaux	\N
22941	\N	ministère de l'Environnement	\N
22942	\N	réserve	\N
22944	\N	Philippe Quesne	\N
22945	\N	travail forcé	\N
22946	\N	Andrew Garfield	\N
22947	\N	héros	\N
22948	\N	Tesla	\N
22951	\N	David Slade	\N
22952	\N	Robert Pattinson	\N
22955	\N	Marc Lavoine	\N
22956	\N	Scolarité	\N
19859	\N	Vladimir Nabokov	\N
19870	\N	Euskadi	\N
19875	\N	déplacement (voyage)Rennes	\N
19882	\N	Alain Badiou	\N
19898	\N	Guillaume Pepy	\N
19899	\N	Mireille Faugère	\N
19904	\N	Nadir Dendoune	\N
19925	\N	Anouar Brahem	\N
19927	\N	Gstaad	\N
19939	\N	offre	\N
19940	\N	Michel Platini	\N
19965	\N	XIXeme arrondissement	\N
19966	\N	géographie	\N
19967	\N	Jeux Olympiques	\N
19968	\N	jean Leonetti	\N
19969	\N	parodie	\N
19970	\N	Grande-bretagne	\N
19971	\N	missive	\N
19972	\N	Pascal Dumay	\N
19973	\N	conservatoire	\N
19974	\N	directeur	\N
19975	\N	Jacques Testart	\N
19976	\N	Poissy (Yvelines)	\N
19977	\N	Samy Frey	\N
19978	\N	Anthony Delon	\N
19979	\N	Philippe Richert	\N
19980	\N	Jacques Bigot	\N
19981	\N	question sociale	\N
19982	\N	Cristina Kirchner	\N
19983	\N	impôts	\N
19984	\N	les Verts.	\N
19985	\N	Olivier Henrard	\N
19986	\N	Nicoals Vanier	\N
19987	\N	rennes	\N
19988	\N	doigt	\N
19989	\N	Crédoc	\N
19990	\N	Rammstein	\N
19991	\N	Eileen Claussen	\N
19992	\N	Michel Serres	\N
19993	\N	Joakim Noah	\N
19994	\N	Léa Fehner	\N
19995	\N	hétrosexualité	\N
19996	\N	Ddass	\N
19997	\N	Clovis Cornillac	\N
19998	\N	bolivie	\N
19999	\N	Denis Jeambar	\N
20000	\N	Olivier Bétourné	\N
20001	\N	Christiane Allain	\N
20002	\N	secrétariat générale	\N
20003	\N	Stéphane Braunschweig	\N
20004	\N	Henrik Ibsen	\N
20005	\N	Camille de Rocca Serra	\N
20006	\N	Hervé de Charette	\N
20007	\N	ministère des affaires étrangère	\N
20008	\N	Gilles Carrez	\N
20009	\N	phénomène de société	\N
20010	\N	Benjamin Stora	\N
20011	\N	travail parlementaire	\N
20012	\N	Rebiya Kadeer	\N
20013	\N	crise sociale	\N
20014	\N	politique de l'Emploi	\N
20015	\N	Sempé	\N
20016	\N	Jean-Jacques Sempé	\N
20017	\N	Virginie Efira	\N
20018	\N	robot	\N
20019	\N	Warner	\N
20020	\N	Universal	\N
20021	\N	détention (prison)	\N
20022	\N	Érythrée	\N
20023	\N	Éthiopie	\N
20024	\N	internat  (scolaire)	\N
20025	\N	Darling Alistair	\N
20026	\N	André Bettencourt	\N
20027	\N	Roger McGowen	\N
20028	\N	recteur	\N
20029	\N	hacker	\N
20030	\N	Bruno Julliard	\N
20031	\N	Rony Brauman	\N
20032	\N	Médecin sans frontières	\N
20033	\N	Heuliez	\N
20034	\N	BKC	\N
20035	\N	Wojciech Jaruzelski	\N
22957	\N	Gérard Holtz	\N
22958	\N	prud'homme	\N
22966	\N	Yves Got	\N
22967	\N	René Pétillon	\N
22976	\N	Olivia Pierrigues	\N
22981	\N	Jean Nouvel	\N
22986	\N	Georges Kiejman	\N
23008	\N	Lafarge	\N
23009	\N	Chongqing	\N
23013	\N	Tricastin	\N
23014	\N	appellation	\N
23023	\N	Accessoire	\N
23029	\N	Jean Lambert-Wild	\N
23033	\N	tableau	\N
23035	\N	Jean-Marc Gourdon	\N
23553	\N	Nicolas Sarkozy Sarkozy	\N
23557	\N	Bernardo Carvalho	\N
23576	\N	Philippe Katerine	\N
23581	\N	Yvonne Baby	\N
23582	\N	Helena Rubinstein	\N
23583	\N	offre de rachat	\N
23584	\N	George Lucas	\N
23585	\N	tolérance	\N
23777	\N	front National	\N
23778	\N	Alexandre de Juniac	\N
23779	\N	Budget de l'Etat	\N
23782	\N	Droit au logement opposable (Dalo)	\N
23783	\N	Unédic	\N
23784	\N	chambre de l'instruction	\N
23785	\N	Mouammar	\N
23786	\N	Kadhafi	\N
23787	\N	Guillermo Fariñas	\N
23788	\N	bidoville	\N
23789	\N	Albin Chalandon	\N
23790	\N	Banque	\N
23791	\N	Mark Zuckerberg	\N
23792	\N	authentification	\N
23793	\N	Audiovisuel extérieur de la France (AEF)	\N
23796	\N	Blake Edwards	\N
23797	\N	Olivier Poivre d'Arvor	\N
23798	\N	Xavier Beulin	\N
23799	\N	égalité	\N
23800	\N	HBO	\N
23801	\N	championnat de monde	\N
23802	\N	chambre d 'instruction	\N
23803	\N	pôle Nord	\N
23804	\N	pôle Sud	\N
23805	\N	crise économique crise financière monde réunion Forum économique de Davos Forum social mondial motion de censure parti socialiste	\N
23808	\N	OL	\N
23809	\N	Alain Passard	\N
23810	\N	Jean Rollin	\N
23811	\N	Fête de fin d'année	\N
23812	\N	prix Delluc	\N
23813	\N	Marcel Duchamps	\N
23814	\N	ex-Urss	\N
23815	\N	François Bon	\N
23816	\N	Marie Marchand-Arvier	\N
23817	\N	Fernand Duchaussoy	\N
23818	\N	Jacqueline de Romilly	\N
23819	\N	Isabelle Prévost-Desprez	\N
23820	\N	Alexandre Loukachenko	\N
23822	\N	Bloc identitaire	\N
23823	\N	Riposte laïque	\N
23824	\N	Universitaire	\N
23825	\N	réchauffement	\N
23826	\N	Sylvie Arditi	\N
23827	\N	ête de fin d'année	\N
23828	\N	ministère de l'Economie	\N
23829	\N	Championnat du monde	\N
23830	\N	Gérald Nanty	\N
23831	\N	Charles Blé Goudé	\N
23833	\N	Ingenico	\N
23834	\N	Dorothée	\N
23835	\N	Journal du Dimanche	\N
23836	\N	Rock	\N
23838	\N	Leucémie	\N
23839	\N	moelle osseuse	\N
24048	\N	conseillet	\N
24049	\N	politique internetionale	\N
24055	\N	intervention chirurgicale	\N
24050	\N	Champoinnat du Monde	\N
24051	\N	James Cook	\N
24054	\N	Charles Beigbeder	\N
24052	\N	David Chaytor	\N
24059	\N	Veolia environnement	\N
24053	\N	Edouard Baer	\N
24057	\N	rectification	\N
24056	\N	Elysée	\N
24058	\N	Nicolat Sarkozy	\N
24060	\N	amélioration	\N
24061	\N	Marta Dominguez	\N
24062	\N	start-up	\N
24063	\N	résultat sportif	\N
24064	\N	personnalité\npolitique	\N
24065	\N	Lara Gut	\N
24066	\N	Cyprien Richard	\N
24067	\N	politique de l'audiovisuel	\N
24068	\N	Anfr	\N
24069	\N	Pierre Arditi	\N
24070	\N	Françoise de Panafieu	\N
24071	\N	Seth Rogen	\N
24072	\N	Agence française de sécurité sanitaire des produits de santé (Afssaps)	\N
24073	\N	Bernard Guetta	\N
24074	\N	TER	\N
24075	\N	RhÔne-Alpes	\N
24076	\N	plan d'urgence	\N
24077	\N	Serge Valletti	\N
24078	\N	Denis Hennequin	\N
24079	\N	français à l'étrange	\N
24080	\N	Al-Qaed	\N
24081	\N	Al-Qaeda au Maghreb islamique (Aqmi)	\N
24082	\N	Guido Mantega	\N
24083	\N	littérture	\N
24084	\N	Nicolas Beau	\N
24085	\N	Bakchich	\N
24086	\N	Gérard Mordillat	\N
24087	\N	Jeanne Candel	\N
24088	\N	Mohammad Yunus	\N
24089	\N	Conseil supérieur de la magistrature (CSM)	\N
24090	\N	Jacques Derrida	\N
24091	\N	Jürgen Habermas	\N
24092	\N	John Searle	\N
24093	\N	Jodie Foster	\N
24094	\N	Le Courrier Picard	\N
24095	\N	Revenu de solidarité active	\N
24096	\N	Sergueï Mavrodi	\N
24097	\N	Philippe Thureau-Dangin	\N
24098	\N	Jean-Christophe Meurisse	\N
24099	\N	Jean-Bedel Bokassa	\N
24100	\N	Bill Clegg	\N
24101	\N	Jean-Louis Martinelli	\N
24102	\N	Botho Strauss	\N
24103	\N	Ronit Elkabetz	\N
24104	\N	instiution culturelle	\N
24105	\N	Raoul Peck	\N
24106	\N	Océan pacifique	\N
24107	\N	Politique et Economie du sport	\N
24108	\N	droit de travail	\N
24109	\N	David de Rothschild	\N
24110	\N	accident aérien décès	\N
24111	\N	Gérard Filoche	\N
24112	\N	António Lobo Antunes	\N
24113	\N	1979	\N
24114	\N	Donald Tusk	\N
24115	\N	INED? étude	\N
24116	\N	convocation	\N
24117	\N	Apec (cadres)	\N
24118	\N	Claude Goasguen	\N
24119	\N	Messageries Lyonnaises de Presse (MLP)	\N
24120	\N	Christophe Barbier	\N
24121	\N	Enrico Macias	\N
24122	\N	Claude Evin	\N
24123	\N	Philippe Douste-Blazy	\N
24124	\N	Dominique Gillot	\N
24125	\N	Jean-François Mattei	\N
24126	\N	Norra Berria	\N
\.


--
-- Name: sulci_descriptor_pkey; Type: CONSTRAINT; Schema: public; Owner: ybon; Tablespace: 
--

ALTER TABLE ONLY sulci_descriptor
    ADD CONSTRAINT sulci_descriptor_pkey PRIMARY KEY (id);


--
-- Name: sulci_descriptor_name; Type: INDEX; Schema: public; Owner: ybon; Tablespace: 
--

CREATE INDEX sulci_descriptor_name ON sulci_descriptor USING btree (name);


--
-- Name: sulci_descriptor_name_like; Type: INDEX; Schema: public; Owner: ybon; Tablespace: 
--

CREATE INDEX sulci_descriptor_name_like ON sulci_descriptor USING btree (name varchar_pattern_ops);


--
-- Name: sulci_descriptor_parent_id; Type: INDEX; Schema: public; Owner: ybon; Tablespace: 
--

CREATE INDEX sulci_descriptor_parent_id ON sulci_descriptor USING btree (parent_id);


--
-- Name: parent_id_refs_id_e7e1cebd; Type: FK CONSTRAINT; Schema: public; Owner: ybon
--

ALTER TABLE ONLY sulci_descriptor
    ADD CONSTRAINT parent_id_refs_id_e7e1cebd FOREIGN KEY (parent_id) REFERENCES sulci_descriptor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

